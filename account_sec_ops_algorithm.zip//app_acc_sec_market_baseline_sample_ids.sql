##Description##
baseline抽样账号，数据为t-1日

##TaskInfo##
creator = 'wucheng17@meituan.com'

source = {
    'db': META['ba_rc'], ## 源库对应的dsn，用于表示Extract阶段的数据源
}

stream = {
    'format': '', ## 单引号中按序填写目标表的列名, 以逗号分割, 与Extract节点的结果顺序对应, hive2hive流程请留空
}

target = {
    'db': META['ba_rc'],  ## 目标库对应的dsn名
    'table': 'app_acc_sec_market_baseline_sample_ids',  ## 目标表的table名
}

##Extract##
## 这里填写一个能读取source库下数据sql, 读出的数据会load到target库，hive2hive流程请留空

##Preload##
## 这里可以写load数据之前执行的SQL，例如清理数据、删除特定分区等，不需要请留空

##Load##
## 这里填写一个能load数据的SQL，非hive2hive流程请留空
## 注意：注释参数请使用##，--注释仅对SQL语句生效
SET hive.exec.dynamic.partition.mode=nonstrict;
SET hive.exec.dynamic.partition=true;
SET hive.exec.max.dynamic.partitions=1000;
SET hive.default.fileformat=orc;
## 触发spark合并小文件的阈值(20M)
SET spark.sql.mergeSmallFileSize=20971520;
SET spark.hadoopRDD.targetBytesInPartition=67108864;
SET spark.sql.adaptive.shuffle.targetPostShuffleInputSize=134217728;
## spark shuffle默认分区数
SET spark.sql.shuffle.partitions=500;

INSERT OVERWRITE TABLE `${target.table}` PARTITION (dt)
SELECT
  a.mt_user_id,
  1.0,
  date_format(date_sub(from_unixtime(unix_timestamp('${now.datekey}','yyyyMMdd'),'yyyy-MM-dd'),2),'yyyyMMdd') AS dt
FROM mart_mtsi.topic_user_active_ss_d a
LEFT ANTI JOIN ba_rc.app_account_analysis_case_user_id c
  ON a.mt_user_id = c.user_id
WHERE a.dt = date_format(date_sub(from_unixtime(unix_timestamp('${now.datekey}','yyyyMMdd'),'yyyy-MM-dd'),2),'yyyyMMdd')
  AND pmod(crc32(cast(a.mt_user_id as string)), 2000) = 0;

##TargetDDL##
CREATE TABLE IF NOT EXISTS `${target.table}`
(
    user_id BIGINT COMMENT '账号ID',
    market_weight DOUBLE COMMENT '市场权重(均匀抽样恒1.0)'
)
COMMENT '大盘 baseline 抽样 ID 表(1/2000 hash 抽样, 排除 case 账号)'
PARTITIONED BY (dt string COMMENT '日期分区,yyyymmdd')
STORED AS ORC
;;