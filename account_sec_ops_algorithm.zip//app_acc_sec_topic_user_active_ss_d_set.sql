##Description##
账号安全用户画像快照精简表(日级)：从 topic_user_active_ss_d 单日快照抽取标识/标签/集合/画像字段，Map类字段取key转Set。与周表 app_acc_sec_topic_user_active_ss_w_set 同 schema，服务近端15天回扫与step1描述。

##TaskInfo##
creator = 'wucheng17@meituan.com'

source = {
    'db': META['ba_rc'],
}

stream = {
    'format': '',
}

target = {
    'db': META['ba_rc'],
    'table': 'app_acc_sec_topic_user_active_ss_d_set',
}

##Extract##

##Preload##

##Load##
SET hive.exec.dynamic.partition.mode=nonstrict;
SET hive.exec.dynamic.partition=true;
SET hive.exec.max.dynamic.partitions=1000;
SET hive.default.fileformat=orc;
SET spark.sql.mergeSmallFileSize=20971520;
SET spark.hadoopRDD.targetBytesInPartition=67108864;
SET spark.sql.adaptive.shuffle.targetPostShuffleInputSize=134217728;
SET spark.sql.shuffle.partitions=500;

INSERT OVERWRITE TABLE `${target.table}` PARTITION (dt)
SELECT
  a.mt_user_id,
  a.is_on_job_employee,
  a.is_company_high_value_user,
  a.is_high_impact_user,
  a.reg_time,
  a.reg_date,
  a.reg_location_city,
  a.reg_ip,
  a.is_virtual_user,
  a.ip_set_14d,
  a.is_active_14d,
  a.is_hit_black_ip,
  a.mt_man_machine_risk_score,
  a.dp_man_machine_risk_score,
  a.is_mt_fe_unload,
  a.is_dp_fe_unload,
  a.is_mt_giveup_verify,
  a.is_dp_giveup_verify,
  a.is_mt_verify_fail,
  a.is_dp_verify_fail,
  a.is_mt_abnormal_pass,
  a.is_dp_abnormal_pass,
  map_keys(a.reg_login_mobile_user_cntd_30d_map_30d) AS reg_login_mobile_user_cntd_30d_set,
  map_keys(a.reg_login_openid_user_cntd_30d_map_30d) AS reg_login_openid_user_cntd_30d_set,
  map_keys(a.reg_login_dfpid_uuid_cntd_30d_map_30d) AS reg_login_dfpid_uuid_cntd_30d_set,
  a.mt_member_level,
  a.high_value_user_source_set,
  a.account_risk_label_set,
  a.account_stability_label_set,
  a.account_activity_label_set,
  a.account_value_label_set,
  a.account_behavior_label_set,
  a.is_hit_mobile_risk_black_tag,
  a.is_hit_mobile_risk_gray_tag,
  a.is_hit_rival_tag,
  a.is_hit_offline_repeat_behavior_seq_tag,
  a.most_common_dev_model,
  map_keys(a.common_dev_model_days_cnt_map) AS common_dev_model_days_set,
  a.most_common_city,
  a.most_common_wifi_name,
  map_keys(a.common_wifi_name_days_cnt_map) AS common_wifi_name_days_set,
  a.most_common_wifi_mac,
  map_keys(a.common_wifi_mac_days_cnt_map) AS common_wifi_mac_days_set,
  map_keys(a.common_addr_ord_cnt_map) AS common_addr_ord_set,
  a.work_addr,
  a.home_addr,
  a.company_wifi,
  a.home_wifi,
  a.act_risk_profile_set,
  a.canzong_risk_profile_set,
  a.graph_risk_profile_set,
  a.account_risk_profile_set,
  map_keys(a.rc_event_account_cnt_90d_intercept_map) AS rc_event_account_cnt_90d_intercept_set,
  map_keys(a.rc_event_trade_cnt_90d_intercept_map) AS rc_event_trade_cnt_90d_intercept_set,
  a.is_mtsi_clue_user,
  a.is_mtsi_case_user,
  a.mtsi_clue_id_set,
  a.mtsi_clue_name_set,
  a.mtsi_case_id_set,
  a.mtsi_clue_partner_set,
  a.dev_risk_second_rules_set_14d,
  a.dev_risk_third_rules_set_14d,
  a.mt_wm_req_markstrategy_set_14d,
  a.mt_yy_req_markstrategy_set_14d,
  a.mt_sg_req_markstrategy_set_14d,
  a.mt_dc_req_markstrategy_set_14d,
  a.mt_dz_req_markstrategy_set_14d,
  a.mt_wm_req_dropstrategy_set_14d,
  a.mt_yy_req_dropstrategy_set_14d,
  a.mt_sg_req_dropstrategy_set_14d,
  a.mt_dc_req_dropstrategy_set_14d,
  a.mt_dz_req_dropstrategy_set_14d,
  a.dp_dc_req_markstrategy_set_14d,
  a.dp_dz_req_markstrategy_set_14d,
  a.dp_dc_req_dropstrategy_set_14d,
  a.dp_dz_req_dropstrategy_set_14d,
  date_format(date_sub(from_unixtime(unix_timestamp('${now.datekey}','yyyyMMdd'),'yyyy-MM-dd'),2),'yyyyMMdd') AS dt
FROM mart_mtsi.topic_user_active_ss_d a
WHERE a.dt = date_format(date_sub(from_unixtime(unix_timestamp('${now.datekey}','yyyyMMdd'),'yyyy-MM-dd'),2),'yyyyMMdd');

##TargetDDL##
CREATE TABLE IF NOT EXISTS `${target.table}`
(
    mt_user_id BIGINT COMMENT '账号ID',
    is_on_job_employee STRING COMMENT '是否在职员工',
    is_company_high_value_user STRING COMMENT '是否企业高价值用户',
    is_high_impact_user STRING COMMENT '是否高影响用户',
    reg_time STRING COMMENT '注册时间',
    reg_date STRING COMMENT '注册日期',
    reg_location_city STRING COMMENT '注册城市',
    reg_ip STRING COMMENT '注册IP',
    is_virtual_user STRING COMMENT '是否虚拟用户',
    ip_set_14d ARRAY<STRING> COMMENT '14天IP集合',
    is_active_14d STRING COMMENT '14天是否活跃',
    is_hit_black_ip STRING COMMENT '是否命中黑IP',
    mt_man_machine_risk_score DOUBLE COMMENT '美团人机风险分',
    dp_man_machine_risk_score DOUBLE COMMENT '点评人机风险分',
    is_mt_fe_unload STRING COMMENT '美团前端是否卸载',
    is_dp_fe_unload STRING COMMENT '点评前端是否卸载',
    is_mt_giveup_verify STRING COMMENT '美团是否放弃验证',
    is_dp_giveup_verify STRING COMMENT '点评是否放弃验证',
    is_mt_verify_fail STRING COMMENT '美团验证是否失败',
    is_dp_verify_fail STRING COMMENT '点评验证是否失败',
    is_mt_abnormal_pass STRING COMMENT '美团是否异常通过',
    is_dp_abnormal_pass STRING COMMENT '点评是否异常通过',
    reg_login_mobile_user_cntd_30d_set ARRAY<STRING> COMMENT '30天注册登录手机号用户关联Set(map取key)',
    reg_login_openid_user_cntd_30d_set ARRAY<STRING> COMMENT '30天注册登录OpenID用户关联Set(map取key)',
    reg_login_dfpid_uuid_cntd_30d_set ARRAY<STRING> COMMENT '30天注册登录DFPID UUID关联Set(map取key)',
    mt_member_level STRING COMMENT '美团会员等级',
    high_value_user_source_set ARRAY<STRING> COMMENT '高价值用户来源集合',
    account_risk_label_set ARRAY<STRING> COMMENT '账号风险标签集合',
    account_stability_label_set ARRAY<STRING> COMMENT '账号稳定性标签集合',
    account_activity_label_set ARRAY<STRING> COMMENT '账号活跃度标签集合',
    account_value_label_set ARRAY<STRING> COMMENT '账号价值标签集合',
    account_behavior_label_set ARRAY<STRING> COMMENT '账号行为标签集合',
    is_hit_mobile_risk_black_tag STRING COMMENT '是否命中手机号风险黑标签',
    is_hit_mobile_risk_gray_tag STRING COMMENT '是否命中手机号风险灰标签',
    is_hit_rival_tag STRING COMMENT '是否命中竞对标签',
    is_hit_offline_repeat_behavior_seq_tag STRING COMMENT '是否命中线下重复行为序列标签',
    most_common_dev_model STRING COMMENT '最常使用设备型号',
    common_dev_model_days_set ARRAY<STRING> COMMENT '常用设备型号天数Set(map取key)',
    most_common_city STRING COMMENT '最常出现城市',
    most_common_wifi_name STRING COMMENT '最常连接WiFi名称',
    common_wifi_name_days_set ARRAY<STRING> COMMENT '常用WiFi名称天数Set(map取key)',
    most_common_wifi_mac STRING COMMENT '最常连接WiFi MAC',
    common_wifi_mac_days_set ARRAY<STRING> COMMENT '常用WiFi MAC天数Set(map取key)',
    common_addr_ord_set ARRAY<STRING> COMMENT '常用地址订单Set(map取key)',
    work_addr STRING COMMENT '工作地址',
    home_addr STRING COMMENT '家庭地址',
    company_wifi STRING COMMENT '公司WiFi',
    home_wifi STRING COMMENT '家庭WiFi',
    act_risk_profile_set ARRAY<STRING> COMMENT '活动风险画像集合',
    canzong_risk_profile_set ARRAY<STRING> COMMENT '参众风险画像集合',
    graph_risk_profile_set ARRAY<STRING> COMMENT '图谱风险画像集合',
    account_risk_profile_set ARRAY<STRING> COMMENT '账号风险画像集合',
    rc_event_account_cnt_90d_intercept_set ARRAY<STRING> COMMENT '90天风控事件账号拦截Set(map取key)',
    rc_event_trade_cnt_90d_intercept_set ARRAY<STRING> COMMENT '90天风控事件交易拦截Set(map取key)',
    is_mtsi_clue_user STRING COMMENT '是否MTSI线索用户',
    is_mtsi_case_user STRING COMMENT '是否MTSI案件用户',
    mtsi_clue_id_set ARRAY<BIGINT> COMMENT 'MTSI线索ID集合',
    mtsi_clue_name_set ARRAY<STRING> COMMENT 'MTSI线索名称集合',
    mtsi_case_id_set ARRAY<BIGINT> COMMENT 'MTSI案件ID集合',
    mtsi_clue_partner_set ARRAY<STRING> COMMENT 'MTSI线索合作方集合',
    dev_risk_second_rules_set_14d ARRAY<STRING> COMMENT '14天设备风险二级规则集合',
    dev_risk_third_rules_set_14d ARRAY<STRING> COMMENT '14天设备风险三级规则集合',
    mt_wm_req_markstrategy_set_14d ARRAY<STRING> COMMENT '14天美团外卖命中策略集合',
    mt_yy_req_markstrategy_set_14d ARRAY<STRING> COMMENT '14天美团优选命中策略集合',
    mt_sg_req_markstrategy_set_14d ARRAY<STRING> COMMENT '14天美团闪购命中策略集合',
    mt_dc_req_markstrategy_set_14d ARRAY<STRING> COMMENT '14天美团到店命中策略集合',
    mt_dz_req_markstrategy_set_14d ARRAY<STRING> COMMENT '14天美团大众命中策略集合',
    mt_wm_req_dropstrategy_set_14d ARRAY<STRING> COMMENT '14天美团外卖降策略集合',
    mt_yy_req_dropstrategy_set_14d ARRAY<STRING> COMMENT '14天美团优选降策略集合',
    mt_sg_req_dropstrategy_set_14d ARRAY<STRING> COMMENT '14天美团闪购降策略集合',
    mt_dc_req_dropstrategy_set_14d ARRAY<STRING> COMMENT '14天美团到店降策略集合',
    mt_dz_req_dropstrategy_set_14d ARRAY<STRING> COMMENT '14天美团大众降策略集合',
    dp_dc_req_markstrategy_set_14d ARRAY<STRING> COMMENT '14天点评到店命中策略集合',
    dp_dz_req_markstrategy_set_14d ARRAY<STRING> COMMENT '14天点评大众命中策略集合',
    dp_dc_req_dropstrategy_set_14d ARRAY<STRING> COMMENT '14天点评到店降策略集合',
    dp_dz_req_dropstrategy_set_14d ARRAY<STRING> COMMENT '14天点评大众降策略集合'
)
COMMENT '账号安全用户画像快照精简表-日级(map转set,76列,近端热表服务step1描述+15天回扫)'
PARTITIONED BY (dt string COMMENT '日期分区,yyyymmdd(每日生成单日快照)')
STORED AS ORC
;
