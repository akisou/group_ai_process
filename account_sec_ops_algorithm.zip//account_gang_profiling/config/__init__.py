# -*- coding: utf-8 -*-
"""配置子包：使 config.yaml 作为包内资源可被 importlib.resources 读取（zip 内亦可）。"""
