# -*- coding: utf-8 -*-
"""
规则验证体系：防过拟合验证 + 大盘反证 + 误伤检测 + 正向风险浓度

四项检查相互独立、各自产出布尔判定 + 具体指标，最终由 validate_rule() 汇总成
单条规则的整体验证结果（是否通过），供 rule_selection 阶段只从"通过验证"的规则里选最终规则集。

背景说明：
- 训练集(dataset_split=train)上挖出的规则，precision/recall 必然存在"训练集自适应"的乐观偏差，
  必须在验证集(dataset_split=validation，含 CORE_SEED 验证切分 + 全部 WEAK_SEED)上复算 recall，
  比较两者比值判断是否过拟合（训练集覆盖率明显高于验证集覆盖率，说明规则记住了训练集的
  特异性噪声而非团伙的普遍性特征）。
- 大盘反证：规则不能只在种子账号里表现好，还必须验证它在全量背景账号上不会“误伤”过多正常账号——
  即使 baseline_support 初筛阶段已经卡过，组合后的联合条件仍需重新在全量/近似全量大盘上复核，
  因为初筛是针对单个 Predicate 的，组合后的联合支持度可能与各分量的乘积预期不同（字段间可能存在
  业务相关性，如同一账号大概率会同时命中多个弱相关标签，使组合支持度高于独立性假设下的预期）。
- 误伤检测：命中规则的账号里，若有相当比例是白名单/高质量账号，说明规则命中了业务正常行为模式
  （如企业内部测试账号频繁换设备），需要一票否决或人工复核，不能只看 precision 数字。
"""

from dataclasses import dataclass
from typing import Dict, List, Optional

from pyspark.sql import DataFrame, functions as F

from account_gang_profiling.rule_mining.combo_search import RuleCombo


@dataclass
class ValidationResult:
    combo: RuleCombo
    passed: bool
    reasons: List[str]                # 未通过时的具体原因列表（可能有多条同时未通过）
    train_recall: float
    validation_recall: float
    generalization_ratio: float       # validation_recall / train_recall
    recall_full_seed: float           # 在全部种子账号(CORE_SEED+WEAK_SEED，不分train/val)上的覆盖率，供展示参考
    baseline_recall_count: int        # 大盘反证：全量/近似全量大盘上的命中账号数
    baseline_recall_multiplier: float # 命中账号数 / clue_hit_count 的倍数
    whitelist_hit_rate: float
    hq_account_hit_rate: float
    risk_concentration: float         # 规则命中的全部账号（种子∪大盘）中，种子账号的占比


def _hit_count(df: DataFrame, combo: RuleCombo) -> int:
    return df.filter(combo.to_column()).count()


def check_generalization(combo: RuleCombo,
                          train_seed_df: DataFrame, validation_seed_df: DataFrame,
                          train_total: int, validation_total: int,
                          min_generalization_ratio: float,
                          empty_validation_policy: str = "fail") -> Dict:
    """
    防过拟合检查：比较训练集 vs 验证集上的召回率（覆盖率）。
    generalization_ratio 过低（验证集覆盖率远低于训练集）说明规则对训练集过拟合。

    empty_validation_policy：验证集为空时的策略（config rule_validation.empty_validation_policy）：
    - "fail"（默认）：generalization_ratio 记 0，判定不通过（严格，向后兼容）；
    - "pass"：标记 skipped=True，视为"没有可对照的验证集、不可评估"而跳过该检查
      （手工小样本调试场景：验证集为空不代表规则过拟合）。
    """
    train_hit = _hit_count(train_seed_df, combo) if train_total > 0 else 0
    val_hit = _hit_count(validation_seed_df, combo) if validation_total > 0 else 0

    train_recall = train_hit / train_total if train_total > 0 else 0.0
    val_recall = val_hit / validation_total if validation_total > 0 else 0.0
    # train_recall 为 0 时（理论上不应出现，训练集是挖掘规则的数据源，命中数至少是挖掘时的 clue_hit_count），
    # 用 epsilon 兜底避免除0，此时视为"无法评估泛化性"，比例记为0（判定不通过，交由上层报告具体原因）
    ratio = val_recall / train_recall if train_recall > 0 else 0.0

    if validation_total == 0 and empty_validation_policy == "pass":
        return {"passed": True, "skipped": True, "train_recall": train_recall,
                "validation_recall": 0.0, "generalization_ratio": 0.0,
                "train_hit": train_hit, "val_hit": val_hit}

    passed = ratio >= min_generalization_ratio
    return {
        "passed": passed, "skipped": False, "train_recall": train_recall,
        "validation_recall": val_recall, "generalization_ratio": ratio,
        "train_hit": train_hit, "val_hit": val_hit,
    }


def check_baseline_recall(combo: RuleCombo, baseline_df: DataFrame, clue_hit_count: int,
                           max_recall_accounts: int, max_recall_multiplier: float,
                           baseline_scale_factor: float = 1.0) -> Dict:
    """
    大盘反证检查：规则在背景大盘上回捞的账号数不能过多（绝对值和相对倍数双重卡控）。
    baseline_scale_factor：若 baseline_df 是抽样数据，回捞账号数需按抽样倍数换算回真实规模
    才能与 max_recall_accounts（这是针对真实大盘规模设定的绝对阈值）比较。
    """
    raw_hit = _hit_count(baseline_df, combo)
    scaled_hit = int(raw_hit * baseline_scale_factor)
    multiplier = scaled_hit / clue_hit_count if clue_hit_count > 0 else float("inf")

    passed = scaled_hit <= max_recall_accounts and multiplier <= max_recall_multiplier
    return {"passed": passed, "baseline_recall_count": scaled_hit,
            "baseline_recall_multiplier": multiplier, "raw_hit": raw_hit}


def check_false_positive(combo: RuleCombo, baseline_df: DataFrame,
                          whitelist_df: DataFrame,
                          max_whitelist_hit_rate: float, max_hq_account_hit_rate: float,
                          *, hq_account_col: str = "act_mt_member_level") -> Dict:
    """
    误伤检测：
    - whitelist_hit_rate: 命中规则的大盘账号中，白名单账号占比（需 <= 阈值）。
      注意 whitelist_df 必须与 baseline_df 同 universe（否则大盘命中账号 join 到 NULL
      被判为非白名单，命中率结构性偏低）——validate_rules 入口有覆盖范围 WARN。
    - hq_account_hit_rate: 命中规则的大盘账号中，"高质量账号"占比（需 <= 阈值），
      当前用会员等级(mt_member_level)是否非空/非0作为高质量账号的简化判定，
      更严谨的判定可结合 consume_amt_sum_1d 等消费字段，此处保持与现有大宽表字段的
      最小依赖，避免引入额外的复杂判定逻辑
    （risk_concentration 已移出本函数：旧实现在本函数的 hit_df（baseline_df 派生，
      全是 EXCLUDED 账号）上统计种子占比，命中数恒 0 导致检查结构性必 FAIL；
      新口径由 validate_rule 用已算出的 train/val/baseline 命中计数拼装，见该函数注释）
    """
    hit_df = baseline_df.filter(combo.to_column())
    hit_count = hit_df.count()
    if hit_count == 0:
        # 规则在大盘上零命中，误伤风险为0，两项检查天然通过
        return {"passed": True, "whitelist_hit_rate": 0.0, "hq_account_hit_rate": 0.0}

    hit_with_whitelist = hit_df.join(whitelist_df, on="account_id", how="left")
    whitelist_hit_count = hit_with_whitelist.filter(F.col("is_whitelisted") == 1).count()
    whitelist_hit_rate = whitelist_hit_count / hit_count

    if hq_account_col in hit_df.columns:
        hq_hit_count = hit_df.filter(
            F.col(hq_account_col).isNotNull() & (F.col(hq_account_col).cast("string") != "UNKNOWN")
            & (F.col(hq_account_col).cast("string") != "0")
        ).count()
    else:
        hq_hit_count = 0
    hq_account_hit_rate = hq_hit_count / hit_count

    passed = (whitelist_hit_rate <= max_whitelist_hit_rate
              and hq_account_hit_rate <= max_hq_account_hit_rate)

    return {"passed": passed, "whitelist_hit_rate": whitelist_hit_rate,
            "hq_account_hit_rate": hq_account_hit_rate}


def validate_rule(combo: RuleCombo,
                   train_seed_df: DataFrame, validation_seed_df: DataFrame,
                   baseline_df: DataFrame, whitelist_df: DataFrame,
                   config: Optional[Dict] = None,
                   baseline_scale_factor: float = 1.0,
                   temporal_verdict: Optional[Dict] = None) -> ValidationResult:
    """
    对单条候选规则执行完整的四项验证（防过拟合 + 大盘反证 + 误伤检测 + 正向风险浓度），
    返回汇总结果。

    Args:
        combo: rule_mining 产出的候选规则
        train_seed_df: dataset_split=train 的 CORE_SEED 账号（大宽表，需含 seed_type/dataset_split 列）
        validation_seed_df: dataset_split=validation 的种子账号（CORE_SEED验证切分 + 全部WEAK_SEED）
        baseline_df: 背景/对照组大宽表（EXCLUDED 派生或 step1b 大盘快照；
            只需含 account_id 用于 join whitelist_df，不要求 seed_type 列——
            risk_concentration 已改用 train/val/baseline 命中计数拼装，不读该列）
        whitelist_df: snapshot_builder.extract_whitelist_flags 产出的 account_id -> is_whitelisted 表
            （必须与 baseline_df 同 universe，否则白名单命中率结构性失真）
        config: config.yaml 中的 rule_validation 配置字典
        baseline_scale_factor: 大盘抽样倍数（全量/抽样），未抽样时为1.0
        temporal_verdict: 可选，gang_validation 4 级判定对该 combo 的 verdict（dict:
            decision/precision_new/n_hit/reasons）。传入时用 4 级判定取代 risk_concentration
            + 误伤检测（injury_gate 的命中率+Lift 取代风险浓度+误伤，不再 ×scale 稀释），
            保留泛化作硬闸；None=旧 4 闸行为（gang_validation 未启用）。

    Raises:
        ValueError: train_seed_df 为空（正常主链路在 rule_mining 阶段已拦截，
            抛此错通常为 ctx 接线错误，显式失败优于静默整批 FAIL）
    """
    config = config or {}
    min_generalization_ratio = config.get("min_generalization_ratio")
    if min_generalization_ratio is None:
        # 兜底默认值（正常路径下 pipeline.step5 会把 dataset_split 段的同名键合并进来，
        # 此处仅为直接调用 validate_rule 的场景兜底）
        min_generalization_ratio = 0.7
    max_recall_accounts = config.get("max_recall_accounts", 50000)
    max_recall_multiplier = config.get("max_recall_multiplier", 100.0)
    max_whitelist_hit_rate = config.get("max_whitelist_hit_rate", 0.05)
    max_hq_account_hit_rate = config.get("max_hq_account_hit_rate", 0.10)
    min_risk_concentration = config.get("min_risk_concentration", 0.60)
    empty_validation_policy = config.get("empty_validation_policy", "fail")
    if empty_validation_policy not in ("fail", "pass"):
        raise ValueError(f"未知的 empty_validation_policy: {empty_validation_policy!r}（合法取值: fail/pass）")

    train_total = train_seed_df.count()
    validation_total = validation_seed_df.count()
    if train_total == 0:
        raise ValueError("train_seed_df 账号数为 0，无法评估规则（rule_mining 阶段已拦截空训练集，"
                          "此处通常为 ctx 接线错误，请检查 step2/step1b 的数据流）")

    gen_result = check_generalization(combo, train_seed_df, validation_seed_df,
                                       train_total, validation_total, min_generalization_ratio,
                                       empty_validation_policy)
    baseline_result = check_baseline_recall(combo, baseline_df, combo.clue_hit_count,
                                             max_recall_accounts, max_recall_multiplier,
                                             baseline_scale_factor)

    full_seed_total = train_total + validation_total
    recall_full_seed = (gen_result["train_hit"] + gen_result["val_hit"]) / full_seed_total \
        if full_seed_total > 0 else 0.0

    # 泛化 + 大盘反证 两项硬闸的原因先建（temporal/非 temporal 两条路径共用）
    reasons = []
    if gen_result.get("skipped"):
        # 让"验证集为空被跳过"在产出中可见，与"泛化达标"可区分（事后审计需要）
        reasons.append("[提示] 泛化性检查已跳过：验证集为空，标记为不可评估（empty_validation_policy=pass）")
    if not gen_result["passed"]:
        reasons.append(f"泛化性不足: validation_recall/train_recall={gen_result['generalization_ratio']:.2%} "
                        f"< {min_generalization_ratio:.2%}")
    if not baseline_result["passed"]:
        reasons.append(f"大盘反证未通过: 回捞{baseline_result['baseline_recall_count']}个账号"
                        f"（倍数{baseline_result['baseline_recall_multiplier']:.1f}x）")

    if temporal_verdict is not None:
        # gang_validation 4 级判定取代 risk_concentration + 误伤检测：
        # injury_gate 的命中率+Lift 取代风险浓度+误伤（不 ×scale 稀释）。
        # 保留泛化作硬闸。PASS/REVIEW=过门仍 ship，REJECT 不 ship。
        decision = temporal_verdict.get("decision")
        verdict_pass = decision in ("PASS", "REVIEW")
        risk_concentration = float(temporal_verdict.get("precision_new") or 0.0)
        n_hit = int(temporal_verdict.get("n_hit") or 0)
        reasons.append(f"[2D verdict 取代 risk_concentration/误伤检测] 时序×截面={decision}"
                        f"（precision_new={risk_concentration:.2f}, N_hit={n_hit}）")
        if not verdict_pass:
            reasons.append(f"2D verdict={decision}（REJECT 不 ship）")
        passed = gen_result["passed"] and baseline_result["passed"] and verdict_pass
        return ValidationResult(
            combo=combo, passed=passed, reasons=reasons,
            train_recall=gen_result["train_recall"], validation_recall=gen_result["validation_recall"],
            generalization_ratio=gen_result["generalization_ratio"], recall_full_seed=recall_full_seed,
            baseline_recall_count=baseline_result["baseline_recall_count"],
            baseline_recall_multiplier=baseline_result["baseline_recall_multiplier"],
            whitelist_hit_rate=0.0, hq_account_hit_rate=0.0,
            risk_concentration=risk_concentration,
        )

    # 无 temporal_verdict：旧 4 闸（泛化 + 大盘反证 + 误伤 + 风险浓度）
    fp_result = check_false_positive(combo, baseline_df, whitelist_df,
                                      max_whitelist_hit_rate, max_hq_account_hit_rate)

    # risk_concentration 正确口径：规则命中的全部账号（种子∪大盘，全量口径）中，种子账号的占比。
    # 分子 = train_hit + val_hit（train∪validation 恰好覆盖全部种子：CORE 按哈希切
    # train/validation，WEAK 全部划入 validation，见 seed_split.split_train_validation），
    # 分母 = 种子命中 + baseline 命中【按 baseline_scale_factor 换算回全量】——
    # 与 combo 的 precision 分母、check_baseline_recall 的 scaled_hit 保持同一全量口径；
    # 若分母用抽样原始命中，市场足迹会被缩小 scale 倍（scale≈2000 时 rc 被系统性高估、
    # 阈值含义随抽样率漂移）。三项检查已经算出的计数直接拼装，零额外 Spark action。
    # 在"样本即种子 + 真实大盘 baseline"模式下同样成立（种子与大盘按构造不相交）。
    seed_hit = gen_result["train_hit"] + gen_result["val_hit"]
    scaled_baseline_hit = int(baseline_result["raw_hit"] * baseline_scale_factor)
    total_hit = seed_hit + scaled_baseline_hit
    risk_concentration = seed_hit / total_hit if total_hit > 0 else 1.0
    rc_passed = risk_concentration >= min_risk_concentration

    if not fp_result["passed"]:
        reasons.append(f"误伤检测未通过: 白名单命中率={fp_result['whitelist_hit_rate']:.2%}, "
                        f"高质量账号命中率={fp_result['hq_account_hit_rate']:.2%}")
    if not rc_passed:
        reasons.append(f"风险浓度不足: {risk_concentration:.2%} < {min_risk_concentration:.2%}"
                        f"（种子命中{seed_hit}/总命中{total_hit}）")

    passed = gen_result["passed"] and baseline_result["passed"] and fp_result["passed"] and rc_passed

    return ValidationResult(
        combo=combo, passed=passed, reasons=reasons,
        train_recall=gen_result["train_recall"], validation_recall=gen_result["validation_recall"],
        generalization_ratio=gen_result["generalization_ratio"], recall_full_seed=recall_full_seed,
        baseline_recall_count=baseline_result["baseline_recall_count"],
        baseline_recall_multiplier=baseline_result["baseline_recall_multiplier"],
        whitelist_hit_rate=fp_result["whitelist_hit_rate"], hq_account_hit_rate=fp_result["hq_account_hit_rate"],
        risk_concentration=risk_concentration,
    )


def validate_rules(combos: List[RuleCombo],
                    train_seed_df: DataFrame, validation_seed_df: DataFrame,
                    baseline_df: DataFrame, whitelist_df: DataFrame,
                    config: Optional[Dict] = None,
                    baseline_scale_factor: float = 1.0,
                    temporal_verdicts: Optional[List[Dict]] = None) -> List[ValidationResult]:
    """批量验证入口：对 rule_mining 产出的多条候选规则逐一验证，缓存输入 df 减少重复扫描。

    temporal_verdicts: 可选，与 combos 顺序对齐的 gang_validation 4 级 verdict 列表
    （每元素 dict: decision/precision_new/n_hit/reasons，None 元素=该 combo 无 verdict）。
    传入时 validate_rule 走 4 级旁路（跳过 risk_concentration + 误伤检测）；
    None 或缺省=旧 4 闸行为。
    """
    train_seed_df = train_seed_df.cache()
    validation_seed_df = validation_seed_df.cache()
    whitelist_df = whitelist_df.cache()
    # 【不 cache baseline_df】baseline 285k 行 × 535 列 eager cache + count 会物化全表 → OOM
    # （和 step1b/step3 同根因）。下游 check_baseline_recall 用 filter(规则).count()，
    # ORC 列裁剪只读谓词列，不 cache 靠谓词下推。whitelist 是窄表（account_id+is_whitelisted）cache 无害。

    # 防御性检查：whitelist_df 与 baseline_df 的 universe 应一致（仅旧 4 闸路径有意义）。
    # temporal_verdicts 路径跳过误伤检测，不依赖 whitelist。用单独 SQL count 避免物化 baseline。
    if temporal_verdicts is None:
        try:
            _spark = baseline_df.sparkSession
            _wl_cnt = whitelist_df.count()
            # baseline_cnt 用 SQL count(*) 不物化（需 baseline_df 是 table 引用）
            print(f"[INFO] whitelist_df 账号数={_wl_cnt}（temporal_verdicts 路径跳过 baseline universe 校验）")
        except Exception:
            pass

    results = []
    for i, combo in enumerate(combos):
        verdict = temporal_verdicts[i] if temporal_verdicts and i < len(temporal_verdicts) else None
        result = validate_rule(combo, train_seed_df, validation_seed_df, baseline_df,
                                whitelist_df, config, baseline_scale_factor,
                                temporal_verdict=verdict)
        results.append(result)
        status = "PASS" if result.passed else "FAIL"
        print(f"[rule_validation] [{status}] {combo.to_readable()} "
              f"(泛化率={result.generalization_ratio:.2%}, 大盘回捞={result.baseline_recall_count}, "
              f"风险浓度={result.risk_concentration:.2%})")
        if not result.passed:
            for reason in result.reasons:
                print(f"    - {reason}")
    return results
