# -*- coding: utf-8 -*-
"""
规则验证体系：防过拟合 + 大盘反证 + 误伤检测

包含：
- 样本内验证（训练集/验证集覆盖率比，防过拟合）
- 大盘反证检查（回捞账号数、回捞倍数，含抽样 scale_factor 换算）
- 误伤检测（白名单命中率、高质量账号命中率、风险浓度）
"""

from .validator import (
    ValidationResult,
    check_generalization,
    check_baseline_recall,
    check_false_positive,
    validate_rule,
    validate_rules,
)
