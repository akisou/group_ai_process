# -*- coding: utf-8 -*-
"""
纯 numpy 位图原语：账号→bit 索引、AND+popcount、三集合相等、Jaccard。

设计要点：
- 账号空间独立：seed_train / baseline / hard_negative 三套账号各自建 AccountIndex，
  位图长度 = ceil(账号数 / 64)。同一 Predicate 在三套账号上各有一张位图。
- 位图用 np.ndarray(dtype=np.uint64)，每 word 64 bit，低位在前（bit i 在 word i//64 的第 i%64 位）。
- popcount 用 np.bitwise_count（numpy 2.0+），单指令级；老 numpy 回退到 np.unpackbits。
- 整个模块无 Spark 依赖，可独立单测。
"""

from typing import Dict, Iterable, List, Sequence

import numpy as np

_WORDS = 64  # 每个 uint64 word 的 bit 数


class AccountIndex:
    """账号→bit 位置的稳定映射。bit i 对应 account_ids[i]。"""

    __slots__ = ("account_ids", "_pos", "n_words")

    def __init__(self, account_ids: Sequence[str]):
        # 去重保序：同一账号重复出现只占一个 bit 位
        seen = set()
        unique_ids = []
        for aid in account_ids:
            if aid in seen:
                continue
            seen.add(aid)
            unique_ids.append(aid)
        self.account_ids = unique_ids
        self._pos: Dict[str, int] = {aid: i for i, aid in enumerate(unique_ids)}
        self.n_words = (len(unique_ids) + _WORDS - 1) // _WORDS

    @property
    def size(self) -> int:
        return len(self.account_ids)

    def pos(self, aid: str) -> int:
        return self._pos[aid]

    def positions(self, aids: Iterable[str]) -> List[int]:
        """批量把账号转成 bit 位置，跳过不在索引里的账号。"""
        get = self._pos.get
        return [p for a in aids if (p := get(a)) is not None]


def build_account_index(account_ids: Iterable[str]) -> AccountIndex:
    return AccountIndex(list(account_ids))


def empty_bitmap(n_words: int) -> np.ndarray:
    return np.zeros(n_words, dtype=np.uint64)


def bitmap_from_positions(positions: Iterable[int], n_words: int) -> np.ndarray:
    """按 bit 位置置 1，构建一张位图。"""
    bm = empty_bitmap(n_words)
    pos_arr = np.fromiter((p for p in positions if 0 <= p < n_words * _WORDS),
                          dtype=np.int64)
    if pos_arr.size == 0:
        return bm
    word_idx = pos_arr // _WORDS
    bit_idx = pos_arr % _WORDS
    shifted = np.uint64(1) << bit_idx.astype(np.uint64)
    # 用 bitwise_or.at 累积：fancy indexing 的 |= 不原位累积（同 word 多个 bit 会互相覆盖），
    # np.bitwise_or.at(bm, word_idx, shifted) 对同一 word 的多个 shifted 做逐元素 OR 后写回
    np.bitwise_or.at(bm, word_idx, shifted)
    return bm


def popcount(a: np.ndarray) -> int:
    """位图置 1 的 bit 总数。"""
    if hasattr(np, "bitwise_count"):
        return int(np.bitwise_count(a).sum())
    # 老版本 numpy 回退（2.0 以下）
    return int(np.unpackbits(a.view(np.uint8)).sum())


def and_bitmap(a: np.ndarray, b: np.ndarray) -> np.ndarray:
    """两张位图按位 AND，返回新位图。"""
    return a & b


def and_popcount(a: np.ndarray, b: np.ndarray) -> int:
    """两张位图 AND 后的 popcount，不分配中间位图（直接对 AND 结果 popcount）。"""
    combined = a & b
    return popcount(combined)


def or_bitmap(a: np.ndarray, b: np.ndarray) -> np.ndarray:
    return a | b


def bitmaps_equal(a: np.ndarray, b: np.ndarray) -> bool:
    """两张位图是否完全相等（长度可能不同时先对齐）。"""
    if a.shape != b.shape:
        return False
    return bool(np.array_equal(a, b))


def bitmaps_equal3(s1: np.ndarray, h1: np.ndarray, b1: np.ndarray,
                   s2: np.ndarray, h2: np.ndarray, b2: np.ndarray) -> bool:
    """三集合（seed/hard_neg/baseline）位图是否都相等——层内去冗余判据。"""
    return bitmaps_equal(s1, s2) and bitmaps_equal(h1, h2) and bitmaps_equal(b1, b2)


def jaccard_bm(a: np.ndarray, b: np.ndarray) -> float:
    """两张位图的 Jaccard 相似度 = |A∩B| / |A∪B|。"""
    inter = and_popcount(a, b)
    if inter == 0:
        # 并集为 0 时无定义，返回 0（两张空位图视为不相似，去重时不合并）
        return 0.0
    union = popcount(a | b)
    if union == 0:
        return 0.0
    return inter / union
