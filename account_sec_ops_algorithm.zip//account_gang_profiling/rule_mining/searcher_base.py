# -*- coding: utf-8 -*-
"""
规则搜索器抽象基类。

搜索器只负责"从候选 Predicate + 三类账号数据 产出候选规则组合 List[RuleCombo]"，
不负责验证（rule_validation）和选择（rule_selection）。
Predicate 生成、数据快照、规则验证、规则选择、结果入库都保持不变，
搜索器做成可替换模块：MultiStartGreedySearcher（当前）/ 未来 SmallBeamSearcher / FullBeamSearcher。
"""

from abc import ABC, abstractmethod
from typing import Dict, List, Optional

from pyspark.sql import DataFrame

from account_gang_profiling.predicates.generator import PredicateStats
from account_gang_profiling.rule_mining.combo_search import RuleCombo


class RuleSearcher(ABC):
    """规则搜索器抽象接口。"""

    @abstractmethod
    def search(self, *,
               seed_train_df: DataFrame,
               baseline_df: DataFrame,
               hard_negative_df: Optional[DataFrame],
               candidate_stats: List[PredicateStats],
               baseline_scale_factor: float,
               verbose: bool = False) -> List[RuleCombo]:
        """
        从候选 Predicate 搜索产出候选规则组合。

        Args:
            seed_train_df: 种子训练集（正样本挖掘集），含 account_id
            baseline_df: 大盘抽样（背景），含 account_id
            hard_negative_df: 已知负样本（白名单+高质量），可为 None
            candidate_stats: 初筛后的候选 PredicateStats
            baseline_scale_factor: 大盘抽样倍数（全量/抽样），用于 precision 换算
            verbose: 是否打印搜索过程

        Returns:
            List[RuleCombo]，供 rule_validation.validate_rules 直接消费
        """
        raise NotImplementedError
