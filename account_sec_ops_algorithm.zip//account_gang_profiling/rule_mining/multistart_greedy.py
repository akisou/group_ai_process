# -*- coding: utf-8 -*-
"""
多起点、Top-K 宽度贪心、有限 Lookahead 逃逸的确定性规则搜索器。

核心思路（详见 /Users/wucheng/.claude/plans/serialized-dazzling-octopus.md）：
1. 根节点三池（高覆盖/高区分/风险异常），根间 Jaccard 去重
2. 每棵树 Top-K 宽度贪心扩展：每层留 K 个存活组合各自往下
3. 层内即时去冗余：三集合位图（seed/hard_neg/baseline）都相等才跳过
4. 选最佳子条件：分级排序（hardneg 更少→大盘下降更多→seed损失更少→条件更少）
5. 走不动时一次二步 Lookahead：试 Top-N 两两组合
6. final_gate 搜索期门禁：precision + 大盘命中 + hardneg 命中率
7. 跨根去冗余 + 贪心集合覆盖选 final_max_rules 条（新增Seed/(新增大盘+1)）

求值用位图（numpy packed bits），搜索期零 Spark action（位图在 bitmap_eval 预计算）。
"""

from dataclasses import dataclass, field
from itertools import combinations
from typing import Dict, List, Optional, Tuple

import numpy as np
from pyspark.sql import DataFrame

from account_gang_profiling.predicates.generator import PredicateStats
from account_gang_profiling.predicates.predicate import Predicate
from account_gang_profiling.rule_mining.bitset import (
    and_bitmap, and_popcount, bitmaps_equal3, jaccard_bm, popcount,
)
from account_gang_profiling.rule_mining.bitmap_eval import BitmapSet, build_bitmap_set
from account_gang_profiling.rule_mining.combo_search import RuleCombo
from account_gang_profiling.rule_mining.searcher_base import RuleSearcher

HIGH_COVERAGE = "HIGH_COVERAGE"
HIGH_DISCRIM = "HIGH_DISCRIM"
RISK_ANOMALY = "RISK_ANOMALY"


@dataclass
class RootNode:
    predicate: Predicate
    pool: str
    seed_bitmap: np.ndarray
    baseline_bitmap: np.ndarray
    hardneg_bitmap: np.ndarray
    seed_hit: int
    baseline_hit: int
    hardneg_hit: int
    lift: float


@dataclass
class CandidateRule:
    predicates: Tuple[Predicate, ...]
    seed_bitmap: np.ndarray
    baseline_bitmap: np.ndarray
    hardneg_bitmap: np.ndarray
    seed_hit: int
    baseline_hit: int
    hardneg_hit: int
    root: RootNode
    stop_reason: str = ""

    def to_rule_combo(self, seed_total: int, baseline_scale_factor: float) -> RuleCombo:
        precision_denom = self.seed_hit + self.baseline_hit * baseline_scale_factor
        precision = self.seed_hit / precision_denom if precision_denom > 0 else 0.0
        recall = self.seed_hit / seed_total if seed_total > 0 else 0.0
        if precision + recall == 0:
            v_score = 0.0
        else:
            v_score = 2 * precision * recall / (precision + recall)
        return RuleCombo(
            predicates=self.predicates,
            clue_hit_count=self.seed_hit,
            baseline_hit_count=self.baseline_hit,
            precision=precision, recall=recall, v_score=v_score,
        )


class MultiStartGreedySearcher(RuleSearcher):
    def __init__(self, config: Dict):
        self.config = config or {}

    def search(self, *,
               seed_train_df: DataFrame, baseline_df: DataFrame,
               hard_negative_df: Optional[DataFrame],
               candidate_stats: List[PredicateStats],
               baseline_scale_factor: float, verbose: bool = False) -> Dict:
        if not candidate_stats:
            return {"signatures": [], "search_mode": "multistart_greedy",
                    "score_mode": self.config.get("score_mode", "v_score")}
        bitmap_set = build_bitmap_set(seed_train_df, baseline_df, hard_negative_df, candidate_stats)
        self._bitmap_set = bitmap_set
        roots = self._select_root_nodes(candidate_stats, bitmap_set)
        if verbose:
            print(f"[multistart_greedy] 根节点: {len(roots)} 个 "
                  f"({sum(1 for r in roots if r.pool==HIGH_COVERAGE)} 高覆盖/"
                  f"{sum(1 for r in roots if r.pool==HIGH_DISCRIM)} 高区分/"
                  f"{sum(1 for r in roots if r.pool==RISK_ANOMALY)} 风险异常)")
        all_candidates: List[CandidateRule] = []
        for root in roots:
            tree_candidates = self._grow_tree(root, candidate_stats, bitmap_set,
                                               baseline_scale_factor, verbose)
            all_candidates.extend(tree_candidates)
        if verbose:
            print(f"[multistart_greedy] 各根共产出 {len(all_candidates)} 条候选规则")
        final_combos = self._finalize_to_rule_combos(all_candidates, bitmap_set, baseline_scale_factor, verbose)
        # 把 root_predicate/root_pool/stop_reason 从 CandidateRule 带到 signatures
        # （_signatures_from_combos 丢了这些，这里补回来）
        cid_map = {id(c): c for c in all_candidates}
        signatures = []
        for idx, combo in enumerate(final_combos):
            # 找对应的 CandidateRule（通过 predicates 匹配）
            cr = None
            for c in all_candidates:
                if c.predicates == combo.predicates:
                    cr = c
                    break
            root_pred = cr.root.predicate.to_readable() if cr and cr.root else ""
            root_pool = cr.root.pool if cr and cr.root else ""
            stop_reason = cr.stop_reason if cr else ""
            signatures.append({
                "features": [p.to_readable() for p in combo.predicates],
                "combo": combo,
                "metrics": {
                    "precision": combo.precision, "recall": combo.recall,
                    "v_score": combo.v_score,
                    "clue_hit_count": combo.clue_hit_count,
                    "baseline_hit_count": combo.baseline_hit_count,
                    "combo_size": combo.size,
                },
                "root_predicate": root_pred,
                "root_pool": root_pool,
                "combo_id": f"c{idx:03d}",
                "stop_reason": stop_reason,
            })
        search_mode = self.config.get("searcher_type", "multistart_greedy")
        return {"signatures": signatures, "search_mode": search_mode,
                "score_mode": self.config.get("score_mode", "v_score")}

    # ---------- 根节点分池 ----------

    def _select_root_nodes(self, stats: List[PredicateStats], bitmap_set: BitmapSet) -> List[RootNode]:
        pools_cfg = self.config.get("root_pools", {}) or {}
        pool_specs = (
            (HIGH_COVERAGE, pools_cfg.get("high_coverage", {})),
            (HIGH_DISCRIM, pools_cfg.get("high_discrim", {})),
        )
        roots: List[RootNode] = []
        for pool_name, pcfg in pool_specs:
            min_cov = pcfg.get("min_seed_coverage", 0.50 if pool_name == HIGH_COVERAGE else 0.10)
            max_base = pcfg.get("max_baseline_support", 0.05 if pool_name == HIGH_COVERAGE else 0.02)
            pool_size = pcfg.get("pool_size", 4)
            # 大盘区分度只靠 max_baseline_support 比例门卡（已含在 eligible 筛选里）。
            # 去除 max_baseline_hit_abs 绝对量门：抽样绝对量随 baseline 总量漂移，且会误杀
            # 高 clue_hit + 低 base_support 的强团伙信号（如 ADA-AL00 clue87%/base0.41%/抽样命中1183）。
            if pool_name == HIGH_COVERAGE:
                eligible = [s for s in stats
                            if s.clue_support >= min_cov and s.baseline_support <= max_base]
            else:
                # 高区分池：clue_support 在 [min_cov, 0.50)，避免与高覆盖池重叠
                eligible = [s for s in stats
                            if min_cov <= s.clue_support < 0.50 and s.baseline_support <= max_base]
            # 池内排序：主 key=clue_hit_count 降序（高命中优先，团伙主体特征），
            # 次 key=lift 降序（同命中数时区分度更高的排前）。池已用三维度筛过，
            # lift 虚高在池内不成立（base_support 已卡），这里只作同命中数的 tiebreaker。
            eligible.sort(key=lambda s: (s.clue_hit_count, s.lift), reverse=True)
            for s in eligible[:pool_size]:
                p = s.predicate
                roots.append(RootNode(
                    predicate=p, pool=pool_name,
                    seed_bitmap=bitmap_set.seed_bitmaps[p],
                    baseline_bitmap=bitmap_set.baseline_bitmaps[p],
                    hardneg_bitmap=bitmap_set.hardneg_bitmaps[p],
                    seed_hit=bitmap_set.seed_hit(p),
                    baseline_hit=bitmap_set.baseline_hit(p),
                    hardneg_hit=bitmap_set.hardneg_hit(p),
                    lift=s.lift,
                ))
        # 风险异常池 MVP 空（派生特征未进宽表）
        return self._dedup_roots_jaccard(roots, self.config.get("root_jaccard_threshold", 0.85))

    def _dedup_roots_jaccard(self, roots: List[RootNode], threshold: float) -> List[RootNode]:
        """根间 Jaccard 去重：seed 位图 Jaccard>阈值 且 baseline 命中也相似 → 留 lift 更高的。"""
        if len(roots) <= 1:
            return roots
        roots_sorted = sorted(roots, key=lambda r: r.lift, reverse=True)
        kept: List[RootNode] = []
        for r in roots_sorted:
            is_dup = False
            for k in kept:
                if jaccard_bm(r.seed_bitmap, k.seed_bitmap) > threshold:
                    is_dup = True
                    break
            if not is_dup:
                kept.append(r)
        return kept

    # ---------- 贪心扩展主循环 ----------

    def _grow_tree(self, root: RootNode, stats: List[PredicateStats],
                   bitmap_set: BitmapSet, baseline_scale_factor: float,
                   verbose: bool) -> List[CandidateRule]:
        max_depth = self.config.get("max_depth", 6)
        top_k = self.config.get("top_k_width", 4)
        root_combo = CandidateRule(
            predicates=(root.predicate,),
            seed_bitmap=root.seed_bitmap.copy(),
            baseline_bitmap=root.baseline_bitmap.copy(),
            hardneg_bitmap=root.hardneg_bitmap.copy(),
            seed_hit=root.seed_hit, baseline_hit=root.baseline_hit,
            hardneg_hit=root.hardneg_hit, root=root,
        )
        alive: List[CandidateRule] = [root_combo]
        finalized: List[CandidateRule] = []
        if self._passes_gate(root_combo, baseline_scale_factor):
            root_combo.stop_reason = "PASS_GATE"
            finalized.append(root_combo)
        # available：全部候选谓词均可参与扩展。去除 max_baseline_hit_abs 绝对量门
        # （与 _select_root_nodes 同步：抽样绝对量随 baseline 总量漂移，误杀高命中强信号；
        # 大盘区分度靠 root 池的 max_baseline_support + 搜索期 collinear_jaccard_threshold 共线检测把关）。
        available = [s.predicate for s in stats]

        for depth in range(2, max_depth + 1):
            if not alive:
                break
            children: List[CandidateRule] = []
            for combo in alive:
                children.extend(self._extend_all(combo, root, available, bitmap_set))
            if not children:
                # 走不动 → 二步 Lookahead
                lookahead = self._lookahead(alive, root, available, bitmap_set)
                if not lookahead:
                    if verbose:
                        print(f"  [root {root.predicate.to_readable()}] depth={depth} NO_GAIN 停止")
                    break
                children = lookahead
            children.sort(key=lambda c: self._rank_key(c, root), reverse=True)
            alive = children[:top_k]
            for c in alive:
                if self._passes_gate(c, baseline_scale_factor):
                    c.stop_reason = "PASS_GATE"
                    finalized.append(c)
        # 末层 survivors 也纳入候选（交 validator 真值判定）
        for c in alive:
            if not c.stop_reason:
                c.stop_reason = "MAX_DEPTH"
                finalized.append(c)
        if verbose and finalized:
            print(f"  [root {root.predicate.to_readable()}] 产出 {len(finalized)} 条候选 "
                  f"(PASS_GATE={sum(1 for c in finalized if c.stop_reason=='PASS_GATE')})")
        return finalized

    def _extend_all(self, combo: CandidateRule, root: RootNode,
                    available: List[Predicate], bitmap_set: BitmapSet) -> List[CandidateRule]:
        used_fields = {p.field_name for p in combo.predicates}
        used_preds = set(combo.predicates)
        children: List[CandidateRule] = []
        collinear_thr = self.config.get("collinear_jaccard_threshold", 0.9)
        for p in available:
            if p in used_preds or p.field_name in used_fields:
                continue
            # 共线检测：新原子 p 的 seed 命中集 与 combo 任一已有原子 q 的 seed 命中集
            # Jaccard > 阈值 → 跳过（dm/os/sdkversion/resolution 同设备画像 99% 共线，叠加不增区分力，
            # 释放 top_k 存活位给真互补原子 ipcity/frozen/黑卡）。位图 O(1)，零 Spark action。
            if collinear_thr > 0 and combo.predicates:
                p_seed = self._seed_bm(p)
                if popcount(p_seed) > 0:
                    collinear = False
                    for q in combo.predicates:
                        q_seed = self._seed_bm(q)
                        q_pop = popcount(q_seed)
                        if q_pop == 0:
                            continue
                        inter = popcount(and_bitmap(p_seed, q_seed))
                        union = popcount(p_seed) + q_pop - inter
                        if union > 0 and inter / union > collinear_thr:
                            collinear = True
                            break
                    if collinear:
                        continue
            child = self._extend(combo, p)
            if child is None:
                continue
            # 层内即时去冗余：三集合位图都相等才跳过（方案第六节）
            if bitmaps_equal3(child.seed_bitmap, child.hardneg_bitmap, child.baseline_bitmap,
                              combo.seed_bitmap, combo.hardneg_bitmap, combo.baseline_bitmap):
                continue
            if not self._hard_filter(child, root):
                continue
            children.append(child)
        return children

    def _extend(self, combo: CandidateRule, p: Predicate) -> Optional[CandidateRule]:
        new_seed = and_bitmap(combo.seed_bitmap, p_seed := self._seed_bm(p))
        new_base = and_bitmap(combo.baseline_bitmap, p_base := self._baseline_bm(p))
        new_hard = and_bitmap(combo.hardneg_bitmap, p_hard := self._hardneg_bm(p))
        sh = popcount(new_seed)
        if sh == 0:
            return None
        return CandidateRule(
            predicates=combo.predicates + (p,),
            seed_bitmap=new_seed, baseline_bitmap=new_base, hardneg_bitmap=new_hard,
            seed_hit=sh, baseline_hit=popcount(new_base), hardneg_hit=popcount(new_hard),
            root=combo.root,
        )

    def _extend2(self, combo: CandidateRule, p1: Predicate, p2: Predicate) -> Optional[CandidateRule]:
        """二步扩展：一次加两个条件（Lookahead 用）。"""
        c1 = self._extend(combo, p1)
        if c1 is None:
            return None
        return self._extend(c1, p2)

    def _seed_bm(self, p: Predicate) -> np.ndarray:
        return self._bitmap_set.seed_bitmaps[p]

    def _baseline_bm(self, p: Predicate) -> np.ndarray:
        return self._bitmap_set.baseline_bitmaps[p]

    def _hardneg_bm(self, p: Predicate) -> np.ndarray:
        return self._bitmap_set.hardneg_bitmaps[p]

    # ---------- 硬过滤 / 排序 ----------

    def _hard_filter(self, child: CandidateRule, root: RootNode) -> bool:
        min_seed = self.config.get("min_seed_accounts", 20)
        min_retention = self.config.get("min_root_retention", 0.60)
        max_growth = self.config.get("max_hardneg_growth_vs_root", 1.0)
        if child.seed_hit < min_seed:
            return False
        if root.seed_hit > 0 and child.seed_hit < root.seed_hit * min_retention:
            return False
        if root.hardneg_hit > 0 and child.hardneg_hit > root.hardneg_hit * max_growth:
            return False
        # root.hardneg_hit==0 时不允许引入任何 hardneg 命中（max_growth 无意义，单独卡）
        if root.hardneg_hit == 0 and child.hardneg_hit > 0:
            return False
        return True

    def _rank_key(self, child: CandidateRule, root: RootNode) -> tuple:
        rank_mode = self.config.get("rank_mode", "tiered")
        if rank_mode == "purification_gain":
            # parent 用 root 单条件近似（每层排序时 parent 各异，这里用 root 做基准；
            # 真正的逐 parent 增益在 _grow_tree 里难拿到，MVP 用 root 基准）
            gain = (root.baseline_hit - child.baseline_hit) / (root.seed_hit - child.seed_hit + 1)
            return (gain, -child.hardneg_hit, -child.baseline_hit, -child.seed_hit, -len(child.predicates))
        # tiered：1.hardneg更少 2.大盘下降更多 3.seed损失更少 4.条件更少
        return (-child.hardneg_hit,
                root.baseline_hit - child.baseline_hit,
                -(root.seed_hit - child.seed_hit),
                -len(child.predicates))

    # ---------- Lookahead ----------

    def _lookahead(self, alive: List[CandidateRule], root: RootNode,
                   available: List[Predicate], bitmap_set: BitmapSet) -> List[CandidateRule]:
        top_n = self.config.get("lookahead_top_n", 10)
        min_hardneg_drop = self.config.get("lookahead_min_hardneg_drop", 1)
        min_baseline_drop = self.config.get("lookahead_min_baseline_drop", 10)
        # 选 Top-N 候选：按 lift 降序取前 N（available 已是 candidate_stats 顺序，按 lift 降序）
        top_preds = available[:top_n]
        results: List[CandidateRule] = []
        for combo in alive:
            used_preds = set(combo.predicates)
            used_fields = {p.field_name for p in combo.predicates}
            for p1, p2 in combinations(top_preds, 2):
                if p1 in used_preds or p2 in used_preds:
                    continue
                if p1.field_name in used_fields or p2.field_name in used_fields:
                    continue
                child = self._extend2(combo, p1, p2)
                if child is None:
                    continue
                if not self._hard_filter(child, root):
                    continue
                if (child.hardneg_hit <= combo.hardneg_hit - min_hardneg_drop
                        or combo.baseline_hit - child.baseline_hit >= min_baseline_drop):
                    results.append(child)
        return results

    # ---------- final_gate ----------

    def _passes_gate(self, child: CandidateRule, baseline_scale_factor: float) -> bool:
        gate = self.config.get("final_gate", {}) or {}
        max_scaled = gate.get("max_scaled_baseline_hit", 50000)
        max_hardneg_rate = gate.get("max_hardneg_hit_rate", 0.05)
        min_seed = gate.get("min_seed_hit", 20)
        min_precision = gate.get("min_precision", 0.30)
        scaled_baseline = child.baseline_hit * baseline_scale_factor
        if scaled_baseline > max_scaled:
            return False
        if child.seed_hit < min_seed:
            return False
        if child.seed_hit > 0 and child.hardneg_hit / child.seed_hit > max_hardneg_rate:
            return False
        precision_denom = child.seed_hit + child.baseline_hit * baseline_scale_factor
        precision = child.seed_hit / precision_denom if precision_denom > 0 else 0.0
        return precision >= min_precision

    # ---------- 跨根去冗余 + 集合覆盖 ----------

    def _finalize_to_rule_combos(self, candidates: List[CandidateRule], bitmap_set: BitmapSet,
                                  baseline_scale_factor: float, verbose: bool) -> List[RuleCombo]:
        if not candidates:
            return []
        # 1) 同命中集去重：三集合位图都相等的只留 depth 最小的一条
        deduped = self._dedup_by_hitset(candidates)
        # diverse 模式：跳过 Jaccard 去重 + 贪心覆盖，把候选都交 step6 diverse 按参数重叠选
        # （Jaccard 去重会按命中集相似压到 1 条，step6 没得选）
        select_mode = self.config.get("select_mode", "auto_cover")
        if select_mode == "diverse":
            final_max = self.config.get("final_max_rules", 16)
            selected = deduped[:final_max]
            if verbose:
                print(f"[multistart_greedy] finalize(diverse): {len(candidates)} 候选 → "
                      f"{len(deduped)} 同命中集去重 → {len(selected)} 交 step6 diverse（跳过Jaccard去重+贪心覆盖）")
        else:
            # 2) Jaccard 去重（基于 seed 位图）
            deduped = self._jaccard_dedup_candidates(deduped, self.config.get("root_jaccard_threshold", 0.85))
            # 3) 贪心集合覆盖：新增Seed/(新增大盘+1) 最高
            selected = self._greedy_cover_precision_aware(deduped, bitmap_set)
            final_max = self.config.get("final_max_rules", 16)
            selected = selected[:final_max]
            if verbose:
                print(f"[multistart_greedy] finalize: {len(candidates)} 候选 → "
                      f"{len(deduped)} 去重后 → {len(selected)} 终选")
        return [c.to_rule_combo(bitmap_set.seed_total, baseline_scale_factor) for c in selected]

    def _dedup_by_hitset(self, candidates: List[CandidateRule]) -> List[CandidateRule]:
        seen: List[Tuple[bytes, bytes, bytes]] = []
        kept: List[CandidateRule] = []
        # 按 depth 升序，保证同命中集留最浅的
        for c in sorted(candidates, key=lambda x: len(x.predicates)):
            key = (c.seed_bitmap.tobytes(), c.hardneg_bitmap.tobytes(), c.baseline_bitmap.tobytes())
            if key in seen:
                continue
            seen.append(key)
            kept.append(c)
        return kept

    def _jaccard_dedup_candidates(self, candidates: List[CandidateRule], threshold: float) -> List[CandidateRule]:
        if len(candidates) <= 1:
            return candidates
        # 按 seed_hit 降序（覆盖大的优先留）
        sorted_c = sorted(candidates, key=lambda c: c.seed_hit, reverse=True)
        kept: List[CandidateRule] = []
        for c in sorted_c:
            is_dup = False
            for k in kept:
                if jaccard_bm(c.seed_bitmap, k.seed_bitmap) > threshold:
                    is_dup = True
                    break
            if not is_dup:
                kept.append(c)
        return kept

    def _greedy_cover_precision_aware(self, candidates: List[CandidateRule],
                                       bitmap_set: BitmapSet) -> List[CandidateRule]:
        """贪心集合覆盖：每轮选 新增Seed覆盖/(新增大盘命中+1) 最高。"""
        if not candidates:
            return []
        covered_seed = None
        covered_baseline = None
        selected: List[CandidateRule] = []
        remaining = list(candidates)
        min_seed_coverage = self.config.get("final_gate", {}).get("min_seed_hit", 20)
        target_coverage = self.config.get("min_total_coverage", 0.5)
        total_seed = bitmap_set.seed_total
        while remaining and len(selected) < self.config.get("final_max_rules", 16):
            best = None
            best_gain = -1.0
            for c in remaining:
                if covered_seed is None:
                    new_seed = popcount(c.seed_bitmap)
                    new_base = popcount(c.baseline_bitmap)
                else:
                    new_seed = popcount(and_bitmap(c.seed_bitmap, _invert(covered_seed)))
                    new_base = popcount(and_bitmap(c.baseline_bitmap, _invert(covered_baseline)))
                if new_seed <= 0:
                    continue
                gain = new_seed / (new_base + 1)
                if gain > best_gain:
                    best_gain = gain
                    best = (c, new_seed, new_base)
            if best is None:
                break
            c, _, _ = best
            selected.append(c)
            if covered_seed is None:
                covered_seed = c.seed_bitmap.copy()
                covered_baseline = c.baseline_bitmap.copy()
            else:
                covered_seed = covered_seed | c.seed_bitmap
                covered_baseline = covered_baseline | c.baseline_bitmap
            # 达到联合覆盖目标则停
            if total_seed > 0 and popcount(covered_seed) / total_seed >= target_coverage:
                break
            remaining = [r for r in remaining if r is not c]
        return selected


def _invert(bm: np.ndarray) -> np.ndarray:
    """位图取反（用于算新增覆盖：AND NOT covered）。"""
    return ~bm
