# -*- coding: utf-8 -*-
"""
特征分级：DEPLOYABLE / EVIDENCE_ONLY / UNSTABLE / LEAKAGE。

- DEPLOYABLE：可进入最终规则（设备、版本、地域、时间差等可上线特征）
- EVIDENCE_ONLY：只用于解释，不进规则（如已有风险策略命中，避免重复已有策略）
- UNSTABLE：变化过快，只用于 CASE 分析（如版本号、sdkversion）
- LEAKAGE：与风险标签同源，禁止进入规则

config.feature_grading 段按字段名标注级别；未标注字段默认 DEPLOYABLE。
"""

from typing import Dict, Iterable, List, Tuple

from account_gang_profiling.predicates.generator import PredicateStats
from account_gang_profiling.predicates.predicate import Predicate

DEPLOYABLE = "DEPLOYABLE"
EVIDENCE_ONLY = "EVIDENCE_ONLY"
UNSTABLE = "UNSTABLE"
LEAKAGE = "LEAKAGE"
_ALL_GRADES = (DEPLOYABLE, EVIDENCE_ONLY, UNSTABLE, LEAKAGE)


def _build_field_grade_map(grading_config: Dict) -> Dict[str, str]:
    """config.feature_grading {级别: [字段名]} → {字段名: 级别}。"""
    field_to_grade: Dict[str, str] = {}
    for grade in _ALL_GRADES:
        fields = grading_config.get(grade, []) or []
        for fld in fields:
            field_to_grade[fld] = grade
    return field_to_grade


def grade_predicate(predicate: Predicate, grading_config: Dict) -> str:
    """查单个 Predicate 的字段级别，未标注返回 DEPLOYABLE。"""
    field_to_grade = _build_field_grade_map(grading_config)
    return field_to_grade.get(predicate.field_name, DEPLOYABLE)


def filter_by_grade(stats: List[PredicateStats], grading_config: Dict,
                    allowed: Iterable[str] = (DEPLOYABLE,)) -> Tuple[List[PredicateStats], List[PredicateStats]]:
    """
    按级别过滤候选。

    Args:
        stats: 初筛后的候选 PredicateStats 列表
        grading_config: config.feature_grading 段
        allowed: 允许进入规则候选池的级别，默认仅 DEPLOYABLE

    Returns:
        (allowed_stats, excluded_stats)：允许的候选 + 被排除的候选（保留供解释/记录）
    """
    allowed_set = set(allowed)
    field_to_grade = _build_field_grade_map(grading_config)
    allowed_stats: List[PredicateStats] = []
    excluded_stats: List[PredicateStats] = []
    for s in stats:
        grade = field_to_grade.get(s.predicate.field_name, DEPLOYABLE)
        if grade in allowed_set:
            allowed_stats.append(s)
        else:
            excluded_stats.append(s)
    return allowed_stats, excluded_stats
