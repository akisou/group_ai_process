# -*- coding: utf-8 -*-
"""
规则挖掘核心算法：分层组合搜索 + Apriori式反单调剪枝 + 批量聚合评估

算法框架（与 hopejob/feature_combiner_pyspark.py 的单树贪心思路一脉相承，
但升级为"分层保留 Top-M 组合"而不是单树贪心一条路走到黑，更能跳出局部最优，
代价是每层的候选组合数更多，因此必须依赖批量聚合评估，否则性能不可接受）：

第1层：候选池中每个 Predicate 单独作为一个组合(size=1)，计算 precision/recall，
        按打分（v_score，兼顾精度和召回）排序，保留 Top-M 存活组合
第k层(k=2..max_combo_size)：
    对上一层每个存活组合，尝试从候选池中添加一个尚未使用的 Predicate 形成新组合，
    批量聚合算出所有新组合的 clue_hit / baseline_hit，
    过滤掉命中账号数低于 base_min_hit / min_coverage_ratio 的组合（反单调剪枝：
    因为新增条件只会让命中范围更窄，如果加条件前已经不满足最小命中数，
    加条件后一定也不满足，这类分支可以直接剪掉不再往下扩展），
    按打分排序保留 Top-M 存活组合
提前终止：若某组合已达到 min_accuracy 且满足 min_recall，视为"已经足够好"，
    不再继续为其增加条件（避免不必要地增加组合复杂度，规则越简单越可解释、越不容易过拟合）
最终结果：合并所有层级中已达标（or 每条搜索路径的最优解）的组合，取 top_k_combos 个返回

Fallback：如果全程没有任何组合达到 min_accuracy，则退化返回全局搜索到的
    v_score 最高的单个组合（哪怕精度不达标），保证挖掘流程始终有可解释的产出，
    而不是直接返回空结果——这与 hopejob 项目"fallback: 返回best single tree"的
    设计原则一致。
"""

from concurrent.futures import ThreadPoolExecutor
from dataclasses import dataclass
from typing import Dict, List, Optional, Tuple

from pyspark.sql import DataFrame, functions as F

from account_gang_profiling.predicates.predicate import Predicate
from account_gang_profiling.predicates.generator import PredicateStats

# 评分模式（rule_mining.score_mode）：
# - v_score（默认，历史行为）：F1(precision, recall) 排序 + precision>=min_accuracy 提前 finalize。
#   注意：baseline_scale_factor 较大（如抽样大盘 scale≈2000）时 precision 对少量大盘命中
#   极端敏感（1 个命中 = ×2000），会系统性错杀"中间步骤有市场命中、但最终组合能过业务闸"
#   的高覆盖特征链。
# - recall_gated（闸内覆盖最大化）：finalize/终选以"大盘反证闸"（scaled 大盘命中 <=
#   gate_max_recall_accounts，与 rule_validation.max_recall_accounts 同口径）为门槛，
#   过闸组合按 recall 降序。搜索期不按闸剪枝——AND 只会让大盘命中变少，父组合不过闸，
#   子组合反而可能过闸（闸门非反单调安全），因此高覆盖但暂时超闸的特征（如 HarmonyOS
#   这类"缩圈"特征）必须留在存活集里继续扩展。
SCORE_MODE_V_SCORE = "v_score"
SCORE_MODE_RECALL_GATED = "recall_gated"
SCORE_MODE_MULTISTART_GREEDY = "multistart_greedy"


def _score_tuple(r: "RuleCombo", score_mode: str) -> tuple:
    """组合排序键（统一 -r.size 使同分时更简洁的组合在前；配合 reverse=True 使用）。"""
    if score_mode == SCORE_MODE_RECALL_GATED:
        return (r.recall, r.v_score, -r.size)
    return (r.v_score, -r.size)


def _scaled_baseline_hit(r: "RuleCombo", baseline_scale_factor: float) -> int:
    """大盘命中按抽样倍数换算回全量口径（与 validator 的 scaled_hit 一致）。"""
    return int(r.baseline_hit_count * baseline_scale_factor)


def _passes_gate(r: "RuleCombo", gate_max_recall_accounts: int, baseline_scale_factor: float) -> bool:
    """recall_gated 模式的大盘反证闸：scaled 大盘命中 <= 预算。"""
    return _scaled_baseline_hit(r, baseline_scale_factor) <= gate_max_recall_accounts


def _should_finalize(r: "RuleCombo", score_mode: str, min_accuracy: float,
                     min_recall: float, gate_max_recall_accounts: int,
                     baseline_scale_factor: float) -> bool:
    """组合是否达标、不再继续扩展（两种模式的统一出口）。"""
    if r.recall < min_recall:
        return False
    if score_mode == SCORE_MODE_RECALL_GATED:
        return _passes_gate(r, gate_max_recall_accounts, baseline_scale_factor)
    return r.precision >= min_accuracy


def _select_survivors(evaluated_sorted: List["RuleCombo"], top_m: int,
                       candidate_predicates: List[Predicate],
                       preserve_roots: bool) -> List["RuleCombo"]:
    """
    每层存活组合选择：全局 top_m + 可选的"保根"机制（仅从第 2 层起调用——
    第 1 层全是单条件，保根会把 top_m 之外的每个根全部补回，存活集退化为整个
    候选池，top_m 截断形同虚设；且被截特征在第 2 层扩展时仍作为"被添加的条件"
    参与配对，从第 2 层开始保根即可完成灭根救援）。

    保根（preserve_roots，对应 hopejob 多起点贪心思想的 beam 内嵌版）：
    对候选池中每个特征，若全局 top_m 里没有任何一条组合包含它（全局排名灭根——
    如 version 类特征中间步骤评分低被挤出 top_m，其整条分支被灭绝），则把"包含该特征的
    最高分组合"补入存活集。已充分代表的特征（top_m 里已出现的）不额外占位。

    Args:
        evaluated_sorted: 已按分数降序排好的候选（首个含某根的组合即该根的最优链）
    """
    survivors = list(evaluated_sorted[:top_m])
    if not preserve_roots:
        return survivors

    covered_roots = set()
    for r in survivors:
        covered_roots |= r.combo_key()
    survivors_keys = set(r.combo_key() for r in survivors)

    for p in candidate_predicates:
        if p in covered_roots:
            continue
        for r in evaluated_sorted:
            if p in r.combo_key() and r.combo_key() not in survivors_keys:
                survivors.append(r)
                survivors_keys.add(r.combo_key())
                covered_roots |= r.combo_key()
                break
    return survivors


def _prune_dominated(combos: List["RuleCombo"]) -> List["RuleCombo"]:
    """
    支配剪枝：组合 B 的谓词集合严格包含组合 A（A ⊂ B）且两者 clue/baseline 命中数
    完全相同（B 多出的条件没有过滤任何账号）时，B 被 A 支配——更复杂却无任何收益，剔除。

    数学安全性：A ⊂ B 且 |hit(A)| == |hit(B)| ⇒ hit(A) == hit(B)（AND 只缩集合），
    对任意后续扩展 p，hit(A∪{p}) ⊇ hit(B∪{p})，A 的后代恒不劣于 B 的后代且更简洁。
    按 (clue_hit, baseline_hit) 分组、组内按组合大小排序后只做小→大的子集比较，
    避免全量两两 O(n²)。
    """
    by_hits = {}
    for r in combos:
        by_hits.setdefault((r.clue_hit_count, r.baseline_hit_count), []).append(r)

    dominated = set()
    for group in by_hits.values():
        if len(group) < 2:
            continue
        group.sort(key=lambda r: r.size)
        for i, a in enumerate(group):
            a_set = set(a.predicates)
            for b in group[i + 1:]:
                if a_set < set(b.predicates):
                    dominated.add(b.combo_key())
    return [r for r in combos if r.combo_key() not in dominated]


@dataclass
class RuleCombo:
    """
    一个候选规则（Predicate 的 AND 组合）及其在 clue/baseline 上的评估指标。
    """
    predicates: Tuple[Predicate, ...]
    clue_hit_count: int
    baseline_hit_count: int
    precision: float      # clue_hit / (clue_hit + baseline_hit)，即"命中此规则的账号中，clue占比"
    recall: float         # clue_hit / clue_total，即"clue账号中，被此规则覆盖的比例"
    v_score: float        # 综合评分，用于排序（兼顾精度与召回，避免只挑召回率极低但精度100%的过拟合规则）

    @property
    def size(self) -> int:
        return len(self.predicates)

    def to_column(self) -> "F.Column":
        cond = self.predicates[0].to_column()
        for p in self.predicates[1:]:
            cond = cond & p.to_column()
        return cond

    def to_readable(self) -> str:
        return " AND ".join(p.to_readable() for p in self.predicates)

    def combo_key(self) -> frozenset:
        """用于组合去重/已使用字段判重的稳定 key（与 Predicate 顺序无关）"""
        return frozenset(self.predicates)


def _calculate_v_score(clue_hit: int, baseline_hit: int, clue_total: int,
                        baseline_total: int, baseline_scale_factor: float = 1.0) -> float:
    """
    综合评分：precision * recall 的调和平均（F1式），但 baseline 命中数先按
    scale_factor 换算回真实大盘规模再计入 precision 分母——因为 baseline_df
    在实际生产中通常是从全量大盘抽样而来（避免每次挖掘都要扫描全量数据），
    此时直接用抽样后的 baseline_hit 计算 precision 会systematic地高估精度，
    必须换算回抽样前的等效规模才能得到符合真实大盘表现的精度估计。

    baseline_scale_factor = 全量大盘账号数 / 抽样大盘账号数，默认1.0表示未抽样（baseline_df即全量）。
    """
    precision_denominator = clue_hit + baseline_hit * baseline_scale_factor
    precision = clue_hit / precision_denominator if precision_denominator > 0 else 0.0
    recall = clue_hit / clue_total if clue_total > 0 else 0.0
    if precision + recall == 0:
        return 0.0
    # F1式调和平均：避免"精度100%但召回率0.1%"这种没有实际覆盖意义的规则排在最前面
    return 2 * precision * recall / (precision + recall)


def _batch_evaluate_combos(clue_df: DataFrame, baseline_df: DataFrame,
                            combos: List[Tuple[Predicate, ...]],
                            clue_total: int, baseline_total: int,
                            baseline_scale_factor: float,
                            batch_size: int = 150,
                            parallel_threads: int = 1) -> List[RuleCombo]:
    """
    批量计算一组候选组合的 clue_hit/baseline_hit，一次 agg 算完一批，
    这是分层搜索性能可行的关键——同一层可能有 top_m_per_layer * len(候选池) 量级的
    候选组合，若逐个 filter().count() 则 action 次数与候选组合数成正比，
    批量 agg 把 action 次数压缩到 2*ceil(combos数/batch_size) 次。

    性能调节（rule_mining.eval_batch_size / eval_parallel_threads）：
    - batch_size 调大（如 150->500）：action 数线性下降（action 调度开销主导时约 3x），
      代价是单批 agg 表达式增多、Catalyst 计划编译成本上升，建议逐步试；
    - parallel_threads > 1：批次用 ThreadPoolExecutor 并行提交 Spark job
      （移植 snapshot_builder 并行物化模式——SparkSession 线程安全，收益来自调度等待
      重叠与 FIFO 尾部填充；输入 df 均已在调用方 cache 物化，满足并行前提）。
      pool.map 按提交顺序返回结果，任一批次异常在 list() 迭代时原样抛出。
    """
    batches = [combos[i:i + batch_size] for i in range(0, len(combos), batch_size)]

    def _eval_one_batch(batch: List[Tuple[Predicate, ...]]) -> List[RuleCombo]:
        clue_aggs = []
        baseline_aggs = []
        for j, combo_preds in enumerate(batch):
            cond = combo_preds[0].to_column()
            for p in combo_preds[1:]:
                cond = cond & p.to_column()
            clue_aggs.append(F.sum(F.when(cond, 1).otherwise(0)).alias(f"c_{j}"))
            baseline_aggs.append(F.sum(F.when(cond, 1).otherwise(0)).alias(f"b_{j}"))

        clue_row = clue_df.agg(*clue_aggs).collect()[0]
        baseline_row = baseline_df.agg(*baseline_aggs).collect()[0]

        batch_results = []
        for j, combo_preds in enumerate(batch):
            clue_hit = clue_row[f"c_{j}"] or 0
            baseline_hit = baseline_row[f"b_{j}"] or 0
            precision_denom = clue_hit + baseline_hit * baseline_scale_factor
            precision = clue_hit / precision_denom if precision_denom > 0 else 0.0
            recall = clue_hit / clue_total if clue_total > 0 else 0.0
            v_score = _calculate_v_score(clue_hit, baseline_hit, clue_total, baseline_total, baseline_scale_factor)
            batch_results.append(RuleCombo(
                predicates=combo_preds, clue_hit_count=clue_hit, baseline_hit_count=baseline_hit,
                precision=precision, recall=recall, v_score=v_score
            ))
        return batch_results

    if parallel_threads > 1 and len(batches) > 1:
        with ThreadPoolExecutor(max_workers=parallel_threads) as pool:
            batch_results_list = list(pool.map(_eval_one_batch, batches))
    else:
        batch_results_list = [_eval_one_batch(b) for b in batches]

    results = []
    for br in batch_results_list:
        results.extend(br)
    return results


def build_feature_combinations(clue_df: DataFrame, baseline_df: DataFrame,
                                candidate_stats: List[PredicateStats],
                                config: Optional[Dict] = None,
                                baseline_scale_factor: float = 1.0,
                                verbose: bool = False,
                                hard_negative_df: Optional[DataFrame] = None,
                                rule_search_config: Optional[Dict] = None) -> Dict:
    """
    主入口：分层组合搜索 + 反单调剪枝，返回最终候选规则集。

    Args:
        clue_df: 种子正样本大宽表（训练集）
        baseline_df: 背景/大盘大宽表（可能是抽样后的，需配合 baseline_scale_factor 换算）
        candidate_stats: predicates.generate_candidate_predicates 的初筛结果，
            作为组合搜索第1层的起点候选池
        config: config.yaml 中的 rule_mining 配置字典
        baseline_scale_factor: 大盘抽样倍数（全量/抽样），用于精度计算换算，默认1.0（未抽样）
        verbose: 是否打印每层搜索的详细过程
        hard_negative_df: 已知负样本（白名单+高质量账号），仅 score_mode=multistart_greedy 使用
        rule_search_config: config.yaml 中的 rule_search 配置字典，仅 multistart_greedy 使用

    Returns:
        {
            "signatures": List[Dict]，每个元素包含 features(Predicate可读描述列表)、
                combo(RuleCombo对象，供 rule_validation/rule_selection 直接复用求值)、
                metrics(precision/recall/v_score/clue_hit_count/baseline_hit_count),
            "search_mode": "layered"（正常分层搜索）或 "empty_baseline_single_only"
                （baseline 为空时的快捷路径，产出仅有团伙共性刻画意义，见函数内 WARN）
                或 "multistart_greedy"（多起点贪心搜索器）
        }
    """
    config = config or {}
    score_mode = config.get("score_mode", SCORE_MODE_V_SCORE)

    # 路由：multistart_greedy 委托给独立搜索器
    if score_mode == SCORE_MODE_MULTISTART_GREEDY:
        from account_gang_profiling.rule_mining.multistart_greedy import MultiStartGreedySearcher
        searcher = MultiStartGreedySearcher(rule_search_config or {})
        result = searcher.search(
            seed_train_df=clue_df, baseline_df=baseline_df,
            hard_negative_df=hard_negative_df, candidate_stats=candidate_stats,
            baseline_scale_factor=baseline_scale_factor, verbose=verbose,
        )
        # searcher.search() 已返回 {"signatures": [...], "search_mode": ..., "score_mode": ...}
        # 直接透传，不再调 _signatures_from_combos（已在 multistart_greedy 内部构建，含 root_predicate 等）
        result["score_mode"] = score_mode
        return result

    max_combo_size = config.get("max_combo_size", 6)
    top_m_per_layer = config.get("top_m_per_layer", 100)
    base_min_hit = config.get("base_min_hit", 20)
    min_coverage_ratio = config.get("min_coverage_ratio", 0.01)
    min_accuracy = config.get("min_accuracy", 0.85)
    min_recall = config.get("min_recall", 0.05)
    top_k_combos = config.get("top_k_combos", 16)
    eval_batch_size = int(config.get("eval_batch_size", 150))
    eval_parallel_threads = int(config.get("eval_parallel_threads", 1))
    if score_mode not in (SCORE_MODE_V_SCORE, SCORE_MODE_RECALL_GATED):
        raise ValueError(f"未知的 rule_mining.score_mode: {score_mode!r}（合法取值: "
                         f"{SCORE_MODE_V_SCORE!r} / {SCORE_MODE_RECALL_GATED!r} / "
                         f"{SCORE_MODE_MULTISTART_GREEDY!r}）")
    gate_max_recall_accounts = int(config.get("gate_max_recall_accounts", 50000))
    prune_dominated_flag = bool(config.get("prune_dominated", True))
    preserve_roots = bool(config.get("preserve_roots", True))

    if not candidate_stats:
        raise ValueError("candidate_stats 为空，无法开展组合搜索（请检查 Predicate 初筛阈值是否过严）")

    clue_df = clue_df.cache()
    baseline_df = baseline_df.cache()
    clue_total = clue_df.count()
    baseline_total = baseline_df.count()
    if clue_total == 0:
        raise ValueError("clue_df 账号数为0，无法开展组合搜索")

    min_hit_threshold = max(base_min_hit, int(clue_total * min_coverage_ratio))

    # 候选池按初筛时的 lift 降序，作为组合搜索时"优先尝试哪个候选"的顺序依据
    candidate_predicates = [s.predicate for s in candidate_stats]

    # 第1层：每个候选 Predicate 单独成组合
    layer1_combos = [(p,) for p in candidate_predicates]
    layer_results = _batch_evaluate_combos(clue_df, baseline_df, layer1_combos,
                                            clue_total, baseline_total, baseline_scale_factor,
                                            batch_size=eval_batch_size,
                                            parallel_threads=eval_parallel_threads)
    layer_results = [r for r in layer_results if r.clue_hit_count >= min_hit_threshold]
    layer_results.sort(key=lambda r: _score_tuple(r, score_mode), reverse=True)

    if verbose:
        print(f"[rule_mining] 第1层: 候选{len(layer1_combos)} -> 存活{len(layer_results)}"
              f"（min_hit_threshold={min_hit_threshold}）")

    # 【空 baseline 快捷路径】baseline_total==0 时（如 sample_as_seed 模式下 EXCLUDED=0
    # 且尚未接入真实大盘 baseline）：任意组合的 baseline_hit≡0 → precision≡1 →
    # v_score=2·recall/(1+recall) 只是 recall 的单调函数；而 AND 组合只会收窄命中集
    # （recall 不超过任一成员子集），第 2~max_combo_size 层的暴力搜索
    # （每层 top_m×候选池 ≈ 数万组合、近千个 Spark action）不可能产出比
    # "单条件按 v_score(=recall序) 取 top_k"更优的规则，单条件版本还更简洁可解释。
    # 直接返回第1层结果，跳过必然浪费的多层搜索。
    # 注意：这不解决区分度问题——本分支产出的规则仅有"团伙共性刻画"意义，
    # precision/lift/大盘反证要恢复意义需接入真实大盘 baseline。
    if baseline_total == 0 and layer_results:
        print("[WARN] baseline_df 为空（baseline_total=0）：precision/lift 无区分度，"
              "已启用空 baseline 快捷路径，直接产出覆盖率最高的单条件规则"
              "（跳过分层组合搜索）。若需区分度/误伤评估，请先接入真实大盘 baseline。")
        final_combos = layer_results[:top_k_combos]
        print(f"[INFO] 规则挖掘完成（空 baseline 快捷路径），产出 {len(final_combos)} 个候选规则（单条件）")
        return {"signatures": _signatures_from_combos(final_combos),
                "search_mode": "empty_baseline_single_only",
                "score_mode": score_mode}

    finalized: List[RuleCombo] = []   # 已达标（不再继续扩展）的组合

    # recall_gated 模式：单条件过闸即直接入候选——单特征若误伤在预算内，
    # 本身就是最简规则（如"75% 覆盖 / 3.4 万误伤"的 version 类特征）；
    # 同时保留在存活集里继续扩展（它的子组合可能更干净）。
    # v_score 模式维持历史行为：单条件不直接 finalize，只作为扩展起点。
    if score_mode == SCORE_MODE_RECALL_GATED:
        finalized.extend(
            r for r in layer_results
            if _should_finalize(r, score_mode, min_accuracy, min_recall,
                                gate_max_recall_accounts, baseline_scale_factor)
        )
        if verbose and finalized:
            print(f"[rule_mining] 第1层: {len(finalized)} 个单条件过闸"
                  f"（scaled大盘命中 <= {gate_max_recall_accounts}），直接入选并继续参与扩展")

    # 第1层存活沿用全局 top_m 截断，不做保根：第1层全是单条件，保根会把 top_m 之外的
    # 每个根全部补回（存活集=整个候选池，top_m 截断形同虚设）；且被截掉的特征在第2层
    # 扩展时仍会作为"被添加的条件"参与配对，从第2层开始保根即可完成灭根救援
    survivors = layer_results[:top_m_per_layer]

    for depth in range(2, max_combo_size + 1):
        if not survivors:
            break

        # 生成下一层候选：每个存活组合尝试添加一个候选池中未使用过的 Predicate
        next_combos = []
        for combo in survivors:
            used = combo.combo_key()
            for p in candidate_predicates:
                if p in used:
                    continue
                next_combos.append(combo.predicates + (p,))

        if not next_combos:
            break

        # 组合去重：不同存活组合 + 不同候选可能生成相同的最终组合（顺序不同但集合相同）
        seen = set()
        deduped_combos = []
        for c in next_combos:
            key = frozenset(c)
            if key in seen:
                continue
            seen.add(key)
            deduped_combos.append(c)

        evaluated = _batch_evaluate_combos(clue_df, baseline_df, deduped_combos,
                                            clue_total, baseline_total, baseline_scale_factor,
                                            batch_size=eval_batch_size,
                                            parallel_threads=eval_parallel_threads)
        # 反单调剪枝：新增条件只会让命中范围更窄，若已低于最小命中数阈值直接丢弃
        evaluated = [r for r in evaluated if r.clue_hit_count >= min_hit_threshold]
        # 注：此处不做支配剪枝——同层组合 size 全相同，严格子集关系不可能成立，
        # 层内调用 _prune_dominated 恒为 no-op；支配剪枝只在终选（混合 size）时进行
        evaluated.sort(key=lambda r: _score_tuple(r, score_mode), reverse=True)

        if verbose:
            print(f"[rule_mining] 第{depth}层: 候选{len(deduped_combos)} -> 存活{len(evaluated)}")

        next_survivors = []
        for r in evaluated:
            if _should_finalize(r, score_mode, min_accuracy, min_recall,
                                gate_max_recall_accounts, baseline_scale_factor):
                finalized.append(r)
            else:
                next_survivors.append(r)
        survivors = _select_survivors(next_survivors, top_m_per_layer,
                                       candidate_predicates, preserve_roots)

    # 收尾：把搜索结束时仍未达标、但仍是"存活"状态的最优组合也纳入候选（而非直接丢弃），
    # 因为它们可能是"精度接近但recall不足"或"recall达标但精度略低"的次优解，
    # 最终是否采纳交给 rule_validation/rule_selection 阶段基于验证集统一决策
    finalized.extend(survivors)

    # recall_gated 契约：产出必须全部过闸。搜索期不剪闸是为了让超闸高覆盖组合继续
    # 扩展出过闸子代（闸门非反单调安全）；但末层 survivors 兜底会把超闸组合带进终选池，
    # 且 recall 主键排序会让它们排在过闸组合之前抢占 top_k 名额——因此终选前显式过滤。
    if score_mode == SCORE_MODE_RECALL_GATED:
        before_gate = len(finalized)
        finalized = [r for r in finalized
                     if _passes_gate(r, gate_max_recall_accounts, baseline_scale_factor)]
        if verbose and len(finalized) < before_gate:
            print(f"[rule_mining] 终选闸门过滤: {before_gate} -> {len(finalized)}"
                  f"（剔除 scaled大盘命中 > {gate_max_recall_accounts} 的组合）")

    if not finalized:
        # Fallback：全程没有任何存活组合（候选池过小/阈值过严导致第1层就全军覆没；
        # recall_gated 下还可能是所有组合均超闸——闸门设得过严），
        # 退化返回第1层里分数最高的单条，保证挖掘流程始终有可解释产出
        # （该回退结果可能未过闸，下游 rule_validation 会如实拒掉并给出原因）
        if layer_results:
            finalized = [layer_results[0]]
            print("[WARN] 未搜索到满足条件的组合，已回退为第1层最优单条件规则"
                  + ("（注意：全部组合均超闸，该回退结果可能未过闸，"
                     "如需更大覆盖请调大 gate_max_recall_accounts）"
                     if score_mode == SCORE_MODE_RECALL_GATED else ""))
        else:
            raise ValueError("规则挖掘未产出任何候选规则，请检查 min_hit_threshold 阈值"
                              "或候选 Predicate 质量（clue_support/baseline_support/lift 初筛是否过严）")

    # 终选支配剪枝：剔除被同命中子集支配的冗余组合（如 4/5 条件的同义堆叠）
    if prune_dominated_flag:
        before = len(finalized)
        finalized = _prune_dominated(finalized)
        if verbose and len(finalized) < before:
            print(f"[rule_mining] 支配剪枝: {before} -> {len(finalized)}（剔除同命中冗余组合）")

    # 去重（不同层级/路径可能产出集合相同的组合）+ 按评分排序 + 截取 top_k_combos
    unique_by_key = {}
    for r in finalized:
        key = r.combo_key()
        if key not in unique_by_key or _score_tuple(r, score_mode) > _score_tuple(unique_by_key[key], score_mode):
            unique_by_key[key] = r
    final_combos = sorted(unique_by_key.values(),
                          key=lambda r: _score_tuple(r, score_mode), reverse=True)[:top_k_combos]

    print(f"[INFO] 规则挖掘完成，最终产出 {len(final_combos)} 个候选规则（组合）"
          f"（score_mode={score_mode}）")
    return {"signatures": _signatures_from_combos(final_combos),
            "search_mode": "layered",
            "score_mode": score_mode}


def _signatures_from_combos(final_combos: List[RuleCombo]) -> List[Dict]:
    """把最终组合列表包装成统一的 signatures 结构（正常路径与空 baseline 快捷路径共用）。"""
    signatures = []
    for combo in final_combos:
        signatures.append({
            "features": [p.to_readable() for p in combo.predicates],
            "combo": combo,
            "metrics": {
                "precision": combo.precision,
                "recall": combo.recall,
                "v_score": combo.v_score,
                "clue_hit_count": combo.clue_hit_count,
                "baseline_hit_count": combo.baseline_hit_count,
                "combo_size": combo.size,
            },
        })
    return signatures
