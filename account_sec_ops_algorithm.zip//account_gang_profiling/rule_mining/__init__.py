# -*- coding: utf-8 -*-
"""
规则挖掘算法：分层组合搜索 + 反单调剪枝 + 批量聚合

包含：
- 分层组合生成（C(N,2) -> C(N,K)）
- 批量聚合评估（PySpark 一次 agg 算完多个组合的指标，替代逐组合 count）
- Apriori 式反单调剪枝（Top-M 存活候选进入下一层）
"""

from .combo_search import (
    RuleCombo,
    build_feature_combinations,
)
from .multistart_greedy import MultiStartGreedySearcher
from .searcher_base import RuleSearcher
