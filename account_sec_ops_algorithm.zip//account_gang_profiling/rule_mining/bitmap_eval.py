# -*- coding: utf-8 -*-
"""
位图预计算：用 Predicate.to_column() 在 Spark 上批量算每个谓词在
seed_train / baseline / hard_negative 三个账号集合上的命中 account_id，
collect 后构建 numpy packed-bit 位图。

设计要点：
- 批量 collect：一次 agg 把一批谓词各包成 F.collect_list(F.when(cond, account_id))，
  一次 action 拿全批命中账号列表，避免逐谓词 filter().collect()。
- 账号空间独立：seed/baseline/hard_neg 三套 AccountIndex 各建一份，同一谓词三张位图。
- Predicate 复用 predicates/predicate.py 的 to_column()，不重写算子语义。
"""

from typing import Dict, List, Optional

import numpy as np
from pyspark.sql import DataFrame, functions as F

from account_gang_profiling.predicates.generator import PredicateStats
from account_gang_profiling.predicates.predicate import Predicate
from account_gang_profiling.rule_mining.bitset import (
    AccountIndex, build_account_index, bitmap_from_positions, empty_bitmap, popcount,
)

_ACCOUNT_ID_COL = "account_id"


class BitmapSet:
    """三集合位图集合：每个 Predicate 在 seed/baseline/hard_neg 上各一张位图。"""

    __slots__ = ("seed_index", "baseline_index", "hardneg_index",
                 "seed_bitmaps", "baseline_bitmaps", "hardneg_bitmaps",
                 "seed_total", "baseline_total")

    def __init__(self, seed_index, baseline_index, hardneg_index,
                 seed_bitmaps, baseline_bitmaps, hardneg_bitmaps,
                 seed_total, baseline_total):
        self.seed_index = seed_index
        self.baseline_index = baseline_index
        self.hardneg_index = hardneg_index
        self.seed_bitmaps = seed_bitmaps            # Dict[Predicate, np.ndarray]
        self.baseline_bitmaps = baseline_bitmaps
        self.hardneg_bitmaps = hardneg_bitmaps
        self.seed_total = seed_total
        self.baseline_total = baseline_total

    def seed_hit(self, p: Predicate) -> int:
        return popcount(self.seed_bitmaps[p])

    def baseline_hit(self, p: Predicate) -> int:
        return popcount(self.baseline_bitmaps[p])

    def hardneg_hit(self, p: Predicate) -> int:
        return popcount(self.hardneg_bitmaps[p])


def _collect_hit_account_ids_batch(df: DataFrame, predicates: List[Predicate],
                                    batch_size: int = 200) -> Dict[Predicate, List[str]]:
    """
    批量收集每个谓词在 df 上命中的 account_id 列表。
    一次 agg 把 batch_size 个谓词各包成 collect_list(when(cond, account_id))，
    把 action 次数从 N 压到 ceil(N/batch_size)。
    """
    # 不 select 砍列：p.to_column() 需引用原始特征列，agg 在原 df 上做
    results: Dict[Predicate, List[str]] = {}
    batches = [predicates[i:i + batch_size] for i in range(0, len(predicates), batch_size)]
    for batch in batches:
        aggs = []
        for j, p in enumerate(batch):
            cond = p.to_column()
            aggs.append(F.collect_list(F.when(cond, F.col(_ACCOUNT_ID_COL))).alias(f"hit_{j}"))
        row = df.agg(*aggs).collect()[0]
        for j, p in enumerate(batch):
            ids = row[f"hit_{j}"] or []
            results[p] = list(ids)
    return results


def build_bitmap_set(seed_train_df: DataFrame, baseline_df: DataFrame,
                     hard_negative_df: Optional[DataFrame],
                     candidate_stats: List[PredicateStats],
                     batch_size: int = 200) -> BitmapSet:
    """
    预计算所有候选谓词在三个账号集合上的位图。

    Args:
        seed_train_df: 种子训练集（正样本），需含 account_id 列
        baseline_df: 大盘抽样（背景），需含 account_id 列
        hard_negative_df: 已知负样本（白名单+高质量），可为 None（退化为空位图）
        candidate_stats: 候选谓词及其初筛指标
        batch_size: 批量 agg 的批大小

    Returns:
        BitmapSet
    """
    predicates: List[Predicate] = [s.predicate for s in candidate_stats]

    # 三套账号索引
    seed_ids = [r[0] for r in seed_train_df.select(_ACCOUNT_ID_COL).collect()]
    baseline_ids = [r[0] for r in baseline_df.select(_ACCOUNT_ID_COL).collect()]
    if hard_negative_df is not None:
        hardneg_ids = [r[0] for r in hard_negative_df.select(_ACCOUNT_ID_COL).collect()]
    else:
        hardneg_ids = []

    seed_index = build_account_index(seed_ids)
    baseline_index = build_account_index(baseline_ids)
    hardneg_index = build_account_index(hardneg_ids)

    # 批量收集命中账号
    seed_hits = _collect_hit_account_ids_batch(seed_train_df, predicates, batch_size)
    baseline_hits = _collect_hit_account_ids_batch(baseline_df, predicates, batch_size)
    if hard_negative_df is not None:
        # hard_negative_df 只含 account_id（已知负样本账号列表），无特征列。
        # 它是 baseline 的子集——join 回 baseline_df 拿特征列，得到 hard_neg 账号的特征视图。
        hn_with_features = hard_negative_df.join(baseline_df, on=_ACCOUNT_ID_COL, how="inner")
        hardneg_hits = _collect_hit_account_ids_batch(hn_with_features, predicates, batch_size)
    else:
        hardneg_hits = {p: [] for p in predicates}

    # 构建位图
    seed_bitmaps: Dict[Predicate, np.ndarray] = {}
    baseline_bitmaps: Dict[Predicate, np.ndarray] = {}
    hardneg_bitmaps: Dict[Predicate, np.ndarray] = {}
    for p in predicates:
        seed_bitmaps[p] = bitmap_from_positions(seed_index.positions(seed_hits[p]),
                                                 seed_index.n_words)
        baseline_bitmaps[p] = bitmap_from_positions(baseline_index.positions(baseline_hits[p]),
                                                     baseline_index.n_words)
        hardneg_bitmaps[p] = bitmap_from_positions(hardneg_index.positions(hardneg_hits[p]),
                                                   hardneg_index.n_words)

    return BitmapSet(seed_index, baseline_index, hardneg_index,
                     seed_bitmaps, baseline_bitmaps, hardneg_bitmaps,
                     seed_total=seed_index.size, baseline_total=baseline_index.size)
