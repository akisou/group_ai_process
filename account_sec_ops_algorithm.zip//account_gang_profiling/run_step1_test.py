# -*- coding: utf-8 -*-
"""
step1~step6 全链路冒烟入口（MLP / spark-submit 提交用）。

跑到 step6（最终规则集选择），验证全链路：
- step1/1b 读预建表、step2 种子分类、step3 谓词生成、step4 挖掘
- step4b 团伙校验（4 级判定）、step5 规则验证、step6 规则选择
- 表4 recall 捞全已暂停（recall_enabled=false，避免全量扫描 OOM）

用法：
    spark-submit --master yarn account_gang_profiling/run_step1_test.py --dt 20260824 --case_id 13081820

用法（MLP / spark-submit）：
    spark-submit --master yarn account_gang_profiling/run_step1_test.py \
        --dt 20260824 --case_id 13081820

参数（与 pipeline.py 同名同义，下划线别名兼容 MLP 全局变量自动追加）：
    --dt          运行日期（今天），对应预建表 dt 分区（非 T-2 数据日期）  [必填]
    --case-id/--case_id      CASE 编号，定位 app_acc_sec_case_snapshot 的 case_id 分区  [必填]
    --config-path/--config_path  config.yaml 路径，默认包内 account_gang_profiling/config/config.yaml
                                  （集群 zip 内 open 不了 → 用 --files ship + 显式传此参数）

说明：本模块全程 Spark DataFrame API（无 executor 端 Python 闭包），
不需要 --py-files 分发整个包，driver 端能 import 到 account_gang_profiling 即可
（在项目根目录下提交）。
"""

import argparse
import os
import sys
import time

# spark-submit 直接运行本文件时，脚本所在目录是 account_gang_profiling/ 而非项目根目录，
# 需把项目根目录加入 sys.path，否则 `from account_gang_profiling.xxx import` 找不到顶层包。
_project_root = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
if _project_root not in sys.path:
    sys.path.insert(0, _project_root)

from pyspark.sql import SparkSession

from account_gang_profiling.pipeline import (
    step1_build_snapshot, step1b_build_market_baseline,
    step2_seed_split, step3_generate_predicates, step4_mine_rules,
    step4b_validate_gang, step5_validate_rules, step6_select_rules,
)


def main():
    parser = argparse.ArgumentParser(description="step1+step1b 冒烟测试（读预建表）")
    parser.add_argument("--dt", type=str, required=True,
                        help="运行日期（今天），对应预建表 dt 分区，如 20260824")
    parser.add_argument("--case-id", "--case_id", dest="case_id", type=str, required=True,
                        help="CASE 编号，定位 app_acc_sec_case_snapshot 的 case_id 分区。"
                             "下划线别名 --case_id 兼容 MLP 全局变量自动追加")
    parser.add_argument("--config-path", "--config_path", dest="config_path", type=str, default=None,
                        help="config.yaml 路径。默认包内 account_gang_profiling/config/config.yaml"
                             "（集群 zip 里 open 不了 → 用 --files ship + 显式传此参数）。"
                             "下划线别名 --config_path 兼容 MLP 全局变量追加")
    args, unknown = parser.parse_known_args()
    if unknown:
        print(f"[WARN] 忽略未识别的命令行参数: {unknown}")

    # 版本号（build 脚本注入 _version.py；据此确认跑的是哪个 commit）
    try:
        from account_gang_profiling._version import COMMIT, BRANCH
    except Exception:
        COMMIT, BRANCH = "no-_version-module", "no-_version-module"

    # ============ 输出主程序及入参、全局变量 ============
    print("=" * 80)
    print("[MAIN] step1~step6 全链路冒烟测试入口")
    print("=" * 80)
    print(f"[VERSION] git_commit={COMMIT} git_branch={BRANCH}")
    print(f"[ARGS] dt={args.dt}")
    print(f"[ARGS] case_id={args.case_id}")
    print(f"[ARGS] config_path={args.config_path or '(默认包内 config.yaml)'}")
    print(f"[ENV] PYTHONPATH={os.environ.get('PYTHONPATH', '(未设)')}")
    print(f"[ENV] _project_root={_project_root}")
    print(f"[ENV] sys.path[0]={sys.path[0]}")
    print(f"[GLOBAL] 预建表: ba_rc.app_acc_sec_case_snapshot (case_id+dt 双分区)")
    print(f"[GLOBAL] 预建表: ba_rc.app_acc_sec_baseline_snapshot_set (dt 单分区)")
    print(f"[GLOBAL] dt 语义=运行日期今天, 数据口径 T-2(由 xt 任务 date_sub(2) 实现)")
    print("=" * 80)

    start_time = time.time()
    print(f"[INFO] 开始初始化 SparkSession (Hive支持)")
    try:
        spark = SparkSession.builder.enableHiveSupport().getOrCreate()
    except Exception as e:
        print(f"[ERROR] Spark/Hive 初始化失败（本地无法运行，需集群/网关机提交）: {e}")
        sys.exit(1)

    # ---- step1: 读 CASE 快照 ----
    ctx = step1_build_snapshot(
        spark, dt=args.dt, case_id=args.case_id, config_path=args.config_path,
    )

    print("\n" + "=" * 80)
    print("[RESULT] step1 结果")
    print("=" * 80)
    # count 用单独 SQL（不物化 535 列，否则 df.count() 读全列 OOM）
    _snap_cnt = spark.sql(
        "SELECT count(*) FROM ba_rc.app_acc_sec_case_snapshot "
        f"WHERE case_id = '{args.case_id}' AND dt = '{args.dt}'"
    ).first()[0]
    print(f"snapshot 账号数: {_snap_cnt}")
    print(f"特征列数: {len(ctx['snapshot_df'].columns)}")
    print("snapshot schema（前30列，LIMIT 0 不读数据）:")
    for field in ctx["snapshot_df"].limit(0).schema.fields[:30]:
        print(f"    - {field.name}: {field.dataType.simpleString()}")

    # ---- step1b: 读大盘 baseline ----
    ctx = step1b_build_market_baseline(ctx)

    print("\n" + "=" * 80)
    print("[RESULT] step1b 结果")
    print("=" * 80)
    _base_cnt = spark.sql(
        f"SELECT count(*) FROM ba_rc.app_acc_sec_baseline_snapshot_set WHERE dt = '{args.dt}'"
    ).first()[0]
    print(f"baseline 账号数: {_base_cnt}")
    print(f"baseline_scale_factor: {ctx['baseline_scale_factor']}")
    print("baseline schema（前30列，LIMIT 0 不读数据）:")
    for field in ctx["baseline_snapshot_df"].limit(0).schema.fields[:30]:
        print(f"    - {field.name}: {field.dataType.simpleString()}")

    # ---- 抽几行看内容（只 select 必要列，ORC 列裁剪）----
    print("\n" + "=" * 80)
    print("[SAMPLE] snapshot 前5行（account_id + 部分列）")
    print("=" * 80)
    ctx["snapshot_df"].select("account_id", "sel_uuid_set", "act_mt_member_level").show(5, truncate=False)

    print("[SAMPLE] baseline 前5行（account_id）")
    ctx["baseline_snapshot_df"].select("account_id").show(5, truncate=False)

    # ---- step2: 种子分类 + 训练/验证切分 ----
    ctx = step2_seed_split(ctx)

    print("\n" + "=" * 80)
    print("[RESULT] step2 结果")
    print("=" * 80)
    print(f"train_seed_df: {ctx['train_seed_df'].count()}")
    print(f"validation_seed_df: {ctx['validation_seed_df'].count()}")
    print(f"full_seed_df: {ctx['full_seed_df'].count()}")
    print(f"baseline_df: {ctx['baseline_df'].count()}")
    print(f"hard_negative_df: {ctx['hard_negative_df'].count()}")
    print(f"full_seed_count: {ctx['full_seed_count']}")

    # ---- step3: 生成候选 Predicate ----
    ctx = step3_generate_predicates(ctx)

    print("\n" + "=" * 80)
    print("[RESULT] step3 结果")
    print("=" * 80)
    _cand = ctx["candidate_stats"]
    print(f"候选 Predicate 总数: {len(_cand)}")
    if _cand:
        print("Top 10（按 lift 降序）:")
        for s in sorted(_cand, key=lambda x: x.lift, reverse=True)[:10]:
            print(f"    - {s.predicate.to_readable()}: clue_support={s.clue_support:.2%}, "
                  f"baseline_support={s.baseline_support:.2%}, lift={s.lift:.2f}, "
                  f"clue_hit={s.clue_hit_count}, baseline_hit={s.baseline_hit_count}")

    # ---- step4: 规则挖掘 ----
    ctx = step4_mine_rules(ctx)

    print("\n" + "=" * 80)
    print("[RESULT] step4 结果")
    print("=" * 80)
    _combos = ctx["candidate_combos"]
    print(f"候选规则组合数: {len(_combos)}")
    if _combos:
        print("全部候选规则（按 v_score 降序）:")
        for sig in ctx["mining_result"]["signatures"]:
            m = sig["metrics"]
            root_pool = sig.get("root_pool", "")
            print(f"    - [{m['combo_size']}条] {' AND '.join(sig['features'])}")
            print(f"        pool={root_pool} precision={m['precision']:.2%}, recall={m['recall']:.2%}, "
                  f"v_score={m['v_score']:.4f}, clue_hit={m['clue_hit_count']}, "
                  f"baseline_hit={m['baseline_hit_count']}")

    # ---- step4b: 团伙校验（4 级判定）----
    ctx = step4b_validate_gang(ctx)

    print("\n" + "=" * 80)
    print("[RESULT] step4b 结果（团伙校验 4 级判定）")
    print("=" * 80)
    _verdicts = ctx.get("gang_validation_results")
    if _verdicts:
        from collections import Counter
        level_cnt = Counter(v.level for v in _verdicts)
        print(f"判定分布: 强确认={level_cnt.get('STRONG',0)}, 高风险={level_cnt.get('HIGH_RISK',0)}, "
              f"可疑={level_cnt.get('SUSPECT',0)}, 不可用={level_cnt.get('UNUSABLE',0)}")
        print("逐条判定:")
        for v in _verdicts:
            combo = ctx["candidate_combos"][int(v.combo_id[1:])]
            label = " AND ".join(p.to_readable() for p in combo.predicates)
            print(f"    - {v.combo_id} [{label}]")
            print(f"        → {v.level} (L2_count={v.l2_count}, injury={'✓' if v.injury_pass else '✗'})")
            for r in v.reasons[:3]:
                print(f"        reason: {r}")
    else:
        print("（step4b 未产出判定——gang_validation.enabled=false 或 candidate_combos 为空）")

    # ---- step5: 规则验证（泛化 + 大盘反证 + 4级判定）----
    ctx = step5_validate_rules(ctx)

    print("\n" + "=" * 80)
    print("[RESULT] step5 结果（规则验证）")
    print("=" * 80)
    _vresults = ctx.get("validation_results") or []
    _passed = sum(1 for r in _vresults if r.passed)
    print(f"通过验证: {_passed}/{len(_vresults)} 条")
    for i, r in enumerate(_vresults):
        combo = r.combo
        label = " AND ".join(p.to_readable() for p in combo.predicates)
        print(f"    - c{i:03d} [{'PASS' if r.passed else 'FAIL'}] [{label}]")
        print(f"        泛化率={r.generalization_ratio:.2%} (train_recall={r.train_recall:.2%}/val_recall={r.validation_recall:.2%}), "
              f"大盘回捞={r.baseline_recall_count}(×{r.baseline_recall_multiplier:.1f}), "
              f"risk_concentration={r.risk_concentration:.2%}")
        for reason in r.reasons[:3]:
            print(f"        reason: {reason}")

    # ---- step6: 最终规则集选择 ----
    ctx = step6_select_rules(ctx)

    print("\n" + "=" * 80)
    print("[RESULT] step6 结果（最终规则集）")
    print("=" * 80)
    _sel = ctx.get("selection_result") or {}
    _final = _sel.get("final_rules") or []
    print(f"最终规则数: {len(_final)}，覆盖率: {_sel.get('total_coverage_ratio', 0):.2%}"
          f"（{_sel.get('total_coverage_ratio', 0) * _sel.get('total_seed_count', 0):.0f}/"
          f"{_sel.get('total_seed_count', 0)} 种子账号）")
    for i, rule in enumerate(_final, 1):
        combo = rule.validation_result.combo
        print(f"  {i}. {combo.to_readable()}")
        print(f"     precision={combo.precision:.2%}, recall={combo.recall:.2%}, "
              f"命中={combo.clue_hit_count}, 新增覆盖={rule.marginal_new_coverage}")

    print(f"\n[DONE] step1~step6 全链路冒烟测试完成，总耗时 {time.time() - start_time:.1f}秒")


if __name__ == "__main__":
    main()
