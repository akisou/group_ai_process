#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
账号级团伙特征识别 - 本地冒烟测试（无需 Hive，不依赖真实集群）

【用途】
- 用 Spark local[*] 模式 + 手工构造的模拟账号特征大宽表，跑通
  seed_split -> predicates -> rule_mining -> rule_validation -> rule_selection
  全链路，验证代码逻辑本身没有问题（语法、Spark API 用法、模块间数据流转）。
- 不会、也不能验证真实业务效果——模拟数据是随机生成的，产出的"规则"没有实际业务意义，
  只用于回归测试：每次改动 predicates/rule_mining/rule_validation/rule_selection 等
  核心算法代码后，跑一遍本脚本确认没有引入新的报错或明显的逻辑错误。

【为什么不能直接跑 pipeline.py 里的 step1_build_snapshot】
pipeline.step1 现在直接读 ba_rc.app_acc_sec_case_snapshot（美团内部 Hive 表），
本地个人开发环境既没有 Hive metastore 也没有内网权限访问，
因此本脚本绕开 step1，直接从 seed_split 阶段开始，
自行构造一个字段结构与真实大宽表兼容（同样的列名前缀、同样的字段类型分类）的模拟 DataFrame。

【使用方法】
    python3 account_gang_profiling/test_pipeline_local.py
（需要本地已安装 pyspark，如未安装先执行: python3 -m pip install pyspark）

【真实业务数据的运行方式】
必须提交到有权限访问 mart_mtsi.*/ba_rc.* 内部表的 Spark 集群/网关机：
    spark-submit account_gang_profiling/pipeline.py --dt <分区日期，如20260726>
"""

import os
import random
import sys

_project_root = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
if _project_root not in sys.path:
    sys.path.insert(0, _project_root)

from pyspark.sql import SparkSession, functions as F
from pyspark.sql.types import (
    StructType, StructField, StringType, IntegerType, DoubleType, ArrayType,
)

from account_gang_profiling.feature_snapshot.seed_split import (
    build_seed_and_split, SEED_CORE, SEED_WEAK, SEED_EXCLUDED, SPLIT_TRAIN, SPLIT_VALIDATION,
)
from account_gang_profiling.feature_snapshot.field_types import infer_field_categories_from_schema
from account_gang_profiling.predicates import generate_candidate_predicates
from account_gang_profiling.rule_mining import build_feature_combinations
from account_gang_profiling.rule_validation import validate_rules
from account_gang_profiling.rule_selection import select_final_rules


# 模拟测试专用配置：阈值刻意放宽（相对 config.yaml 生产默认值），
# 因为模拟数据规模小（几千账号）且是随机生成，若沿用生产阈值（如 min_lift=10）很容易
# 在小样本上一个候选都筛不出来，导致冒烟测试本身失去意义（无法覆盖到后续阶段的代码路径）
_TEST_CONFIG = {
    "seed_classification": {"high_conf_threshold": 0.8, "low_conf_threshold": 0.5, "min_seed_size": 100},
    "dataset_split": {"train_ratio": 0.8, "min_generalization_ratio": 0.5},
    "predicate_generation": {
        "numeric_quantiles": [0.5, 0.7, 0.9], "min_clue_support": 0.1,
        "max_baseline_support": 0.05, "min_lift": 3.0,
    },
    "rule_mining": {
        "max_combo_size": 3, "top_m_per_layer": 20, "base_min_hit": 20,
        "min_coverage_ratio": 0.01, "min_accuracy": 0.8, "min_recall": 0.1, "top_k_combos": 10,
    },
    "rule_validation": {
        "max_recall_accounts": 2000, "max_recall_multiplier": 50.0,
        "max_whitelist_hit_rate": 0.3, "max_hq_account_hit_rate": 0.3,
        "min_risk_concentration": 0.3, "min_generalization_ratio": 0.3,
    },
    "rule_selection": {"max_rules": 5, "min_total_coverage": 0.5, "similarity_threshold": 0.8},
}


def _build_mock_snapshot_df(spark: SparkSession, gang_size: int = 800, normal_size: int = 5000):
    """
    构造与真实账号特征大宽表字段结构兼容的模拟 DataFrame：
    - act_ 前缀字段：模拟 user_active 表（含 risk_score 计算依赖的原始信号列）
    - sel_ 前缀字段：模拟 strong_end_login 表聚合后的 _cntd/_set 字段

    团伙账号（gang_）：高概率命中CASE + 高人机风险分 + 集中使用少数几个设备型号 + 高ip_cntd
    正常账号（normal_）：几乎不命中CASE/线索，风险分低，设备型号分散
    """
    schema = StructType([
        StructField("account_id", StringType()),
        StructField("act_is_mtsi_case_user", IntegerType()),
        StructField("act_is_mtsi_clue_user", IntegerType()),
        StructField("act_mtsi_case_cntd", DoubleType()),
        StructField("act_mtsi_clue_cntd", DoubleType()),
        StructField("act_mt_man_machine_risk_score", DoubleType()),
        StructField("act_dp_man_machine_risk_score", DoubleType()),
        StructField("act_is_on_job_employee", IntegerType()),
        StructField("act_is_company_high_value_user", IntegerType()),
        StructField("act_is_high_impact_user", IntegerType()),
        StructField("act_mt_member_level", StringType()),
        StructField("sel_ip_cntd", DoubleType()),
        StructField("sel_dm_set", ArrayType(StringType())),
    ])

    rows = []
    gang_devices = ["iPhone13ProMax", "Redmi9", "HonorX10"]
    for i in range(gang_size):
        rows.append((
            f"gang_{i}",
            1 if random.random() < 0.9 else 0,
            1,
            float(random.randint(1, 5)),
            float(random.randint(1, 5)),
            float(random.randint(70, 100)),
            float(random.randint(70, 100)),
            0, 0, 0,
            "UNKNOWN",
            float(random.randint(20, 50)),
            [random.choice(gang_devices)],
        ))

    normal_devices = [f"device_{j}" for j in range(200)]
    for i in range(normal_size):
        rows.append((
            f"normal_{i}",
            0, 0, 0.0, 0.0,
            float(random.randint(0, 30)),
            float(random.randint(0, 30)),
            1 if random.random() < 0.02 else 0,
            0, 0,
            "gold" if random.random() < 0.05 else "UNKNOWN",
            float(random.randint(0, 5)),
            [random.choice(normal_devices)],
        ))

    return spark.createDataFrame(rows, schema=schema)


def run_local_smoke_test_with_spark(spark: SparkSession) -> dict:
    """
    冒烟测试核心逻辑，接收外部已创建好的 SparkSession，不在内部创建/关闭。

    【适用场景】
    - CodeLab / mtjupyter Notebook：先用 %%spark 魔法命令启动 Spark 会话（平台会自动注入
      名为 spark 的 SparkSession 变量到 Notebook 全局命名空间），再在普通代码 Cell 中调用：

          import sys
          sys.path.insert(0, "/绝对路径/到/项目根目录")   # 保证能 import account_gang_profiling
          from account_gang_profiling.test_pipeline_local import run_local_smoke_test_with_spark
          result = run_local_smoke_test_with_spark(spark)   # spark 变量由 %%spark 注入，直接引用即可

      注意：
        1. 不要在 Notebook 里自己再写 SparkSession.builder...getOrCreate()，
           必须使用 %%spark 注入的 spark 变量，否则会遇到 SparkContext 未初始化
           （AttributeError: 'NoneType' object has no attribute '_jsc'）的报错。
        2. 本函数不会调用 spark.stop()——Notebook 场景下这个 spark 会话是 Jupyter Kernel
           托管的公共资源，后续 Cell 还要复用，函数内部关闭会导致整个 Notebook 的 Spark
           会话报废，需要用户自行决定何时释放（一般是关闭 Notebook / Kernel 时自动释放）。

    Returns:
        与 pipeline.run_account_gang_profiling 一致结构的 dict:
        {"snapshot_df", "candidate_stats", "mining_result", "validation_results", "selection_result"}
    """
    random.seed(42)  # 固定随机种子，保证每次跑冒烟测试结果可复现，便于比较改动前后的差异
    spark.sparkContext.setLogLevel("ERROR")

    print("=" * 80)
    print("[STAGE 0/6] 构造模拟账号特征大宽表（跳过真实 Hive 数据源）")
    print("=" * 80)
    raw_df = _build_mock_snapshot_df(spark)
    print(f"模拟总账号数: {raw_df.count()}")

    print("=" * 80)
    print("[STAGE 1/6] 种子账号分类 + 训练/验证集切分")
    print("=" * 80)
    # 用测试专用配置覆盖默认 config.yaml：直接 monkeypatch load_config，
    # 避免为了测试而写一份磁盘上的 test_config.yaml（保持测试自包含，不产生额外文件）
    import account_gang_profiling.feature_snapshot.seed_split as seed_split_mod
    seed_split_mod.load_config = lambda config_path=None: _TEST_CONFIG

    snapshot_df = build_seed_and_split(raw_df, config_path=None).cache()
    snapshot_df.groupBy("seed_type", "dataset_split").count().show()

    train_seed_df = snapshot_df.filter(
        (F.col("seed_type") == SEED_CORE) & (F.col("dataset_split") == SPLIT_TRAIN))
    validation_seed_df = snapshot_df.filter(
        (F.col("seed_type").isin(SEED_CORE, SEED_WEAK)) & (F.col("dataset_split") == SPLIT_VALIDATION))
    full_seed_df = snapshot_df.filter(F.col("seed_type").isin(SEED_CORE, SEED_WEAK))
    baseline_df = snapshot_df.filter(F.col("seed_type") == SEED_EXCLUDED)

    whitelist_df = snapshot_df.select(
        "account_id",
        F.when(F.col("act_is_on_job_employee") == 1, F.lit(1)).otherwise(F.lit(0)).alias("is_whitelisted"),
    )

    print("=" * 80)
    print("[STAGE 1.5/6] sample_as_seed 种子模式回归")
    print("=" * 80)
    # 验证 seed_classification.mode=sample_as_seed：样本全部 CORE、受保护账号排除、
    # 不产生 WEAK、不触发 compute_risk_score 的必需列校验、常量 risk_score 列补全
    _sas_config = dict(_TEST_CONFIG)
    _sas_config["seed_classification"] = {
        "mode": "sample_as_seed",
        "sample_as_seed": {
            "min_seed_size": 10,
            "protected_account": {
                "use_whitelist_flags": True,
                "member_level_field": "act_mt_member_level",
                "member_level_match": "isin",
                "member_level_protected_values": ["gold"],
            },
        },
    }
    seed_split_mod.load_config = lambda config_path=None: _sas_config
    _sas_df = build_seed_and_split(raw_df, config_path=None)
    _sas_dist = {r["seed_type"]: r["count"] for r in _sas_df.groupBy("seed_type").count().collect()}
    assert _sas_dist.get(SEED_CORE, 0) > 0, "sample_as_seed: CORE_SEED 为空"
    assert _sas_dist.get(SEED_WEAK, 0) == 0, "sample_as_seed: 不应产生 WEAK_SEED"
    assert _sas_dist.get(SEED_EXCLUDED, 0) > 0, "sample_as_seed: 受保护账号排除未生效（gold 会员/员工应被排除）"
    assert "risk_score" in _sas_df.columns and "dataset_split" in _sas_df.columns, \
        "sample_as_seed: 产出 schema 缺少 risk_score/dataset_split 列"
    print(f"  sample_as_seed 分布: {_sas_dist}（CORE 应≈全部团伙+未受保护正常账号）")
    # 恢复 risk_score 模式配置，供后续阶段继续使用
    seed_split_mod.load_config = lambda config_path=None: _TEST_CONFIG

    print("=" * 80)
    print("[STAGE 2/6] 生成候选 Predicate")
    print("=" * 80)
    field_categories = infer_field_categories_from_schema(snapshot_df, declared_category_map={
        "act_is_mtsi_case_user": "boolean", "act_is_mtsi_clue_user": "boolean",
        "act_is_on_job_employee": "whitelist_flag", "act_is_company_high_value_user": "whitelist_flag",
        "act_is_high_impact_user": "whitelist_flag",
    })
    exclude_fields = [
        "act_is_on_job_employee", "act_is_company_high_value_user", "act_is_high_impact_user",
        "risk_score", "seed_type", "dataset_split",
        "act_mtsi_case_cntd", "act_mtsi_clue_cntd", "act_is_mtsi_case_user", "act_is_mtsi_clue_user",
    ]
    candidate_stats = generate_candidate_predicates(
        clue_df=train_seed_df, baseline_df=baseline_df, field_categories=field_categories,
        exclude_fields=exclude_fields, config=_TEST_CONFIG["predicate_generation"],
    )
    assert candidate_stats, "候选 Predicate 为空，冒烟测试未能覆盖后续阶段"
    for s in candidate_stats[:5]:
        print(f"  {s.predicate.to_readable()}: clue_support={s.clue_support:.2%}, "
              f"baseline_support={s.baseline_support:.2%}, lift={s.lift:.1f}")

    print("=" * 80)
    print("[STAGE 3/6] 规则挖掘（分层组合搜索）")
    print("=" * 80)
    mining_result = build_feature_combinations(
        clue_df=train_seed_df, baseline_df=baseline_df, candidate_stats=candidate_stats,
        config=_TEST_CONFIG["rule_mining"], verbose=True,
    )
    assert mining_result["signatures"], "规则挖掘未产出任何候选规则"
    assert mining_result.get("search_mode") == "layered", "正常分层搜索应标记 search_mode=layered"

    print("=" * 80)
    print("[STAGE 3.5/6] 空 baseline 快捷路径回归")
    print("=" * 80)
    # 验证 baseline_total==0 时跳过 2~K 层搜索、直接产出单条件 top_k（与暴力搜索等价且更简洁）
    _empty_result = build_feature_combinations(
        clue_df=train_seed_df, baseline_df=baseline_df.limit(0), candidate_stats=candidate_stats,
        config=_TEST_CONFIG["rule_mining"], verbose=False,
    )
    assert _empty_result["signatures"], "空 baseline 快捷路径未产出任何规则"
    assert _empty_result.get("search_mode") == "empty_baseline_single_only", \
        "空 baseline 应标记 search_mode=empty_baseline_single_only"
    assert all(sig["metrics"]["combo_size"] == 1 for sig in _empty_result["signatures"]), \
        "空 baseline 快捷路径应只产出单条件规则"
    print(f"  快捷路径产出 {len(_empty_result['signatures'])} 条单条件规则（跳过 2~K 层搜索）")

    print("=" * 80)
    print("[STAGE 3.6/6] recall_gated 评分模式回归")
    print("=" * 80)
    # 验证 recall_gated：过闸（scaled大盘命中<=gate）单条件直接入选、终选按 recall 降序、
    # 高覆盖但超闸的特征不会以单条件入选（只能作为组合零件出现）
    _rg_config = dict(_TEST_CONFIG["rule_mining"])
    _rg_config["score_mode"] = "recall_gated"
    _rg_config["gate_max_recall_accounts"] = 50
    _rg_result = build_feature_combinations(
        clue_df=train_seed_df, baseline_df=baseline_df, candidate_stats=candidate_stats,
        config=_rg_config, baseline_scale_factor=1.0, verbose=False,
    )
    assert _rg_result["signatures"], "recall_gated 未产出任何规则"
    assert _rg_result.get("score_mode") == "recall_gated"
    _rg_recalls = [s["metrics"]["recall"] for s in _rg_result["signatures"]]
    assert _rg_recalls == sorted(_rg_recalls, reverse=True), "recall_gated 终选应按 recall 降序"
    for s in _rg_result["signatures"]:
        assert s["metrics"]["baseline_hit_count"] <= 50, \
            f"recall_gated 终选规则必须全部过闸: {s['features']}"
    assert any(s["metrics"]["combo_size"] == 1 for s in _rg_result["signatures"]), \
        "recall_gated 下过闸单条件应能直接入选"
    print(f"  recall_gated 产出 {len(_rg_result['signatures'])} 条规则（全部过闸），"
          f"最高 recall={_rg_recalls[0]:.2%}，含单条件规则 ✓")

    print("=" * 80)
    print("[STAGE 3.7/6] prune_dominated 支配剪枝单元测试")
    print("=" * 80)
    from account_gang_profiling.rule_mining.combo_search import _prune_dominated, RuleCombo
    from account_gang_profiling.predicates.predicate import Predicate, OP_EQ_BOOL
    _p1 = Predicate(field_name="f1", op=OP_EQ_BOOL)
    _p2 = Predicate(field_name="f2", op=OP_EQ_BOOL)
    _p3 = Predicate(field_name="f3", op=OP_EQ_BOOL)
    _a = RuleCombo(predicates=(_p1,), clue_hit_count=100, baseline_hit_count=5,
                   precision=0.95, recall=0.5, v_score=0.64)
    _b = RuleCombo(predicates=(_p1, _p2), clue_hit_count=100, baseline_hit_count=5,
                   precision=0.95, recall=0.5, v_score=0.64)   # 命中与 _a 完全相同且为父集 → 被支配
    _c = RuleCombo(predicates=(_p1, _p3), clue_hit_count=90, baseline_hit_count=5,
                   precision=0.9, recall=0.45, v_score=0.6)    # 命中不同 → 保留
    _kept = _prune_dominated([_a, _b, _c])
    assert len(_kept) == 2 and all(k.predicates != (_p1, _p2) for k in _kept), \
        "支配剪枝应剔除同命中父集组合"
    print("  支配剪枝正确剔除同命中父集组合 ✓")

    print("=" * 80)
    print("[STAGE 3.8/6] multistart_greedy 多起点贪心搜索器回归")
    print("=" * 80)
    # 验证 multistart_greedy：位图求值、根节点分池、Top-K 贪心、产出 List[RuleCombo] 可喂 validator
    from account_gang_profiling.rule_mining.bitmap_eval import build_bitmap_set

    # hard_negative：白名单 ∪ 高质量账号（mock 里 normal 的 gold 会员/员工）
    _hn_df = snapshot_df.filter(
        (F.col("act_is_on_job_employee") == 1)
        | ((F.col("act_mt_member_level").isNotNull())
           & (F.col("act_mt_member_level") != "UNKNOWN")
           & (F.col("act_mt_member_level") != "0"))
    ).select("account_id").distinct()
    _msg_config = dict(_TEST_CONFIG["rule_mining"])
    _msg_config["score_mode"] = "multistart_greedy"
    _msg_rule_search = {
        "root_pools": {
            "high_coverage": {"min_seed_coverage": 0.50, "max_baseline_support": 0.05, "pool_size": 4},
            "high_discrim": {"min_seed_coverage": 0.10, "max_baseline_support": 0.02, "pool_size": 4},
            "risk_anomaly": {"pool_size": 4},
        },
        "root_jaccard_threshold": 0.85,
        "top_k_width": 4, "max_depth": 6,
        "min_seed_accounts": 5, "min_root_retention": 0.5,
        "max_hardneg_growth_vs_root": 1.0,
        "rank_mode": "tiered",
        "lookahead_top_n": 10, "lookahead_min_hardneg_drop": 1, "lookahead_min_baseline_drop": 1,
        "final_gate": {"max_scaled_baseline_hit": 50000, "max_hardneg_hit_rate": 0.5,
                       "min_seed_hit": 5, "min_precision": 0.1},
        "final_max_rules": 16, "min_total_coverage": 0.3,
    }
    _msg_result = build_feature_combinations(
        clue_df=train_seed_df, baseline_df=baseline_df, candidate_stats=candidate_stats,
        config=_msg_config, baseline_scale_factor=1.0, verbose=True,
        hard_negative_df=_hn_df, rule_search_config=_msg_rule_search,
    )
    assert _msg_result.get("search_mode") == "multistart_greedy", "multistart_greedy 应标记 search_mode"
    assert _msg_result["signatures"], "multistart_greedy 未产出任何规则"
    # 位图正确性：单谓词位图 popcount == Spark filter count
    _bs = build_bitmap_set(train_seed_df, baseline_df, _hn_df, candidate_stats)
    _p0 = candidate_stats[0].predicate
    _spark_seed_hit = train_seed_df.filter(_p0.to_column()).count()
    assert _bs.seed_hit(_p0) == _spark_seed_hit, \
        f"位图 seed_hit({ _bs.seed_hit(_p0)}) != Spark 真值({_spark_seed_hit})"
    print(f"  位图正确性: seed_hit({_p0.to_readable()})={_bs.seed_hit(_p0)} == Spark 真值 ✓")
    # 产出的 RuleCombo 字段齐全
    for s in _msg_result["signatures"]:
        m = s["metrics"]
        assert "precision" in m and "recall" in m and "combo" in s
    print(f"  multistart_greedy 产出 {len(_msg_result['signatures'])} 条候选规则 ✓")

    print("=" * 80)
    print("[STAGE 4/6] 规则验证")
    print("=" * 80)
    combos = [sig["combo"] for sig in mining_result["signatures"]]
    validation_results = validate_rules(
        combos=combos, train_seed_df=train_seed_df, validation_seed_df=validation_seed_df,
        baseline_df=baseline_df, whitelist_df=whitelist_df, config=_TEST_CONFIG["rule_validation"],
    )

    print("=" * 80)
    print("[STAGE 5/6] 最终规则集选择")
    print("=" * 80)
    selection_result = select_final_rules(
        results=validation_results, full_seed_df=full_seed_df, config=_TEST_CONFIG["rule_selection"],
    )
    assert selection_result["final_rules"], "最终规则集为空，请检查各阶段阈值/模拟数据"

    print("=" * 80)
    print(f"[PASS] 本地冒烟测试全部通过，最终规则数: {len(selection_result['final_rules'])}, "
          f"覆盖率: {selection_result['total_coverage_ratio']:.2%}")
    print("=" * 80)
    for i, r in enumerate(selection_result["final_rules"], 1):
        combo = r.validation_result.combo
        print(f"{i}. {combo.to_readable()}")
        print(f"   precision={combo.precision:.2%}, recall={combo.recall:.2%}, "
              f"命中账号数={combo.clue_hit_count}, 新增覆盖={r.marginal_new_coverage}")

    return {
        "snapshot_df": snapshot_df,
        "candidate_stats": candidate_stats,
        "mining_result": mining_result,
        "validation_results": validation_results,
        "selection_result": selection_result,
    }


def run_local_smoke_test():
    """
    独立运行入口：内部自行创建 SparkSession（local[*]）并在结束后关闭。

    【适用场景】
    - 普通终端 spark-submit 提交（Mac 本地开发机 / CodeLab 终端均可）：
          spark-submit --master local[*] account_gang_profiling/test_pipeline_local.py
      这种场景下没有 Notebook Kernel 托管 Spark 会话，脚本自己创建、自己用完即关，
      是完全独立的一次性进程，不影响其他任何环境。

    - 不适用于 Notebook + %%spark 场景，Notebook 场景请改用 run_local_smoke_test_with_spark(spark)。
    """
    # 本地开发机（尤其 Mac）常见 Spark driver 无法绑定随机端口的问题
    # （java.net.BindException），显式指定 localhost 作为 driver 绑定地址可规避，
    # 不影响 local[*] 模式的运行（本来就是单机进程内通信，不需要真实网络地址）
    spark = (
        SparkSession.builder
        .master("local[*]")
        .appName("account_gang_profiling_smoke_test")
        .config("spark.driver.host", "127.0.0.1")
        .config("spark.driver.bindAddress", "127.0.0.1")
        .config("spark.ui.enabled", "false")
        .getOrCreate()
    )
    try:
        run_local_smoke_test_with_spark(spark)
    finally:
        spark.stop()


if __name__ == "__main__":
    run_local_smoke_test()
