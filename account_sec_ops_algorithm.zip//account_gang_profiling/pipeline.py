# -*- coding: utf-8 -*-
"""
账号级团伙特征识别 - 主线流水线入口

串联全部子模块，完整流程：

1. feature_snapshot: 构建账号特征大宽表（多源表 JOIN 对齐）
1b. （可选）market_baseline: 构建真实大盘抽样快照作为对照组
   （step1b_build_market_baseline；config.market_baseline.enabled=true 时
    run_account_gang_profiling 自动调用）
2. feature_snapshot.seed_split: 种子账号分类（risk_score 或 sample_as_seed 两种模式）
   -> 训练/验证集切分(train/validation)
3. predicates: 基于训练集(CORE_SEED+train) vs 对照组 baseline_df，
   生成并初筛候选 Predicate（数值阈值/布尔/集合成员/Map key/字符串分类）
4. rule_mining: 分层组合搜索 + 反单调剪枝，产出候选规则集
5. rule_validation: 对每条候选规则做防过拟合验证 + 大盘反证 + 误伤检测 + 风险浓度
6. rule_selection: 相似规则去重 + 贪心集合覆盖，产出最终规则集

用法示例（需在有 Hive 支持、且能访问 mart_mtsi.*/ba_rc.* 内部表的 Spark 集群/网关机上运行，
本地个人开发环境无法直接跑通本文件——本地验证代码逻辑请用同目录下的 test_pipeline_local.py）：

    cd case-traffic-characteristics   # 必须在项目根目录下执行，保证相对导入路径正确
    spark-submit --master yarn account_gang_profiling/pipeline.py --dt 20260726

说明：本模块全程使用 Spark DataFrame API（无自定义 UDF / RDD.map 等需要在 executor 端
执行 Python 闭包的操作），因此不需要通过 --py-files 把 account_gang_profiling 整个包
分发到 executor，只需保证 driver 端能 import 到本包即可（即在项目根目录下提交任务）。
"""

import os
import sys
import time
from typing import Any, Dict, Optional

# 与项目内其余入口脚本（main/hope_main.py 等）保持一致的约定：
# spark-submit 直接运行本文件时，脚本所在目录是 account_gang_profiling/ 而非项目根目录，
# 需要显式把项目根目录加入 sys.path，否则下面的 `from account_gang_profiling.xxx import`
# 绝对导入会因为找不到 account_gang_profiling 这个顶层包而失败。
# 作为被其他模块 import 的库使用时（而非直接 spark-submit 运行），项目根目录通常已经在
# sys.path 中（由调用方的入口脚本负责），这里的插入是幂等的，不会造成副作用。
_project_root = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
if _project_root not in sys.path:
    sys.path.insert(0, _project_root)

from pyspark.sql import DataFrame, SparkSession
from pyspark.sql import functions as F

from account_gang_profiling.feature_snapshot import (
    extract_whitelist_flags,
    build_field_category_map,
    infer_field_categories_from_schema,
    get_whitelist_flag_columns,
    build_seed_and_split,
    load_config,
    SEED_CORE,
    SEED_WEAK,
    SEED_EXCLUDED,
    SPLIT_TRAIN,
    SPLIT_VALIDATION,
)
from account_gang_profiling.predicates import generate_candidate_predicates
from account_gang_profiling.predicates.predicate import Predicate, OP_ARRAY_CONTAINS, OP_STRING_EQ
from account_gang_profiling.rule_mining import build_feature_combinations
from account_gang_profiling.rule_validation import validate_rules
from account_gang_profiling.rule_selection import select_final_rules
from account_gang_profiling.gang_validation import (
    build_event_timeseries, scene_bucket_totals,
    score_l1, score_l2_surge, score_l2_cluster, score_injury, combine_verdicts,
    L1Evidence, L2SurgeScore, L2ClusterScore, InjuryScore, GangVerdict,
    LEVEL_STRONG, LEVEL_HIGH_RISK, LEVEL_SUSPECT, LEVEL_UNUSABLE,
)


# ============================================================================
# 分步执行版本：把 run_account_gang_profiling 拆成 6 个独立的 step_* 函数，
# 供 Notebook 环境下逐个 cell 执行、逐阶段查看中间产出（而不是一次性跑完整个流程）。
#
# 用法示例（每个 cell 执行一个 step，可在 step 之间任意插入自己的 df.show()/count() 等
# 探索性代码，不影响后续 step 继续执行——所有状态都保存在 ctx 这个 dict 里）：
#
#     from account_gang_profiling.pipeline import (
#         step1_build_snapshot, step1b_build_market_baseline, step2_seed_split,
#         step3_generate_predicates, step4_mine_rules, step5_validate_rules, step6_select_rules,
#     )
#
#     ctx = step1_build_snapshot(spark, dt="20260726")
#     ctx["snapshot_df"].printSchema()          # 自行查看快照表结构
#
#     ctx = step1b_build_market_baseline(ctx)   # 可选：接入真实大盘对照组（需先启用
#                                               # market_baseline 并按注释建好抽样 ID 表）
#
#     ctx = step2_seed_split(ctx)
#     ctx["snapshot_df"].groupBy("seed_type").count().show()   # 自行查看种子分布
#
#     ctx = step3_generate_predicates(ctx)
#     ctx = step4_mine_rules(ctx)
#     ctx = step5_validate_rules(ctx)
#     ctx = step6_select_rules(ctx)
#
# 每个 step_* 函数都：
# 1. 接收上一步返回的 ctx（第一个 step 除外，需要显式传入 spark/dt）；
# 2. 只依赖 ctx 里已经存在的字段作为输入，若发现前置 step 未执行会主动报错提示；
# 3. 把本阶段新产出的中间结果写回 ctx 并 return ctx，同时打印本阶段的关键统计量
#    （而不只是一句"执行完成"），方便在 Notebook 里一眼判断该阶段结果是否符合预期；
# 4. 与 run_account_gang_profiling()（一次性跑完整个流程）内部复用同一套逻辑，
#    两种调用方式产出完全一致，不存在"分步版"和"一次性版"逻辑不同步的风险。
# ============================================================================

def _fail_loud(stage_tag: str, what: str) -> None:
    """元数据/捞全表写 Hive 失败时大声报错（打完整 traceback），但不中断核心 pipeline。
    修旧版 broad except 只打一行 WARN、schema drift 等被静默吞的问题
    （case_info experiments 列那次就是被这样吞的，事后查空表才发现）。"""
    import traceback
    print(f"[{stage_tag}] [FAIL] {what} 写 Hive 失败（元数据/捞全，pipeline 继续；查空表时先看此处）:")
    traceback.print_exc()


def _tlog(msg: str) -> None:
    """带时间戳的日志（定位耗时/阻塞），flush 立即输出。
    卡住时最后一行「开始 X」就是阻塞点。"""
    print(f"[{time.strftime('%Y-%m-%d %H:%M:%S')}] {msg}", flush=True)


def _require_ctx_keys(ctx: Dict[str, Any], keys: list, step_name: str, pre_step_hint: str) -> None:
    missing = [k for k in keys if k not in ctx]
    if missing:
        raise ValueError(
            f"[{step_name}] ctx 中缺少必要字段 {missing}，请先执行 {pre_step_hint} "
            f"并将其返回值作为 ctx 传入本函数"
        )


def step1_build_snapshot(spark: SparkSession, dt: str,
                          config_path: Optional[str] = None,
                          case_id: Optional[str] = None,
                          case_name: Optional[str] = None,
                          sample_sql: Optional[str] = None) -> Dict[str, Any]:
    """
    [STAGE 1/6] 读取 CASE 快照大宽表（由 SQL xt 任务 case_task2 预建）。

    直接读 ba_rc.app_acc_sec_case_snapshot（case_id+dt 双分区，dt=运行日期即今天），
    不再在本地做 5 表 collect_set 聚合 + FULL OUTER JOIN——该聚合已由
    case_task2_snapshot_xt.sql 完成。--case-id 必传（表按 case_id 分区定位本 CASE 快照）。

    Args:
        spark: SparkSession（需已开启 Hive 支持）
        dt: 运行日期（今天），对应 case_snapshot 的 dt 分区。注意不是 T-2 数据日期——
            case_snapshot 的数据口径是 T-2，由 xt 任务在扫描事件表时 date_sub(2) 实现，
            但分区 dt 写的是运行日期。
        config_path: config.yaml 路径，默认取 account_gang_profiling/config/config.yaml
        case_id: 【必传】本次 CASE 编号，定位 app_acc_sec_case_snapshot 的 case_id 分区
        case_name: 不再影响快照读取（样本已烤进预建表），仅保留向后兼容
        sample_sql: 不再使用（样本由 case_task2 按 case_id 过滤烤进预建表），保留向后兼容

    Returns:
        ctx（新建）：{"config", "config_path", "dt", "spark", "snapshot_df"}
    """
    config = load_config(config_path)

    print("=" * 80)
    print("[STAGE 1/6] 读取 CASE 快照大宽表（预建表 app_acc_sec_case_snapshot）")
    print("=" * 80)
    if not case_id:
        raise ValueError(
            "[STAGE 1/6] 读 ba_rc.app_acc_sec_case_snapshot 需必传 --case-id"
            "（表按 case_id+dt 分区，无 case_id 无法定位本 CASE 快照）。"
            "请通过命令行 --case-id 或 run 参数传入"
        )
    _t_stage1 = time.time()
    # case_snapshot 由 case_task2 预建：case_id+dt 双分区，dt=运行日期（今天）。
    # drop 分区列 case_id/dt：不进 snapshot_df，否则 case_id 会被 step3 当业务特征
    # 生成谓词（dt 已在 step3 exclude_fields，case_id 不在）。
    #
    # 【不 SELECT *、不 eager cache】与 step1b 同理：case_snapshot 535 列含高基数数组列，
    # SELECT * 投影全列 + .cache().count() 会物化全表进 storage 内存 → executor OOM。
    # 改：table() 引用不投影（下游 select 按需读列，ORC 列裁剪），count 走单独 SQL count(*)。
    snapshot_df = spark.table("ba_rc.app_acc_sec_case_snapshot").filter(
        (F.col("case_id") == case_id) & (F.col("dt") == dt)
    ).drop("case_id", "dt")

    # 轻量 count：单独 SQL count(*)，不物化列、不触发 cache
    total_accounts = spark.sql(
        f"SELECT count(*) FROM ba_rc.app_acc_sec_case_snapshot "
        f"WHERE case_id = '{case_id}' AND dt = '{dt}'"
    ).first()[0]
    if total_accounts == 0:
        raise ValueError(
            f"[STAGE 1/6] ba_rc.app_acc_sec_case_snapshot 分区 (case_id={case_id}, dt={dt}) 为 0 行。"
            f"必为故障：case_task2 未跑/未产 today 分区 / case_id 写错 / dt 非运行日期"
            f"（dt 应为运行日期今天，对应 case_snapshot 的 dt 分区，非 T-2 数据日期）"
        )
    # schema 预览从 table 元数据取（LIMIT 0），不物化数据
    print(f"[STAGE 1/6] 完成: 账号数={total_accounts}, 特征列数={len(snapshot_df.columns)}, "
          f"总耗时={time.time() - _t_stage1:.1f}秒")
    print("[STAGE 1/6] 快照表结构预览（前30列）:")
    for field in snapshot_df.schema.fields[:30]:
        print(f"    - {field.name}: {field.dataType.simpleString()}")
    if len(snapshot_df.columns) > 30:
        print(f"    ... 其余 {len(snapshot_df.columns) - 30} 列已省略，可通过 "
              f"ctx['snapshot_df'].printSchema() 查看完整结构")

    # 表7：快照信息写 Hive（只依赖 config.source_tables，step1 即可写）
    # 表6 case_info 不在 step1 写——那时 baseline/train/validation/seed 计数还没出（会全是 0），
    # 改到 step2 末写终态
    _ctx_tmp = {"spark": spark, "config": config, "snapshot_df": snapshot_df,
                "case_id": case_id, "case_name": case_name, "dt": dt}
    try:
        from account_gang_profiling.gang_validation.hive_writer import write_snapshot_info_table
        write_snapshot_info_table(spark, _ctx_tmp, case_id or "", dt)
    except Exception:
        _fail_loud("STAGE 1/6", "表7 snapshot_info")

    return {
        "spark": spark,
        "config": config,
        "config_path": config_path,
        "dt": dt,
        "snapshot_df": snapshot_df,
        "case_id": case_id,
        "case_name": case_name,
        "sample_sql": sample_sql,
    }


def step1b_build_market_baseline(ctx: Dict[str, Any],
                                  sample_sql: Optional[str] = None) -> Dict[str, Any]:
    """
    [STAGE 1.5/6] 读取真实大盘 baseline 快照（由 SQL xt 任务预建，可选阶段）。

    直接读 ba_rc.app_acc_sec_baseline_snapshot_set（dt 单分区，dt=运行日期即今天），
    不再在本地做 5 表聚合——该聚合已由 app_acc_sec_baseline_snapshot_set.sql 完成
    （1/2000 hash 抽样、受保护账号保留作误伤信号源）。作为 step3~step5 的对照组
    （baseline_df），接入后 baseline_support/lift/precision/大盘反证/误伤检测才有真实区分度。

    前置条件：config.market_baseline.enabled=true（或显式传 sample_sql 兼容旧入口）。
    baseline_snapshot_set 表的 today 分区必须已由 xt 任务产出。

    注意：
    - 与 CASE 快照同 dt（运行日期今天），数据口径同为 T-2（xt 任务扫描事件表 date_sub(2)）；
    - 受保护账号（黑钻/员工/高价值/高影响）刻意保留在 baseline 中——误伤检测信号源；
    - baseline_scale_factor 仍由 config.market_baseline.sample_mod（=2000）估算。

    Returns:
        ctx（原地追加后返回）：新增 "baseline_snapshot_df"、"baseline_scale_factor"
    """
    _require_ctx_keys(ctx, ["spark", "config", "config_path", "dt"],
                      "STAGE 1.5/6", "step1_build_snapshot")
    spark, config, config_path, dt = ctx["spark"], ctx["config"], ctx["config_path"], ctx["dt"]
    mb_cfg = config.get("market_baseline", {}) or {}
    if not mb_cfg.get("enabled", False) and not sample_sql:
        raise ValueError(
            "market_baseline 未启用（config.market_baseline.enabled 非 true）且未显式传 sample_sql，"
            "无法读取大盘 baseline。请先在 config.yaml 开启 market_baseline，"
            "并确认 ba_rc.app_acc_sec_baseline_snapshot_set 的 today 分区已由 xt 任务产出"
        )

    print("=" * 80)
    print("[STAGE 1.5/6] 读取真实大盘 baseline 快照（预建表 app_acc_sec_baseline_snapshot_set）")
    print("=" * 80)
    _t_stage = time.time()
    # baseline_snapshot_set 由 app_acc_sec_baseline_snapshot_set.sql 预建：dt 单分区，
    # dt=运行日期（今天）。
    #
    # 【不 SELECT *、不 eager cache】baseline 535 列含高基数数组列（sel_uuid_set/imei/
    # ip/bssid 等 7 天 collect_set），且 baseline 分区只有 4 个 ORC 文件（单文件 ~63MB），
    # SELECT * 投影全列后调 df.count()/printSchema() 会读全 535 列（Catalyst 不裁剪已投影
    # 列），反序列化进内存 → executor OOM(exit 137)。
    # 改：baseline_snapshot_df 直接 table() 引用（不投影），下游 select 按需读列（ORC 列裁剪），
    # count 用单独 SQL count(*)（只读文件统计，不读列）。
    baseline_snapshot_df = spark.table("ba_rc.app_acc_sec_baseline_snapshot_set").filter(
        F.col("dt") == dt
    ).drop("dt")

    # 轻量 count：单独 SQL count(*)，不物化列、不触发 cache，只读文件统计信息
    n_base = spark.sql(
        f"SELECT count(*) FROM ba_rc.app_acc_sec_baseline_snapshot_set WHERE dt = '{dt}'"
    ).first()[0]
    if n_base == 0:
        # 空 baseline 几乎必然是故障：xt 任务未跑/未产 today 分区/裸字符串 bug 未修。
        # 静默放行会让下游全部"优雅降级"（lift 虚高、快捷路径、验证天然全过），
        # 产出看似合法实则无对照的规则——与种子侧 min_seed_size 故障闸同一哲学，显式失败。
        raise ValueError(
            f"ba_rc.app_acc_sec_baseline_snapshot_set dt={dt} 为 0 行。"
            f"必为故障：xt 任务 app_acc_sec_baseline_snapshot_set.sql 未跑/未产 today 分区 / "
            f"该 SQL 的 now.delta 裸字符串 bug（'$now.delta(N).datekey' 未加大括号）未修 / "
            f"dt 非运行日期。请检查后重跑"
        )
    sample_mod = int(mb_cfg.get("sample_mod", 0) or 0)
    n_total = mb_cfg.get("market_total_accounts") or 0
    if n_total:
        n_total_source = "config 精确值"
    elif sample_mod:
        # hash 取模抽样的期望比例为 1/M，免费估计（n=10 万时相对误差 ~0.3%，够用）；
        # 如需精确值，跑一次全分区 count 并回填 market_baseline.market_total_accounts
        n_total = n_base * sample_mod
        n_total_source = f"估计值(n_base×sample_mod={sample_mod})"
    else:
        n_total_source = "未知（baseline_scale_factor 按 1.0 处理；"
        "请配置 sample_mod 或 market_total_accounts）"
    scale_factor = (n_total / n_base) if (n_total and n_base) else 1.0

    print(f"[STAGE 1.5/6] 完成: baseline 账号数={n_base}, 全量账号数={n_total}（{n_total_source}）, "
          f"baseline_scale_factor={scale_factor:.1f}, 总耗时={time.time() - _t_stage:.1f}秒")

    ctx.update({
        "baseline_snapshot_df": baseline_snapshot_df,
        "baseline_scale_factor": scale_factor,
    })
    return ctx


def _build_hard_negative_df(baseline_df: DataFrame, whitelist_df: DataFrame,
                             protected_cfg: Optional[Dict] = None) -> DataFrame:
    """
    构建 hard_negative（已知负样本/确认正常账号）= 白名单 ∪ 高等级会员（黑钻）。

    白名单来自 whitelist_df.is_whitelisted==1（在职员工/公司高价值/高影响）。
    高等级会员口径复用 seed_classification.sample_as_seed.protected_account：
    member_level_field 按 member_level_match(isin/contains) 匹配 member_level_protected_values
    （如 ["黑钻","黑钻会员"]）——与 seed_split 受保护会员判定同口径（改 config 一处生效两处）。
    旧版用 act_mt_member_level 非空/非UNKNOWN/非0 太松（~95% 命中），改为黑钻精确匹配。
    与 baseline 同 universe（whitelist_df 已在 step2 用 baseline 快照重建）。

    返回单列 account_id 的去重 DataFrame，供 multistart_greedy 搜索器做位图预计算。
    """
    wl = whitelist_df.select("account_id", "is_whitelisted")
    protected_cfg = protected_cfg or {}
    member_field = protected_cfg.get("member_level_field", "act_mt_member_level")
    protected_values = [str(v) for v in (protected_cfg.get("member_level_protected_values") or [])]
    match_mode = protected_cfg.get("member_level_match", "isin")
    has_member_col = member_field in baseline_df.columns
    base = (baseline_df.select("account_id", member_field) if has_member_col
            else baseline_df.select("account_id"))
    joined = base.join(wl, on="account_id", how="left")
    hq_flag = F.lit(False)
    if has_member_col and protected_values:
        member_col = F.trim(F.col(member_field).cast("string"))
        if match_mode == "isin":
            hq_flag = member_col.isin(*protected_values)
        elif match_mode == "contains":
            for v in protected_values:
                hq_flag = hq_flag | member_col.contains(v)
        else:
            raise ValueError(f"未知的 member_level_match: {match_mode!r}（合法: isin/contains）")
    return joined.filter(
        (F.col("is_whitelisted") == 1) | hq_flag
    ).select("account_id").distinct()


def step2_seed_split(ctx: Dict[str, Any]) -> Dict[str, Any]:
    """
    [STAGE 2/6] 种子账号分类（CORE_SEED/WEAK_SEED/EXCLUDED） + 训练/验证集切分。

    依赖: ctx 中需已有 step1_build_snapshot 产出的 "snapshot_df"。

    种子判定模式由 seed_classification.mode 决定（risk_score 默认 / sample_as_seed）。
    若已通过 step1b_build_market_baseline 接入真实大盘 baseline，本阶段末尾会用
    baseline 快照替换 EXCLUDED 派生的 baseline_df、并用同 universe 重建 whitelist_df。

    Returns:
        ctx（原地追加后返回）：新增 "snapshot_df"（已覆盖为含 risk_score/seed_type/
        dataset_split 三列的版本）、"train_seed_df"、"validation_seed_df"、
        "full_seed_df"、"baseline_df"、"whitelist_df"
    """
    _require_ctx_keys(ctx, ["snapshot_df", "config_path", "config"], "STAGE 2/6", "step1_build_snapshot")

    print("=" * 80)
    print("[STAGE 2/6] 种子账号分类 + 训练/验证集切分")
    print("=" * 80)
    _t = time.time(); _tlog("[STAGE 2/6] 开始 build_seed_and_split（snapshot 上算 risk_score/seed_type）...")
    snapshot_df = build_seed_and_split(
        ctx["snapshot_df"], config_path=ctx["config_path"], config=ctx["config"]).cache()
    _tlog(f"[STAGE 2/6] 完成 build_seed_and_split，耗时 {time.time()-_t:.1f}s")

    train_seed_df = snapshot_df.filter(
        (snapshot_df.seed_type == SEED_CORE) & (snapshot_df.dataset_split == SPLIT_TRAIN)
    )
    validation_seed_df = snapshot_df.filter(
        (snapshot_df.seed_type.isin(SEED_CORE, SEED_WEAK)) & (snapshot_df.dataset_split == SPLIT_VALIDATION)
    )
    full_seed_df = snapshot_df.filter(snapshot_df.seed_type.isin(SEED_CORE, SEED_WEAK))
    baseline_df = snapshot_df.filter(snapshot_df.seed_type == SEED_EXCLUDED)

    _t = time.time(); _tlog("[STAGE 2/6] 开始 extract_whitelist_flags（snapshot 上）...")
    whitelist_df = extract_whitelist_flags(snapshot_df, config_path=ctx["config_path"])
    _tlog(f"[STAGE 2/6] 完成 extract_whitelist_flags(snapshot)，耗时 {time.time()-_t:.1f}s")

    # 若已通过 step1b 接入真实大盘 baseline：
    # 1) 用 baseline 快照替换 EXCLUDED 派生的对照组——EXCLUDED 是"样本内无信号账号"，
    #    与真实大盘有系统性偏差（甚至为空），区分度/反证/误伤检测需要真实大盘做对照；
    # 2) whitelist_df 必须用 baseline 快照在同 universe 上重建——否则大盘命中账号
    #    join 白名单表全是 NULL，whitelist_hit_rate 结构性恒 0，误伤检测静默失效。
    if ctx.get("baseline_snapshot_df") is not None:
        baseline_df = ctx["baseline_snapshot_df"]
        _t = time.time(); _tlog("[STAGE 2/6] 开始 extract_whitelist_flags(baseline 286k 上重建)——若 baseline cache 挤掉会重扫 2.4h...")
        whitelist_df = extract_whitelist_flags(baseline_df, config_path=ctx["config_path"])
        _tlog(f"[STAGE 2/6] 完成 extract_whitelist_flags(baseline)，耗时 {time.time()-_t:.1f}s")
        print(f"[STAGE 2/6] 已接入真实大盘 baseline（替代 EXCLUDED 派生对照组），"
              f"whitelist_df 已用 baseline 快照重建")

    _t = time.time(); _tlog("[STAGE 2/6] 开始 种子分类分布 groupBy.show（snapshot 上）...")
    print("[STAGE 2/6] 种子分类分布:")
    snapshot_df.groupBy("seed_type", "dataset_split").count().orderBy("seed_type", "dataset_split").show(truncate=False)
    _tlog(f"[STAGE 2/6] 完成 种子分类分布，耗时 {time.time()-_t:.1f}s")

    baseline_label = "market_baseline" if ctx.get("baseline_snapshot_df") is not None else "EXCLUDED"
    _t = time.time(); _tlog("[STAGE 2/6] 开始 各 seed df count（含 baseline_df.count()——若 cache 挤掉会重扫）...")
    _trn = train_seed_df.count(); _val = validation_seed_df.count(); _full = full_seed_df.count(); _base = baseline_df.count()
    print(f"[STAGE 2/6] train_seed_df(CORE_SEED+train)={_trn}, "
          f"validation_seed_df(CORE_SEED+WEAK_SEED的validation)={_val}, "
          f"full_seed_df(CORE_SEED+WEAK_SEED)={_full}, "
          f"baseline_df({baseline_label})={_base}")
    _tlog(f"[STAGE 2/6] 完成 各 seed df count，耗时 {time.time()-_t:.1f}s")

    # hard_negative：已知负样本（白名单 ∪ 高等级会员黑钻），供 multistart_greedy 搜索器用。
    # 口径：is_whitelisted==1 或 member_level 命中黑钻（复用 seed_classification.protected_account 配置）。
    # 与 baseline 同 universe 重建，保证搜索期 hard_neg 命中口径与验证期一致。
    _protected = ((ctx["config"].get("seed_classification") or {}).get("sample_as_seed") or {}).get("protected_account") or {}
    _t = time.time(); _tlog("[STAGE 2/6] 开始 _build_hard_negative_df（baseline join whitelist，lazy 构建）...")
    hard_negative_df = _build_hard_negative_df(baseline_df, whitelist_df, _protected)
    _tlog(f"[STAGE 2/6] 完成 _build_hard_negative_df 构建(lazy)，耗时 {time.time()-_t:.1f}s")
    if ctx.get("baseline_snapshot_df") is not None:
        _t = time.time(); _tlog("[STAGE 2/6] 开始 hard_negative_df.count()（baseline action——若 cache 挤掉会重扫 2.4h）...")
        _hn = hard_negative_df.count()
        print(f"[STAGE 2/6] hard_negative_df(白名单∪黑钻)={_hn}")
        _tlog(f"[STAGE 2/6] 完成 hard_negative_df.count()={_hn}，耗时 {time.time()-_t:.1f}s")

    _t = time.time(); _tlog("[STAGE 2/6] 开始 full_seed_df.count()（写 ctx full_seed_count）...")
    _full_seed_count = full_seed_df.count()
    _tlog(f"[STAGE 2/6] 完成 full_seed_df.count()={_full_seed_count}，耗时 {time.time()-_t:.1f}s")

    ctx.update({
        "snapshot_df": snapshot_df,
        "train_seed_df": train_seed_df,
        "validation_seed_df": validation_seed_df,
        "full_seed_df": full_seed_df,
        "baseline_df": baseline_df,
        "whitelist_df": whitelist_df,
        "hard_negative_df": hard_negative_df,
        "full_seed_count": _full_seed_count,
    })
    # 表8：种子分类信息写 Hive
    try:
        from account_gang_profiling.gang_validation.hive_writer import write_seed_split_table
        write_seed_split_table(ctx["spark"], ctx, ctx.get("case_id", ""), ctx["dt"])
    except Exception:
        _fail_loud("STAGE 2/6", "表8 seed_split")
    # 表6：CASE 基础信息写 Hive（step2 末写——此时 baseline/train/validation/full_seed/
    # hard_negative/whitelist 计数都齐；step1 写会导致这些字段全是 0）
    try:
        from account_gang_profiling.gang_validation.hive_writer import write_case_info_table
        write_case_info_table(ctx["spark"], ctx, ctx.get("case_id", ""), ctx["dt"])
    except Exception:
        _fail_loud("STAGE 2/6", "表6 case_info")
    return ctx


def step3_generate_predicates(ctx: Dict[str, Any]) -> Dict[str, Any]:
    """
    [STAGE 3/6] 生成候选 Predicate（基于训练集 CORE_SEED vs 对照组 baseline_df——
    EXCLUDED 派生或 step1b 接入的大盘快照）。

    依赖: ctx 中需已有 step2_seed_split 产出的 "snapshot_df"/"train_seed_df"/"baseline_df"。

    Returns:
        ctx（原地追加后返回）：新增 "field_categories"、"candidate_stats"
    """
    _require_ctx_keys(ctx, ["snapshot_df", "train_seed_df", "baseline_df", "config", "config_path"],
                       "STAGE 3/6", "step2_seed_split")

    print("=" * 80)
    print("[STAGE 3/6] 生成候选 Predicate")
    print("=" * 80)
    _t_stage3 = time.time()
    declared_category_map = build_field_category_map(config_path=ctx["config_path"])
    field_categories = infer_field_categories_from_schema(ctx["snapshot_df"], declared_category_map)
    whitelist_cols = set(get_whitelist_flag_columns(config_path=ctx["config_path"]))
    # 候选池排除：whitelist_flag 字段（不应作为挖掘特征）+ risk_score/seed_type/dataset_split
    # 等本模块新增的元数据列（同样不应作为业务特征参与挖掘）+ account_id/window_end 等
    # 快照元数据列（account_id 阈值谓词、window_end/dt 常量列谓词均无业务语义；
    # 这些列当前还靠 infer_field_categories_from_schema 的默认 exclude_cols 隐式排除，
    # 这里显式声明使不变量本地化，不依赖调用路径上的默认参数）
    exclude_fields = whitelist_cols | {"risk_score", "seed_type", "dataset_split",
                                        "account_id", "window_end", "dt",
                                        "snapshot_version", "snapshot_time"}
    # feature_grading.EVIDENCE_ONLY：只解释不进规则的字段（激活原死配置）。
    # 临时排除 *_markstrategy_set_14d 试挖掘效果（这些是上游打标策略，高 lift 但语义重叠）。
    grading = ctx["config"].get("feature_grading", {}) or {}
    exclude_fields |= set(grading.get("EVIDENCE_ONLY", []))
    exclude_fields |= set(grading.get("LEAKAGE", []))

    # baseline_total：接了 step1b 大盘表时用单独 SQL count(*)（不读列，避免 OOM）；
    # 未接（baseline_df 是 EXCLUDED 派生小表）时传 None，generator 内 df.count() 安全。
    _baseline_total = None
    if ctx.get("baseline_snapshot_df") is not None:
        _baseline_total = ctx["spark"].sql(
            f"SELECT count(*) FROM ba_rc.app_acc_sec_baseline_snapshot_set WHERE dt = '{ctx['dt']}'"
        ).first()[0]

    candidate_stats = generate_candidate_predicates(
        clue_df=ctx["train_seed_df"], baseline_df=ctx["baseline_df"],
        field_categories=field_categories, exclude_fields=list(exclude_fields),
        config=ctx["config"].get("predicate_generation", {}),
        baseline_total=_baseline_total,
    )

    pg_cfg = ctx["config"].get("predicate_generation", {})
    top_n = pg_cfg.get("preview_top_n", 0)   # 0=全打，>0 只打 Top N
    sorted_stats = sorted(candidate_stats, key=lambda s: s.lift, reverse=True)
    show_stats = sorted_stats if top_n <= 0 else sorted_stats[:top_n]
    label = f"Top{top_n}" if top_n > 0 else f"全部{len(show_stats)}"
    print(f"[STAGE 3/6] 候选 Predicate 初筛完成，共 {len(candidate_stats)} 个，"
          f"总耗时={time.time() - _t_stage3:.1f}秒，按 lift 降序 {label} 预览:")
    for stat in show_stats:
        print(f"    - {stat.predicate.to_readable()}: clue_support={stat.clue_support:.2%}, "
              f"baseline_support={stat.baseline_support:.2%}, lift={stat.lift:.2f}, "
              f"clue_hit={stat.clue_hit_count}, baseline_hit={stat.baseline_hit_count}")

    # 表2：候选 Predicate 写 Hive
    try:
        from account_gang_profiling.gang_validation.hive_writer import write_candidate_predicates_table
        _exp = (ctx["config"].get("gang_validation") or {}).get("experiment", "default")
        write_candidate_predicates_table(ctx["spark"], candidate_stats, ctx.get("case_id", ""), ctx["dt"], _exp)
    except Exception:
        _fail_loud("STAGE 3/6", "表2 candidates")

    ctx.update({
        "field_categories": field_categories,
        "candidate_stats": candidate_stats,
    })
    return ctx


def step4_mine_rules(ctx: Dict[str, Any], baseline_scale_factor: Optional[float] = None,
                      verbose: bool = True) -> Dict[str, Any]:
    """
    [STAGE 4/6] 规则挖掘：分层组合搜索 + 反单调剪枝，产出候选规则集。

    依赖: ctx 中需已有 step3_generate_predicates 产出的 "candidate_stats"。

    Args:
        ctx: 上一步返回的上下文
        baseline_scale_factor: 若背景大盘账号是从全量抽样而来（如 step1b 接入的市场
            baseline），传入全量/抽样的换算倍数；不传则复用 ctx 中 step1b 已写入的
            "baseline_scale_factor"（默认1.0，不换算）
        verbose: 是否打印每层搜索的详细过程

    Returns:
        ctx（原地追加后返回）：新增 "mining_result"、"candidate_combos"、
        "baseline_scale_factor"
    """
    _require_ctx_keys(ctx, ["train_seed_df", "baseline_df", "candidate_stats", "config"],
                       "STAGE 4/6", "step3_generate_predicates")

    if baseline_scale_factor is None:
        baseline_scale_factor = ctx.get("baseline_scale_factor", 1.0)

    print("=" * 80)
    print("[STAGE 4/6] 规则挖掘（分层组合搜索）")
    print("=" * 80)
    # select_mode 从 rule_selection 段透传给 searcher（diverse 模式时 finalize 跳过 Jaccard 去重）
    rs_cfg = dict(ctx["config"].get("rule_search", {}))
    rs_cfg["select_mode"] = (ctx["config"].get("rule_selection", {}) or {}).get("select_mode", "auto_cover")
    mining_result = build_feature_combinations(
        clue_df=ctx["train_seed_df"], baseline_df=ctx["baseline_df"], candidate_stats=ctx["candidate_stats"],
        config=ctx["config"].get("rule_mining", {}), baseline_scale_factor=baseline_scale_factor, verbose=verbose,
        hard_negative_df=ctx.get("hard_negative_df"),
        rule_search_config=rs_cfg,
    )
    candidate_combos = [sig["combo"] for sig in mining_result["signatures"]]
    if mining_result.get("search_mode"):
        print(f"[STAGE 4/6] 搜索模式: {mining_result['search_mode']}")

    _sort_desc = ("recall" if mining_result.get("score_mode") == "recall_gated" else "v_score")
    print(f"[STAGE 4/6] 挖掘完成，产出 {len(candidate_combos)} 个候选规则组合，按 {_sort_desc} 降序预览:")
    for sig in mining_result["signatures"]:
        m = sig["metrics"]
        print(f"    - [{m['combo_size']}条件] {' AND '.join(sig['features'])}")
        print(f"        precision={m['precision']:.2%}, recall={m['recall']:.2%}, "
              f"v_score={m['v_score']:.4f}, clue_hit={m['clue_hit_count']}, "
              f"baseline_hit={m['baseline_hit_count']}")

    # 表3：挖掘过程写 Hive
    try:
        from account_gang_profiling.gang_validation.hive_writer import write_mining_process_table
        _exp = (ctx["config"].get("gang_validation") or {}).get("experiment", "default")
        write_mining_process_table(ctx["spark"], mining_result, ctx.get("case_id", ""), ctx["dt"], _exp)
    except Exception:
        _fail_loud("STAGE 4/6", "表3 mining")

    ctx.update({
        "mining_result": mining_result,
        "candidate_combos": candidate_combos,
        "baseline_scale_factor": baseline_scale_factor,
    })
    return ctx


def _translate_to_event_predicates(snapshot_predicates, source_tables_cfg) -> tuple:
    """快照谓词 → 事件级谓词 + 目标事件表名。

    只翻 per-event 等值条件：<prefix><field>_set array_contains / <prefix><field> string_eq
    → 事件表 <field> string_eq。prefix 决定目标事件表（sel_→strong_end_login，
    ses_→strong_end_signup，按 source_tables 各表 prefix 反查）。

    账号级谓词（act_/_cntd/_score/非事件表前缀/非等值算子）→ 剔除到截面，不参与时序：
    它们是长期稳定 trait，无 per-event 起量动态，当不了时序原子（L2-4 只用 event_detail 的
    per-event 特征算 combo_growth/归因比）。剔除后若仍有事件谓词 → 对事件侧子集做 L2-4，
    act_ 部分由 L1/injury 在完整组合上求值，避免"含 act_ 就连事件侧协同起量也不算"。
    全被剔除（纯账号级 trait 组合）→ (None,None,原因) L2-4 跳过（无起量可验）。
    硬阻塞整组跳过：混合多个事件表前缀（sel_+ses_，无法单表分桶；多表回捞需账号-桶 AND 扩展）。
    """
    # prefix → 该事件表配置（所有 table_type=event_detail 的源表）
    event_table_by_prefix = {t["prefix"]: t for t in source_tables_cfg
                             if t.get("table_type") == "event_detail"}
    # 前缀按长度降序匹配，防短前缀误吞（各前缀均以 _ 结尾，实际无包含关系，保险起见）
    prefixes_sorted = sorted(event_table_by_prefix, key=len, reverse=True)
    # 各事件表的 json_map_array_fields（snapshot_builder 把这类 JSON 列展平成"分类:子标签"
    # array<string>）；事件侧回捞也需同款展平（见 build_event_timeseries），翻译时这类字段
    # 保留 array_contains——string_eq 在原始 JSON 列上匹配 0 行，会误判原子历史不足。
    json_fields_by_prefix = {pr: set(t.get("json_map_array_fields", []))
                             for pr, t in event_table_by_prefix.items()}

    event_preds = []
    excluded = []   # 剔除的账号级谓词（act_/_cntd/_score/非事件前缀/非等值算子），
                    # 不进 L2-4 时序但留在组合里供 L1/injury 求值
    seen_prefix = None
    for p in snapshot_predicates:
        fname = p.field_name
        # act_ 表是 snapshot 类型（每日 dt、账号级）；act_/_cntd/_score 都是长期稳定 trait，
        # 无 per-event 起量动态、当不了时序原子——剔到截面，别让它们连累整组跳过时序。
        if fname.startswith("act_"):
            excluded.append(f"{fname}(act_账号级)")
            continue
        prefix = next((pr for pr in prefixes_sorted if fname.startswith(pr)), None)
        if prefix is None:
            excluded.append(f"{fname}(非事件表前缀)")
            continue
        if seen_prefix is None:
            seen_prefix = prefix
        elif seen_prefix != prefix:
            # 跨事件表前缀是单表分桶硬阻塞（多表回捞需账号-桶 AND 扩展，另开），
            # 不靠"剔除某表谓词"硬来（会改变组合时序语义）→ 仍整组跳过
            return None, None, f"混合事件表前缀({seen_prefix}+{prefix})，无法单表分桶，跳过时序"
        raw = fname[len(prefix):]              # 去前缀
        if raw.endswith("_set"):
            raw = raw[:-4]                     # 去 _set 后缀
        if raw.endswith("_cntd") or "_score" in raw:
            excluded.append(f"{fname}(账号级聚合)")
            continue
        if p.op == OP_ARRAY_CONTAINS or p.op == OP_STRING_EQ:
            # json_map_array_fields 字段事件侧已展平成 array<string> → array_contains(token)；
            # 其余字段事件侧是标量列 → string_eq(value)。
            event_op = (OP_ARRAY_CONTAINS if raw in json_fields_by_prefix.get(prefix, set())
                        else OP_STRING_EQ)
            event_preds.append(Predicate(field_name=raw, op=event_op,
                                         value=p.value, display_name=p.display_name))
        else:
            excluded.append(f"{fname}(算子{p.op}非等值)")
            continue
    if not event_preds:
        # 全是账号级 trait → 无 per-event 原子可算协同起量，诚实 REVIEW
        # （这类组合的异常靠截面 precision_new 判，本身没有起量动态可验）
        return None, None, f"全为账号级特征无 per-event 原子({'; '.join(excluded) or '无'})，跳过时序"
    target_cfg = event_table_by_prefix[seen_prefix]
    return target_cfg.get("name"), event_preds, None


def _load_case_sample_df(ctx: Dict[str, Any]):
    """加载 case 账号样本（供时序读取按 case 账号过滤，避免事件表全分区扫描）。

    复用 snapshot_builder._load_account_id_sample（同口径：sample_sql > case_id 过滤 > 全表）。
    ctx 内缓存，step4b 多次/多表读复用一份。None=未配置抽样表，时序读全分区。
    """
    if "_case_sample_df" in ctx:
        return ctx["_case_sample_df"]
    from account_gang_profiling.feature_snapshot.snapshot_builder import _load_account_id_sample
    sdf = _load_account_id_sample(ctx["spark"], ctx["config"],
                                  case_id=ctx.get("case_id"), sample_sql=ctx.get("sample_sql"))
    if sdf is not None:
        sdf = sdf.cache()
    ctx["_case_sample_df"] = sdf
    return sdf


def _build_cross_universe(ctx: Dict[str, Any]) -> DataFrame:
    """截面 scorer 的 universe = case 快照(seed) ∪ baseline 快照(大盘)。

    文档要求截面 P/N/S/R 分类在"seed+大盘都在"的完整快照上算：纯种子 universe 上
    所有命中都是 seed → __p=1 全量 → N=S=R=0 必然 → precision_new 恒 1.00、截面恒 PASS（假象）。
    baseline 与 case 快照同 schema，仅缺 step2 给 case 快照加的 seed_type/dataset_split/
    risk_score 三列，补 null（按 snapshot 类型 cast）对齐后 unionByName（按名匹配，Spark 3.0 安全）。
    baseline 缺失时退化回 snapshot_df（纯种子，截面退化为假象但不崩）。

    【不 eager cache】union 后 535 列 eager cache 会物化 case(1922)+baseline(285873) 进 storage
    → executor OOM（和 step1b/step3 同根因）。各 scorer（L1/L2簇/误伤）实际只读窄列
    （account_id + seed_type + 谓词涉及列），不 cache 靠 Catalyst 把 union 谓词下推到两侧
    ORC 扫描 + 列裁剪。各 scorer 内部 combo_filter(cross_universe).cache() 命中集（几百账号）。
    """
    snapshot_df = ctx["snapshot_df"]
    baseline_df = ctx.get("baseline_df")
    if baseline_df is None:
        print("[STAGE 4.5/6] [WARN] baseline_df 缺失，截面退化为纯种子 universe（N=S=R 恒 0）")
        return snapshot_df
    snap_schema = {f.name: f.dataType for f in snapshot_df.schema.fields}
    missing = [c for c in snapshot_df.columns if c not in baseline_df.columns]
    base_padded = baseline_df
    for c in missing:
        base_padded = base_padded.withColumn(c, F.lit(None).cast(snap_schema[c]))
    return snapshot_df.unionByName(base_padded.select(*snapshot_df.columns))


def _market_total(ctx: Dict[str, Any]) -> int:
    """大盘全量账号数：config market_total_accounts 优先，否则 baseline_df 行数 × scale 估计。"""
    mb = ctx.get("config", {}).get("market_baseline") or {}
    if mb.get("market_total_accounts", 0):
        return int(mb["market_total_accounts"])
    bdf = ctx.get("baseline_df")
    scale = ctx.get("baseline_scale_factor", 1.0) or 1.0
    if bdf is not None:
        return int(bdf.count() * scale)
    return 0


def _load_history_snapshot(ctx: Dict[str, Any], gv: Dict[str, Any]) -> Optional[DataFrame]:
    """读 w_set 历史快照表：找离 history_window_days 最近的那周分区（每周一一份）。

    w_set 是周级快照（每周一抽 T-2 单日快照，每分区含 14 天窗口聚合值）。
    90/180 天历史基线 → 找 <= target_d 的最大 dt（最近的那周分区），读 1 个分区即可。
    分区缺失（任务没跑/超 26 周）→ 返回 None，L2-4 history 指标降级跳过。
    """
    from datetime import datetime as _dt_cls, timedelta as _td_cls
    spark = ctx["spark"]
    table = gv.get("history_snapshot_table", "ba_rc.app_acc_sec_topic_user_active_ss_w_set")
    history_days = int(gv.get("history_window_days", 90))
    target_d = _dt_cls.strptime(ctx["dt"], "%Y%m%d") - _td_cls(days=history_days)
    target_dt = target_d.strftime("%Y%m%d")
    try:
        parts = spark.sql(f"SHOW PARTITIONS {table}").collect()
    except Exception as e:
        print(f"[STAGE 4.5/6] [WARN] {table} SHOW PARTITIONS 失败: {e}，L2-4 历史基线降级跳过")
        return None
    history_dts = []
    for row in parts:
        for kv in row[0].split("/"):
            if kv.startswith("dt="):
                history_dts.append(kv[3:])
    if not history_dts:
        print(f"[STAGE 4.5/6] [WARN] {table} 无分区，L2-4 历史基线降级跳过")
        return None
    # 找 <= target_dt 的最大 dt（最近的历史快照）
    eligible = sorted([d for d in history_dts if d <= target_dt], reverse=True)
    if not eligible:
        # target_dt 比所有分区都早 → 取最早的分区兜底
        eligible = sorted(history_dts, reverse=True)
        print(f"[STAGE 4.5/6] [WARN] {table} 无 <= {target_dt} 的分区，用最早分区 {eligible[0]} 兜底")
    history_dt = eligible[0]
    print(f"[STAGE 4.5/6] 历史快照 {table} dt={history_dt}（target={target_dt}, 窗口{history_days}天）")
    return spark.table(table).filter(F.col("dt") == history_dt).cache()


def step4b_validate_gang(ctx: Dict[str, Any], verbose: bool = True,
                         plot: bool = False, plot_dir: str = "/home/hadoop-ba-rc") -> Dict[str, Any]:
    """[STAGE 4.5/6] 团伙校验（L1 硬证据 + L2-4 起量归因 + 误伤门槛 → 4 级判定）。

    依赖: ctx 中需已有 step4_mine_rules 产出的 "candidate_combos" + "snapshot_df" + "baseline_df"。
    config.gang_validation.enabled=false 时直接返回（跳过本阶段）。
    产出 ctx["gang_validation_results"]: List[GangVerdict]（与 candidate_combos 同序）。
    plot=True 时画逐日命中折线存 plot_dir。
    """
    _require_ctx_keys(ctx, ["candidate_combos", "snapshot_df", "config", "spark", "dt"],
                       "STAGE 4.5/6", "step4_mine_rules")
    config = ctx["config"]
    gv = config.get("gang_validation") or {}
    if not gv.get("enabled", False):
        return ctx

    print("=" * 80)
    print("[STAGE 4.5/6] 团伙校验（L1 硬证据 + L2-4 起量归因 + 误伤门槛 → 4 级）")
    print("=" * 80)
    _t_4b = time.time()
    _t_4b_ts = None      # 时序算(L2-4/L2-5) 段
    _t_4b_xs = None      # 截面(L1/L2簇/误伤) 段

    candidate_combos = ctx["candidate_combos"]
    src_tables = config.get("feature_snapshot", {}).get("source_tables", [])
    window_days = gv.get("window_days", 180)
    event_time_field = gv.get("event_time_field", "request_time")
    scene_values = gv.get("scene", {}) or {}

    # 事件表口径 T-2：事件表是增量表，最新分区是运行日期前 2 天（xt 任务 date_sub(2) 产数）。
    # ctx["dt"]=运行日期今天，直接用作事件扫描窗口右端点会扫到今天/昨天的不存在分区
    # （_get_existing_partitions 跳过，不报错但起量归因"最近桶"偏 2 天，t0/变点检测偏）。
    # 改用 event_dt=T-2，窗口 [T-2-30, T-2] 对齐最新可用分区。
    from datetime import datetime as _dt_cls, timedelta as _td_cls
    _event_d = _dt_cls.strptime(ctx["dt"], "%Y%m%d") - _td_cls(days=2)
    event_dt = _event_d.strftime("%Y%m%d")

    # 1) 翻译：可时序的 vs 跳过的（L2-4 起量归因需 per-event 时序）
    translatable = []   # [(combo_id, target_table_name, event_preds)]
    skipped = []        # [(combo_id, reason)]
    for i, combo in enumerate(candidate_combos):
        cid = f"c{i:03d}"
        target_name, event_preds, reason = _translate_to_event_predicates(combo.predicates, src_tables)
        if reason:
            skipped.append((cid, reason))
        else:
            translatable.append((cid, target_name, event_preds))

    # 2) L2-4 起量归因：按事件表分组，每组读一次表（cache 复用）。验证口径=全量大盘。
    _t_4b_ts = time.time()
    l2_by_id = {}      # cid -> L2SurgeScore
    if translatable:
        case_sample_df = _load_case_sample_df(ctx)
        groups = {}
        for cid, target_name, event_preds in translatable:
            groups.setdefault(target_name, []).append((cid, event_preds))
        for target_name, cid_preds in groups.items():
            et_cfg = next((t for t in src_tables if t.get("name") == target_name), None)
            if et_cfg is None:
                for cid, _ in cid_preds:
                    l2_by_id[cid] = L2SurgeScore(cid, None, 0.0, None, False, 0.0, None, False,
                                                  reasons=[f"事件表{target_name}未配置,跳过L2-4"])
                continue
            id_field = et_cfg.get("id_field", "user_id")
            # needed 含 combo 谓词字段 + platform/app（场景分母）+ L2-5 非可信 factor 字段
            # factor_account_usertrust_*_score / factor_account_history_env 只在 login 表有，
            # signup 表没有——探测表 schema，只加实际存在的字段，避免 SELECT 报 AnalysisException。
            gv_factor_all = {f"factor_account_usertrust_{s}_score" for s in ("dfpid", "uuid", "subip", "dm")}
            gv_factor_all.add("factor_account_history_env")
            table_cols = set(ctx["spark"].sql(f"SELECT * FROM {et_cfg['table']} LIMIT 0").columns)
            gv_factor = gv_factor_all & table_cols
            needed = sorted(({p.field_name for _, ep in cid_preds for p in ep}
                            | {"platform", "app"} | gv_factor))
            cache_key = f"_event_ts_{et_cfg['table']}_{window_days}_{event_dt}_{'_'.join(needed)}_case"
            event_ts_df = ctx.get(cache_key)
            if event_ts_df is None:
                print(f"[STAGE 4.5/6] 读取事件表 {et_cfg['table']}（{target_name}），dt={event_dt}(T-2)，needed={needed}，按 case 账号过滤")
                # 按 case 账号过滤（1922 账号），避免全量扫描 OOM。
                # scene_totals 也在 case 过滤后的 df 上算 → combo_growth 倍数仍可信（看相对倍数，
                # case 内部场景占比变化同样反映起量）。scene_growth 指标（防大盘同步涨）去掉。
                event_ts_df = build_event_timeseries(
                    ctx["spark"], et_cfg["table"], event_dt, window_days, needed,
                    event_time_field=event_time_field, id_field=id_field,
                    account_id_sample_df=case_sample_df,
                    json_map_array_fields=et_cfg.get("json_map_array_fields"))
                ctx[cache_key] = event_ts_df
            else:
                print(f"[STAGE 4.5/6] 复用缓存事件表 {et_cfg['table']}（{target_name}，{window_days}天，dt={event_dt}，case过滤）")
            scene_totals = scene_bucket_totals(event_ts_df, scene_values, id_field=id_field)
            group_cfg = {**gv, "event_id_field": id_field}
            # L2-5 非可信曲线批量预算：一次 agg 算组内所有 combo 的 (combo∧非可信) 逐桶数组
            from account_gang_profiling.gang_validation.l2_scorer import _nontrust_bucket_counts_batch
            # 注册 combo(ses_/wes_) 的 factor 字段在 login 表(sel_/wel_)，不在 signup 表——
            # 需读 login 表 + 用 signup 圈的 combo 命中账号集去 login 表算 nontrust。
            signup_to_login = {"strong_end_signup": "strong_end_login",
                                "weak_end_signup": "weak_end_login"}
            account_sets = None
            nt_event_ts_df = event_ts_df
            nt_scene_totals = scene_totals
            if target_name in signup_to_login:
                login_name = signup_to_login[target_name]
                login_cfg = next((t for t in src_tables if t.get("name") == login_name), None)
                if login_cfg is not None:
                    login_factor = {f"factor_account_usertrust_{s}_score" for s in ("dfpid","uuid","subip","dm")}
                    login_factor.add("factor_account_history_env")
                    login_needed = sorted({"platform", "app"} | login_factor)
                    login_cache = f"_event_ts_{login_cfg['table']}_{window_days}_{event_dt}_{'_'.join(login_needed)}_nt_case"
                    login_ts_df = ctx.get(login_cache)
                    if login_ts_df is None:
                        print(f"[STAGE 4.5/6] L2-5 读 login 表 {login_cfg['table']}（{login_name}）算非可信，dt={event_dt}(T-2)，needed={login_needed}，按 case 账号过滤")
                        login_ts_df = build_event_timeseries(
                            ctx["spark"], login_cfg["table"], event_dt, window_days, login_needed,
                            event_time_field=event_time_field, id_field=id_field,
                            account_id_sample_df=case_sample_df,
                            json_map_array_fields=login_cfg.get("json_map_array_fields"))
                        ctx[login_cache] = login_ts_df
                    nt_event_ts_df = login_ts_df
                    nt_scene_totals = scene_bucket_totals(login_ts_df, scene_values, id_field=id_field)
                    # 用 signup event_ts_df 圈各 combo 命中账号集（combo 谓词在 signup 字段）
                    account_sets = {}
                    for cid, event_preds in cid_preds:
                        cond = F.lit(True)
                        for p in event_preds:
                            cond = cond & p.to_column()
                        account_sets[cid] = event_ts_df.filter(cond).select(
                            F.col(id_field).alias("account_id")).distinct().cache()
            nt_by_cid = _nontrust_bucket_counts_batch(nt_event_ts_df, nt_scene_totals, cid_preds,
                                                      id_field, account_sets=account_sets)
            # login 表的 scene_counts 数组（和 nontrust 曲线同源同长度，防长度不匹配）
            import numpy as _np
            _nt_scene_rows = nt_scene_totals.orderBy("bucket_ts").collect()
            _nt_scene_counts = _np.array([float(r["scene_total_accounts"] or 0) for r in _nt_scene_rows], dtype=float)
            for cid, event_preds in cid_preds:
                l2_by_id[cid] = score_l2_surge(cid, event_preds, event_ts_df, scene_totals,
                                                group_cfg, nontrust_counts=nt_by_cid.get(cid),
                                                nontrust_scene_counts=_nt_scene_counts)
            if plot:
                from account_gang_profiling.gang_validation.timeseries_plot import plot_combo_timeseries
                # S3 上传器（config 配置 endpoint/appkey/bucket 时启用，懒加载 mssapi）
                s3_uploader = None
                s3_cfg = gv.get("s3_upload") or {}
                if s3_cfg.get("enabled", False):
                    from account_gang_profiling.gang_validation.image_uploader import GangImageUploader
                    s3_uploader = GangImageUploader(
                        endpoint=s3_cfg.get("endpoint", "s3plus-bj02.sankuai.com"),
                        appkey=s3_cfg["appkey"],
                        bucket_name=s3_cfg["bucket"],
                        image_prefix=s3_cfg.get("image_prefix", "gang_validation"))
                plot_paths = ctx.setdefault("gang_plot_paths", {})
                all_chart_svgs = ctx.setdefault("gang_chart_svgs", [])
                for cid, event_preds in cid_preds:
                    t0 = l2_by_id[cid].t0_ts if cid in l2_by_id else None
                    try:
                        paths, chart_svgs = plot_combo_timeseries(event_ts_df, cid, event_preds,
                                                      t0_ts=t0, out_dir=plot_dir, id_field=id_field,
                                                      case_sample_df=case_sample_df,
                                                      s3_uploader=s3_uploader)
                        plot_paths[cid] = [p for p in (paths or []) if p]
                        for p in plot_paths[cid]:
                            print(f"[STAGE 4.5/6] 时序折线图 SVG: {cid} → {p}")
                        all_chart_svgs.extend(chart_svgs)
                    except Exception as e:
                        print(f"[STAGE 4.5/6] [WARN] 画 {cid} 时序图失败: {e}")
    # 跳过的组合 → L2-4 未成立
    for cid, reason in skipped:
        l2_by_id[cid] = L2SurgeScore(cid, None, 0.0, None, False, 0.0, None, False, reasons=[reason])
    print(f"[STAGE 4.5/6] 时序段(L2-4/L2-5/画图)耗时={time.time() - _t_4b_ts:.1f}秒")

    # 3) L1 硬证据 + 误伤门槛（snapshot 级，在 seed∪baseline 完整 universe 上）
    _t_4b_xs = time.time()
    cross_universe = _build_cross_universe(ctx)
    market_total = _market_total(ctx)
    case_total = ctx.get("full_seed_count") or ctx.get("case_total") or 0
    if not case_total:
        # 退化：用 snapshot_df 行数（无 baseline 时）
        case_total = ctx["snapshot_df"].count()
    baseline_scale = ctx.get("baseline_scale_factor", 1.0)
    l1_scores, l2_cluster_scores, injury_scores = [], [], []
    for i, combo in enumerate(candidate_combos):
        cid = f"c{i:03d}"
        l1_scores.append(score_l1(cid, list(combo.predicates), cross_universe, gv))
        l2_cluster_scores.append(score_l2_cluster(cid, list(combo.predicates), cross_universe, gv))
        injury_scores.append(score_injury(cid, list(combo.predicates), cross_universe,
                                          baseline_scale_factor=baseline_scale,
                                          market_total=market_total, case_total=case_total, cfg=gv))

    # 4) 4 级判定（L1 + L2-4 surge + L2 簇 + 误伤）
    l2_surge_list = [l2_by_id[f"c{i:03d}"] for i in range(len(candidate_combos))]
    verdicts = combine_verdicts(l1_scores, l2_surge_list, l2_cluster_scores, injury_scores, gv)

    # 5) 汇总 + 可选剪枝 UNUSABLE
    n_strong = sum(1 for v in verdicts if v.level == LEVEL_STRONG)
    n_high = sum(1 for v in verdicts if v.level == LEVEL_HIGH_RISK)
    n_suspect = sum(1 for v in verdicts if v.level == LEVEL_SUSPECT)
    n_unusable = sum(1 for v in verdicts if v.level == LEVEL_UNUSABLE)
    print(f"[STAGE 4.5/6] L2-4 可验证 {len(translatable)}/{len(candidate_combos)}，跳过 {len(skipped)}")
    print(f"[STAGE 4.5/6] 4 级判定: 强确认={n_strong} 高风险={n_high} 可疑={n_suspect} 不可用={n_unusable}")
    if verbose:
        l1_by_id = {e.combo_id: e for e in l1_scores}
        l2c_by_id = {e.combo_id: e for e in l2_cluster_scores}
        l2s_by_id = {e.combo_id: e for e in l2_surge_list}
        inj_by_id = {e.combo_id: e for e in injury_scores}
        for v in verdicts:
            label = " AND ".join(p.to_readable() for p in candidate_combos[int(v.combo_id[1:])].predicates)
            print(f"    - {v.combo_id} [{label}]")
            print(f"        → {v.level}")
            # L1 四轴明细
            l1 = l1_by_id.get(v.combo_id)
            if l1:
                def _mk(ok): return "✓" if ok else "✗"
                print(f"        L1: dev(max={l1.device_max_ratio:.0%}/shared={l1.device_shared_ratio:.0%}){_mk(l1.device_l1)} "
                      f"ja3(max={l1.ja3_max_ratio:.0%}/shared={l1.ja3_shared_ratio:.0%}){_mk(l1.ja3_l1)} "
                      f"黑产池={l1.black_pool_rate:.0%}{_mk(l1.black_pool_l1)} "
                      f"下游={l1.downstream_rate:.0%}{_mk(l1.downstream_l1)}")
                if l1.downstream_detail:
                    print(f"            下游明细: {l1.downstream_detail}")
            # L2 明细
            l2c = l2c_by_id.get(v.combo_id)
            l2s = l2s_by_id.get(v.combo_id)
            if l2s or l2c:
                s = l2s
                if s:
                    surge_str = f"surge(growth={s.combo_growth:.1f},pct={'✓' if s.history_pct_pass else '✗'}){'✓' if s.surge_pass else '✗'}"
                    nt_str = f"nontrust(growth={s.nontrust_growth:.1f},pct={'✓' if s.nontrust_pct_pass else '✗'}){'✓' if s.nontrust_pass else '✗'}" + ("[注册跳过]" if s.is_signup else "")
                else:
                    surge_str = nt_str = "NA"
                geo_str = f"geo(max={l2c.geo_max_ratio:.0%}){'✓' if l2c.geo_pass else '✗'}" if l2c else ""
                seg_str = f"seg(max={l2c.segment_max_ratio:.0%}){'✓' if l2c.segment_pass else '✗'}" if l2c else ""
                wifi_str = f"wifi(max={l2c.wifi_max_ratio:.0%}){'✓' if l2c.wifi_pass else '✗'}" if l2c else ""
                print(f"        L2(count={v.l2_count}): {surge_str} {nt_str} {geo_str} {seg_str} {wifi_str}")
            # 误伤明细
            inj = inj_by_id.get(v.combo_id)
            if inj:
                lift_s = "∞" if inj.lift == float("inf") else (f"{inj.lift:.1f}" if inj.lift is not None else "NA")
                print(f"        误伤: hit_rate={inj.market_hit_rate:.4%}<{gv.get('market_hit_rate_max',0.001):.4%}"
                      f" lift={lift_s}>{gv.get('lift_min',10.0)} {'✓' if inj.injury_pass else '✗'}")
            for r in v.reasons[:2]:
                print(f"        reason: {r}")

    # 数值汇总表（方便拷贝贴回分析，不看图）
    if verbose:
        print("\n" + "=" * 80)
        print("[数值汇总] combo | level | 条件数 | growth | pct | t0_idx | post_peak | hist_total | nt_growth | nt_pct | geo_max | dev_max | ja3_max | 黑产池 | 下游 | hit_rate | lift | L2 | injury")
        print("-" * 80)
        for v in verdicts:
            l1 = l1_by_id.get(v.combo_id)
            l2s = l2s_by_id.get(v.combo_id)
            l2c = l2c_by_id.get(v.combo_id)
            inj = inj_by_id.get(v.combo_id)
            combo = candidate_combos[int(v.combo_id[1:])]
            n_cond = len(combo.predicates)
            growth = f"{v.combo_growth:.1f}" if v.combo_growth < 1e5 else "1e6"
            pct = "✓" if (l2s and l2s.history_pct_pass) else "✗"
            t0_idx = f"{l2s.t0_ts:.0f}" if (l2s and l2s.t0_ts) else "NA"
            post_peak = f"{l2s.bucket_count_std:.0f}" if (l2s and l2s.bucket_count_std is not None) else "NA"
            hist_total = "NA"
            nt_growth = f"{v.nontrust_growth:.1f}" if v.nontrust_growth < 1e5 else "1e6"
            nt_pct = "✓" if (l2s and l2s.nontrust_pct_pass) else "✗"
            geo_max = f"{l2c.geo_max_ratio:.0%}" if l2c else "NA"
            dev_max = f"{l1.device_max_ratio:.0%}" if l1 else "NA"
            ja3_max = f"{l1.ja3_max_ratio:.0%}" if l1 else "NA"
            bp = f"{l1.black_pool_rate:.0%}" if l1 else "NA"
            ds = f"{l1.downstream_rate:.0%}" if l1 else "NA"
            hit_rate = f"{v.market_hit_rate:.4%}"
            lift = "∞" if v.lift == float("inf") else (f"{v.lift:.1f}" if v.lift is not None else "NA")
            print(f"  {v.combo_id} | {v.level} | {n_cond} | {growth} | {pct} | {t0_idx} | {post_peak} | {hist_total} | {nt_growth} | {nt_pct} | {geo_max} | {dev_max} | {ja3_max} | {bp} | {ds} | {hit_rate} | {lift} | {v.l2_count} | {'✓' if v.injury_pass else '✗'}")
        print("=" * 80)

    # 表1：规则验证结果写 Hive（在 prune 之前写，保留 UNUSABLE 的完整判定结果）
    try:
        from account_gang_profiling.gang_validation.hive_writer import write_validation_result_table
        _exp = (ctx["config"].get("gang_validation") or {}).get("experiment", "default")
        write_validation_result_table(ctx["spark"], verdicts, candidate_combos,
                                      ctx.get("case_id", ""), ctx["dt"], _exp)
    except Exception:
        _fail_loud("STAGE 4.5/6", "表1 result")

    if gv.get("prune_unusable", True) and n_unusable > 0:
        verdicts = [v for v in verdicts if v.level != LEVEL_UNUSABLE]
        kept_ids = {v.combo_id for v in verdicts}
        ctx["candidate_combos"] = [combo for i, combo in enumerate(candidate_combos)
                                    if f"c{i:03d}" in kept_ids]
        print(f"[STAGE 4.5/6] 剪枝 UNUSABLE {n_unusable} 条，剩 {len(ctx['candidate_combos'])} 条进 step5/6")

    print(f"[STAGE 4.5/6] 截面段(L1/L2簇/误伤/判定)耗时={time.time() - _t_4b_xs:.1f}秒")
    print(f"[STAGE 4.5/6] 总耗时={time.time() - _t_4b:.1f}秒")
    ctx["gang_validation_results"] = verdicts
    return ctx


def step5_validate_rules(ctx: Dict[str, Any], baseline_scale_factor: Optional[float] = None) -> Dict[str, Any]:
    """
    [STAGE 5/6] 规则验证：防过拟合验证 + 大盘反证 + 误伤检测。

    依赖: ctx 中需已有 step4_mine_rules 产出的 "candidate_combos"。

    Args:
        ctx: 上一步返回的上下文
        baseline_scale_factor: 不传则复用 ctx 中 step4 已设置的值（默认1.0）

    Returns:
        ctx（原地追加后返回）：新增 "validation_results"
    """
    _require_ctx_keys(ctx, ["candidate_combos", "train_seed_df", "validation_seed_df",
                             "baseline_df", "whitelist_df", "config"],
                       "STAGE 5/6", "step4_mine_rules")

    if baseline_scale_factor is None:
        baseline_scale_factor = ctx.get("baseline_scale_factor", 1.0)

    # min_generalization_ratio 的归属段是 dataset_split（切分语义），但 validator 只读
    # rule_validation 段——不合并的话改 config.yaml 的 dataset_split 段永远不生效
    # （隐性死配置）。此处合并：rule_validation 段显式配置优先，缺省继承 dataset_split 段。
    rv_config = dict(ctx["config"].get("rule_validation") or {})
    if "min_generalization_ratio" not in rv_config:
        rv_config["min_generalization_ratio"] = (ctx["config"].get("dataset_split") or {}).get(
            "min_generalization_ratio", 0.7)

    print("=" * 80)
    print("[STAGE 5/6] 规则验证")
    print("=" * 80)
    _t_stage5 = time.time()
    # gang_validation 4 级判定（step4b 产出，已剪 UNUSABLE，与 candidate_combos 对齐）：
    # 存在时 validate_rule 走逻辑门旁路（跳过 risk_concentration + 误伤检测，由 injury_gate
    # 的命中率+Lift 取代），保留泛化作硬闸。
    gang_results = ctx.get("gang_validation_results")
    gang_verdicts = None
    if gang_results:
        gang_verdicts = [
            {"decision": "PASS" if v.level in (LEVEL_STRONG, LEVEL_HIGH_RISK) else "REVIEW",
             "precision_new": 0.0, "n_hit": 0, "reasons": v.reasons}
            for v in gang_results
        ]
        print(f"[STAGE 5/6] 已接入 gang_validation 4 级判定（{len(gang_verdicts)} 条），"
              f"risk_concentration/误伤由 injury_gate(命中率+Lift) 取代")
    validation_results = validate_rules(
        combos=ctx["candidate_combos"], train_seed_df=ctx["train_seed_df"],
        validation_seed_df=ctx["validation_seed_df"], baseline_df=ctx["baseline_df"],
        whitelist_df=ctx["whitelist_df"], config=rv_config,
        baseline_scale_factor=baseline_scale_factor,
        temporal_verdicts=gang_verdicts,
    )

    passed_count = sum(1 for r in validation_results if r.passed)
    gate_desc = "4 级判定+泛化" if gang_verdicts else "全部四项"
    print(f"[STAGE 5/6] 验证完成: {passed_count}/{len(validation_results)} 条规则通过{gate_desc}检查"
          f"（详细逐条 PASS/FAIL 日志见上方 [rule_validation] 前缀输出）")
    print(f"[STAGE 5/6] 总耗时={time.time() - _t_stage5:.1f}秒")

    ctx.update({
        "validation_results": validation_results,
        "baseline_scale_factor": baseline_scale_factor,
    })
    return ctx


def step6_select_rules(ctx: Dict[str, Any]) -> Dict[str, Any]:
    """
    [STAGE 6/6] 最终规则集选择：相似规则去重 + 贪心集合覆盖。

    依赖: ctx 中需已有 step5_validate_rules 产出的 "validation_results"。

    Returns:
        ctx（原地追加后返回）：新增 "selection_result"
    """
    _require_ctx_keys(ctx, ["validation_results", "full_seed_df", "config"],
                       "STAGE 6/6", "step5_validate_rules")

    print("=" * 80)
    print("[STAGE 6/6] 最终规则集选择")
    print("=" * 80)
    _t_stage6 = time.time()
    selection_result = select_final_rules(
        results=ctx["validation_results"], full_seed_df=ctx["full_seed_df"],
        config=ctx["config"].get("rule_selection", {}),
    )

    print(f"[STAGE 6/6] 最终产出 {len(selection_result['final_rules'])} 条规则，"
          f"覆盖率={selection_result['total_coverage_ratio']:.2%}"
          f"（{selection_result['total_coverage_ratio'] * selection_result['total_seed_count']:.0f}/"
          f"{selection_result['total_seed_count']} 个种子账号）")
    print("\n最终规则集:")
    for i, rule in enumerate(selection_result["final_rules"], 1):
        combo = rule.validation_result.combo
        print(f"{i}. {combo.to_readable()}")
        print(f"   precision={combo.precision:.2%}, recall={combo.recall:.2%}, "
              f"命中账号数={combo.clue_hit_count}, 新增覆盖={rule.marginal_new_coverage}")

    print(f"[STAGE 6/6] 总耗时={time.time() - _t_stage6:.1f}秒")

    # 把时序图 SVG 写 Hive 表（不需要 S3/kms/AK，Spark 直写 Hive）
    chart_svgs = ctx.get("gang_chart_svgs") or []
    if chart_svgs:
        try:
            from pyspark.sql import Row
            from account_gang_profiling.gang_validation.hive_writer import _write_partitioned, TABLE_CHARTS, _global_combo_id
            _cid = str(ctx.get("case_id", ""))
            chart_df = ctx["spark"].createDataFrame([
                Row(combo_id=_global_combo_id(_cid, c["combo_id"]),
                    chart_type=c["kind"], chart_label=c["label"], svg_content=c["svg"])
                for c in chart_svgs
            ])
            _exp = (ctx["config"].get("gang_validation") or {}).get("experiment", "default")
            _write_partitioned(ctx["spark"], chart_df, TABLE_CHARTS,
                               str(ctx.get("case_id", "")), _exp, str(ctx["dt"]))
            print(f"[STAGE 6/6] 时序图 SVG 已写入 Hive: {TABLE_CHARTS} partition(case_id={ctx.get('case_id')},experiment={_exp},dt={ctx['dt']})（{len(chart_svgs)} 张图）")
            ctx["chart_table"] = TABLE_CHARTS
        except Exception:
            _fail_loud("STAGE 6/6", "表0 charts(SVG)")

    # 表4：捞全——用最终规则在全量大盘上捞 account_id。
    # 暂停（recall_enabled=false）：_full_window_scan 全量账号+cache 有 OOM 风险，
    # 待优化（改 case 过滤或去 cache）后再开启。表9 final_rules 仍写（不含捞全 account_id）。
    _rs_cfg = ctx["config"].get("rule_selection", {}) or {}
    if _rs_cfg.get("recall_enabled", False):
        try:
            from account_gang_profiling.gang_validation.hive_writer import recall_accounts
            _exp = (ctx["config"].get("gang_validation") or {}).get("experiment", "default")
            recall_accounts(ctx["spark"], selection_result["final_rules"], ctx,
                            ctx.get("case_id", ""), ctx["dt"], _exp)
        except Exception:
            _fail_loud("STAGE 6/6", "表4 recall 捞全")
    else:
        print("[STAGE 6/6] 表4 recall 捞全已暂停（rule_selection.recall_enabled=false，避免全量扫描 OOM）")

    # 表9：最终规则集（rule-level，N 行）——平台一张表读完，免表4+1+6 distinct+join
    try:
        from account_gang_profiling.gang_validation.hive_writer import write_final_rules_table
        _exp = (ctx["config"].get("gang_validation") or {}).get("experiment", "default")
        write_final_rules_table(ctx["spark"], selection_result, ctx,
                                ctx.get("case_id", ""), ctx["dt"], _exp)
    except Exception:
        _fail_loud("STAGE 6/6", "表9 final_rules")

    ctx["selection_result"] = selection_result
    return ctx


def run_account_gang_profiling(spark: SparkSession, dt: str,
                                config_path: Optional[str] = None,
                                baseline_scale_factor: Optional[float] = None,
                                verbose: bool = True,
                                case_id: Optional[str] = None,
                                case_name: Optional[str] = None,
                                sample_sql: Optional[str] = None) -> Dict[str, Any]:
    """
    端到端主线流水线。

    Args:
        spark: SparkSession（需已开启 Hive 支持）
        dt: 快照分区日期（窗口右端点），如 '20260726'
        config_path: config.yaml 路径，默认取 account_gang_profiling/config/config.yaml
        baseline_scale_factor: 全量/抽样换算倍数，仅当需要显式强制覆盖时传入。
            不传（None，默认）：启用了 market_baseline 时继承 step1b 计算的换算倍数
            （写入 ctx["baseline_scale_factor"]），否则按 1.0（不换算，对应
            EXCLUDED 直接来自快照全量账号的场景）。rule_mining/rule_validation 的
            precision/大盘反证/风险浓度计算都依赖这个换算。
        verbose: 是否打印各阶段详细过程日志
        case_id: 本次任务编号（多 CASE 任务化调试），见 step1_build_snapshot
        case_name: 本次任务名称，仅用于缓存表命名
        sample_sql: 自定义样本账号查询 SQL（优先级最高的样本来源）

    Returns:
        {
            "snapshot_df": 账号特征大宽表（已含 risk_score/seed_type/dataset_split 列）,
            "candidate_stats": predicates 初筛结果,
            "mining_result": rule_mining 产出（signatures）,
            "validation_results": rule_validation 逐条验证结果,
            "selection_result": rule_selection 最终规则集,
        }

    说明：本函数内部直接复用 step1_build_snapshot ~ step6_select_rules 六个分步函数
    （定义见上方），与"分步执行版"共享同一套逻辑，不存在两个版本产出不一致的风险。
    若需要在 Notebook 里逐阶段查看中间结果，请直接调用 step1_build_snapshot 等函数，
    而不是本函数。
    """
    _ts = time.time(); _tlog("[RUN] step1 构建账号特征快照 开始...")
    ctx = step1_build_snapshot(spark, dt=dt, config_path=config_path,
                                case_id=case_id, case_name=case_name, sample_sql=sample_sql)
    _tlog(f"[RUN] step1 完成，耗时 {time.time()-_ts:.1f}s")
    # 可选阶段：config.market_baseline.enabled=true 时自动接入真实大盘 baseline
    # （notebook 分步执行场景也可随时手动调用 step1b_build_market_baseline）
    if (ctx["config"].get("market_baseline") or {}).get("enabled", False):
        _ts = time.time(); _tlog("[RUN] step1b 构建大盘 baseline 快照 开始（慢，扫 5 表）...")
        ctx = step1b_build_market_baseline(ctx)
        _tlog(f"[RUN] step1b 完成，耗时 {time.time()-_ts:.1f}s")
    _ts = time.time(); _tlog("[RUN] step2 种子分类+训练/验证切分 开始（多个 baseline action，疑卡点）...")
    ctx = step2_seed_split(ctx)
    _tlog(f"[RUN] step2 完成，耗时 {time.time()-_ts:.1f}s")
    _ts = time.time(); _tlog("[RUN] step3 生成候选 Predicate 开始...")
    ctx = step3_generate_predicates(ctx)
    _tlog(f"[RUN] step3 完成，耗时 {time.time()-_ts:.1f}s")
    _ts = time.time(); _tlog("[RUN] step4 规则挖掘 开始...")
    ctx = step4_mine_rules(ctx, baseline_scale_factor=baseline_scale_factor, verbose=verbose)
    _tlog(f"[RUN] step4 完成，耗时 {time.time()-_ts:.1f}s")
    if (ctx["config"].get("gang_validation") or {}).get("enabled", False):
        _ts = time.time(); _tlog("[RUN] step4b 团伙校验 开始（扫事件表 30 天时序，疑慢）...")
        ctx = step4b_validate_gang(ctx, verbose=verbose)
        _tlog(f"[RUN] step4b 完成，耗时 {time.time()-_ts:.1f}s")
    _ts = time.time(); _tlog("[RUN] step5 规则验证 开始...")
    ctx = step5_validate_rules(ctx, baseline_scale_factor=baseline_scale_factor)
    _tlog(f"[RUN] step5 完成，耗时 {time.time()-_ts:.1f}s")
    _ts = time.time(); _tlog("[RUN] step6 最终规则集选择 开始...")
    ctx = step6_select_rules(ctx)
    _tlog(f"[RUN] step6 完成，耗时 {time.time()-_ts:.1f}s")

    print("=" * 80)
    print(f"[DONE] 账号级团伙特征识别流水线执行完成，"
          f"最终产出 {len(ctx['selection_result']['final_rules'])} 条规则")
    print("=" * 80)

    return {
        "snapshot_df": ctx["snapshot_df"],
        "candidate_stats": ctx["candidate_stats"],
        "mining_result": ctx["mining_result"],
        "validation_results": ctx["validation_results"],
        "selection_result": ctx["selection_result"],
    }


if __name__ == "__main__":
    import argparse
    import time

    parser = argparse.ArgumentParser(description="账号级团伙特征识别 - 主线流水线")
    parser.add_argument("--dt", type=str, required=True, help="快照分区日期，如 20260726")
    parser.add_argument("--case-id", "--case_id", type=str, default=None,
                        help="本次任务编号（多 CASE 任务化调试）：按样本表 case_id 字段过滤样本账号，"
                             "并生成该 CASE 专属的缓存表名。下划线别名 --case_id 兼容 MLP 全局变量自动追加")
    parser.add_argument("--case-name", "--case_name", type=str, default=None,
                        help="本次任务名称，仅用于缓存表命名，便于人工识别。下划线别名 --case_name 兼容 MLP")
    parser.add_argument("--sample-sql", "--sample_sql", type=str, default=None,
                        help="自定义样本账号查询 SQL（优先级最高的样本来源），如 "
                             "\"select distinct user_id from ba_rc_test.acc_sec_tmp_13_new_nanyang_m5w3_uid\"。"
                             "下划线别名 --sample_sql 兼容 MLP")
    parser.add_argument("--config-path", "--config_path", type=str, default=None,
                        help="config.yaml 路径。默认走包内 account_gang_profiling/config/config.yaml"
                             "（__file__ 相对路径，集群模式 zip 里 open 不了 → 用 --files ship + 显式传此参数）。"
                             "下划线别名 --config_path 兼容 MLP 全局变量追加")
    args, unknown = parser.parse_known_args()
    if unknown:
        print(f"[WARN] 忽略未识别的命令行参数: {unknown}")

    # 版本号（build 脚本注入 _version.py；日志据此确认跑的是哪个 commit）
    try:
        from account_gang_profiling._version import COMMIT, BRANCH
    except Exception:
        COMMIT, BRANCH = "no-_version-module", "no-_version-module"
    print(f"[VERSION] git_commit={COMMIT} git_branch={BRANCH}", flush=True)

    start_time = time.time()
    print(f"[INFO] 开始初始化 SparkSession (Hive支持)，dt={args.dt}, "
          f"case_id={args.case_id}, case_name={args.case_name}")
    try:
        spark_session = SparkSession.builder.enableHiveSupport().getOrCreate()
    except Exception as e:
        print(f"[ERROR] Spark/Hive 初始化失败，请确认当前环境具备 Hive 元数据访问权限"
              f"（本地个人开发环境无法运行本脚本，需在集群/网关机上提交）: {e}")
        sys.exit(1)

    try:
        result = run_account_gang_profiling(spark_session, dt=args.dt,
                                             case_id=args.case_id, case_name=args.case_name,
                                             sample_sql=args.sample_sql,
                                             config_path=args.config_path)
    except Exception as e:
        print(f"[ERROR] 流水线执行失败: {type(e).__name__}: {e}")
        raise
    finally:
        elapsed = time.time() - start_time
        print(f"[INFO] 流水线总耗时: {elapsed:.1f}秒")

    print("\n最终规则集:")
    for i, rule in enumerate(result["selection_result"]["final_rules"], 1):
        combo = rule.validation_result.combo
        print(f"{i}. {combo.to_readable()}")
        print(f"   precision={combo.precision:.2%}, recall={combo.recall:.2%}, "
              f"命中账号数={combo.clue_hit_count}, 新增覆盖={rule.marginal_new_coverage}")
