# -*- coding: utf-8 -*-
"""
_translate_pred_to_slim_field 单测（纯 python，无 Spark）：
验证 act_ 谓词扫精简日表（app_acc_sec_topic_user_active_ss_d_set）时的列名/op 翻译——
仅去 act_ 前缀、保留 _set 后缀、op 不变。区别于事件表翻译（去 _set 后缀 + 改 op）。
"""

from account_gang_profiling.predicates.predicate import (
    Predicate, OP_ARRAY_CONTAINS, OP_GTE, OP_EQ_BOOL,
)
from account_gang_profiling.gang_validation.hive_writer import _translate_pred_to_slim_field


def _ac(field, value):
    return Predicate(field_name=field, op=OP_ARRAY_CONTAINS, value=value)


def _gte(field, value):
    return Predicate(field_name=field, op=OP_GTE, value=value)


def _bool(field):
    return Predicate(field_name=field, op=OP_EQ_BOOL)


def main():
    print("=" * 70)
    print("[_translate_pred_to_slim_field 单测]")
    print("=" * 70)
    fails = 0

    def check(desc, cond):
        nonlocal fails
        mark = "✓" if cond else "✗"
        if not cond:
            fails += 1
        print(f"  {mark} {desc}")

    # 1) 原 map 列（精简表已 map_keys 转 _set）：act_..._map_30d 谓词 → 精简表 ..._set 列
    #    谓词 field_name 来自 snapshot，snapshot 按 field_type_overrides.array 生成 op=array_contains
    p = _ac("act_reg_login_mobile_user_cntd_30d_set", "13800138000")
    t = _translate_pred_to_slim_field(p)
    check(f"map→set 列: field={t.field_name} op={t.op}",
          t.field_name == "reg_login_mobile_user_cntd_30d_set" and t.op == OP_ARRAY_CONTAINS
          and t.value == "13800138000")

    # 2) 原本就是 array<string> 的 _set 列（非 map 转来）：act_ip_set_14d → ip_set_14d
    p = _ac("act_ip_set_14d", "1.2.3.4")
    t = _translate_pred_to_slim_field(p)
    check(f"原生 array 列: field={t.field_name} op={t.op}",
          t.field_name == "ip_set_14d" and t.op == OP_ARRAY_CONTAINS)

    # 3) 布尔列（无 _set 后缀）：act_is_hit_black_ip → is_hit_black_ip，op=eq_bool 不变
    p = _bool("act_is_hit_black_ip")
    t = _translate_pred_to_slim_field(p)
    check(f"布尔列: field={t.field_name} op={t.op}",
          t.field_name == "is_hit_black_ip" and t.op == OP_EQ_BOOL)

    # 4) 数值列：act_mt_man_machine_risk_score → mt_man_machine_risk_score，op=gte 不变
    p = _gte("act_mt_man_machine_risk_score", 85.0)
    t = _translate_pred_to_slim_field(p)
    check(f"数值列: field={t.field_name} op={t.op}",
          t.field_name == "mt_man_machine_risk_score" and t.op == OP_GTE and t.value == 85.0)

    # 5) intercept map→set 列（L1-4 用）：act_rc_event_account_cnt_90d_intercept_set
    p = _ac("act_rc_event_account_cnt_90d_intercept_set", "login_verify")
    t = _translate_pred_to_slim_field(p)
    check(f"intercept map→set: field={t.field_name}",
          t.field_name == "rc_event_account_cnt_90d_intercept_set" and t.op == OP_ARRAY_CONTAINS)

    # 6) display_name 保留
    p = Predicate(field_name="act_ip_set_14d", op=OP_ARRAY_CONTAINS, value="1.2.3.4", display_name="IP集")
    t = _translate_pred_to_slim_field(p)
    check(f"display_name 保留: {t.display_name}", t.display_name == "IP集")

    # 7) 关键：与事件表翻译的区别——act_ 谓词 _set 后缀【必须保留】（精简表列名带 _set）
    #    事件表翻译会把 act_X_set → X（去后缀），精简表翻译绝不能去后缀
    p = _ac("act_reg_login_dfpid_uuid_cntd_30d_set", "uuid_xxx")
    t = _translate_pred_to_slim_field(p)
    check(f"_set 后缀保留（不去除）: field={t.field_name}",
          t.field_name == "reg_login_dfpid_uuid_cntd_30d_set"
          and t.field_name.endswith("_set"))

    print("=" * 70)
    if fails:
        print(f"[FAIL] {fails} 项未过")
        raise SystemExit(1)
    print("[PASS] _translate_pred_to_slim_field 单测全过")


if __name__ == "__main__":
    main()
