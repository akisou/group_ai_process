# -*- coding: utf-8 -*-
"""团伙校验模块（v1.0《团伙判定校验方案》精简核心）。

判定走逻辑门（误伤门>L1>L2>L3），不用加权求和；证据分层不可互相替代。
- L1 硬证据（l1_scorer）：设备-账号一对多 / ja3 网络指纹 / 黑产资源池 / 下游作弊。
- L2-4 结构证据（l2_scorer）：组合起量 + 原子增量归因（含噪声过滤）。
- 误伤门槛（injury_gate）：大盘命中率 + Lift（替 precision 口径）。
- 4 级输出（gang_gate）：强确认 / 高风险 / 可疑 / 不可用。

Phase 2 待加：L2-1/2/3/5/6/7、L3 报告、簇级准确率、后验、防过拟合。
"""
from .event_timeseries import (
    build_event_timeseries,
    scene_bucket_totals,
    combo_bucket_hits,
)
from .l1_scorer import (
    L1Evidence,
    score_l1,
    combo_filter,
)
from .l2_scorer import (
    L2SurgeScore,
    score_l2_surge,
)
from .l2_cluster_scorer import (
    L2ClusterScore,
    score_l2_cluster,
)
from .injury_gate import (
    InjuryScore,
    score_injury,
)
from .gang_gate import (
    GangVerdict,
    decide_gang,
    combine_verdicts,
    LEVEL_STRONG,
    LEVEL_HIGH_RISK,
    LEVEL_SUSPECT,
    LEVEL_UNUSABLE,
)
