# -*- coding: utf-8 -*-
"""
_translate_to_event_predicates 单测（纯 python，无 Spark）：
验 sel_/ses_ 翻译 + 目标表派生 + 账号级谓词(act_/_cntd/非等值)剔除不连累整组时序 + 混合前缀/纯账号级 skip。
"""

from account_gang_profiling.predicates.predicate import (
    Predicate, OP_ARRAY_CONTAINS, OP_STRING_EQ, OP_GTE,
)
from account_gang_profiling.pipeline import _translate_to_event_predicates

# 与 config.yaml source_tables 同构的最小事件表配置（只取前缀/name/table_type）
SOURCE_TABLES = [
    {"name": "strong_end_login", "prefix": "sel_", "table_type": "event_detail"},
    {"name": "strong_end_signup", "prefix": "ses_", "table_type": "event_detail",
     "json_map_array_fields": ["deviceriskhitrulesv2new"]},
    {"name": "weak_end_login", "prefix": "wel_", "table_type": "event_detail"},
    {"name": "weak_end_signup", "prefix": "wes_", "table_type": "event_detail"},
    {"name": "user_active", "prefix": "act_", "table_type": "snapshot"},
]


def _ac(field, value):
    return Predicate(field_name=field, op=OP_ARRAY_CONTAINS, value=value)


def _eq(field, value):
    return Predicate(field_name=field, op=OP_STRING_EQ, value=value)


def _gte(field, value):
    return Predicate(field_name=field, op=OP_GTE, value=value)


def main():
    print("=" * 70)
    print("[_translate_to_event_predicates 单测]")
    print("=" * 70)
    fails = 0

    def check(desc, cond):
        nonlocal fails
        mark = "✓" if cond else "✗"
        if not cond:
            fails += 1
        print(f"  {mark} {desc}")

    # 1) 全 sel_ → 登录表，_set 去前缀+去后缀
    target, preds, reason = _translate_to_event_predicates(
        [_ac("sel_dm_set", "ADA-AL00"), _eq("sel_methodname", "sdk_mobile_login_v5")],
        SOURCE_TABLES)
    check(f"全 sel_→登录表: target={target}, preds={[p.field_name for p in preds]}, reason={reason}",
          target == "strong_end_login" and [p.field_name for p in preds] == ["dm", "methodname"]
          and reason is None and all(p.op == OP_STRING_EQ for p in preds))

    # 2) 全 ses_ → 注册表
    target, preds, reason = _translate_to_event_predicates(
        [_ac("ses_dm_set", "ADA-AL00"), _ac("ses_version_set", "12.49.405")],
        SOURCE_TABLES)
    check(f"全 ses_→注册表: target={target}, preds={[p.field_name for p in preds]}, reason={reason}",
          target == "strong_end_signup" and [p.field_name for p in preds] == ["dm", "version"]
          and reason is None)

    # 3) 混合 sel_+ses_ → skip（无法单表分桶）
    target, preds, reason = _translate_to_event_predicates(
        [_ac("sel_dm_set", "X"), _ac("ses_version_set", "Y")], SOURCE_TABLES)
    check(f"混合前缀 skip: target={target}, reason={reason}",
          target is None and preds is None and "混合事件表前缀" in reason)

    # 4) 含 _cntd 账号级聚合 → 剔除到截面，不连累整组（sel_dm 照常翻译→可时序）
    target, preds, reason = _translate_to_event_predicates(
        [_ac("sel_dm_set", "X"), _gte("sel_deviceriskhitrulesv2new_cntd", 1.0)], SOURCE_TABLES)
    check(f"_cntd 剔除不连累: target={target}, preds={[p.field_name for p in preds]}, reason={reason}",
          target == "strong_end_login" and [p.field_name for p in preds] == ["dm"] and reason is None)

    # 5) 含 act_ 账号字段 → 剔除到截面，不连累整组（sel_dm 照常翻译→可时序）
    target, preds, reason = _translate_to_event_predicates(
        [_ac("sel_dm_set", "X"), _gte("act_mt_man_machine_risk_score", 85.0)], SOURCE_TABLES)
    check(f"act_ 剔除不连累: target={target}, preds={[p.field_name for p in preds]}, reason={reason}",
          target == "strong_end_login" and [p.field_name for p in preds] == ["dm"] and reason is None)

    # 6) 非等值算子（gte）→ 剔除；这里单谓词→全被剔除→REVIEW（无 per-event 原子）
    target, preds, reason = _translate_to_event_predicates(
        [_gte("sel_dm", 35.0)], SOURCE_TABLES)
    check(f"非等值剔除→空→REVIEW: reason={reason}",
          target is None and "非等值" in reason)

    # 7) 纯 act_（无事件谓词）→ 无 per-event 原子 → 诚实 REVIEW
    target, preds, reason = _translate_to_event_predicates(
        [_gte("act_mt_man_machine_risk_score", 85.0)], SOURCE_TABLES)
    check(f"纯 act_ REVIEW: reason={reason}",
          target is None and "账号级" in reason)

    # 8) 翻译后 value/display_name 保留
    p = _ac("sel_dm_set", "ADA-AL00")
    _, preds, _ = _translate_to_event_predicates([p], SOURCE_TABLES)
    check(f"value/display_name 保留: value={preds[0].value}, display={preds[0].display_name}",
          preds[0].value == "ADA-AL00")

    # 9) json_map_array_fields 字段 → 翻译保留 array_contains（事件侧展平后匹配，非 string_eq）
    target, preds, reason = _translate_to_event_predicates(
        [_ac("ses_deviceriskhitrulesv2new_set", "Customized_Case:harmony_X")], SOURCE_TABLES)
    check(f"json 字段→array_contains: target={target}, op={preds[0].op if preds else None}, reason={reason}",
          target == "strong_end_signup" and len(preds) == 1
          and preds[0].field_name == "deviceriskhitrulesv2new"
          and preds[0].op == OP_ARRAY_CONTAINS
          and preds[0].value == "Customized_Case:harmony_X"
          and reason is None)

    # 10) json 字段与非 json 字段混排：json→array_contains，普通→string_eq
    target, preds, reason = _translate_to_event_predicates(
        [_ac("ses_deviceriskhitrulesv2new_set", "Customized_Case:harmony_X"),
         _ac("ses_dm_set", "ADA-AL00")], SOURCE_TABLES)
    ops = {p.field_name: p.op for p in preds}
    check(f"json+普通混排: ops={ops}, reason={reason}",
          target == "strong_end_signup"
          and ops.get("deviceriskhitrulesv2new") == OP_ARRAY_CONTAINS
          and ops.get("dm") == OP_STRING_EQ
          and reason is None)

    print("=" * 70)
    if fails:
        print(f"[FAIL] {fails} 项未过")
        raise SystemExit(1)
    print("[PASS] _translate_to_event_predicates 单测全过")


if __name__ == "__main__":
    main()
