# -*- coding: utf-8 -*-
"""
L2-4 组合起量（v1.0 文档 §三）。时序形态证据，定性靠 L1。

- combo_growth：target 窗 ComboRate 均值 / 历史窗均值；多窗 14/30/90 取 max；
  low_base（history<50）用 Poisson survival 判显著性；history_percentile（P99.9）判起量前稀疏。
- t0 变点：滑动窗前后均值比 argmax。
- scene_growth：场景 14 天前后均值比（起量与大盘同步→不可用，gang_gate 用）。
- bucket_count_std：每桶命中账号数 std（L3 标准差，report-only）。
- L2-5 非可信环境突变：combo∧非可信 逐桶曲线，同阶跃+稀疏判定（注册场景跳过）。

surge_pass = combo_growth≥pass ∧ history_pct（起量+起量前稀疏）。
注：原子增量归因已删除——v1.0 文档「时序形态可被辩护」，定性靠 L1；归因耗时长（每 combo
扫 event_ts_df pre/post 两窗）且对 STRONG 结论无影响（L1 优先）。L2-1/2/3/5/6/7 留 Phase 2。
"""
import math
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Tuple

import numpy as np
from pyspark.sql import DataFrame, functions as F

from account_gang_profiling.predicates.predicate import Predicate
from .event_timeseries import combo_bucket_hits, scene_bucket_totals

_BUCKETS_PER_DAY = 48
_DEFAULT_WINDOWS_DAYS = (14, 30, 90)
_DEFAULT_LOW_BASE_TOTAL = 50
_DEFAULT_HISTORY_PERCENTILE = 99.9
_DEFAULT_ABS_FALLBACK = 30.0
_DEFAULT_HISTORY_ZERO_MIN_TARGET = 30.0
_DEFAULT_COMBO_GROWTH_PASS = 3.0
_DEFAULT_SCENE_GROWTH_SYNC = 1.5
_GROWTH_CAP = 1e6


def _poisson_sf(k: int, lam: float) -> float:
    """P(X >= k | X ~ Poisson(lam))。精确累加。"""
    if k <= 0:
        return 1.0
    if lam <= 0:
        return 0.0
    log_lam = math.log(lam)
    log_term = -lam
    cdf = math.exp(log_term)
    for i in range(1, k):
        log_term += log_lam - math.log(i)
        cdf += math.exp(log_term)
        if cdf > 1.0 - 1e-12:
            return 0.0
    return max(0.0, 1.0 - cdf)


def _bucket_arrays(combo_hits_df: DataFrame, scene_totals_df: DataFrame
                   ) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    """scene LEFT JOIN combo，按 bucket_ts 排序 collect 成 numpy 数组。"""
    joined = (scene_totals_df.join(combo_hits_df.select("bucket_ts", "combo_hit_accounts"),
                                   on="bucket_ts", how="left")
              .fillna({"combo_hit_accounts": 0}))
    rows = joined.orderBy("bucket_ts").collect()
    if not rows:
        return (np.array([]), np.array([]), np.array([]))
    combo = np.array([float(r["combo_hit_accounts"]) for r in rows], dtype=float)
    scene = np.array([float(r["scene_total_accounts"]) for r in rows], dtype=float)
    ts = np.array([r["bucket_ts"].timestamp() for r in rows], dtype=float)
    return ts, combo, scene


def _find_changepoint(combo_counts: np.ndarray, window_buckets: int,
                      min_consecutive: int = 3) -> int:
    """变点检测：前 0 后有量形态优先找「第一个连续 min_consecutive 个非零桶」的起点，
    不靠后。全程有量（无 0 段）或全程 0 回退滑动窗 ratio argmax。
    - 前 0 后有量（有 0 段）→ t0 = 第一个连续非零段起点（post 窗有足够长度）
    - 全程有量（无 0 段）→ argmax（找涨幅最大点）
    - 全 0 → argmax（n//2）
    """
    n = len(combo_counts)
    # 只在有 0 段时用连续段逻辑（前 0 后有量形态）
    has_zero = np.any(combo_counts == 0)
    if has_zero:
        consec = 0
        for i in range(n):
            if combo_counts[i] > 0:
                consec += 1
                if consec >= min_consecutive:
                    return i - min_consecutive + 1
            else:
                consec = 0
    # 回退：滑动窗前后均值比 argmax
    if n < 2 * window_buckets:
        return max(n // 2, 1)
    ratios = np.empty(n - 2 * window_buckets)
    for i in range(window_buckets, n - window_buckets):
        pre = combo_counts[i - window_buckets:i].mean()
        post = combo_counts[i:i + window_buckets].mean()
        ratios[i - window_buckets] = (post + 1.0) / (pre + 1.0)
    return window_buckets + int(np.argmax(ratios))


def _rate(combo_counts: np.ndarray, scene_counts: np.ndarray) -> np.ndarray:
    scene_safe = np.maximum(scene_counts, 1.0)
    return np.where(scene_counts > 0, combo_counts / scene_safe, 0.0)


def _growth_and_history(combo_counts: np.ndarray, scene_counts: np.ndarray, t0_idx: int,
                        buckets_per_day: int = _BUCKETS_PER_DAY,
                        windows_days: Tuple[int, ...] = _DEFAULT_WINDOWS_DAYS,
                        low_base_total: float = _DEFAULT_LOW_BASE_TOTAL,
                        history_percentile: float = _DEFAULT_HISTORY_PERCENTILE,
                        abs_fallback: float = _DEFAULT_ABS_FALLBACK,
                        history_zero_min_target: float = _DEFAULT_HISTORY_ZERO_MIN_TARGET,
                        history_nonzero_threshold: int = 3) -> Dict[str, Any]:
    rate = _rate(combo_counts, scene_counts)
    n = len(combo_counts)
    if t0_idx is None or t0_idx < 0 or t0_idx >= n:
        t0_idx = max(n // 2, 1)
    target_rate = rate[t0_idx:]
    target_counts = combo_counts[t0_idx:]
    target_peak = float(target_counts.max()) if len(target_counts) else 0.0
    target_mean_rate = float(np.mean(target_rate)) if len(target_rate) else 0.0

    growths: List[float] = []
    for W in windows_days:
        start = t0_idx - W * buckets_per_day
        if start < 0:
            continue
        hist_rate_w = rate[start:t0_idx]
        if len(hist_rate_w) == 0:
            continue
        growths.append(target_mean_rate / max(float(np.mean(hist_rate_w)), 1e-9))
    if not growths and t0_idx > 0:
        hist_rate_w = rate[:t0_idx]
        if len(hist_rate_w):
            growths.append(target_mean_rate / max(float(np.mean(hist_rate_w)), 1e-9))
    combo_growth = max(growths) if growths else 0.0

    min_w = min(windows_days) if windows_days else 14
    start = t0_idx - min_w * buckets_per_day
    if start < 0:
        start = 0
    hist_counts = combo_counts[start:t0_idx] if t0_idx > 0 else np.array([0.0])
    if hist_counts is None or len(hist_counts) == 0:
        hist_counts = np.array([0.0])
    history_total = int(hist_counts.sum())
    history_nonzero_buckets = int((hist_counts > 0).sum())
    history_all_zero = history_nonzero_buckets == 0
    if history_all_zero and combo_growth > _GROWTH_CAP:
        combo_growth = _GROWTH_CAP

    low_base = history_total < low_base_total
    significant = True
    if low_base:
        if history_all_zero:
            significant = False
        else:
            lam = history_total / max(len(hist_counts), 1)
            p = _poisson_sf(int(target_peak), max(lam, 1e-9))
            significant = p < 0.01

    if history_nonzero_buckets >= history_nonzero_threshold:
        p_val = float(np.percentile(hist_counts, history_percentile))
        percentile_pass = target_peak >= p_val
    else:
        p_val = None
        if history_all_zero:
            # 历史 all-zero = 起量前完全无命中（最稀疏）。只看 post 是否有量(target_peak≥阈值)，
            # 不再要求 nonzero_buckets≥3（全 0 时 nonzero=0 恒不满足，旧逻辑 bug 导致全 0 反而 pct=False）。
            percentile_pass = target_peak >= history_zero_min_target
        else:
            percentile_pass = target_peak >= abs_fallback

    return {"combo_growth": combo_growth, "low_base": low_base, "significant": significant,
            "history_p": p_val, "percentile_pass": percentile_pass,
            "target_peak": target_peak, "history_total": history_total,
            "history_nonzero_buckets": history_nonzero_buckets, "t0_idx": t0_idx}


def _nontrust_bucket_counts_batch(event_ts_df: DataFrame, scene_totals_df: DataFrame,
                                  cid_preds_list: List[Tuple[str, List[Predicate]]],
                                  id_field: str,
                                  account_sets: Optional[Dict[str, DataFrame]] = None) -> Dict[str, np.ndarray]:
    """L2-5 批量：一次 agg 算所有 combo 的 (combo∧非可信) 逐桶 distinct account 数。
    30 分桶（和 combo_hits/scene_totals 同粒度），LEFT JOIN scene_totals 保证同序同长度。
    非可信 = 任一 factor _set 含 "0"/"0.0"/"false"。返回 {cid: np.ndarray}（缺失桶填 0）。

    account_sets: 注册 combo 场景——combo 谓词在 signup 表(无 factor)，但非可信要看 login 表。
    传 {cid: combo命中账号集 DataFrame(account_id 列)} 时，该 cid 用账号集过滤替 combo 谓词
    （login 表无 ses_ 字段，不能直接 filter combo 谓词；用 signup 圈的账号集去 login 表 filter）。
    None = combo 谓词直接在 event_ts_df 上 filter（login combo 场景）。"""
    factor_cols = [c for c in _NONTRUST_FACTOR_FIELDS if c in event_ts_df.columns]
    scene_rows = scene_totals_df.select("bucket_ts").orderBy("bucket_ts").collect()
    scene_ts = [r["bucket_ts"] for r in scene_rows]
    if not scene_ts or not cid_preds_list:
        return {cid: np.zeros(len(scene_ts)) for cid, _ in cid_preds_list}

    # 非可信标记（所有 combo 共用）。factor 字段在事件表是 string（单条请求值如 "0.0"），
    # 在 snapshot 聚合后才是 array<string>(_set)。按字段类型分派：array→array_contains，string→==
    schema_types = {f.name: f.dataType for f in event_ts_df.schema.fields}
    from pyspark.sql.types import ArrayType as _ArrayType
    if factor_cols:
        nontrust_cond = F.lit(False)
        for c in factor_cols:
            dt = schema_types.get(c)
            if isinstance(dt, _ArrayType):
                arr = F.coalesce(F.col(c), F.array())
                for v in _NONTRUST_ZERO_VALUES:
                    nontrust_cond = nontrust_cond | F.array_contains(arr, F.lit(v))
            else:  # string 或其他标量
                col_s = F.col(c).cast("string")
                for v in _NONTRUST_ZERO_VALUES:
                    nontrust_cond = nontrust_cond | (col_s == F.lit(v))
    else:
        nontrust_cond = F.lit(False)
    df = event_ts_df.withColumn("__nt", nontrust_cond)

    # 每 combo 一个 (combo ∧ nt) flag → countDistinct
    # 注册 combo(account_sets 给定): 用账号集过滤替 combo 谓词；login combo: combo 谓词直接 filter
    agg_exprs = []
    cid_list = []
    for cid, preds in cid_preds_list:
        if account_sets and cid in account_sets and account_sets[cid] is not None:
            # 注册 combo：signup 圈的账号集 ∩ login 表的非可信行（login 表无 ses_ 字段，
            # 用 signup 圈的账号集 broadcast join 标记 combo 命中）
            acct_set = account_sets[cid]
            flag_col = f"__hit_{cid}"
            df = df.join(F.broadcast(acct_set.select(F.col("account_id").alias(flag_col))),
                         df[id_field] == F.col(flag_col), how="left")
            cn = f"__nt_{cid}"
            df = df.withColumn(cn, F.col("__nt") & F.col(flag_col).isNotNull()).drop(flag_col)
        else:
            combo_cond = F.lit(True)
            for p in preds:
                combo_cond = combo_cond & p.to_column()
            cn = f"__nt_{cid}"
            df = df.withColumn(cn, combo_cond & F.col("__nt"))
        agg_exprs.append(F.countDistinct(F.when(F.col(cn), F.col(id_field))).alias(cid))
        cid_list.append(cid)

    # groupBy bucket_ts（30 分桶，和 scene_totals 同粒度）。用 collect 不走 toPandas
    # （pandas 新版对 tz-aware timestamp astype datetime64 报 TypeError）。
    rows = (df.withColumn("b", F.col("bucket_ts")).groupBy("b").agg(*agg_exprs)
            .orderBy("b").collect())
    if not rows:
        return {cid: np.zeros(len(scene_ts)) for cid in cid_list}
    lookup = {r["b"]: {c: r[c] for c in cid_list} for r in rows}
    return {cid: np.array([float(lookup.get(ts, {}).get(cid, 0) or 0) for ts in scene_ts], dtype=float)
            for cid in cid_list}


@dataclass
class L2SurgeScore:
    combo_id: str
    t0_ts: Optional[float]
    combo_growth: float
    attribution_ratio: Optional[float]
    history_pct_pass: bool
    scene_growth: float
    bucket_count_std: Optional[float]
    surge_pass: bool
    nontrust_growth: float = 0.0          # L2-5: combo∧非可信 逐桶曲线的 growth
    nontrust_pct_pass: bool = False       # L2-5: 起量前非可信稀疏
    nontrust_pass: bool = False           # L2-5: growth_ok ∧ pct_ok（注册场景恒 False）
    is_signup: bool = False               # 注册 combo(ses_/wes_) 跳 L2-5
    reasons: List[str] = field(default_factory=list)


# L2-5 非可信环境字段（登录 sel_/wel_ 的 factor _set）：任一含 "0"/"0.0" → 非可信
_NONTRUST_FACTOR_FIELDS = [
    "factor_account_usertrust_dfpid_score",
    "factor_account_usertrust_uuid_score",
    "factor_account_usertrust_subip_score",
    "factor_account_usertrust_dm_score",
    "factor_account_history_env",
]
_NONTRUST_ZERO_VALUES = ["0", "0.0", "false"]   # false = factor_account_history_env 不可信


def score_l2_surge(combo_id: str, combo_predicates: List[Predicate],
                   event_ts_df: DataFrame, scene_totals_df: DataFrame,
                   cfg: Optional[Dict[str, Any]] = None,
                   nontrust_counts: Optional[np.ndarray] = None,
                   nontrust_scene_counts: Optional[np.ndarray] = None) -> L2SurgeScore:
    """nontrust_counts: 预算好的 L2-5 非可信逐桶数组。
    nontrust_scene_counts: nontrust 曲线对应的 scene_counts（注册 combo 用 login 表的 scene，
    和 nontrust_counts 同源同长度；None 时回退用 signup 的 scene_counts）。"""
    cfg = cfg or {}
    combo_hits = combo_bucket_hits(event_ts_df, combo_predicates, combo_id)
    ts, combo_counts, scene_counts = _bucket_arrays(combo_hits, scene_totals_df)
    if len(combo_counts) == 0:
        return L2SurgeScore(combo_id, None, 0.0, None, False, 0.0, None, False, reasons=["无命中桶"])

    win_buckets = cfg.get("changepoint_window_days", 1) * _BUCKETS_PER_DAY
    t0_idx = _find_changepoint(combo_counts, max(win_buckets, 1))
    t0_ts = float(ts[t0_idx]) if t0_idx < len(ts) else None

    m = _growth_and_history(combo_counts, scene_counts, t0_idx,
                            buckets_per_day=cfg.get("buckets_per_day", _BUCKETS_PER_DAY),
                            windows_days=cfg.get("windows_days", _DEFAULT_WINDOWS_DAYS),
                            low_base_total=cfg.get("low_base_total", _DEFAULT_LOW_BASE_TOTAL),
                            history_percentile=cfg.get("history_percentile", _DEFAULT_HISTORY_PERCENTILE),
                            abs_fallback=cfg.get("abs_fallback", _DEFAULT_ABS_FALLBACK),
                            history_zero_min_target=cfg.get("history_zero_min_target", _DEFAULT_HISTORY_ZERO_MIN_TARGET))

    scene_pre = scene_counts[max(0, t0_idx - 14 * _BUCKETS_PER_DAY):t0_idx]
    scene_post = scene_counts[t0_idx:t0_idx + 14 * _BUCKETS_PER_DAY]
    scene_growth = 0.0
    if len(scene_pre) and len(scene_post) and scene_pre.mean() > 0:
        scene_growth = float(scene_post.mean() / max(scene_pre.mean(), 1e-9))

    g_pass = cfg.get("combo_growth_pass", _DEFAULT_COMBO_GROWTH_PASS)
    growth_ok = m["combo_growth"] >= g_pass and (not m["low_base"] or m["significant"])
    pct_ok = m["percentile_pass"]
    surge_pass = bool(growth_ok and pct_ok)

    reasons: List[str] = []
    if not growth_ok:
        reasons.append(f"combo_growth={m['combo_growth']:.2f}<{g_pass}")
    if not pct_ok:
        reasons.append("起量前历史非稀疏")

    bucket_std = float(np.std(combo_counts)) if len(combo_counts) else None

    # L2-5 非可信环境突变：combo命中 ∧ 非可信(factor 含0/0.0) 逐桶曲线，同 L2-4 阶跃+稀疏判定（去归因）
    is_signup = any(p.field_name.startswith(("ses_", "wes_")) for p in combo_predicates)
    nontrust_growth = 0.0
    nontrust_pct_pass = False
    nontrust_pass = False
    # L2-5 非可信突变：注册 combo 也算（用 login 表的非可信，pipeline 预算传 nontrust_counts）
    # 优先用预算的 nontrust_counts（批量，和 scene_counts 同序）；否则回退单 combo 算（慢）
    nt_counts = nontrust_counts
    if nt_counts is None:
        nt_counts = _nontrust_bucket_counts_batch(
            event_ts_df, scene_totals_df, [(combo_id, combo_predicates)],
            id_field=cfg.get("event_id_field", "user_id")).get(combo_id)
    if nt_counts is not None and len(nt_counts) > 0:
        # 非可信曲线变点/增长用同源 scene_counts 归一化（注册 combo 用 login 表 scene，
        # 和 nontrust_counts 同长度；None 时回退 signup scene，长度不匹配则截断对齐）
        nt_scene = nontrust_scene_counts if nontrust_scene_counts is not None else scene_counts
        if len(nt_scene) != len(nt_counts):
            n = min(len(nt_scene), len(nt_counts))
            nt_scene = nt_scene[:n]
            nt_counts = nt_counts[:n]
        nt_t0 = _find_changepoint(nt_counts, max(win_buckets, 1))
        nt_m = _growth_and_history(nt_counts, nt_scene, nt_t0,
                                   buckets_per_day=cfg.get("buckets_per_day", _BUCKETS_PER_DAY),
                                   windows_days=cfg.get("windows_days", _DEFAULT_WINDOWS_DAYS),
                                   low_base_total=cfg.get("low_base_total", _DEFAULT_LOW_BASE_TOTAL),
                                   history_percentile=cfg.get("history_percentile", _DEFAULT_HISTORY_PERCENTILE),
                                   abs_fallback=cfg.get("abs_fallback", _DEFAULT_ABS_FALLBACK),
                                   history_zero_min_target=cfg.get("history_zero_min_target", _DEFAULT_HISTORY_ZERO_MIN_TARGET))
        nontrust_growth = nt_m["combo_growth"]
        nt_growth_ok = nt_m["combo_growth"] >= g_pass and (not nt_m["low_base"] or nt_m["significant"])
        nontrust_pct_pass = nt_m["percentile_pass"]
        nontrust_pass = bool(nt_growth_ok and nontrust_pct_pass)
        if nontrust_pass:
            reasons.append(f"L2-5 非可信突变 growth={nt_m['combo_growth']:.1f}≥{g_pass}+稀疏")
        else:
            reasons.append(f"L2-5 非可信未突变(growth={nt_m['combo_growth']:.1f}<{g_pass}或非稀疏)")
    else:
        reasons.append("L2-5 无非可信命中(factor 字段缺失或全可信)")

    return L2SurgeScore(combo_id=combo_id, t0_ts=t0_ts, combo_growth=m["combo_growth"],
                        attribution_ratio=None, history_pct_pass=pct_ok,
                        scene_growth=scene_growth, bucket_count_std=bucket_std,
                        surge_pass=surge_pass,
                        nontrust_growth=nontrust_growth, nontrust_pct_pass=nontrust_pct_pass,
                        nontrust_pass=nontrust_pass, is_signup=is_signup,
                        reasons=reasons)
