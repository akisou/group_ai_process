# -*- coding: utf-8 -*-
"""
4 级输出（v1.0 文档 §二「判定输出分级」）：替旧 3 级 PASS/REVIEW/REJECT。

- UNUSABLE 不可用：大盘命中率≥0.1%（误伤超阈）或 起量与大盘同步 → 废弃/重构。
- STRONG 强确认：L1 任一硬证据成立 → 可直接处置。
- HIGH_RISK 高风险：L2 ≥2 项 + 误伤达标 → 上策略观察。
  L2 项 = L2-4 surge_pass + L2-1 geo_pass + L2-2 segment_pass + L2-7 wifi_pass。
- SUSPECT 可疑：L2 单项 + 误伤达标，或无硬证据 → 不定性，仅监控。

判定优先级：UNUSABLE > STRONG > HIGH_RISK > SUSPECT。误伤超阈最高（安全优先，哪怕 L1 成立也废弃）。
"""
from dataclasses import dataclass, field
from typing import List, Optional

from .l1_scorer import L1Evidence
from .l2_scorer import L2SurgeScore
from .l2_cluster_scorer import L2ClusterScore
from .injury_gate import InjuryScore

LEVEL_STRONG = "STRONG"
LEVEL_HIGH_RISK = "HIGH_RISK"
LEVEL_SUSPECT = "SUSPECT"
LEVEL_UNUSABLE = "UNUSABLE"


@dataclass
class GangVerdict:
    combo_id: str
    level: str
    l1_pass: bool
    surge_pass: bool
    nontrust_pass: bool
    geo_pass: bool
    segment_pass: bool
    wifi_pass: bool
    l2_count: int
    injury_pass: bool
    market_hit_rate: float
    lift: Optional[float]
    combo_growth: float
    attribution_ratio: Optional[float]
    nontrust_growth: float
    scene_growth: float = 0.0          # 场景14天前后均值比（UNUSABLE 判定依据）
    history_pct_pass: bool = False     # L2-4 起量前稀疏
    device_max_ratio: float = 0.0      # L1-1 设备簇占比
    ja3_max_ratio: float = 0.0         # L1-2 ja3簇占比
    black_pool_rate: float = 0.0       # L1-3 黑产池率
    downstream_rate: float = 0.0       # L1-4 下游作弊率
    downstream_detail: str = ""       # L1-4 下游逐字段/逐标签命中明细（审计用，pipe 分隔串）
    geo_max_ratio: float = 0.0         # L2-1 地理簇占比
    segment_max_ratio: float = 0.0     # L2-2 号段簇占比
    wifi_max_ratio: float = 0.0        # L2-7 WiFi簇占比
    case_hit: int = 0                  # case命中数
    case_coverage: float = 0.0         # case覆盖率
    baseline_hit: int = 0              # 大盘抽样命中数
    scaled_baseline_hit: float = 0.0   # 大盘全量命中(×scale)
    precision: float = 0.0             # 精度
    recall: float = 0.0               # 召回率
    v_score: float = 0.0              # F1
    reasons: List[str] = field(default_factory=list)


def _l2_count(l2_surge: Optional[L2SurgeScore], l2_cluster: Optional[L2ClusterScore]) -> int:
    n = 0
    if l2_surge is not None:
        if l2_surge.surge_pass:
            n += 1    # L2-4 组合起量
        if l2_surge.nontrust_pass:
            n += 1    # L2-5 非可信环境突变
    if l2_cluster is not None:
        n += l2_cluster.l2_cluster_count    # L2-1/2/7
    return n


def decide_gang(combo_id: str, l1: Optional[L1Evidence],
                l2_surge: Optional[L2SurgeScore], l2_cluster: Optional[L2ClusterScore],
                injury: InjuryScore, cfg: Optional[dict] = None) -> GangVerdict:
    cfg = cfg or {}
    scene_sync = cfg.get("scene_growth_sync", 1.5)
    rate_max = cfg.get("market_hit_rate_max", 0.001)
    l2_min_for_high = cfg.get("l2_min_for_high_risk", 2)

    l2c = _l2_count(l2_surge, l2_cluster)
    reasons: List[str] = []
    # 1. UNUSABLE（误伤超阈 / 起量与大盘同步）
    if injury.market_hit_rate >= rate_max:
        reasons.append(f"不可用:大盘命中率{injury.market_hit_rate:.4%}≥{rate_max:.4%}(误伤超阈)")
        level = LEVEL_UNUSABLE
    elif l2_surge is not None and l2_surge.scene_growth > scene_sync:
        reasons.append(f"不可用:起量与大盘同步(scene_growth={l2_surge.scene_growth:.2f}>{scene_sync})")
        level = LEVEL_UNUSABLE
    # 2. STRONG（L1 任一硬证据）
    elif l1 is not None and l1.l1_pass:
        axes = [r for r in l1.reasons if r.startswith("L1-")]
        reasons.append(f"强确认:L1硬证据成立({'; '.join(axes) or 'device/ja3/黑产池/下游'})")
        level = LEVEL_STRONG
    # 3. HIGH_RISK（L2 ≥2 + 误伤达标）
    elif l2c >= l2_min_for_high and injury.injury_pass:
        reasons.append(f"高风险:L2 {l2c}项+误伤达标")
        level = LEVEL_HIGH_RISK
    # 4. SUSPECT（L2 单项 + 误伤达标）
    elif l2c >= 1 and injury.injury_pass:
        reasons.append(f"可疑:L2 {l2c}项+误伤达标(无L1硬证据)")
        level = LEVEL_SUSPECT
    # 5. else SUSPECT
    else:
        reasons.append(f"可疑:无L1硬证据+L2 {l2c}项/误伤不达标")
        level = LEVEL_SUSPECT

    return GangVerdict(
        combo_id=combo_id, level=level,
        l1_pass=l1.l1_pass if l1 else False,
        surge_pass=l2_surge.surge_pass if l2_surge else False,
        nontrust_pass=l2_surge.nontrust_pass if l2_surge else False,
        geo_pass=l2_cluster.geo_pass if l2_cluster else False,
        segment_pass=l2_cluster.segment_pass if l2_cluster else False,
        wifi_pass=l2_cluster.wifi_pass if l2_cluster else False,
        l2_count=l2c, injury_pass=injury.injury_pass,
        market_hit_rate=injury.market_hit_rate, lift=injury.lift,
        combo_growth=l2_surge.combo_growth if l2_surge else 0.0,
        attribution_ratio=l2_surge.attribution_ratio if l2_surge else None,
        nontrust_growth=l2_surge.nontrust_growth if l2_surge else 0.0,
        scene_growth=l2_surge.scene_growth if l2_surge else 0.0,
        history_pct_pass=l2_surge.history_pct_pass if l2_surge else False,
        device_max_ratio=l1.device_max_ratio if l1 else 0.0,
        ja3_max_ratio=l1.ja3_max_ratio if l1 else 0.0,
        black_pool_rate=l1.black_pool_rate if l1 else 0.0,
        downstream_rate=l1.downstream_rate if l1 else 0.0,
        downstream_detail=l1.downstream_detail if l1 else "",
        geo_max_ratio=l2_cluster.geo_max_ratio if l2_cluster else 0.0,
        segment_max_ratio=l2_cluster.segment_max_ratio if l2_cluster else 0.0,
        wifi_max_ratio=l2_cluster.wifi_max_ratio if l2_cluster else 0.0,
        case_hit=injury.case_hit, case_coverage=injury.case_coverage,
        baseline_hit=injury.baseline_hit, scaled_baseline_hit=injury.scaled_baseline_hit,
        reasons=reasons)


def combine_verdicts(l1_scores: List[L1Evidence], l2_surge_scores: List[L2SurgeScore],
                     l2_cluster_scores: List[L2ClusterScore],
                     injury_scores: List[InjuryScore],
                     cfg: Optional[dict] = None) -> List[GangVerdict]:
    """按 combo_id 配对 L1+L2-4+L2 簇+误伤 → 4 级判定。"""
    l1_by_id = {e.combo_id: e for e in (l1_scores or [])}
    l2s_by_id = {e.combo_id: e for e in (l2_surge_scores or [])}
    l2c_by_id = {e.combo_id: e for e in (l2_cluster_scores or [])}
    results: List[GangVerdict] = []
    for inj in injury_scores:
        l1 = l1_by_id.get(inj.combo_id)
        l2s = l2s_by_id.get(inj.combo_id)
        l2c = l2c_by_id.get(inj.combo_id)
        results.append(decide_gang(inj.combo_id, l1, l2s, l2c, inj, cfg))
    return results
