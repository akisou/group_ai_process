# -*- coding: utf-8 -*-
"""
L1 硬证据（v1.0《团伙判定校验方案》§二）：snapshot 级，任一成立 → 强确认团伙。

占比口径（替旧绝对数 ≥5/≥10）：回捞总账号为分母。
- L1-1 设备-账号一对多：同一 uuid/dfpid 单簇账号占比 ≥ l1_device_single_ratio(50%)
  或 共用多指纹（≥2账号簇）涉及的账号占比 ≥ l1_device_shared_ratio(70%)。
  设备指纹用 sel/ses/wel/wes × {uuid,dfpid} 合并 8 列（唯一；device_id 是 Build ID、dm 型号、imei unknown 不用）。
- L1-2 网络指纹共用：同一 ja3/ja4 单簇占比 ≥50% 或 共用多指纹账号占比 ≥70%。
  user_active 的 12 个 map<指纹,PV> 取 key。
- L1-3 黑产资源池：命中账号中 is_hit_black_ip / login_black_mobile_level_last_1d /
  is_hit_mobile_risk_black_tag / is_hit_mobile_risk_gray_tag 任一阳性占比 ≥ l1_black_pool_rate(90%)。
- L1-4 下游作弊：命中账号中 risk_profile_sets / rc_event intercept maps / mtsi case·clue
  flags·cntd·id·name·partner sets 任一阳性占比 ≥ l1_downstream_cheat_rate(90%)。

L1 按 combo 算（在 combo 命中账号集上）。资源池(geohash/号段/BSSID) 是 L2 结构证据（l2_cluster_scorer），不在 L1。
"""
from dataclasses import dataclass, field
from functools import reduce
from typing import Any, Dict, List, Optional

from pyspark.sql import DataFrame, functions as F
from pyspark.sql.types import ArrayType, MapType

from account_gang_profiling.predicates.predicate import Predicate

# 设备指纹：sel/ses/wel/wes × {uuid, dfpid} = 8 列
_DEVICE_COLS = [f"{p}_{f}_set" for p in ("sel", "ses", "wel", "wes")
                for f in ("uuid", "dfpid")]
# JA3/JA4 TLS 指纹：user_active 的 map<指纹,PV>（6 业务线 × ja3/ja4 × 1d）
_JA3_COLS = [f"act_mt_{b}_ja{v}_h_cnt_map_1d"
             for b in ("wm", "yy", "sg", "dc", "dz", "xx") for v in ("3", "4")]

_DEFAULT_DEVICE_SINGLE = 0.5
_DEFAULT_DEVICE_SHARED = 0.7
_DEFAULT_JA3_SINGLE = 0.5
_DEFAULT_JA3_SHARED = 0.7
_DEFAULT_BLACK_POOL_RATE = 0.9
_DEFAULT_DOWNSTREAM_RATE = 0.9
# L1-3 黑产资源池：4 act_ 标签字段（任一阳性）+ ipipriskaction 含代理/机房 + canzong 含黑卡
_DEFAULT_BLACK_POOL_FIELDS = ["act_is_hit_black_ip", "act_login_black_mobile_level_last_1d",
                               "act_is_hit_mobile_risk_black_tag", "act_is_hit_mobile_risk_gray_tag"]
_DEFAULT_IPIPRISK_FIELDS = [f"{p}_ipipriskaction_set" for p in ("sel", "ses", "wel", "wes")]
_DEFAULT_IPIPRISK_LABELS = ["代理", "机房"]
_DEFAULT_CANZONG_BLACK_LABELS = ["黑卡"]   # canzong_risk_profile_set 里的「黑卡」也算 L1-3 黑产池
# L1-3 标签白名单型字段（同 L1-4 机制）：ipipriskaction → 代理/机房；canzong → 黑卡
_BLACK_POOL_LABEL_WHITELIST = {
    **{f: _DEFAULT_IPIPRISK_LABELS for f in _DEFAULT_IPIPRISK_FIELDS},
    "act_canzong_risk_profile_set": _DEFAULT_CANZONG_BLACK_LABELS,
}
_DEFAULT_DOWNSTREAM_FIELDS = [
    "act_act_risk_profile_set", "act_canzong_risk_profile_set", "act_graph_risk_profile_set",
    "act_account_risk_profile_set", "act_rc_event_account_cnt_90d_intercept_map",
    "act_rc_event_trade_cnt_90d_intercept_map", "act_is_mtsi_clue_user", "act_is_mtsi_case_user",
    "act_mtsi_case_cntd", "act_mtsi_clue_cntd", "act_mtsi_clue_id_set",
    "act_mtsi_clue_name_set", "act_mtsi_case_id_set", "act_mtsi_clue_partner_set",
]
# 白名单标签型字段：只关注特定标签（任一命中即阳性，OR），其余标签忽略
_DEFAULT_CANZONG_LABELS = ["高危账号"]
_DEFAULT_ACCOUNT_RISK_LABELS = [
    "账号曾被拦截注册", "账号曾被冻结-全量", "批量登录", "批量注册",
    "账号曾被拦截登录", "设备高风险",
]
_LABEL_WHITELIST = {  # field → 只认这些标签
    "act_canzong_risk_profile_set": _DEFAULT_CANZONG_LABELS,
    "act_account_risk_profile_set": _DEFAULT_ACCOUNT_RISK_LABELS,
}
# rc_event intercept map：空对象 {} 不算阳性（map 有 keys 才算）。键名即拦截动作（登录二次验证/找回密码等）。
# mtsi_case_id_set 的 "-1" 表示无 case，不算阳性（需排除）。
_MAP_NONEMPTY_EXCLUDE = {"act_mtsi_case_id_set": ["-1"]}


def combo_filter(snapshot_df: DataFrame, predicates: List[Predicate]) -> DataFrame:
    """共享 helper：AND 链 filter snapshot_df 到 combo 命中账号。injury_gate/l2_cluster 复用。"""
    if not predicates:
        return snapshot_df
    cond = F.lit(True)
    for p in predicates:
        cond = cond & p.to_column()
    return snapshot_df.filter(cond)


def _existing(df: DataFrame, cols: List[str]) -> List[str]:
    return [c for c in cols if c in df.columns]


def _long_df(hit_df: DataFrame, account_col: str, fp_cols: List[str]) -> Optional[DataFrame]:
    """array 列 concat → 单 explode → (acct, fp) 长表。concat 替 N-way union 防 OOM。
    过滤脏值（null/空串/UNKNOWN/0），防 bssid/ssid/province 等存脏值进簇当指纹。"""
    if not fp_cols:
        return None
    combined = F.concat(*[F.coalesce(F.col(c), F.array()) for c in fp_cols])
    return (hit_df.select(F.col(account_col).alias("acct"), F.explode(combined).alias("fp"))
            .filter(F.col("fp").isNotNull()
                    & (F.col("fp") != "") & (F.col("fp") != "UNKNOWN")
                    & (F.col("fp") != "0") & (F.col("fp") != "null")))


def _long_df_map(hit_df: DataFrame, account_col: str, map_cols: List[str]) -> Optional[DataFrame]:
    """map<string,*> 列取 keys → concat → 单 explode → (acct, fp) 长表（用于 ja3/ja4）。"""
    if not map_cols:
        return None
    combined = F.concat(*[F.coalesce(F.map_keys(F.col(c)), F.array()) for c in map_cols])
    return (hit_df.select(F.col(account_col).alias("acct"), F.explode(combined).alias("fp"))
            .filter(F.col("fp").isNotNull()))


def _cluster_ratio(long_df: Optional[DataFrame], total: int,
                   single_thr: float, shared_thr: float) -> tuple:
    """(max_ratio, shared_ratio, pass)。
    max_ratio = 最大簇账号数/total；shared_ratio = 处于≥2账号簇的去重账号数/total。
    pass = max_ratio≥single_thr 或 shared_ratio≥shared_thr。"""
    if long_df is None or total == 0 or long_df.rdd.isEmpty():
        return 0.0, 0.0, False
    clusters = long_df.groupBy("fp").agg(F.countDistinct("acct").alias("n"))
    max_row = clusters.agg(F.max("n").alias("mx")).first()
    max_n = int(max_row["mx"] or 0) if max_row else 0
    max_ratio = max_n / total
    shared_fps = clusters.filter(F.col("n") >= 2).select("fp")
    shared_accts = (long_df.join(shared_fps, "fp").select("acct").distinct().count()
                    if not shared_fps.rdd.isEmpty() else 0)
    shared_ratio = (shared_accts / total) if shared_accts else 0.0
    return max_ratio, shared_ratio, (max_ratio >= single_thr or shared_ratio >= shared_thr)


def _field_positive_cond(df: DataFrame, field: str,
                          label_whitelist: Optional[Dict[str, List[str]]] = None) -> Optional["F.Column"]:
    """字段「阳性」条件：
    - array 白名单字段：array_contains 任一白名单标签
    - array 普通字段：size>0；若在 _MAP_NONEMPTY_EXCLUDE（如 mtsi_case_id_set 含 -1）则再排除指定值
    - map 字段：map_keys size>0（空对象 {} 的 keys 为空 → 不算阳性；rc_event intercept 的 {} 不算）
    - boolean/int/string：非 0/空/UNKNOWN/null（string 的 "0"/"0.0" 也算无，如 mtsi_case_cntd="0.0"）
    字段不存在 → None。"""
    dt = {f.name: f.dataType for f in df.schema}.get(field)
    if dt is None:
        return None
    col = F.col(field)
    labels = (label_whitelist or {}).get(field)
    if labels and isinstance(dt, ArrayType):
        arr = F.coalesce(col, F.array())
        return reduce(lambda a, b: a | b, [F.array_contains(arr, F.lit(l)) for l in labels])
    if isinstance(dt, ArrayType):
        base = F.size(F.coalesce(col, F.array())) > 0
        excl = _MAP_NONEMPTY_EXCLUDE.get(field)
        if excl:
            arr = F.coalesce(col, F.array())
            for v in excl:
                base = base & ~F.array_contains(arr, F.lit(v))
        return base
    if isinstance(dt, MapType):
        # map 非空且 keys 非空（排空对象 {}）；value 全 0 也视为有键算阳性（键名=拦截动作即信号）
        return F.size(F.coalesce(F.map_keys(col), F.array())) > 0
    s = col.cast("string")
    return col.isNotNull() & (s != "0") & (s != "0.0") & (s != "") & (s != "UNKNOWN") & (~s.isin("null", "None"))


def _label_hit_detail(hit_df: DataFrame, field: str, labels: List[str]) -> str:
    """逐标签命中账号数明细（白名单标签型字段）。返回 "label(n)/label(n)" 字符串，n=0 也列。"""
    arr = F.coalesce(F.col(field), F.array())
    aggs = [F.sum(F.when(F.array_contains(arr, F.lit(l)), 1).otherwise(0)).alias(l) for l in labels]
    row = hit_df.agg(*aggs).first()
    if row is None:
        return ""
    parts = [f"{l}({int(row[l] or 0)})" for l in labels]
    return "/".join(parts)


def _field_positive_rate(hit_df: DataFrame, fields: List[str],
                          label_whitelist: Optional[Dict[str, List[str]]] = None) -> tuple:
    """命中账号中任一 fields 阳性的占比 → (rate, hit_n, total)。白名单字段透传 _field_positive_cond。"""
    total_row = hit_df.agg(F.count("account_id").alias("t")).first()
    total = int(total_row["t"]) if total_row and total_row["t"] else 0
    conds = [c for f in fields if (c := _field_positive_cond(hit_df, f, label_whitelist)) is not None]
    if total == 0 or not conds:
        return 0.0, 0, total
    hit_cond = reduce(lambda a, b: a | b, conds)
    row = hit_df.agg(F.sum(F.when(hit_cond, 1).otherwise(0)).alias("c")).first()
    n = int(row["c"]) if row and row["c"] else 0
    return n / total, n, total


@dataclass
class L1Evidence:
    combo_id: str
    device_max_ratio: float
    device_shared_ratio: float
    device_l1: bool
    ja3_max_ratio: float
    ja3_shared_ratio: float
    ja3_l1: bool
    black_pool_rate: float
    black_pool_l1: bool
    downstream_rate: float
    downstream_l1: bool
    downstream_detail: str        # 逐字段/逐标签命中明细（调优用，如 canzong:高危账号(90)/account_risk:批量登录(150)...）
    l1_pass: bool
    reasons: List[str] = field(default_factory=list)


def score_l1(combo_id: str, combo_predicates: List[Predicate],
             snapshot_df: DataFrame, cfg: Optional[Dict[str, Any]] = None) -> L1Evidence:
    cfg = cfg or {}
    dev_single = cfg.get("l1_device_single_ratio", _DEFAULT_DEVICE_SINGLE)
    dev_shared = cfg.get("l1_device_shared_ratio", _DEFAULT_DEVICE_SHARED)
    ja3_single = cfg.get("l1_ja3_single_ratio", _DEFAULT_JA3_SINGLE)
    ja3_shared = cfg.get("l1_ja3_shared_ratio", _DEFAULT_JA3_SHARED)
    bp_rate = cfg.get("l1_black_pool_rate", _DEFAULT_BLACK_POOL_RATE)
    ds_rate = cfg.get("l1_downstream_cheat_rate", _DEFAULT_DOWNSTREAM_RATE)
    bp_fields = cfg.get("l1_black_pool_fields", _DEFAULT_BLACK_POOL_FIELDS)
    ds_fields = cfg.get("l1_downstream_fields", _DEFAULT_DOWNSTREAM_FIELDS)

    hit_df = combo_filter(snapshot_df, combo_predicates).cache()
    total_row = hit_df.agg(F.count("account_id").alias("t")).first()
    total = int(total_row["t"]) if total_row and total_row["t"] else 0
    reasons: List[str] = []

    # L1-1 设备-账号一对多（占比口径）
    dev_cols = _existing(hit_df, _DEVICE_COLS)
    dev_mr, dev_sr, dev_l1 = _cluster_ratio(_long_df(hit_df, "account_id", dev_cols),
                                              total, dev_single, dev_shared)
    if dev_l1:
        reasons.append(f"L1-1 设备簇 max={dev_mr:.0%}/shared={dev_sr:.0%}")

    # L1-2 网络指纹(ja3/ja4，map_keys)
    ja3_cols = _existing(hit_df, _JA3_COLS)
    ja3_mr, ja3_sr, ja3_l1 = _cluster_ratio(_long_df_map(hit_df, "account_id", ja3_cols),
                                            total, ja3_single, ja3_shared)
    if ja3_l1:
        reasons.append(f"L1-2 ja3簇 max={ja3_mr:.0%}/shared={ja3_sr:.0%}")

    # L1-3 黑产资源池：4 act_ 标签 + ipipriskaction(代理/机房) + canzong(黑卡) 任一阳性
    bp_all_fields = bp_fields + _existing(hit_df, _DEFAULT_IPIPRISK_FIELDS) \
                    + (["act_canzong_risk_profile_set"] if "act_canzong_risk_profile_set" in hit_df.columns else [])
    bp_wl = {**_BLACK_POOL_LABEL_WHITELIST,
             "act_canzong_risk_profile_set": cfg.get("l1_canzong_black_labels", _DEFAULT_CANZONG_BLACK_LABELS)}
    bp_r, _, _ = _field_positive_rate(hit_df, bp_all_fields, label_whitelist=bp_wl)
    black_pool_l1 = bp_r >= bp_rate
    if black_pool_l1:
        reasons.append(f"L1-3 黑产池率={bp_r:.0%}≥{bp_rate:.0%}")

    # L1-4 下游作弊（risk_profile/rc_event/mtsi case·clue 字段集）
    # 白名单标签型字段（canzong/account_risk_profile）只认指定标签，其余忽略
    wl = {"act_canzong_risk_profile_set": cfg.get("l1_canzong_labels", _DEFAULT_CANZONG_LABELS),
          "act_account_risk_profile_set": cfg.get("l1_account_risk_labels", _DEFAULT_ACCOUNT_RISK_LABELS)}
    ds_r, _, _ = _field_positive_rate(hit_df, ds_fields, label_whitelist=wl)
    downstream_l1 = ds_r >= ds_rate
    # 逐字段/逐标签命中明细（调优用）：白名单字段列标签命中数，非白名单列总阳性数
    detail_parts = []
    for f in _existing(hit_df, ds_fields):
        if f in wl:
            d = _label_hit_detail(hit_df, f, wl[f])
            detail_parts.append(f"{f}:{d}" if d else f"{f}:0")
        else:
            c = _field_positive_cond(hit_df, f)
            if c is not None:
                rn = hit_df.agg(F.sum(F.when(c, 1).otherwise(0)).alias("n")).first()
                detail_parts.append(f"{f}:{int(rn['n'] or 0) if rn else 0}")
    downstream_detail = " | ".join(detail_parts)
    if downstream_l1:
        reasons.append(f"L1-4 下游作弊率={ds_r:.0%}≥{ds_rate:.0%}  [{downstream_detail}]")

    l1_pass = dev_l1 or ja3_l1 or black_pool_l1 or downstream_l1
    return L1Evidence(combo_id=combo_id,
                      device_max_ratio=dev_mr, device_shared_ratio=dev_sr, device_l1=dev_l1,
                      ja3_max_ratio=ja3_mr, ja3_shared_ratio=ja3_sr, ja3_l1=ja3_l1,
                      black_pool_rate=bp_r, black_pool_l1=black_pool_l1,
                      downstream_rate=ds_r, downstream_l1=downstream_l1,
                      downstream_detail=downstream_detail,
                      l1_pass=l1_pass, reasons=reasons)
