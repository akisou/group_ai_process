# -*- coding: utf-8 -*-
"""l1_scorer 单测（占比口径）：L1-1 设备/L1-2 ja3 单簇≥50%或共用多≥70%，L1-3 黑产池/L1-4 下游 ≥90%。"""
from pyspark.sql import SparkSession
from pyspark.sql.types import (StructType, StructField, StringType, IntegerType,
                                ArrayType, MapType, LongType)

from account_gang_profiling.predicates.predicate import Predicate, OP_ARRAY_CONTAINS
from account_gang_profiling.gang_validation.l1_scorer import score_l1

_DM = Predicate("sel_dm_set", OP_ARRAY_CONTAINS, "ADA-AL00")


def _schema():
    return StructType([
        StructField("account_id", StringType()),
        StructField("sel_dm_set", ArrayType(StringType())),
        StructField("sel_uuid_set", ArrayType(StringType())),
        StructField("ses_uuid_set", ArrayType(StringType())),
        StructField("act_mt_wm_ja3_h_cnt_map_1d", MapType(StringType(), LongType())),
        StructField("act_is_hit_black_ip", IntegerType()),
        StructField("act_is_mtsi_case_user", IntegerType()),
        StructField("act_canzong_risk_profile_set", ArrayType(StringType())),
        StructField("act_account_risk_profile_set", ArrayType(StringType())),
    ])


def run_l1_test(spark):
    spark.sparkContext.setLogLevel("ERROR")
    print("=" * 70)
    print("[l1_scorer 单测（占比口径）]")
    print("=" * 70)

    # L1-1 设备 单簇≥50%：10 账号 5 共用 uuid-X → max_ratio=0.5 → 成立
    rows = [(f"a{i}", ["ADA-AL00"], ["UUID-X"], ["UUID-X"], {}, 0, 0, [], []) for i in range(5)] \
        + [(f"b{i}", ["ADA-AL00"], [f"U{i}"], [f"U{i}"], {}, 0, 0, [], []) for i in range(5)]
    df = spark.createDataFrame(rows, schema=_schema())
    s = score_l1("L1A", [_DM], df)
    assert abs(s.device_max_ratio - 0.5) < 0.01, f"单簇 max_ratio 应=0.5，实={s.device_max_ratio}"
    assert s.device_l1, f"5/10=50%≥50% → L1-1 应成立"
    assert s.l1_pass
    print(f"  L1-1 设备单簇50%: max={s.device_max_ratio:.0%} device_l1={s.device_l1}  ✓")

    # L1-1 设备 共用多≥70%：3+2+2 共用三簇(7账号) → shared_ratio=0.7 → 成立（max=0.3<0.5 走 shared）
    rows2 = ([(f"c{i}", ["ADA-AL00"], ["A"], ["A"], {}, 0, 0, [], []) for i in range(3)]
             + [(f"d{i}", ["ADA-AL00"], ["B"], ["B"], {}, 0, 0, [], []) for i in range(2)]
             + [(f"e{i}", ["ADA-AL00"], ["C"], ["C"], {}, 0, 0, [], []) for i in range(2)]
             + [(f"f{i}", ["ADA-AL00"], [f"U{i}"], [f"U{i}"], {}, 0, 0, [], []) for i in range(3)])
    df2 = spark.createDataFrame(rows2, schema=_schema())
    s2 = score_l1("L1B", [_DM], df2)
    assert s2.device_max_ratio < 0.5, f"max 应<0.5（3/10=0.3），实={s2.device_max_ratio}"
    assert abs(s2.device_shared_ratio - 0.7) < 0.01, f"shared 应=0.7，实={s2.device_shared_ratio}"
    assert s2.device_l1, f"7/10=70%≥70% → L1-1 应成立(shared)"
    print(f"  L1-1 设备共用多70%: max={s2.device_max_ratio:.0%} shared={s2.device_shared_ratio:.0%} device_l1={s2.device_l1}  ✓")

    # L1-1 零复用 → 不成立
    rows3 = [(f"g{i}", ["ADA-AL00"], [f"U{i}"], [f"U{i}"], {}, 0, 0, [], []) for i in range(10)]
    df3 = spark.createDataFrame(rows3, schema=_schema())
    s3 = score_l1("L1C", [_DM], df3)
    assert s3.device_max_ratio <= 0.11 and not s3.device_l1
    print(f"  L1-1 零复用: max={s3.device_max_ratio:.0%} device_l1={s3.device_l1}  ✓")

    # L1-2 ja3 单簇≥50%：10 账号 5 共用 ja3 key → 成立
    rows4 = [(f"j{i}", ["ADA-AL00"], [f"U{i}"], [f"U{i}"],
              {"JA3FP": 1} if i < 5 else {f"fp{i}": 1}, 0, 0, [], []) for i in range(10)]
    df4 = spark.createDataFrame(rows4, schema=_schema())
    s4 = score_l1("L1D", [_DM], df4)
    assert abs(s4.ja3_max_ratio - 0.5) < 0.01, f"ja3 max 应=0.5，实={s4.ja3_max_ratio}"
    assert s4.ja3_l1, f"5/10=50% → L1-2 应成立"
    assert s4.l1_pass
    print(f"  L1-2 ja3单簇50%: max={s4.ja3_max_ratio:.0%} ja3_l1={s4.ja3_l1}  ✓")

    # L1-3 黑产池 ≥90%：10 账号 9 个 is_hit_black_ip=1 → 成立
    rows5 = [(f"p{i}", ["ADA-AL00"], [f"U{i}"], [f"U{i}"], {},
              1 if i < 9 else 0, 0, [], []) for i in range(10)]
    df5 = spark.createDataFrame(rows5, schema=_schema())
    s5 = score_l1("L1E", [_DM], df5)
    assert abs(s5.black_pool_rate - 0.9) < 0.01
    assert s5.black_pool_l1, f"0.9≥0.9 → L1-3 应成立"
    assert s5.l1_pass
    print(f"  L1-3 黑产池90%: rate={s5.black_pool_rate:.0%} black_pool_l1={s5.black_pool_l1}  ✓")

    # L1-4 下游 ≥90%：10 账号 9 个 is_mtsi_case_user=1 → 成立
    rows6 = [(f"q{i}", ["ADA-AL00"], [f"U{i}"], [f"U{i}"], {},
              0, 1 if i < 9 else 0, [], []) for i in range(10)]
    df6 = spark.createDataFrame(rows6, schema=_schema())
    s6 = score_l1("L1F", [_DM], df6)
    assert abs(s6.downstream_rate - 0.9) < 0.01
    assert s6.downstream_l1, f"0.9≥0.9 → L1-4 应成立"
    assert s6.l1_pass
    print(f"  L1-4 下游90%: rate={s6.downstream_rate:.0%} downstream_l1={s6.downstream_l1}  ✓")

    # L1-4 标签白名单：canzong 只有「高危账号」算；account_risk 只有 6 标签算，其余标签不算阳性
    # 10 账号全带非白名单标签（canzong=白金会员、account_risk=三十天内注册）→ ds_rate 应=0（白名单标签一个没命中）
    rows7 = [(f"w{i}", ["ADA-AL00"], [f"U{i}"], [f"U{i}"], {},
              0, 0, ["白金会员"], ["三十天内注册"]) for i in range(10)]
    df7 = spark.createDataFrame(rows7, schema=_schema())
    s7 = score_l1("L1G", [_DM], df7)
    assert s7.downstream_rate == 0.0, f"非白名单标签不应算阳性，ds_rate 应=0，实={s7.downstream_rate}"
    assert not s7.downstream_l1, "全非白名单标签 → L1-4 不成立"
    print(f"  L1-4 白名单过滤(非白名单标签不算): ds_rate={s7.downstream_rate:.0%} downstream_l1={s7.downstream_l1}  ✓")

    # L1-4 标签白名单命中：9 账号 canzong=高危账号 → ds_rate=0.9 → 成立
    rows8 = [(f"x{i}", ["ADA-AL00"], [f"U{i}"], [f"U{i}"], {},
              0, 0, ["高危账号"] if i < 9 else ["白金会员"], []) for i in range(10)]
    df8 = spark.createDataFrame(rows8, schema=_schema())
    s8 = score_l1("L1H", [_DM], df8)
    assert abs(s8.downstream_rate - 0.9) < 0.01, f"9 个高危账号 → ds_rate=0.9，实={s8.downstream_rate}"
    assert s8.downstream_l1, "canzong 高危账号 9/10 → L1-4 应成立"
    assert "高危账号(9)" in s8.downstream_detail, f"detail 应含 高危账号(9)，实={s8.downstream_detail}"
    print(f"  L1-4 白名单命中(canzong高危账号9/10): rate={s8.downstream_rate:.0%} detail={s8.downstream_detail}  ✓")

    assert not s3.l1_pass, "L1C 全 negative 应 l1_pass=False"
    print(f"  全 negative: L1C l1_pass={s3.l1_pass}  ✓")

    print("[PASS] l1_scorer 单测通过")


def _main():
    spark = (SparkSession.builder.master("local[*]").appName("l1_test")
             .config("spark.driver.host", "127.0.0.1")
             .config("spark.driver.bindAddress", "127.0.0.1")
             .config("spark.ui.enabled", "false").getOrCreate())
    try:
        run_l1_test(spark)
    finally:
        spark.stop()


if __name__ == "__main__":
    _main()
