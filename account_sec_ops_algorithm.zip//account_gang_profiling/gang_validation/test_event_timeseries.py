# -*- coding: utf-8 -*-
"""
event_timeseries 单测：mock 事件级明细，验证 30 分钟桶 + combo_bucket_hits +
scene_bucket_totals 的 countDistinct 口径与手算一致。

不经过 build_event_timeseries 的 Hive 读取（本地无 Hive），直接构造带 request_time
的事件 df，套 _bucket_start_col + scene_bucket_totals + combo_bucket_hits。
"""

import sys
import os

from pyspark.sql import SparkSession
from pyspark.sql.types import StructType, StructField, StringType

from account_gang_profiling.predicates.predicate import Predicate, OP_STRING_EQ
from account_gang_profiling.gang_validation.event_timeseries import (
    _bucket_start_col, scene_bucket_totals, combo_bucket_hits,
)

_ACCOUNT_ID = "user_id"


def _build_mock_event_df(spark):
    """5 条登录请求，跨 2 个 30 分钟桶。dm=ADA-AL00 是组合条件。"""
    schema = StructType([
        StructField("user_id", StringType()),
        StructField("request_time", StringType()),  # string，测 F.to_timestamp 兜底
        StructField("dm", StringType()),
        StructField("platform", StringType()),
        StructField("app", StringType()),
    ])
    rows = [
        ("a1", "2026-08-07 14:05:00", "ADA-AL00", "android", "X"),  # 桶 14:00
        ("a2", "2026-08-07 14:20:00", "ADA-AL00", "android", "X"),  # 桶 14:00
        ("a3", "2026-08-07 14:10:00", "OTHER",    "android", "X"),  # 桶 14:00 不命中组合
        ("a1", "2026-08-07 14:35:00", "ADA-AL00", "android", "X"),  # 桶 14:30 a1 再现（不同桶各计一次）
        ("a4", "2026-08-07 14:40:00", "ADA-AL00", "android", "X"),  # 桶 14:30
    ]
    df = spark.createDataFrame(rows, schema=schema)
    return df.withColumn("bucket_ts", _bucket_start_col("request_time")).cache()


def run_event_timeseries_test(spark):
    spark.sparkContext.setLogLevel("ERROR")
    print("=" * 70)
    print("[event_timeseries 单测]")
    print("=" * 70)
    df = _build_mock_event_df(spark)

    combo = [Predicate(field_name="dm", op=OP_STRING_EQ, value="ADA-AL00")]
    scene = {"platform": "android", "app": "X"}

    scene_df = scene_bucket_totals(df, scene).orderBy("bucket_ts").collect()
    combo_df = combo_bucket_hits(df, combo, "C1").orderBy("bucket_ts").collect()

    scene_by_ts = {r["bucket_ts"].strftime("%H:%M"): r["scene_total_accounts"] for r in scene_df}
    combo_by_ts = {r["bucket_ts"].strftime("%H:%M"): r["combo_hit_accounts"] for r in combo_df}

    # 手算：桶 14:00 → 组合{a1,a2}=2，场景{a1,a2,a3}=3；桶 14:30 → 组合{a1,a4}=2，场景{a1,a4}=2
    assert scene_by_ts.get("14:00") == 3, f"scene 14:00 应=3，实={scene_by_ts.get('14:00')}"
    assert scene_by_ts.get("14:30") == 2, f"scene 14:30 应=2，实={scene_by_ts.get('14:30')}"
    assert combo_by_ts.get("14:00") == 2, f"combo 14:00 应=2，实={combo_by_ts.get('14:00')}"
    assert combo_by_ts.get("14:30") == 2, f"combo 14:30 应=2，实={combo_by_ts.get('14:30')}"
    print(f"  scene_bucket_totals: {scene_by_ts}  ✓")
    print(f"  combo_bucket_hits:   {combo_by_ts}  ✓")
    print("  countDistinct 口径与手算一致（同账号跨桶各计一次、组合 AND 过滤正确）✓")

    # 场景分母不含 partner 的校验：传 partner 进 scene_values 应报错
    try:
        scene_bucket_totals(df, {"platform": "android", "partner": "Y"})
        assert False, "partner 进 scene_values 应抛 ValueError"
    except ValueError as e:
        print(f"  partner 拒入场景分母: {e}  ✓")

    print("[PASS] event_timeseries 单测通过")


def _main():
    spark = (SparkSession.builder.master("local[*]").appName("event_ts_test")
             .config("spark.driver.host", "127.0.0.1")
             .config("spark.driver.bindAddress", "127.0.0.1")
             .config("spark.ui.enabled", "false").getOrCreate())
    try:
        run_event_timeseries_test(spark)
    finally:
        spark.stop()


if __name__ == "__main__":
    _main()
