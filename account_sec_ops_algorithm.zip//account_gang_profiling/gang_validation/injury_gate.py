# -*- coding: utf-8 -*-
"""
误伤门槛（v1.0 文档 §四）：大盘命中率 + Lift，替旧 precision 口径。

旧误伤门用 precision_new<0.2（case 样本口径）——case 样本才几百个，是 20万团伙的抽样，
precision 对小样本失真，把「1万大盘命中（20万团伙范围内）」误判为「组合过宽超阈」。
改用绝对口径：
- market_hit_rate = scaled_baseline_hit / market_total（全量大盘命中率）
- lift = case_coverage / market_hit_rate（团伙覆盖率 / 大盘命中率）
- injury_pass = market_hit_rate < market_hit_rate_max(0.1%) 且 lift > lift_min(10)

1万大盘命中 = 1万/562M = 0.0018% < 0.1% → 达标（20万团伙回捞1万正常，不超阈）。
"""
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

from pyspark.sql import DataFrame, functions as F

from account_gang_profiling.predicates.predicate import Predicate
from account_gang_profiling.feature_snapshot.seed_split import SEED_CORE, SEED_WEAK
from .l1_scorer import combo_filter

_DEFAULT_MARKET_HIT_RATE_MAX = 0.001    # 0.1%
_DEFAULT_LIFT_MIN = 10.0


@dataclass
class InjuryScore:
    combo_id: str
    case_hit: int
    case_total: int
    case_coverage: float
    baseline_hit: int           # 抽样大盘命中
    scaled_baseline_hit: float  # 全量大盘命中（×scale）
    market_total: int
    market_hit_rate: float
    lift: Optional[float]
    injury_pass: bool
    reasons: List[str] = field(default_factory=list)


def score_injury(combo_id: str, combo_predicates: List[Predicate],
                 cross_universe: DataFrame, baseline_scale_factor: float,
                 market_total: int, case_total: int,
                 cfg: Optional[Dict[str, Any]] = None) -> InjuryScore:
    cfg = cfg or {}
    rate_max = cfg.get("market_hit_rate_max", _DEFAULT_MARKET_HIT_RATE_MAX)
    lift_min = cfg.get("lift_min", _DEFAULT_LIFT_MIN)

    hit_df = combo_filter(cross_universe, combo_predicates)
    seed_cond = F.col("seed_type").isin(SEED_CORE, SEED_WEAK)
    row = hit_df.agg(
        F.sum(F.when(seed_cond, 1).otherwise(0)).alias("case"),
        F.sum(F.when(~seed_cond, 1).otherwise(0)).alias("base"),
    ).first()
    case_hit = int(row["case"] or 0)
    baseline_hit = int(row["base"] or 0)

    case_coverage = case_hit / case_total if case_total else 0.0
    scaled_baseline_hit = baseline_hit * baseline_scale_factor
    market_hit_rate = (scaled_baseline_hit / market_total) if market_total else 0.0
    # 零大盘命中 = 完美无误差（combo 完全 case-specific），lift=∞，injury 视为达标
    if market_hit_rate > 0:
        lift = case_coverage / market_hit_rate
    elif case_coverage > 0:
        lift = float("inf")
    else:
        lift = None

    reasons: List[str] = []
    injury_pass = market_hit_rate < rate_max and (lift is not None and lift > lift_min)
    if market_hit_rate >= rate_max:
        reasons.append(f"大盘命中率={market_hit_rate:.4%}≥{rate_max:.4%}(误伤超阈→不可用)")
    if lift is None or lift <= lift_min:
        reasons.append(f"lift={lift}(区分力不足<{lift_min})")
    if injury_pass:
        lift_str = "∞" if lift == float("inf") else f"{lift:.1f}"
        reasons.append(f"误伤达标(命中率={market_hit_rate:.4%}<{rate_max:.4%},lift={lift_str}>{lift_min})")

    return InjuryScore(combo_id=combo_id, case_hit=case_hit, case_total=case_total,
                       case_coverage=case_coverage, baseline_hit=baseline_hit,
                       scaled_baseline_hit=scaled_baseline_hit, market_total=market_total,
                       market_hit_rate=market_hit_rate, lift=lift, injury_pass=injury_pass,
                       reasons=reasons)
