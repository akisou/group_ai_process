# -*- coding: utf-8 -*-
"""gang_gate 单测：4 级输出（强确认/高风险/可疑/不可用），含 L2 簇计数。纯 python。"""
from account_gang_profiling.gang_validation.l1_scorer import L1Evidence
from account_gang_profiling.gang_validation.l2_scorer import L2SurgeScore
from account_gang_profiling.gang_validation.l2_cluster_scorer import L2ClusterScore
from account_gang_profiling.gang_validation.injury_gate import InjuryScore
from account_gang_profiling.gang_validation.gang_gate import (
    decide_gang, LEVEL_STRONG, LEVEL_HIGH_RISK, LEVEL_SUSPECT, LEVEL_UNUSABLE)


def _l1(l1_pass, reasons=None):
    return L1Evidence("C", 0.0, 0.0, False, 0.0, 0.0, False, 0.0, False, 0.0, False, l1_pass,
                      reasons or ([f"L1-x"] if l1_pass else []))


def _l2(surge_pass, scene_growth=0.0, growth=5.0, attr=0.5, nontrust=False):
    return L2SurgeScore("C", None, growth, attr, True, scene_growth, 8.0, surge_pass,
                        nontrust_growth=5.0 if nontrust else 0.0, nontrust_pct_pass=nontrust,
                        nontrust_pass=nontrust, is_signup=False, reasons=[])


def _l2c(count, geo=False, seg=False, wifi=False):
    return L2ClusterScore("C", 0.0, 0.0, geo, 0.0, 0.0, seg, 0.0, 0.0, wifi, count, [])


def _i(injury_pass, rate=0.0001, lift=100.0):
    return InjuryScore("C", 50, 100, 0.5, 5, 10000, 562_000_000, rate, lift, injury_pass, [])


def run_gate_test():
    print("=" * 70)
    print("[gang_gate 单测]")
    print("=" * 70)

    # 1) UNUSABLE: 误伤超阈（哪怕 L1 成立也废弃）
    v = decide_gang("C", _l1(True), _l2(True), _l2c(0), _i(False, rate=0.002))
    assert v.level == LEVEL_UNUSABLE, f"误伤超阈应 UNUSABLE，实={v.level}"
    print(f"  误伤超阈(rate=0.2%)+L1成立: → {v.level}（L1不救超阈）✓")

    # 2) UNUSABLE: 起量与大盘同步
    v2 = decide_gang("C", _l1(True), _l2(True, scene_growth=2.0), _l2c(0), _i(True))
    assert v2.level == LEVEL_UNUSABLE, f"起量同步应 UNUSABLE，实={v2.level}"
    print(f"  起量与大盘同步(scene=2.0): → {v2.level} ✓")

    # 3) STRONG: L1 成立 + 误伤达标
    v3 = decide_gang("C", _l1(True), _l2(False), _l2c(0), _i(True))
    assert v3.level == LEVEL_STRONG, f"L1 成立应 STRONG，实={v3.level}"
    print(f"  L1硬证据成立+误伤达标: → {v3.level} ✓")

    # 4) HIGH_RISK: L2≥2 + 误伤达标（surge=1 + geo=1 → count=2）
    v4 = decide_gang("C", _l1(False), _l2(True), _l2c(1, geo=True), _i(True))
    assert v4.level == LEVEL_HIGH_RISK, f"L2=2 应 HIGH_RISK，实={v4.level}"
    assert v4.l2_count == 2
    print(f"  L2=2(surge+geo)+误伤达标: → {v4.level} ✓")

    # 4b) HIGH_RISK: L2=2(surge + nontrust) + 误伤达标
    v4b = decide_gang("C", _l1(False), _l2(True, nontrust=True), _l2c(0), _i(True))
    assert v4b.level == LEVEL_HIGH_RISK, f"surge+nontrust L2=2 应 HIGH_RISK，实={v4b.level}"
    assert v4b.l2_count == 2 and v4b.nontrust_pass
    print(f"  L2=2(surge+nontrust)+误伤达标: → {v4b.level} ✓")

    # 5) SUSPECT: L2 单项 + 误伤达标
    v5 = decide_gang("C", _l1(False), _l2(True), _l2c(0), _i(True))
    assert v5.level == LEVEL_SUSPECT, f"L2=1 应 SUSPECT，实={v5.level}"
    print(f"  L2=1(surge单项)+误伤达标: → {v5.level} ✓")

    # 6) SUSPECT 默认：无 L1 + L2=0
    v6 = decide_gang("C", _l1(False), _l2(False), _l2c(0), _i(True))
    assert v6.level == LEVEL_SUSPECT
    print(f"  无L1+L2=0: → {v6.level} ✓")

    # 7) SUSPECT：L2=2 但误伤不达标 → SUSPECT（非 HIGH_RISK）
    v7 = decide_gang("C", _l1(False), _l2(True), _l2c(1, geo=True), _i(False, lift=5.0))
    assert v7.level == LEVEL_SUSPECT, f"误伤不达标应 SUSPECT 非 HIGH_RISK，实={v7.level}"
    print(f"  L2=2但lift<10: → {v7.level}（HIGH_RISK 需误伤达标）✓")

    print("[PASS] gang_gate 4 级单测通过")


if __name__ == "__main__":
    run_gate_test()
