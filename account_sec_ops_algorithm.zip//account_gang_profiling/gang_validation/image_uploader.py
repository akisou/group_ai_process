# -*- coding: utf-8 -*-
"""
S3 图片上传器（复用反爬 hopejob 的 S3ImageUploader 模式）。
把 gang_validation 的时序折线图（SVG/PNG）上传到美团 S3plus 对象存储，返回公开 URL。
URL 可写结果表，供下游平台/人审直接看图。

凭证用 KMS appkey 认证（非 access_key/secret），同反爬。
config gang_validation.s3_upload 配置 endpoint/appkey/bucket/prefix。
"""
import hashlib
from typing import List, Dict, Optional


class GangImageUploader:
    """gang_validation 图片上传 S3。懒加载 mssapi（prod 机器可能没装）。"""

    def __init__(self, endpoint: str, appkey: str, bucket_name: str, image_prefix: str = "gang_validation"):
        self.endpoint = endpoint
        self.appkey = appkey
        self.bucket_name = bucket_name
        self.image_prefix = image_prefix
        self._connection = None
        self._bucket = None

    def _ensure_conn(self):
        """懒加载 S3 连接（codelab 用 kms_appkey 透明密钥，需容器开 pc.use.kms=true）。"""
        if self._bucket is not None:
            return
        from mssapi.s3.connection import S3Connection
        self._connection = S3Connection(
            kms_appkey=self.appkey,
            is_secure=False,
            host=self.endpoint,
        )
        self._bucket = self._connection.get_bucket(self.bucket_name)

    def _generate_key(self, combo_id: str, content_hash: str, ext: str = "svg") -> str:
        """生成唯一 key：{prefix}_{combo_id}_{hash}.{ext}。同 combo+同内容→同 key（幂等）。"""
        return f"{self.image_prefix}_{combo_id}_{content_hash}.{ext}"

    def upload_image_from_bytes(self, image_bytes: bytes, combo_id: str,
                                 ext: str = "svg") -> Optional[str]:
        """上传图片字节到 S3，返回公开 URL。失败返回 None（不阻断主流程）。
        ext: svg/png。SVG 直接传字符串字节，浏览器可渲染；PNG 需 matplotlib 生成。"""
        try:
            self._ensure_conn()
            content_hash = hashlib.md5(image_bytes).hexdigest()[:16]
            key = self._generate_key(combo_id, content_hash, ext)
            s3_key = self._bucket.new_key(key)
            # SVG 是文本，设 content-type 让浏览器直接渲染
            content_type = "image/svg+xml" if ext == "svg" else "image/png"
            s3_key.set_contents_from_string(image_bytes, headers={"Content-Type": content_type})
            url = f"http://{self.endpoint}/{self.bucket_name}/{key}"
            return url
        except Exception as e:
            print(f"  [WARN] S3 上传失败({combo_id}): {e}")
            return None
