# -*- coding: utf-8 -*-
"""
时序折线图（逐日命中账号数）。每个组合产两张 SVG（均内联渲染+落文件）：
① atoms 图：各原子·大盘逐日命中（单维度 before-surge 监控）。
② combo 图：combo·大盘 + combo·样本 + 样本总量（case 样本总活跃），三线对比
   "组合在大盘 vs 团伙样本 vs 团伙整体活跃"。

event_ts_df 为全量大盘时序（验证口径）；case_sample_df 给定时画 combo·样本 + 样本总量。
无 matplotlib 依赖（SVG 纯字符串）；IPython.display 不可用时回退 sparkline 文本。
"""
import os
from typing import List, Optional

import pandas as pd
from pyspark.sql import DataFrame, functions as F

from account_gang_profiling.predicates.predicate import Predicate

_BLOCKS = "▁▂▃▄▅▆▇█"
_PALETTE = ["#000000", "#1f77b4", "#ff7f0e", "#2ca02c", "#d62728",
            "#9467bd", "#8c564b", "#e377c2", "#7f7f7f"]


def _daily_hits_pd(event_ts_df: DataFrame, preds: List[Predicate],
                   label: str, id_field: str = "user_id") -> pd.DataFrame:
    """单组谓词的逐日 distinct 命中账号数 → pandas（列: d, <label>）。
    空 preds = 不过滤 = 该 df 的逐日 distinct 总账号数（用于"样本总量"线）。"""
    if preds:
        cond = F.lit(True)
        for p in preds:
            cond = cond & p.to_column()
        df = event_ts_df.filter(cond)
    else:
        df = event_ts_df
    pdf = (df.withColumn("d", F.to_date("bucket_ts"))
           .groupBy("d").agg(F.countDistinct(F.col(id_field)).alias("hits"))
           .orderBy("d")).toPandas()
    return pdf.rename(columns={"hits": label})


def _sparkline(values) -> str:
    vals = [float(v) for v in values]
    if not vals:
        return ""
    mx = max(vals)
    if mx <= 0:
        return _BLOCKS[0] * len(vals)
    return "".join(_BLOCKS[min(7, int(v / mx * 7))] for v in vals)


def _svg_linechart(dates: List[str], series_cols: List[str],
                   data_by_col: dict, t0_idx: Optional[int] = None,
                   title: str = "逐日命中账号数", width: int = 1000, height: int = 440) -> str:
    """纯字符串生成 SVG 折线图。combo·大盘 黑粗，样本线稍粗，其余细。"""
    n = len(dates)
    if n == 0:
        return ""
    mx = max((max(data_by_col[c]) for c in series_cols if c in data_by_col), default=0)
    if mx <= 0:
        mx = 1.0
    L, R, T, B = 60, 210, 34, 50
    pw, ph = width - L - R, height - T - B

    def x(i): return round(L + (i / max(1, n - 1)) * pw, 1)
    def y(v): return round(T + (1 - v / mx) * ph, 1)

    p = [f'<svg xmlns="http://www.w3.org/2000/svg" width="{width}" height="{height}" '
         f'style="background:#fff;font-family:sans-serif;font-size:11px">']
    p.append(f'<text x="{L}" y="{T-12}" fill="#222" font-size="13">{title}</text>')
    p.append(f'<rect x="{L}" y="{T}" width="{pw}" height="{ph}" fill="none" stroke="#bbb"/>')
    for frac, lbl in [(1.0, "0"), (0.5, str(int(mx / 2))), (0.0, str(int(mx)))]:
        yy = round(T + frac * ph, 1)
        p.append(f'<line x1="{L}" y1="{yy}" x2="{L+pw}" y2="{yy}" stroke="#eee"/>')
        p.append(f'<text x="{L-5}" y="{yy+3}" text-anchor="end" fill="#666">{lbl}</text>')
    for frac in (0.0, 0.25, 0.5, 0.75, 1.0):
        idx = int(frac * (n - 1))
        xx = round(L + frac * pw, 1)
        p.append(f'<line x1="{xx}" y1="{T}" x2="{xx}" y2="{T+ph}" stroke="#f0f0f0"/>')
        p.append(f'<text x="{xx}" y="{T+ph+14}" text-anchor="middle" fill="#666">{dates[idx]}</text>')
    if t0_idx is not None and 0 <= t0_idx < n:
        xx0 = x(t0_idx)
        p.append(f'<line x1="{xx0}" y1="{T}" x2="{xx0}" y2="{T+ph}" stroke="#d00" '
                 f'stroke-width="1.5" stroke-dasharray="5,3"/>')
        p.append(f'<text x="{xx0+3}" y="{T+12}" fill="#d00">t0</text>')
    for i, col in enumerate(series_cols):
        if col not in data_by_col:
            continue
        vals = data_by_col[col]
        color = _PALETTE[i % len(_PALETTE)]
        w = 2.6 if col == "combo·大盘" else (2.0 if "样本" in col else 1.4)
        pts = " ".join(f"{x(j)},{y(v)}" for j, v in enumerate(vals))
        p.append(f'<polyline points="{pts}" fill="none" stroke="{color}" stroke-width="{w}"/>')
    lx = L + pw + 12
    for i, col in enumerate(series_cols):
        color = _PALETTE[i % len(_PALETTE)]
        ly = T + 6 + i * 16
        p.append(f'<line x1="{lx}" y1="{ly}" x2="{lx+18}" y2="{ly}" stroke="{color}" stroke-width="2"/>')
        p.append(f'<text x="{lx+24}" y="{ly+3}" fill="#333">{col[:22]}</text>')
    p.append('</svg>')
    return "".join(p)


def plot_combo_timeseries(event_ts_df: DataFrame, combo_id: str,
                          event_preds: List[Predicate],
                          t0_ts: Optional[object] = None,
                          out_dir: str = "/home/hadoop-ba-rc",
                          id_field: str = "user_id",
                          case_sample_df: Optional[DataFrame] = None,
                          s3_uploader=None) -> List[Optional[str]]:
    """每个组合产两张 SVG（内联渲染+落文件+可选S3上传）：
    ① atoms 图：各原子·大盘。② combo 图：combo·大盘 + combo·样本 + 样本总量。
    case_sample_df 给定时才画 combo·样本 + 样本总量（_apply_sample_filter 处理
    sample_account_id 列名+类型，不能用 user_id 直接 join）。
    s3_uploader: GangImageUploader 实例（可选），给定时上传 SVG 到 S3 拿公开 URL。
    Returns: [atoms_svg_path, combo_svg_path]（写盘失败项为 None）。
    Returns: [atoms_svg_path, combo_svg_path]（写盘失败项为 None）。
    """
    from account_gang_profiling.feature_snapshot.snapshot_builder import _apply_sample_filter

    # 1) 收集逐日序列（大盘口径）
    atom_specs = [(f"{p.field_name}={p.value}", p) for p in event_preds]
    atom_pds = [(lbl, _daily_hits_pd(event_ts_df, [p], lbl, id_field)) for lbl, p in atom_specs]
    combo_pd = _daily_hits_pd(event_ts_df, event_preds, "combo·大盘", id_field)
    # case 样本过滤（_apply_sample_filter 处理 sample_account_id 列+类型转换）
    combo_sample_pd = None
    sample_total_pd = None
    if case_sample_df is not None:
        try:
            case_df = _apply_sample_filter(event_ts_df, id_field, case_sample_df)
            combo_sample_pd = _daily_hits_pd(case_df, event_preds, "combo·样本", id_field)
            sample_total_pd = _daily_hits_pd(case_df, [], "样本总量", id_field)  # 空 preds=case 全活跃
        except Exception as e:
            print(f"  [WARN] {combo_id} 样本线计算失败: {e}")

    # 2) 合并 + 补全日期范围内全 0 天
    merged = combo_pd
    extra = [combo_sample_pd, sample_total_pd] + [ap for _, ap in atom_pds]
    for pd_ in extra:
        if pd_ is not None:
            merged = pd.merge(merged, pd_, on="d", how="outer")
    merged = merged.sort_values("d").fillna(0)
    merged["d"] = pd.to_datetime(merged["d"])
    if len(merged) > 1:
        full = pd.date_range(merged["d"].min(), merged["d"].max(), freq="D")
        merged = (merged.set_index("d").reindex(full).fillna(0)
                  .reset_index().rename(columns={"index": "d"}))
    dates = merged["d"].dt.strftime("%m-%d").tolist()
    data_by_col = {c: merged[c].tolist() for c in merged.columns if c != "d"}

    # t0 → 日索引
    t0_idx = None
    if t0_ts is not None:
        try:
            t0_date = pd.Timestamp(t0_ts, unit="s").normalize()
            t0_idx = int((t0_date - merged["d"].iloc[0]).days)
        except Exception:
            t0_idx = None

    # 3) 每个原子一张 SVG（各自 y 轴，避免 app/scene_id 等量大参数压扁其他）+ combo 一张
    combo_cols = ["combo·大盘"] + (["combo·样本", "样本总量"] if combo_sample_pd is not None else [])
    os.makedirs(out_dir, exist_ok=True)
    charts = []  # [(kind, label, svg), ...]
    for i, (lbl, _) in enumerate(atom_specs):
        charts.append((f"atom{i}", lbl,
                       _svg_linechart(dates, [lbl], {lbl: data_by_col[lbl]}, t0_idx,
                                      title=f"{combo_id} {lbl}·大盘逐日命中")))
    charts.append(("combo", "combo",
                   _svg_linechart(dates, combo_cols, {c: data_by_col[c] for c in combo_cols}, t0_idx,
                                  title=f"{combo_id} combo·大盘 vs 样本 vs 样本总量")))
    paths: List[Optional[str]] = []
    s3_urls: List[Optional[str]] = []
    chart_svgs: List[Dict[str, str]] = []  # [{combo_id, kind, label, svg}, ...] 供 Hive 存图
    for kind, label, svg in charts:
        path = None
        try:
            path = os.path.join(out_dir, f"{combo_id}_{kind}.svg")
            with open(path, "w", encoding="utf-8") as f:
                f.write(svg)
        except Exception:
            path = None
        paths.append(path)
        # S3 上传（可选）：svg 字节传 S3 拿公开 URL
        s3_url = None
        if s3_uploader is not None:
            s3_url = s3_uploader.upload_image_from_bytes(
                svg.encode("utf-8"), combo_id=f"{combo_id}_{kind}", ext="svg")
            if s3_url:
                print(f"  [{kind}] {combo_id} S3: {s3_url}")
        s3_urls.append(s3_url)
        chart_svgs.append({"combo_id": combo_id, "kind": kind, "label": label, "svg": svg})
        try:
            from IPython.display import HTML, display
            print(f"  [{kind} {label}] {combo_id}")
            display(HTML(svg))
        except Exception:
            pass

    # 4) sparkline 文本兜底（任一图没落盘或 IPython 不可用时打印形态）
    if any(p is None for p in paths):
        for kind, label, svg in charts:
            cols = [label] if kind.startswith("atom") else combo_cols
            lines = [f"=== {combo_id} {kind}（{len(dates)} 天；▁→█ 由低到高）==="]
            for c in cols:
                vals = data_by_col.get(c, [])
                mx = int(max(vals)) if vals else 0
                lines.append(f"  {c[:30]:<30}: {_sparkline(vals)}  max={mx}")
            print("\n".join(lines))
    # S3 URLs 存入 paths（有 S3 URL 时替落盘路径，无时保落盘路径）
    final_paths = [u if u else p for u, p in zip(s3_urls, paths)]
    return final_paths, chart_svgs
