# -*- coding: utf-8 -*-
"""l2_scorer 单测：combo_growth/pct numpy 数学 + L2-5 批量非可信。归因比已删。"""
import numpy as np
from pyspark.sql import SparkSession
from pyspark.sql.types import (StructType, StructField, StringType,
                                ArrayType, TimestampType)

from account_gang_profiling.predicates.predicate import Predicate, OP_ARRAY_CONTAINS
from account_gang_profiling.gang_validation.l2_scorer import (
    _find_changepoint, _growth_and_history, _poisson_sf,
)


def run_l2_test(spark):
    spark.sparkContext.setLogLevel("ERROR")
    print("=" * 70)
    print("[l2_scorer 单测]")
    print("=" * 70)

    # 归因比测试已删（_attribution_ratio 函数已移除，v1.0 文档「时序可辩护」，定性靠 L1）

    # numpy 数学（搬 test_temporal_scorer_math 关键路径）
    counts = np.array([5.0] * 336 + [30.0] * 336, dtype=float)
    t0 = _find_changepoint(counts, 48)
    assert 320 <= t0 <= 352, f"变点应在336附近，实={t0}"
    print(f"  变点: t0={t0} ✓")

    m = _growth_and_history(counts, np.full(672, 1000.0), 336)
    assert m["combo_growth"] >= 3 and m["percentile_pass"] and not m["low_base"]
    print(f"  清晰起量: growth={m['combo_growth']:.2f} pct={m['percentile_pass']} ✓")

    # 全0历史→起量：post peak=30≥history_zero_min_target(30) → pct=True（修 bug：旧版全0 要求
    # nonzero_buckets≥3 恒不满足，导致最稀疏的全0反 pct=False）
    counts0 = np.array([0.0] * 336 + [30.0] * 336, dtype=float)
    m0 = _growth_and_history(counts0, np.full(672, 1000.0), 336)
    assert m0["combo_growth"] == 1e6 and not m0["significant"], f"全0历史 growth 应封顶1e6，实={m0['combo_growth']}"
    assert m0["percentile_pass"], f"全0历史+post有量(30≥30) → pct 应 True（修后），实={m0['percentile_pass']}"
    print(f"  全0历史→起量: growth封顶={m0['combo_growth']:.0f} sig={m0['significant']} pct={m0['percentile_pass']}(修后True) ✓")

    assert _poisson_sf(30, 0.0179) < 1e-10 and _poisson_sf(1, 0.5) > 0.3
    print(f"  poisson_sf: sf(30,0.0179)={_poisson_sf(30,0.0179):.2e} sf(1,0.5)={_poisson_sf(1,0.5):.3f} ✓")

    # 4) L2-5 非可信曲线批量：2 combo，一次 agg 拿各 combo 的非可信逐桶数组
    from account_gang_profiling.gang_validation.l2_scorer import _nontrust_bucket_counts_batch
    from account_gang_profiling.gang_validation.event_timeseries import scene_bucket_totals
    # 复用 _build_event_df 的 post 窗数据 + 加 factor 字段（含 0/0.0 标非可信）
    from datetime import datetime
    t0 = datetime(2026, 2, 1)
    post_bucket = datetime(2026, 2, 5)
    nt_schema = StructType([
        StructField("bucket_ts", TimestampType()),
        StructField("user_id", StringType()),
        StructField("dm", ArrayType(StringType())),                       # 事件表原字段名（无前缀）
        StructField("factor_account_usertrust_dm_score", ArrayType(StringType())),  # 真实字段名
    ])
    # combo A=dm X: 5 账号非可信(trust含0)；combo B=dm Y: 3 账号非可信
    nt_rows = ([(post_bucket, f"a{i}", ["X"], ["0.0"]) for i in range(5)]
               + [(post_bucket, f"b{i}", ["Y"], ["0"]) for i in range(3)]
               + [(post_bucket, f"c{i}", ["X"], ["4.8"]) for i in range(2)])  # 可信，不计入
    nt_df = spark.createDataFrame(nt_rows, schema=nt_schema)
    scene_tot = scene_bucket_totals(nt_df, {}, id_field="user_id")
    cid_preds = [("cA", [Predicate("dm", OP_ARRAY_CONTAINS, "X")]),
                 ("cB", [Predicate("dm", OP_ARRAY_CONTAINS, "Y")])]
    nt_by_cid = _nontrust_bucket_counts_batch(nt_df, scene_tot, cid_preds, "user_id")
    a_arr = nt_by_cid["cA"]
    b_arr = nt_by_cid["cB"]
    assert len(a_arr) == len(b_arr) == len(scene_tot.select("bucket_ts").collect()), "数组应与 scene 同长"
    assert a_arr.max() == 5.0, f"combo A 非可信应 5（trust含0的5账号），实 max={a_arr.max()}"
    assert b_arr.max() == 3.0, f"combo B 非可信应 3，实 max={b_arr.max()}"
    print(f"  L2-5 批量非可信: cA max={a_arr.max():.0f}(5非可信) cB max={b_arr.max():.0f}(3非可信) ✓")

    print("[PASS] l2_scorer 单测通过")


def _main():
    spark = (SparkSession.builder.master("local[*]").appName("l2_test")
             .config("spark.driver.host", "127.0.0.1")
             .config("spark.driver.bindAddress", "127.0.0.1")
             .config("spark.ui.enabled", "false").getOrCreate())
    try:
        run_l2_test(spark)
    finally:
        spark.stop()


if __name__ == "__main__":
    _main()
