# -*- coding: utf-8 -*-
"""
L2 结构证据——snapshot 级聚集簇（v1.0 文档 §二 L2-1/2/7）：占比口径。

- L2-1 地理聚集：同一 省份/城市/geohash6/geohash7 下账号占比 ≥ l2_geo_single(50%)
  或 共用多地理值（≥2账号簇）涉及账号占比 ≥ l2_geo_shared(70%)。
- L2-2 号段集中：同一手机号段(前7位) 账号占比 ≥ l2_segment_single(70%)
  或 共用多号段账号占比 ≥ l2_segment_shared(70%)。（号段熵低暂未实现，走占比口径）
- L2-7 WiFi/基站聚集：同一 BSSID 账号占比 ≥ l2_wifi_single(50%) 或 共用多 BSSID 占比 ≥ 70%。

l2_cluster_count = geo_pass + segment_pass + wifi_pass（供 gang_gate 的 HIGH_RISK L2≥2 用）。
注：L2-3 设备新鲜度 v1.0 未列；L2-5/6 留后续。与 L2-4(event 级 surge) 在 gang_gate 汇总。
"""
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

from pyspark.sql import DataFrame, functions as F

from account_gang_profiling.predicates.predicate import Predicate
from .l1_scorer import combo_filter, _existing, _long_df, _cluster_ratio

# 地理：sel/ses/wel/wes × {mobileprovince, ipprovince, mobile_city, ipcity, geocode6, geocode7}
_GEO_FIELDS = ("mobileprovince", "ipprovince", "mobile_city", "ipcity", "geocode6", "geocode7")
_GEO_COLS = [f"{p}_{f}_set" for p in ("sel", "ses", "wel", "wes") for f in _GEO_FIELDS]
# 号段：sel/ses/wel/wes × mobile7
_SEGMENT_COLS = [f"{p}_mobile7_set" for p in ("sel", "ses", "wel", "wes")]
# WiFi：sel/ses/wel/wes × bssid
_WIFI_COLS = [f"{p}_bssid_set" for p in ("sel", "ses", "wel", "wes")]

_DEFAULT_GEO_SINGLE = 0.5
_DEFAULT_GEO_SHARED = 0.7
_DEFAULT_SEGMENT_SINGLE = 0.7
_DEFAULT_SEGMENT_SHARED = 0.7
_DEFAULT_WIFI_SINGLE = 0.5
_DEFAULT_WIFI_SHARED = 0.7


@dataclass
class L2ClusterScore:
    combo_id: str
    geo_max_ratio: float
    geo_shared_ratio: float
    geo_pass: bool
    segment_max_ratio: float
    segment_shared_ratio: float
    segment_pass: bool
    wifi_max_ratio: float
    wifi_shared_ratio: float
    wifi_pass: bool
    l2_cluster_count: int
    reasons: List[str] = field(default_factory=list)


def score_l2_cluster(combo_id: str, combo_predicates: List[Predicate],
                     snapshot_df: DataFrame, cfg: Optional[Dict[str, Any]] = None) -> L2ClusterScore:
    cfg = cfg or {}
    geo_single = cfg.get("l2_geo_single_ratio", _DEFAULT_GEO_SINGLE)
    geo_shared = cfg.get("l2_geo_shared_ratio", _DEFAULT_GEO_SHARED)
    seg_single = cfg.get("l2_segment_single_ratio", _DEFAULT_SEGMENT_SINGLE)
    seg_shared = cfg.get("l2_segment_shared_ratio", _DEFAULT_SEGMENT_SHARED)
    wifi_single = cfg.get("l2_wifi_single_ratio", _DEFAULT_WIFI_SINGLE)
    wifi_shared = cfg.get("l2_wifi_shared_ratio", _DEFAULT_WIFI_SHARED)

    hit_df = combo_filter(snapshot_df, combo_predicates).cache()
    total_row = hit_df.agg(F.count("account_id").alias("t")).first()
    total = int(total_row["t"]) if total_row and total_row["t"] else 0
    reasons: List[str] = []

    geo_cols = _existing(hit_df, _GEO_COLS)
    geo_mr, geo_sr, geo_pass = _cluster_ratio(_long_df(hit_df, "account_id", geo_cols),
                                                total, geo_single, geo_shared)
    if geo_pass:
        reasons.append(f"L2-1 地理簇 max={geo_mr:.0%}/shared={geo_sr:.0%}")

    seg_cols = _existing(hit_df, _SEGMENT_COLS)
    seg_mr, seg_sr, seg_pass = _cluster_ratio(_long_df(hit_df, "account_id", seg_cols),
                                                total, seg_single, seg_shared)
    if seg_pass:
        reasons.append(f"L2-2 号段簇 max={seg_mr:.0%}/shared={seg_sr:.0%}")

    wifi_cols = _existing(hit_df, _WIFI_COLS)
    wifi_mr, wifi_sr, wifi_pass = _cluster_ratio(_long_df(hit_df, "account_id", wifi_cols),
                                                   total, wifi_single, wifi_shared)
    if wifi_pass:
        reasons.append(f"L2-7 WiFi簇 max={wifi_mr:.0%}/shared={wifi_sr:.0%}")

    l2_cluster_count = sum([geo_pass, seg_pass, wifi_pass])
    return L2ClusterScore(combo_id=combo_id,
                          geo_max_ratio=geo_mr, geo_shared_ratio=geo_sr, geo_pass=geo_pass,
                          segment_max_ratio=seg_mr, segment_shared_ratio=seg_sr, segment_pass=seg_pass,
                          wifi_max_ratio=wifi_mr, wifi_shared_ratio=wifi_sr, wifi_pass=wifi_pass,
                          l2_cluster_count=l2_cluster_count, reasons=reasons)
