# -*- coding: utf-8 -*-
"""l2_cluster_scorer 单测：L2-1 地理 / L2-2 号段 / L2-7 WiFi 占比口径。"""
from pyspark.sql import SparkSession
from pyspark.sql.types import StructType, StructField, StringType, ArrayType

from account_gang_profiling.predicates.predicate import Predicate, OP_ARRAY_CONTAINS
from account_gang_profiling.gang_validation.l2_cluster_scorer import score_l2_cluster

_DM = Predicate("sel_dm_set", OP_ARRAY_CONTAINS, "ADA-AL00")
_SCHEMA = StructType([
    StructField("account_id", StringType()),
    StructField("sel_dm_set", ArrayType(StringType())),
    StructField("sel_geocode6_set", ArrayType(StringType())),
    StructField("sel_mobile7_set", ArrayType(StringType())),
    StructField("sel_bssid_set", ArrayType(StringType())),
])


def run_l2_cluster_test(spark):
    spark.sparkContext.setLogLevel("ERROR")
    print("=" * 70)
    print("[l2_cluster_scorer 单测]")
    print("=" * 70)

    # L2-1 地理 单簇≥50%：10 账号 5 共用 geocode6=GEO-X → 成立
    rows = [(f"a{i}", ["ADA-AL00"], ["GEO-X"] if i < 5 else [f"g{i}"],
              [f"m{i}"], [f"b{i}"]) for i in range(10)]
    df = spark.createDataFrame(rows, schema=_SCHEMA)
    s = score_l2_cluster("L2A", [_DM], df)
    assert abs(s.geo_max_ratio - 0.5) < 0.01, f"geo max 应=0.5，实={s.geo_max_ratio}"
    assert s.geo_pass, f"5/10=50% → L2-1 应成立"
    print(f"  L2-1 地理单簇50%: max={s.geo_max_ratio:.0%} geo_pass={s.geo_pass}  ✓")

    # L2-2 号段 单簇≥70%：10 账号 7 共用 mobile7=SEG → 成立
    rows2 = [(f"b{i}", ["ADA-AL00"], [f"g{i}"],
              "SEG" if i < 7 else f"s{i}", [f"b{i}"]) for i in range(10)]
    # 注：mobile7 字段构造为 array；上面写成 string，修正：
    rows2 = [(f"b{i}", ["ADA-AL00"], [f"g{i}"],
              ["SEG"] if i < 7 else [f"s{i}"], [f"b{i}"]) for i in range(10)]
    df2 = spark.createDataFrame(rows2, schema=_SCHEMA)
    s2 = score_l2_cluster("L2B", [_DM], df2)
    assert abs(s2.segment_max_ratio - 0.7) < 0.01, f"segment max 应=0.7，实={s2.segment_max_ratio}"
    assert s2.segment_pass, f"7/10=70% → L2-2 应成立"
    print(f"  L2-2 号段单簇70%: max={s2.segment_max_ratio:.0%} segment_pass={s2.segment_pass}  ✓")

    # L2-7 WiFi 单簇≥50%：10 账号 5 共用 bssid=BSS → 成立
    rows3 = [(f"c{i}", ["ADA-AL00"], [f"g{i}"], [f"m{i}"],
              ["BSS"] if i < 5 else [f"b{i}"]) for i in range(10)]
    df3 = spark.createDataFrame(rows3, schema=_SCHEMA)
    s3 = score_l2_cluster("L2C", [_DM], df3)
    assert abs(s3.wifi_max_ratio - 0.5) < 0.01
    assert s3.wifi_pass, f"5/10=50% → L2-7 应成立"
    print(f"  L2-7 WiFi单簇50%: max={s3.wifi_max_ratio:.0%} wifi_pass={s3.wifi_pass}  ✓")

    # 全 negative → l2_cluster_count=0
    rows4 = [(f"d{i}", ["ADA-AL00"], [f"g{i}"], [f"m{i}"], [f"b{i}"]) for i in range(10)]
    df4 = spark.createDataFrame(rows4, schema=_SCHEMA)
    s4 = score_l2_cluster("L2D", [_DM], df4)
    assert s4.l2_cluster_count == 0, f"全 negative 应 count=0，实={s4.l2_cluster_count}"
    print(f"  全 negative: count={s4.l2_cluster_count}  ✓")

    # 多项成立 → count=2
    rows5 = [(f"e{i}", ["ADA-AL00"],
              ["GEO"] if i < 5 else [f"g{i}"],
              ["SEG"] if i < 7 else [f"s{i}"],
              [f"b{i}"]) for i in range(10)]
    df5 = spark.createDataFrame(rows5, schema=_SCHEMA)
    s5 = score_l2_cluster("L2E", [_DM], df5)
    assert s5.l2_cluster_count == 2, f"geo+segment 应 count=2，实={s5.l2_cluster_count}"
    print(f"  geo+segment 双成立: count={s5.l2_cluster_count}  ✓")

    print("[PASS] l2_cluster_scorer 单测通过")


def _main():
    spark = (SparkSession.builder.master("local[*]").appName("l2cluster_test")
             .config("spark.driver.host", "127.0.0.1")
             .config("spark.driver.bindAddress", "127.0.0.1")
             .config("spark.ui.enabled", "false").getOrCreate())
    try:
        run_l2_cluster_test(spark)
    finally:
        spark.stop()


if __name__ == "__main__":
    _main()
