# -*- coding: utf-8 -*-
"""
Hive 表写入器：把 pipeline 各阶段结果写 Hive 表，供可视化平台读取。
所有 case 共用一张表，case_id + experiment + dt 作为分区字段。

表1 gang_validation_result：4级判定 + L1/L2/误伤 全字段
表2 candidate_predicates：初筛候选 Predicate
表3 mining_process：挖掘过程
表4 gang_recall_accounts：捞全账号（全量大盘回捞）
表0 gang_validation_charts：时序图 SVG（在 pipeline step6 写）
"""
import json
from typing import Any, Dict, List, Optional, Tuple

from pyspark.sql import DataFrame, Row, SparkSession
from pyspark.sql import functions as F

from account_gang_profiling.predicates.predicate import Predicate

TABLE_RESULT = "ba_rc_test.acc_sec_gang_validation_result"
TABLE_CANDIDATES = "ba_rc_test.acc_sec_candidate_predicates"
TABLE_MINING = "ba_rc_test.acc_sec_mining_process"
TABLE_RECALL = "ba_rc_test.acc_sec_gang_recall_accounts"
TABLE_CHARTS = "ba_rc_test.acc_sec_gang_validation_charts"
TABLE_CASE_INFO = "ba_rc_test.acc_sec_case_info"
TABLE_SNAPSHOT_INFO = "ba_rc_test.acc_sec_snapshot_info"
TABLE_SEED_SPLIT = "ba_rc_test.acc_sec_seed_split"
TABLE_FINAL_RULES = "ba_rc_test.acc_sec_gang_final_rules"

# 事件表前缀 → 表名映射（用于捞全时按谓词前缀扫全量事件表）
_EVENT_TABLE_PREFIXES = {
    "sel_": "ba_rc.app_stra_account_strong_end_login_feature_info",
    "ses_": "ba_rc.app_stra_account_strong_end_signup_feature_info",
    "wel_": "ba_rc.app_stra_account_week_end_login_feature_info",
    "wes_": "ba_rc.app_stra_account_week_end_signup_feature_info",
}
# act_ 谓词扫精简日表（76列，去计数+map转set）。原 mart_mtsi.topic_user_active_ss_d 全量表
# 存储消耗过大，切到 ba_rc_test.app_acc_sec_topic_user_active_ss_d_set（每日单日快照，T-2）。
# 精简表是"已聚合快照表"（一账号一行），列名 = snapshot 列名去掉 act_ 前缀（_set 后缀保留），
# 故 act_ 谓词扫它时跳过 _translate_pred_to_event_field 的去 _set 后缀逻辑（见 recall_accounts）。
_USER_ACTIVE_TABLE = "ba_rc_test.app_acc_sec_topic_user_active_ss_d_set"
_USER_ACTIVE_ID_FIELD = "mt_user_id"


_PARTITION_COLS = ("case_id", "experiment", "dt")


def _ensure_table_columns(spark: SparkSession, df: DataFrame, table: str) -> None:
    """schema drift 自愈：表已存在时，把 df 有但表没有的数据列 ALTER ADD COLUMNS 补齐。
    非破坏——保留所有历史分区（旧分区新列读为 NULL），避免 append schema mismatch
    被吞（case_info experiments 列那次就是这场景）。只补缺列、不处理类型不匹配
    （罕见，由 _fail_loud 兜底报错）。分区列从不补（由 partitionBy 管）。"""
    try:
        existing = {f.name for f in spark.table(table).schema.fields}
    except Exception:
        return  # 表不存在（首次写）→ saveAsTable 会按 df schema 建表，无需补列
    missing = [f for f in df.schema.fields
               if f.name not in existing and f.name not in _PARTITION_COLS]
    if not missing:
        return
    cols_sql = ", ".join(f"`{f.name}` {f.dataType.simpleString()}" for f in missing)
    spark.sql(f"ALTER TABLE {table} ADD COLUMNS ({cols_sql})")
    print(f"[Hive] {table}: auto-heal ADD COLUMNS ({cols_sql})")


def _write_partitioned(spark: SparkSession, df: DataFrame, table: str,
                        case_id: str, experiment: str, dt: str):
    """按 case_id + experiment + dt 动态分区写入。
    首次：partitionBy 自动建分区表。
    后续：先删旧分区（同 case+experiment+dt）再 append，避免 mode(overwrite) 覆盖全表。
    schema drift 自愈：append 前自动 ADD COLUMNS 补齐 df 有、表没有的列（非破坏）。"""
    from pyspark.sql import functions as F2
    df_with_part = (df
        .withColumn("case_id", F2.lit(case_id))
        .withColumn("experiment", F2.lit(experiment))
        .withColumn("dt", F2.lit(dt)))

    # 先删旧分区（如果表已存在且该分区有数据）
    try:
        spark.sql(f"ALTER TABLE {table} DROP IF EXISTS PARTITION "
                  f"(case_id='{case_id}',experiment='{experiment}',dt='{dt}')")
    except Exception:
        pass  # 表不存在（首次）或分区不存在，忽略

    # schema drift 自愈：补齐表缺的数据列（非破坏，保留历史分区）
    _ensure_table_columns(spark, df_with_part, table)

    # 首次建表用 partitionBy，后续 append 到同表
    df_with_part.write.mode("append").partitionBy("case_id", "experiment", "dt").saveAsTable(table)


def _global_combo_id(case_id: str, combo_id: str) -> str:
    """生成全局唯一 combo_id：case_id + '_' + combo_id（如 '13081001_c000'）。
    代码内部仍用 c000（索引兼容），写 Hive 时拼成全局唯一键。"""
    return f"{case_id}_{combo_id}"


def write_validation_result_table(spark: SparkSession, verdicts: List,
                                   candidate_combos: List, case_id: str, dt: str,
                                   experiment: str = "default"):
    """表1：规则验证结果主表。"""
    if not verdicts:
        return
    rows = []
    for rank, v in enumerate(verdicts, 1):
        combo = candidate_combos[int(v.combo_id[1:])]
        preds_json = json.dumps([
            {"field": p.field_name, "op": p.op, "value": str(p.value)}
            for p in combo.predicates
        ], ensure_ascii=False)
        combo_sql = " AND ".join(p.to_sql_fragment() for p in combo.predicates)
        rows.append(Row(
            combo_id=_global_combo_id(case_id, v.combo_id), rule_rank=rank,
            predicates=preds_json, combo_sql=combo_sql, combo_size=len(combo.predicates),
            level=v.level,
            combo_growth=float(v.combo_growth), surge_pass=bool(v.surge_pass),
            nontrust_growth=float(v.nontrust_growth), nontrust_pass=bool(v.nontrust_pass),
            geo_max_ratio=float(v.geo_max_ratio), geo_pass=bool(v.geo_pass),
            segment_max_ratio=float(v.segment_max_ratio), segment_pass=bool(v.segment_pass),
            wifi_max_ratio=float(v.wifi_max_ratio), wifi_pass=bool(v.wifi_pass),
            l2_count=int(v.l2_count),
            l1_pass=bool(v.l1_pass),
            device_max_ratio=float(v.device_max_ratio), ja3_max_ratio=float(v.ja3_max_ratio),
            black_pool_rate=float(v.black_pool_rate), downstream_rate=float(v.downstream_rate),
            downstream_detail=str(v.downstream_detail),
            market_hit_rate=float(v.market_hit_rate),
            lift=float(v.lift) if v.lift is not None and v.lift != float("inf") else float("inf"),
            case_hit=int(v.case_hit), case_coverage=float(v.case_coverage),
            baseline_hit=int(v.baseline_hit), scaled_baseline_hit=float(v.scaled_baseline_hit),
            injury_pass=bool(v.injury_pass),
            precision=float(v.precision), recall=float(v.recall), v_score=float(v.v_score),
            scene_growth=float(v.scene_growth), history_pct_pass=bool(v.history_pct_pass),
            reasons="; ".join(v.reasons),
        ))
    df = spark.createDataFrame(rows)
    _write_partitioned(spark, df, TABLE_RESULT, case_id, experiment, dt)
    print(f"[Hive] 表1 result: partition(case_id={case_id},experiment={experiment},dt={dt})（{len(rows)} 行）")


def write_candidate_predicates_table(spark: SparkSession, candidate_stats: List,
                                      case_id: str, dt: str, experiment: str = "default"):
    """表2：候选 Predicate 初筛表。"""
    if not candidate_stats:
        return
    rows = []
    for s in candidate_stats:
        rows.append(Row(
            field_name=s.predicate.field_name,
            op=s.predicate.op,
            value=str(s.predicate.value),
            clue_support=float(s.clue_support),
            baseline_support=float(s.baseline_support),
            lift=float(s.lift),
            clue_hit=int(s.clue_hit_count),
            baseline_hit=int(s.baseline_hit_count),
            passed=True,
        ))
    df = spark.createDataFrame(rows)
    _write_partitioned(spark, df, TABLE_CANDIDATES, case_id, experiment, dt)
    print(f"[Hive] 表2 candidates: partition(case_id={case_id},experiment={experiment},dt={dt})（{len(rows)} 行）")


def write_mining_process_table(spark: SparkSession, mining_result: Dict,
                                case_id: str, dt: str, experiment: str = "default"):
    """表3：挖掘过程表。"""
    signatures = mining_result.get("signatures", [])
    if not signatures:
        return
    rows = []
    for idx, sig in enumerate(signatures):
        combo = sig["combo"]
        metrics = sig.get("metrics", {})
        preds_json = json.dumps([
            {"field": p.field_name, "op": p.op, "value": str(p.value)}
            for p in combo.predicates
        ], ensure_ascii=False)
        combo_id = sig.get("combo_id", f"c{idx:03d}")
        features = sig.get("features", [])
        root_predicate = features[0] if features else ""
        rows.append(Row(
            root_predicate=root_predicate,
            root_pool=sig.get("root_pool", ""),
            depth=len(combo.predicates),
            combo_id=_global_combo_id(case_id, combo_id),
            predicates=preds_json,
            stop_reason=sig.get("stop_reason", mining_result.get("search_mode", "")),
            precision=float(metrics.get("precision", combo.precision)),
            recall=float(metrics.get("recall", combo.recall)),
            v_score=float(metrics.get("v_score", combo.v_score)),
            clue_hit=int(metrics.get("clue_hit_count", combo.clue_hit_count)),
            baseline_hit=int(metrics.get("baseline_hit_count", combo.baseline_hit_count)),
        ))
    df = spark.createDataFrame(rows)
    _write_partitioned(spark, df, TABLE_MINING, case_id, experiment, dt)
    print(f"[Hive] 表3 mining: partition(case_id={case_id},experiment={experiment},dt={dt})（{len(rows)} 行）")


def _split_predicates_by_table(predicates: List[Predicate]) -> Dict[str, List[Predicate]]:
    """按谓词 field_name 前缀分组：sel_/ses_/wel_/wes_ → 对应事件表；act_ → user_active。
    返回 {table_name: [predicates]}。同表谓词一起 filter，跨表交集。"""
    groups: Dict[str, List[Predicate]] = {}
    for p in predicates:
        matched = False
        for prefix, table in _EVENT_TABLE_PREFIXES.items():
            if p.field_name.startswith(prefix):
                groups.setdefault(table, []).append(p)
                matched = True
                break
        if not matched and p.field_name.startswith("act_"):
            groups.setdefault(_USER_ACTIVE_TABLE, []).append(p)
            matched = True
        # 未匹配的谓词（无前缀）忽略——不应出现在最终规则里
    return groups


def _translate_pred_to_event_field(pred: Predicate, field_types: Dict[str, Any]) -> Predicate:
    """snapshot 列名（ses_os_set）→ 事件表原字段名（os）+ 按事件表实际类型修正 op。
    去前缀 + 去 _set 后缀。快照的 _set 列是 collect_set 出的数组、array_contains 成立；
    但事件表原字段（os/dm/methodname 每条事件一个标量）是 string，array_contains 对
    string 报 type mismatch。故事件表该字段为标量（非 array）时 array_contains→string_eq；
    字段本就是 array（如预聚合集合列）才保留 array_contains。field_types 由调用方从
    事件表 schema 读入（{field_name: DataType}）。"""
    from account_gang_profiling.predicates.predicate import OP_ARRAY_CONTAINS, OP_STRING_EQ
    from pyspark.sql.types import ArrayType
    # 去前缀
    fname = pred.field_name
    for prefix in ("sel_", "ses_", "wel_", "wes_", "act_"):
        if fname.startswith(prefix):
            fname = fname[len(prefix):]
            break
    # 去 _set 后缀
    if fname.endswith("_set"):
        fname = fname[:-4]
    # op 修正：事件表字段为标量（非 array）时，array_contains → string_eq
    op = pred.op
    raw_type = field_types.get(fname)
    if pred.op == OP_ARRAY_CONTAINS and raw_type is not None and not isinstance(raw_type, ArrayType):
        op = OP_STRING_EQ
    return Predicate(field_name=fname, op=op, value=pred.value, display_name=pred.display_name)


def _translate_pred_to_slim_field(pred: Predicate) -> Predicate:
    """snapshot 列名（act_xxx_set）→ 精简表列名：仅去 act_ 前缀，保留 _set 后缀，op 不变。

    精简表是"已聚合快照表"（一账号一行，列名 = snapshot 列名去掉 act_ 前缀），与原始事件表
    （每条事件一个标量字段、需去 _set 后缀还原原字段名 + 改 op）不同。精简表里：
    - 9 个原 map 列已 map_keys 转 array<string>，列名带 _set；谓词 op 已是 array_contains（snapshot
      按 field_type_overrides.array 分类生成），扫 array 列正确。
    - 其余 act_ 列（布尔/数值/string_boolean）列名无 _set 后缀，去 act_ 前缀即原字段名，op 不变。
    故 act_ 谓词扫精简表时不能用 _translate_pred_to_event_field（它去 _set 后缀会让 reg_login_*_set
    → reg_login_*，对不上精简表列名）。"""
    fname = pred.field_name[4:] if pred.field_name.startswith("act_") else pred.field_name
    return Predicate(field_name=fname, op=pred.op, value=pred.value, display_name=pred.display_name)


def _window_start(dt: str, window_days: int) -> str:
    """快照窗口左端点（YYYYMMDD）= dt - window_days。事件表回捞扫 [start_dt, dt] 匹配 snapshot 窗口语义。"""
    from datetime import datetime, timedelta
    return (datetime.strptime(dt, "%Y%m%d") - timedelta(days=window_days)).strftime("%Y%m%d")


def _full_window_scan(spark: SparkSession, table_name: str, id_field: str,
                       event_preds: List[Predicate], dt: str, start_dt: str,
                       is_user_active: bool, cache: Dict[str, DataFrame]) -> DataFrame:
    """取该表全量扫描（缓存跨谓词/跨 rank 复用，每表只扫一次）。
    事件表（sel_/ses_/wel_/wes_）扫整窗口 dt BETWEEN start_dt AND dt——snapshot 的 ses_X_set
    是 collect_set over window，单日扫会漏窗口内别天账号（rank1 820→238 主因）。
    user_active 扫单 dt——act_ 字段是预聚合滚动窗口数组（14d 等），单 dt 即含聚合，且全表
    562M/分区、扫 180 天不可行。"""
    if table_name in cache:
        return cache[table_name]
    needed = sorted({p.field_name for p in event_preds})
    cols = list(dict.fromkeys([id_field] + needed))
    cols_sql = ", ".join(f"`{c}`" for c in cols)
    where = f"dt='{dt}'" if is_user_active else f"dt BETWEEN '{start_dt}' AND '{dt}'"
    scan = spark.sql(f"SELECT {cols_sql} FROM {table_name} WHERE {where}")
    cache[table_name] = scan.cache()
    return cache[table_name]


def recall_accounts(spark: SparkSession, final_rules: List, ctx: Dict,
                     case_id: str, dt: str, experiment: str = "default"):
    """表4：捞全——用最终规则在全量大盘上捞 account_id。

    recall.rule_rank 是最终规则序号（1-N，diverse 选出），与 result.rule_rank（1-7 含 UNUSABLE）
    独立。跨表关联用 combo_id。

    修 3 个 bug（相对旧版）：
    1. 事件表扫整个窗口 dt BETWEEN start AND dt（旧版单 dt '{dt}' 漏窗口内别天账号——rank1
       820→238 主因）。user_active 仍单 dt（act_ 是预聚合滚动窗口数组、全窗口扫不可行）。
    2. 每谓词各自 filter+distinct account 再账号级交集（旧版同表多谓词单事件 AND——rank2
       3 个 ses_ 谓词→0）。匹配 snapshot 的 per-account set 语义（跨事件 OR）。
    3. combo_id 从 candidate_combos 按 identity 反查 index（旧版按 rank 索引 gang_results 错号）。
    """
    if not final_rules:
        return

    src_tables = (ctx.get("config", {}).get("feature_snapshot", {}).get("source_tables", []))
    window_days = ctx.get("config", {}).get("feature_snapshot", {}).get("window_days", 0)
    start_dt = _window_start(dt, window_days)
    # 事件表字段类型缓存 {table: {field: DataType}}，跨 rank 复用，避免重复读 schema
    table_field_types: Dict[str, Dict[str, Any]] = {}
    # 全窗口 scan 缓存 {table: DataFrame}，跨谓词/跨 rank 复用，每表只扫一次
    scan_cache: Dict[str, DataFrame] = {}
    candidate_combos = ctx.get("candidate_combos") or []
    all_hits = []

    for rank, rule in enumerate(final_rules, 1):
        combo = rule.validation_result.combo
        # combo_id = 该 combo 在 candidate_combos 里的 index（c{NNN}）。
        # 不能按 rank 索引 gang_results——final_rules 是 diverse 选择序、gang_results 是
        # candidate 序，两序不同会 combo_id 对错号、recall↔result↔mining 按 combo_id join 断。
        combo_id = next((f"c{idx:03d}" for idx, cc in enumerate(candidate_combos) if cc is combo), "")
        if not combo_id and candidate_combos:
            print(f"[Hive] 表4 recall: rank={rank} rule.combo 未在 candidate_combos 命中(身份)，combo_id 留空")
        raw_preds = list(combo.predicates)

        # 按前缀分表
        pred_groups = _split_predicates_by_table(raw_preds)
        if not pred_groups:
            print(f"[Hive] 表4 recall: rank={rank} 无可识别前缀的谓词，跳过")
            continue

        # 每谓词各自 filter+distinct account，再账号级交集——修 Bug B（per-account set 语义，
        # 旧版同表多谓词单事件 AND，rank2 3 个 ses_ 谓词→0）
        per_pred_sets: List[DataFrame] = []
        for table_name, preds in pred_groups.items():
            is_ua = table_name == _USER_ACTIVE_TABLE
            if table_name not in table_field_types:
                table_field_types[table_name] = {
                    f.name: f.dataType for f in spark.table(table_name).schema.fields}
            field_types = table_field_types[table_name]
            id_field = (_USER_ACTIVE_ID_FIELD if is_ua
                        else (next((t for t in src_tables if t.get("table") == table_name), None)
                              or {}).get("id_field", "user_id"))
            # act_ 谓词扫精简表：列名仅去 act_ 前缀（保留 _set 后缀）、op 不变；
            # 事件表谓词扫原始事件表：去前缀+去_set后缀+按表schema自适应op。
            if is_ua:
                event_preds = [_translate_pred_to_slim_field(p) for p in preds]
            else:
                event_preds = [_translate_pred_to_event_field(p, field_types) for p in preds]
            scan = _full_window_scan(spark, table_name, id_field, event_preds,
                                     dt, start_dt, is_ua, scan_cache)
            for ep in event_preds:
                per_pred_sets.append(
                    scan.filter(ep.to_column())
                        .select(F.col(id_field).cast("string").alias("account_id"))
                        .distinct())
            print(f"  rank={rank} {table_name}: {len(event_preds)} 谓词，{'单dt' if is_ua else f'{start_dt}~{dt}'}")

        if not per_pred_sets:
            continue
        # 账号级交集（所有谓词，含跨表）= snapshot 的 combo AND 语义
        rule_hits = per_pred_sets[0]
        for s in per_pred_sets[1:]:
            rule_hits = rule_hits.join(s, on="account_id", how="inner")

        # 加 rule_rank + combo_id + combo_hit（实际全量命中数）+ incremental_coverage（diverse 增量）
        actual_hit_count = rule_hits.count()
        rule_hits = rule_hits.withColumn("rule_rank", F.lit(rank))
        rule_hits = rule_hits.withColumn("combo_id", F.lit(_global_combo_id(case_id, combo_id)))
        rule_hits = rule_hits.withColumn("combo_hit", F.lit(actual_hit_count))
        rule_hits = rule_hits.withColumn("incremental_coverage", F.lit(rule.marginal_new_coverage))

        all_hits.append(rule_hits)
        print(f"  rank={rank} 全量捞回: {actual_hit_count} 账号")

    if not all_hits:
        print("[Hive] 表4 recall: 无可捞全账号")
        return

    # union 所有规则
    recall_df = all_hits[0]
    for df in all_hits[1:]:
        recall_df = recall_df.unionByName(df)

    _write_partitioned(spark, recall_df, TABLE_RECALL, case_id, experiment, dt)
    total = recall_df.count()
    distinct = recall_df.select("account_id").distinct().count()
    print(f"[Hive] 表4 recall: partition(case_id={case_id},experiment={experiment},dt={dt})（{total} 行，去重 {distinct}）")


def write_final_rules_table(spark: SparkSession, selection_result: Dict, ctx: Dict,
                             case_id: str, dt: str, experiment: str = "default"):
    """表9：最终规则集（rule-level，N 行/case）。step6 diverse 选出的 N 条规则一行一条，
    含谓词/判定/精度召回/命中/新增覆盖/累计覆盖。平台一张表读完最终规则集，
    免表4+表1+表6 distinct+join。不依赖 recall（recall 失败不影响）。"""
    final_rules = selection_result.get("final_rules", [])
    if not final_rules:
        return
    candidate_combos = ctx.get("candidate_combos") or []
    gang_results = ctx.get("gang_validation_results") or []
    verdict_by_id = {v.combo_id: v for v in gang_results}  # combo_id(短 c000) → verdict
    rows = []
    total_cov = 0
    for rank, rule in enumerate(final_rules, 1):
        combo = rule.validation_result.combo
        cid_short = next((f"c{idx:03d}" for idx, cc in enumerate(candidate_combos) if cc is combo), "")
        verdict = verdict_by_id.get(cid_short)
        preds_json = json.dumps([
            {"field": p.field_name, "op": p.op, "value": str(p.value)}
            for p in combo.predicates
        ], ensure_ascii=False)
        combo_sql = " AND ".join(p.to_sql_fragment() for p in combo.predicates)
        total_cov += int(rule.marginal_new_coverage or 0)
        rows.append(Row(
            rule_rank=rank,
            combo_id=_global_combo_id(case_id, cid_short),
            combo_size=len(combo.predicates),
            combo_sql=combo_sql,
            predicates=preds_json,
            level=(verdict.level if verdict else ""),
            precision=float(combo.precision),
            recall=float(combo.recall),
            v_score=float(combo.v_score),
            clue_hit=int(combo.clue_hit_count),
            baseline_hit=int(combo.baseline_hit_count),
            incremental_coverage=int(rule.marginal_new_coverage or 0),
            total_coverage=total_cov,
        ))
    df = spark.createDataFrame(rows)
    _write_partitioned(spark, df, TABLE_FINAL_RULES, case_id, experiment, dt)
    print(f"[Hive] 表9 final_rules: partition(case_id={case_id},experiment={experiment},dt={dt})（{len(rows)} 行）")


def write_case_info_table(spark: SparkSession, ctx: Dict, case_id: str, dt: str):
    """表6：CASE 基础信息表。记录 CASE_ID/名称/样本量/快照时间/种子分布/大盘信息。"""
    cfg = ctx.get("config", {})
    rows = [Row(
        case_id=str(case_id),
        case_name=str(ctx.get("case_name", "")),
        sample_count=int(ctx.get("snapshot_df").count()) if ctx.get("snapshot_df") else 0,
        feature_col_count=int(len(ctx["snapshot_df"].columns)) if ctx.get("snapshot_df") else 0,
        snapshot_dt=str(dt),
        window_days=int(cfg.get("feature_snapshot", {}).get("window_days", 0)),
        # 种子分类
        core_seed_count=int(ctx.get("full_seed_count", 0) or ctx.get("snapshot_df").count() if ctx.get("snapshot_df") else 0),
        train_count=int(ctx.get("train_seed_df").count()) if ctx.get("train_seed_df") else 0,
        validation_count=int(ctx.get("validation_seed_df").count()) if ctx.get("validation_seed_df") else 0,
        excluded_count=0,
        # 大盘 baseline
        baseline_count=int(ctx.get("baseline_df").count()) if ctx.get("baseline_df") else 0,
        baseline_scale_factor=float(ctx.get("baseline_scale_factor", 1.0)),
        market_total=int(ctx.get("baseline_df").count() * ctx.get("baseline_scale_factor", 1.0)) if ctx.get("baseline_df") else 0,
        # 时序回捞
        temporal_window_days=int((cfg.get("gang_validation") or {}).get("window_days", 0)),
        # 种子模式
        seed_mode=str(cfg.get("seed_classification", {}).get("mode", "")),
        # 实验列表（存实验名逗号分隔，平台切实验用）
        experiments=str((cfg.get("gang_validation") or {}).get("experiment", "default")),
        run_experiments=bool((cfg.get("gang_validation") or {}).get("run_experiments", False)),
        # 硬编码补充（后续从 ctx 取）
        hard_negative_count=int(ctx.get("hard_negative_df").count()) if ctx.get("hard_negative_df") else 0,
        whitelist_count=int(ctx.get("whitelist_df").count()) if ctx.get("whitelist_df") else 0,
        create_time=str(dt),
    )]
    df = spark.createDataFrame(rows)
    _write_partitioned(spark, df, TABLE_CASE_INFO, case_id, "default", dt)
    print(f"[Hive] 表6 case_info: partition(case_id={case_id},dt={dt})（1 行）")


def write_snapshot_info_table(spark: SparkSession, ctx: Dict, case_id: str, dt: str):
    """表7：快照构建信息表。记录每张源表的读取信息（表名/前缀/类型/账号数/字段数/耗时）。"""
    cfg = ctx.get("config", {})
    src_tables = cfg.get("feature_snapshot", {}).get("source_tables", [])
    rows = []
    for t_cfg in src_tables:
        rows.append(Row(
            case_id=str(case_id),
            source_table=str(t_cfg.get("table", "")),
            source_name=str(t_cfg.get("name", "")),
            prefix=str(t_cfg.get("prefix", "")),
            table_type=str(t_cfg.get("table_type", "")),
            id_field=str(t_cfg.get("id_field", "")),
            agg_field_count=int(len(t_cfg.get("agg_fields", []) or t_cfg.get("select_fields", []))),
            cntd_field_count=int(len(t_cfg.get("cntd_fields", []))),
            has_json_map=bool(t_cfg.get("json_map_array_fields")),
        ))
    if rows:
        df = spark.createDataFrame(rows)
        _write_partitioned(spark, df, TABLE_SNAPSHOT_INFO, case_id, "default", dt)
        print(f"[Hive] 表7 snapshot_info: partition(case_id={case_id},dt={dt})（{len(rows)} 行）")


def write_seed_split_table(spark: SparkSession, ctx: Dict, case_id: str, dt: str):
    """表8：种子分类 + 训练/验证切分信息表。"""
    rows = [Row(
        case_id=str(case_id),
        seed_mode=str(ctx.get("config", {}).get("seed_classification", {}).get("mode", "")),
        core_seed_count=int(ctx.get("full_seed_count", 0) or 0),
        excluded_count=0,
        weak_seed_count=0,
        train_count=int(ctx.get("train_seed_df").count()) if ctx.get("train_seed_df") else 0,
        validation_count=int(ctx.get("validation_seed_df").count()) if ctx.get("validation_seed_df") else 0,
        train_ratio=float(ctx.get("config", {}).get("dataset_split", {}).get("train_ratio", 0.8)),
        baseline_count=int(ctx.get("baseline_df").count()) if ctx.get("baseline_df") else 0,
        baseline_scale_factor=float(ctx.get("baseline_scale_factor", 1.0)),
        hard_negative_count=int(ctx.get("hard_negative_df").count()) if ctx.get("hard_negative_df") else 0,
        whitelist_count=int(ctx.get("whitelist_df").count()) if ctx.get("whitelist_df") else 0,
    )]
    df = spark.createDataFrame(rows)
    _write_partitioned(spark, df, TABLE_SEED_SPLIT, case_id, "default", dt)
    print(f"[Hive] 表8 seed_split: partition(case_id={case_id},dt={dt})（1 行）")
