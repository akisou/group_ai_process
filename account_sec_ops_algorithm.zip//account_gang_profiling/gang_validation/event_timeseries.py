# -*- coding: utf-8 -*-
"""
事件级时序读取器：直读 event_detail 源表（strong_end_login 等），按 30 分钟桶
产出每个候选特征组合的命中账号数时序，供 temporal_scorer 算 combo_growth /
interaction_ratio / history_percentile / 变点 t0。

与 snapshot_builder._read_event_detail_table 的区别：
- 不做账号级 groupBy 聚合（账号级聚合会把时序丢掉，见 snapshot_builder L511 注释）；
- select 出 request_time（事件级时间戳，账号级聚合里被丢弃的字段），按 30 分钟分桶；
- 对每个候选组合 filter(combo AND) → groupBy(bucket) → countDistinct(account_id)。
"""

from typing import Dict, Iterable, List, Optional

from pyspark.sql import DataFrame, SparkSession
from pyspark.sql import functions as F

from account_gang_profiling.predicates.predicate import Predicate

# strong_end_login / weak_end_login 的事件级时间戳字段。账号级聚合时被丢弃
# （snapshot_builder L511），这里 select 回来。类型可能 string/timestamp，
# 统一用 F.to_timestamp 转；运行时若字段不存在会抛 AnalysisException（清晰报错）。
_EVENT_TIME_FIELD = "request_time"
_ACCOUNT_ID = "user_id"
# 场景分母只取 platform∧app，不含 partner（partner 是组合判别条件，进场景分母会
# 让稀有 partner 制造小分母假 PASS；见对抗验证 blocker 4）。
_SCENE_FIELDS = ("platform", "app")

_BUCKET_SECONDS = 30 * 60


def _bucket_start_col(event_time_field: str = _EVENT_TIME_FIELD):
    """30 分钟桶起始时间戳：floor(epoch/1800)*1800 → 桶起点 epoch → cast timestamp。"""
    epoch = F.unix_timestamp(F.to_timestamp(F.col(event_time_field)))
    return (F.floor(epoch / _BUCKET_SECONDS) * _BUCKET_SECONDS).cast("timestamp")


def build_event_timeseries(
    spark: SparkSession,
    table: str,
    dt: str,
    window_days: int,
    needed_fields: Iterable[str],
    event_time_field: str = _EVENT_TIME_FIELD,
    id_field: str = _ACCOUNT_ID,
    account_id_sample_df: Optional[DataFrame] = None,
    json_map_array_fields: Optional[Iterable[str]] = None,
) -> DataFrame:
    """
    读 event_detail 源表，产出带 30 分钟桶时间戳的事件明细（不做账号级聚合）。

    Args:
        table: 源表全名（如 ba_rc.app_stra_account_strong_end_login_feature_info）
        dt: 窗口右端点（分区日期，YYYYMMDD 或 YYYY-MM-DD，与 snapshot_builder 同口径）
        window_days: 窗口天数（与 snapshot_builder window_days 一致，默认 90）
        needed_fields: 候选组合谓词 + 场景字段用到的列名（如 dm/os/mobile_souce/
                       platform/app）。只 select 这些 + id_field + event_time_field，
                       列裁剪减 IO（与 snapshot_builder 的列裁剪同思路）。
        event_time_field: 事件级时间戳字段名，默认 request_time
        id_field: 账号 ID 字段，默认 user_id（strong_end_login 的 id_field）
        account_id_sample_df: 可选账号范围过滤（与 snapshot_builder 同口径，
                              inner join 过滤，只留样本范围内账号的明细行）
        json_map_array_fields: 该表的 JSON map 列（如 deviceriskhitrulesv2new，原值
                              '{"分类":[子标签]}'）。回捞时复用 snapshot_builder 的
                              _parse_json_map_array_column 展平成"分类:子标签" array<string>，
                              使 array_contains(token) 能命中（否则 string_eq 在 JSON 上匹配 0）。

    Returns:
        带 bucket_ts 列的事件明细 DataFrame（已 cache）。列：id_field, event_time_field,
        needed_fields, bucket_ts。一事件一行，未聚合。
    """
    # 复用 snapshot_builder 的分区扫描/账号过滤小工具，避免重写 SHOW PARTITIONS 等逻辑
    from account_gang_profiling.feature_snapshot.snapshot_builder import (
        _apply_sample_filter, _date_range, _get_existing_partitions, log_with_time,
    )

    candidate_dts = _date_range(dt, window_days)
    existing_dts = _get_existing_partitions(spark, table, candidate_dts)
    if not existing_dts:
        raise ValueError(f"源表 {table} 在窗口 [{candidate_dts[0]},{candidate_dts[-1]}] 内无可用分区")

    select_cols = [id_field, event_time_field] + list(needed_fields)
    cols_sql = ", ".join(f"`{c}`" for c in dict.fromkeys(select_cols))  # dict.fromkeys 去重保序
    dt_list_sql = ", ".join(f"'{d}'" for d in existing_dts)
    df = spark.sql(f"SELECT {cols_sql} FROM {table} WHERE dt IN ({dt_list_sql})")

    if account_id_sample_df is not None:
        df = _apply_sample_filter(df, id_field, account_id_sample_df)

    # json_map_array_fields：与 snapshot_builder 同款展平 JSON map→"分类:子标签" array<string>。
    # 不展平则 array_contains(token) 在原始 JSON 列上匹配 0 行 → 该原子历史为 0 →
    # atom_history_ok=False → 误判"无法算协同基线"，含这类字段的组合拿不到时序信号。
    if json_map_array_fields:
        from account_gang_profiling.feature_snapshot.snapshot_builder import _parse_json_map_array_column
        for c in json_map_array_fields:
            if c in select_cols:
                df = _parse_json_map_array_column(df, c, c)

    df = df.withColumn("bucket_ts", _bucket_start_col(event_time_field))
    log_with_time(f"  [event_timeseries] {table} 窗口[{existing_dts[0]},{existing_dts[-1]}]"
                  f"({len(existing_dts)}分区) 已分桶 cache")
    return df.cache()


def build_daily_timeseries(
    spark: SparkSession,
    table: str,
    dt: str,
    window_days: int,
    needed_fields: Iterable[str],
    id_field: str = _ACCOUNT_ID,
    account_id_sample_df: Optional[DataFrame] = None,
    json_map_array_fields: Optional[Iterable[str]] = None,
) -> DataFrame:
    """
    读 event_detail 源表，产出按天聚合的时序（每天每账号一行，combo 命中按天 distinct）。

    与 build_event_timeseries 的区别：
    - 按天聚合（dt 分区作时间维度），不做 30 分钟桶——L2-4 改按天粒度，t0 粗略到天即可。
    - 窄列：只 select id_field + dt + needed_fields（去掉 event_time_field，按天用 dt）。
    - 默认按 case 账号过滤（account_id_sample_df 传入时），行数降 3 个数量级。

    Args:
        dt: 窗口右端点（T-2，事件表最新分区）
        window_days: 近期扫描天数（如 7，只扫近期短窗）
        account_id_sample_df: case 账号样本（必传，按 case 过滤降行数）
    Returns:
        带 dt 列的按天账号明细（已 cache）。列：id_field, dt, needed_fields。
        一天一账号一行（同账号同天多次请求的 needed_fields 取 collect_set 去重）。
    """
    from account_gang_profiling.feature_snapshot.snapshot_builder import (
        _apply_sample_filter, _date_range, _get_existing_partitions, log_with_time,
    )
    from pyspark.sql import functions as _F

    candidate_dts = _date_range(dt, window_days)
    existing_dts = _get_existing_partitions(spark, table, candidate_dts)
    if not existing_dts:
        raise ValueError(f"源表 {table} 在窗口 [{candidate_dts[0]},{candidate_dts[-1]}] 内无可用分区")

    needed = list(dict.fromkeys(needed_fields))  # 去重保序
    # 按天聚合：同账号同天的 needed_fields 取 collect_set（array 去重）
    agg_exprs = [_F.collect_set(_F.col(c)).alias(c) for c in needed]
    select_cols = [id_field, "dt"] + needed
    cols_sql = ", ".join(f"`{c}`" for c in dict.fromkeys([id_field] + needed))
    dt_list_sql = ", ".join(f"'{d}'" for d in existing_dts)
    df = spark.sql(f"SELECT {cols_sql}, dt FROM {table} WHERE dt IN ({dt_list_sql})")

    if account_id_sample_df is not None:
        df = _apply_sample_filter(df, id_field, account_id_sample_df)

    if json_map_array_fields:
        from account_gang_profiling.feature_snapshot.snapshot_builder import _parse_json_map_array_column
        for c in json_map_array_fields:
            if c in needed:
                df = _parse_json_map_array_column(df, c, c)

    # 按天聚合：groupBy(id_field, dt) → collect_set(needed_fields)
    df = df.groupBy(id_field, "dt").agg(*agg_exprs)
    log_with_time(f"  [daily_timeseries] {table} 窗口[{existing_dts[0]},{existing_dts[-1]}]"
                  f"({len(existing_dts)}分区) 按天聚合 cache")
    return df.cache()


def build_daily_scene_totals(
    spark: SparkSession,
    table: str,
    dt: str,
    window_days: int,
    scene_values: Dict[str, str],
    id_field: str = _ACCOUNT_ID,
) -> DataFrame:
    """
    场景分母（大盘全量，按天）：扫事件表近期 window_days 天全量场景（不按 case 过滤），
    按天 groupBy(dt) 算 distinct 账号数。窄列（只 id_field + platform + app + dt）。

    用于 scene_growth 防大盘同步涨：近 7 天场景日均 vs 历史场景日均。
    Returns: DataFrame[dt, scene_total_accounts]
    """
    from account_gang_profiling.feature_snapshot.snapshot_builder import (
        _date_range, _get_existing_partitions, log_with_time,
    )
    from pyspark.sql import functions as _F

    candidate_dts = _date_range(dt, window_days)
    existing_dts = _get_existing_partitions(spark, table, candidate_dts)
    if not existing_dts:
        raise ValueError(f"源表 {table} 场景分母窗口 [{candidate_dts[0]},{candidate_dts[-1]}] 无可用分区")

    scene_cols = list(scene_values.keys()) if scene_values else ["platform", "app"]
    cols_sql = ", ".join(f"`{c}`" for c in dict.fromkeys([id_field] + scene_cols))
    dt_list_sql = ", ".join(f"'{d}'" for d in existing_dts)
    df = spark.sql(f"SELECT {cols_sql}, dt FROM {table} WHERE dt IN ({dt_list_sql})")

    cond = _F.lit(True)
    if scene_values:
        for k, v in scene_values.items():
            cond = cond & (_F.col(k) == _F.lit(v))
        df = df.filter(cond)

    scene_totals = df.groupBy("dt").agg(_F.countDistinct(id_field).alias("scene_total_accounts"))
    log_with_time(f"  [daily_scene] {table} 场景分母窗口[{existing_dts[0]},{existing_dts[-1]}]"
                  f"({len(existing_dts)}分区) 按天 distinct cache")
    return scene_totals.cache()


def scene_bucket_totals(
    event_ts_df: DataFrame,
    scene_values: Dict[str, str],
    id_field: str = _ACCOUNT_ID,
) -> DataFrame:
    """
    场景分母：按 platform∧app 过滤后，每个 30 分钟桶的 distinct 账号数。

    一场景算一次，同场景的所有候选组合复用这份分母（combo_growth 的 ComboRate
    = 组合命中 / 场景总数）。

    Args:
        event_ts_df: build_event_timeseries 产出的带 bucket_ts 的事件明细
        scene_values: 场景取值，如 {"platform":"android","app":"X"}。键必须是
                      _SCENE_FIELDS 子集（platform/app）；partner 不进这里
    Returns:
        DataFrame[bucket_ts, scene_total_accounts]
    """
    invalid = set(scene_values) - set(_SCENE_FIELDS)
    if invalid:
        raise ValueError(f"scene_values 键 {invalid} 不在允许的场景字段 {_SCENE_FIELDS} 内"
                          f"（partner 是组合判别条件，不进场景分母）")
    cond = F.lit(True)
    for f, v in scene_values.items():
        cond = cond & (F.col(f) == F.lit(v))
    return (event_ts_df.filter(cond)
            .groupBy("bucket_ts")
            .agg(F.countDistinct(F.col(id_field)).alias("scene_total_accounts")))


def combo_bucket_hits(
    event_ts_df: DataFrame,
    combo_predicates: List[Predicate],
    combo_id: str,
    id_field: str = _ACCOUNT_ID,
) -> DataFrame:
    """
    单个候选组合的命中时序：filter(combo AND) → groupBy(bucket) → countDistinct(account_id)。

    Returns:
        DataFrame[bucket_ts, combo_hit_accounts, combo_id]
    """
    cond = F.lit(True)
    for p in combo_predicates:
        cond = cond & p.to_column()
    return (event_ts_df.filter(cond)
            .groupBy("bucket_ts")
            .agg(F.countDistinct(F.col(id_field)).alias("combo_hit_accounts"))
            .withColumn("combo_id", F.lit(combo_id)))
