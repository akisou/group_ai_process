# -*- coding: utf-8 -*-
"""injury_gate 单测：大盘命中率 + Lift（替 precision 口径）。"""
from pyspark.sql import SparkSession
from pyspark.sql.types import StructType, StructField, StringType, ArrayType

from account_gang_profiling.predicates.predicate import Predicate, OP_ARRAY_CONTAINS
from account_gang_profiling.feature_snapshot.seed_split import SEED_CORE, SEED_EXCLUDED
from account_gang_profiling.gang_validation.injury_gate import score_injury

_DM = Predicate("sel_dm_set", OP_ARRAY_CONTAINS, "ADA-AL00")
_SCHEMA = StructType([
    StructField("account_id", StringType()),
    StructField("seed_type", StringType()),
    StructField("sel_dm_set", ArrayType(StringType())),
])


def run_injury_test(spark):
    spark.sparkContext.setLogLevel("ERROR")
    print("=" * 70)
    print("[injury_gate 单测]")
    print("=" * 70)

    # case_total=100, case_hit=50(coverage=0.5); baseline 抽样命中 5 ×scale=2000 → 1万全量;
    # market_total=562000000(562M) → rate=10000/562M=0.0018% <0.1%; lift=0.5/0.0018%=27800>10 → 达标
    rows = [(f"c{i}", SEED_CORE, ["ADA-AL00"]) for i in range(50)]          # case 命中 50
    rows += [(f"c{i}", SEED_CORE, ["OTHER"]) for i in range(50, 100)]        # case 未命中
    rows += [(f"b{i}", SEED_EXCLUDED, ["ADA-AL00"]) for i in range(5)]       # baseline 命中 5
    rows += [(f"b{i}", SEED_EXCLUDED, ["OTHER"]) for i in range(100, 200)]   # baseline 未命中
    df = spark.createDataFrame(rows, schema=_SCHEMA).cache()

    s = score_injury("I1", [_DM], df, baseline_scale_factor=2000.0,
                     market_total=562_000_000, case_total=100)
    assert s.case_hit == 50 and s.baseline_hit == 5
    assert abs(s.scaled_baseline_hit - 10000) < 0.1
    assert s.market_hit_rate < 0.001, f"1万/562M=0.0018% 应<0.1%，实={s.market_hit_rate:.4%}"
    assert s.lift is not None and s.lift > 10, f"lift 应>10，实={s.lift}"
    assert s.injury_pass, "1万大盘命中(20万团伙范围)→应达标"
    print(f"  1万大盘命中: rate={s.market_hit_rate:.4%} lift={s.lift:.0f} → 达标 ✓")

    # 超阈：baseline 命中 50 ×2000=10万; market_total=1亿 → rate=0.1% ≥0.1% → 不可用
    rows2 = [(f"c{i}", SEED_CORE, ["ADA-AL00"]) for i in range(50)]
    rows2 += [(f"b{i}", SEED_EXCLUDED, ["ADA-AL00"]) for i in range(50)]     # baseline 命中 50
    df2 = spark.createDataFrame(rows2, schema=_SCHEMA).cache()
    s2 = score_injury("I2", [_DM], df2, baseline_scale_factor=2000.0,
                      market_total=100_000_000, case_total=100)
    assert s2.market_hit_rate >= 0.001, f"10万/1亿=0.1% 应≥0.1%，实={s2.market_hit_rate:.4%}"
    assert not s2.injury_pass, "0.1% 超阈→不可用"
    print(f"  10万大盘命中: rate={s2.market_hit_rate:.4%}≥0.1% → 超阈不可用 ✓")

    # lift 不足：case 覆盖率低（case_hit=1/100=1%）但大盘命中率也低 → lift 可能<10
    rows3 = [(f"c0", SEED_CORE, ["ADA-AL00"])]                              # case 命中 1
    rows3 += [(f"c{i}", SEED_CORE, ["OTHER"]) for i in range(1, 100)]
    rows3 += [(f"b{i}", SEED_EXCLUDED, ["ADA-AL00"]) for i in range(5)]     # baseline 5
    df3 = spark.createDataFrame(rows3, schema=_SCHEMA).cache()
    s3 = score_injury("I3", [_DM], df3, baseline_scale_factor=2000.0,
                      market_total=562_000_000, case_total=100)
    # coverage=1%, rate=0.0018%, lift=0.01/0.0000178≈562>10 → 实际仍达标（case 1% vs 大盘 0.0018%）
    assert s3.case_hit == 1 and s3.case_coverage == 0.01
    print(f"  低覆盖但高lift: coverage={s3.case_coverage:.2%} lift={s3.lift:.0f} → {'达标' if s3.injury_pass else '不达标'} ✓")

    # 4) 零大盘命中（combo 完全 case-specific）→ lift=∞, injury_pass=True（修 bug：原 lift=None→False）
    rows4 = [(f"c0", SEED_CORE, ["ADA-AL00"])]                          # case 命中 1
    rows4 += [(f"c{i}", SEED_CORE, ["OTHER"]) for i in range(1, 100)]
    # baseline 全未命中 → baseline_hit=0 → hit_rate=0 → lift=∞ → injury_pass=True
    rows4 += [(f"b{i}", SEED_EXCLUDED, ["OTHER"]) for i in range(100)]
    df4 = spark.createDataFrame(rows4, schema=_SCHEMA).cache()
    s4 = score_injury("I4", [_DM], df4, baseline_scale_factor=2000.0,
                      market_total=562_000_000, case_total=100)
    assert s4.baseline_hit == 0, f"baseline 命中应=0"
    assert s4.market_hit_rate == 0.0, f"hit_rate 应=0"
    assert s4.lift == float("inf"), f"零大盘命中 lift 应=∞，实={s4.lift}"
    assert s4.injury_pass, f"零大盘命中=完美无误差，injury 应达标(True)，实={s4.injury_pass}"
    print(f"  零大盘命中: hit_rate=0 lift=∞ injury={s4.injury_pass}（修 bug：原 False）✓")

    print("[PASS] injury_gate 单测通过")


def _main():
    spark = (SparkSession.builder.master("local[*]").appName("injury_test")
             .config("spark.driver.host", "127.0.0.1")
             .config("spark.driver.bindAddress", "127.0.0.1")
             .config("spark.ui.enabled", "false").getOrCreate())
    try:
        run_injury_test(spark)
    finally:
        spark.stop()


if __name__ == "__main__":
    _main()
