# -*- coding: utf-8 -*-
"""
最终规则集选择：相似规则去重（Jaccard相似度） + 贪心集合覆盖(Greedy Set Cover)

背景：rule_validation 阶段产出的是"通过验证"的规则列表，但这些规则之间可能高度重叠
（比如两条规则命中的几乎是同一批账号，只是用了不同的字段组合表达），直接把它们全部
作为最终结果输出，会造成"规则数量虚高但实际覆盖的独立团伙很少"的误导。

本模块两步走：
1. 相似规则去重：计算每条规则命中账号集合两两之间的 Jaccard 相似度，
   相似度超过阈值的视为"表达同一个团伙"的规则，只保留其中 v_score 更高的一条
2. 贪心集合覆盖：从去重后的规则池中，每轮选择"能为已选规则集新增覆盖最多账号"的一条，
   直到达到 min_total_coverage（占全体种子账号的覆盖率）或 max_rules 数量上限，
   这样保证最终规则集在数量精简的前提下，覆盖尽可能多的、互不重叠的团伙账号
"""

from dataclasses import dataclass
from typing import Dict, List, Optional, Set

from pyspark.sql import DataFrame, functions as F

from account_gang_profiling.rule_validation.validator import ValidationResult


@dataclass
class SelectedRule:
    validation_result: ValidationResult
    hit_account_ids: Set[str]        # 该规则在全体种子账号（用于覆盖率计算的口径）中命中的账号ID集合
    marginal_new_coverage: int = 0   # 被选中时，相对已选规则集新增覆盖的账号数（仅贪心选择阶段有意义）


def _collect_hit_account_ids(df: DataFrame, result: ValidationResult) -> Set[str]:
    """
    收集某条规则在给定 df（通常是全体种子账号：CORE_SEED+WEAK_SEED）上命中的 account_id 集合，
    用 collect() 落到 driver 端做集合运算（Jaccard相似度、贪心覆盖）。

    注意：这里假设"种子账号总量"在可以 collect 到 driver 内存的规模（通常几千到几十万级别，
    团伙挖掘的种子池不会无限增长），若种子规模远超此量级，需改为在 Spark 侧用
    DataFrame 交并集操作代替 driver 端 Python set 运算，当前先用更直观的实现方式。
    """
    rows = df.filter(result.combo.to_column()).select("account_id").distinct().collect()
    return {r["account_id"] for r in rows}


def _jaccard_similarity(set_a: Set[str], set_b: Set[str]) -> float:
    if not set_a and not set_b:
        return 1.0
    union_size = len(set_a | set_b)
    if union_size == 0:
        return 0.0
    return len(set_a & set_b) / union_size


def deduplicate_similar_rules(results: List[ValidationResult], full_seed_df: DataFrame,
                               similarity_threshold: float = 0.8) -> List[SelectedRule]:
    """
    对通过验证的规则做相似度去重：两两比较命中账号集合的 Jaccard 相似度，
    相似度超过阈值时，只保留 v_score 更高的一条（v_score 相同则保留 combo_size 更小、
    即规则更简洁可解释的一条）。

    Returns:
        去重后的 SelectedRule 列表（未排序，保留原始相对顺序），
        每个 SelectedRule 已附带其 hit_account_ids，供后续贪心覆盖复用，
        避免重复计算一次代价不小的 collect()
    """
    passed_results = [r for r in results if r.passed]
    if not passed_results:
        return []

    full_seed_df = full_seed_df.cache()
    candidates = [SelectedRule(validation_result=r, hit_account_ids=_collect_hit_account_ids(full_seed_df, r))
                  for r in passed_results]

    # 按 v_score 降序排序：优先保留分数更高的规则作为"代表"，后续相似的低分规则被剔除
    candidates.sort(key=lambda c: (c.validation_result.combo.v_score, -c.validation_result.combo.size),
                     reverse=True)

    kept: List[SelectedRule] = []
    for cand in candidates:
        is_duplicate = False
        for existing in kept:
            sim = _jaccard_similarity(cand.hit_account_ids, existing.hit_account_ids)
            if sim >= similarity_threshold:
                is_duplicate = True
                print(f"[rule_selection] 剔除相似规则(Jaccard={sim:.2%} >= {similarity_threshold:.2%}): "
                      f"{cand.validation_result.combo.to_readable()} "
                      f"~= {existing.validation_result.combo.to_readable()}")
                break
        if not is_duplicate:
            kept.append(cand)

    print(f"[rule_selection] 相似规则去重完成: {len(passed_results)} -> {len(kept)}")
    return kept


def greedy_set_cover(deduped_rules: List[SelectedRule], total_seed_count: int,
                      max_rules: int = 5, min_total_coverage: float = 0.7) -> List[SelectedRule]:
    """
    贪心集合覆盖：每轮从剩余候选中选出"新增覆盖账号数最多"的一条，
    直到覆盖率达到 min_total_coverage 或已选规则数达到 max_rules。

    Returns:
        按选中顺序排列的 SelectedRule 列表（每个元素的 marginal_new_coverage 已回填），
        列表长度 <= max_rules
    """
    if not deduped_rules or total_seed_count == 0:
        return []

    remaining = list(deduped_rules)
    selected: List[SelectedRule] = []
    covered_ids: Set[str] = set()

    while remaining and len(selected) < max_rules:
        best_idx, best_new_coverage = -1, -1
        for idx, cand in enumerate(remaining):
            new_coverage = len(cand.hit_account_ids - covered_ids)
            if new_coverage > best_new_coverage:
                best_idx, best_new_coverage = idx, new_coverage

        if best_new_coverage <= 0:
            # 剩余候选都无法为已选规则集新增覆盖任何账号，提前结束（避免选入完全冗余的规则）
            print("[rule_selection] 剩余候选规则均无法新增覆盖账号，提前结束贪心选择")
            break

        chosen = remaining.pop(best_idx)
        chosen.marginal_new_coverage = best_new_coverage
        covered_ids |= chosen.hit_account_ids
        selected.append(chosen)

        current_coverage_ratio = len(covered_ids) / total_seed_count
        print(f"[rule_selection] 选中第{len(selected)}条规则: {chosen.validation_result.combo.to_readable()} "
              f"(新增覆盖={best_new_coverage}, 累计覆盖率={current_coverage_ratio:.2%})")

        if current_coverage_ratio >= min_total_coverage:
            print(f"[rule_selection] 已达到目标覆盖率 {min_total_coverage:.2%}，停止选择")
            break

    final_coverage_ratio = len(covered_ids) / total_seed_count
    if final_coverage_ratio < min_total_coverage:
        print(f"[WARN] 最终规则集覆盖率({final_coverage_ratio:.2%})未达到目标({min_total_coverage:.2%})，"
              f"已选出全部可用规则（{len(selected)}条）或达到 max_rules 上限")

    return selected


def _param_overlap(rule_a: SelectedRule, rule_b: SelectedRule) -> int:
    """两条规则的参数（谓词 field_name）重叠数。"""
    fields_a = {p.field_name for p in rule_a.validation_result.combo.predicates}
    fields_b = {p.field_name for p in rule_b.validation_result.combo.predicates}
    return len(fields_a & fields_b)


def select_diverse_rules(deduped_rules: List[SelectedRule], max_rules: int = 5,
                          max_param_overlap: int = 2,
                          min_rules: int = 1) -> List[SelectedRule]:
    """多样性选择：按 v_score 降序选，新规则与已选任一规则的参数重叠 ≤ max_param_overlap 才选。
    目的：输出多组参数差异大的规则供人选择最优，而非自动贪心覆盖定终选。
    max_param_overlap: 组间重复参数上限（≤此值才选，即严格小于 max_param_overlap+1 个重叠）。
    min_rules: 至少选这么多条（若候选不足放宽重叠约束补足）。"""
    if not deduped_rules:
        return []
    # 按 v_score 降序
    remaining = sorted(deduped_rules,
                       key=lambda r: r.validation_result.combo.v_score, reverse=True)
    selected: List[SelectedRule] = []
    for cand in remaining:
        if len(selected) >= max_rules:
            break
        ok = all(_param_overlap(cand, s) <= max_param_overlap for s in selected)
        if ok:
            selected.append(cand)
    # 若不足 min_rules，放宽重叠约束补足（仍按 v_score 降序）
    if len(selected) < min_rules:
        selected_fields = {id(s) for s in selected}
        for cand in remaining:
            if len(selected) >= min_rules:
                break
            if id(cand) in selected_fields:
                continue
            selected.append(cand)
    # 回填 marginal_new_coverage（相对已选的新增覆盖，供人参考）
    covered: Set[str] = set()
    for r in selected:
        r.marginal_new_coverage = len(r.hit_account_ids - covered)
        covered |= r.hit_account_ids
    return selected


def select_final_rules(results: List[ValidationResult], full_seed_df: DataFrame,
                        config: Optional[Dict] = None) -> Dict:
    """
    主入口：相似规则去重 -> 贪心集合覆盖，产出最终规则集。

    Args:
        results: rule_validation.validate_rules 的输出（含未通过验证的规则，本函数内部会先过滤）
        full_seed_df: 全体种子账号大宽表（CORE_SEED + WEAK_SEED，不区分train/validation），
            用于计算规则命中账号集合和总体覆盖率的统一口径
        config: config.yaml 中的 rule_selection 配置字典

    Returns:
        {
            "final_rules": List[SelectedRule]，最终选中的规则（按选择顺序）,
            "total_coverage_ratio": float，最终规则集对全体种子账号的覆盖率,
            "total_seed_count": int,
        }
    """
    config = config or {}
    max_rules = config.get("max_rules", 5)
    min_total_coverage = config.get("min_total_coverage", 0.7)
    similarity_threshold = config.get("similarity_threshold", 0.8)
    select_mode = config.get("select_mode", "auto_cover")  # auto_cover | diverse

    total_seed_count = full_seed_df.count()

    deduped = deduplicate_similar_rules(results, full_seed_df, similarity_threshold)
    if select_mode == "diverse":
        # 多样性选择：输出多组参数差异大的规则供人选择最优（不自动贪心覆盖定终选）
        max_param_overlap = config.get("max_param_overlap", 2)
        diverse_min_rules = config.get("diverse_min_rules", 1)
        final_rules = select_diverse_rules(deduped, max_rules, max_param_overlap, diverse_min_rules)
        print(f"[rule_selection] diverse 模式: 选 {len(final_rules)} 条（参数重叠≤{max_param_overlap}，"
              f"按 v_score 降序供人选择）")
    else:
        final_rules = greedy_set_cover(deduped, total_seed_count, max_rules, min_total_coverage)

    covered_ids: Set[str] = set()
    for r in final_rules:
        covered_ids |= r.hit_account_ids
    total_coverage_ratio = len(covered_ids) / total_seed_count if total_seed_count > 0 else 0.0

    print(f"[INFO] 最终规则集选择完成: {len(final_rules)} 条规则，"
          f"覆盖 {len(covered_ids)}/{total_seed_count} 个种子账号 ({total_coverage_ratio:.2%})")

    return {
        "final_rules": final_rules,
        "total_coverage_ratio": total_coverage_ratio,
        "total_seed_count": total_seed_count,
    }
