# -*- coding: utf-8 -*-
"""
最终规则集选择：贪心集合覆盖(Set Cover)

包含：
- 相似规则去重（命中账号集合 Jaccard 相似度）
- 贪心集合覆盖选择（新增覆盖账号数 + 误伤率综合评分）
"""

from .selector import (
    SelectedRule,
    deduplicate_similar_rules,
    greedy_set_cover,
    select_final_rules,
)
