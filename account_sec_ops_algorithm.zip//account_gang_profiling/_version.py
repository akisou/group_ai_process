# -*- coding: utf-8 -*-
"""运行时版本号。构建 account_gang_profiling.zip 前由 build 脚本注入 git commit/branch，
pipeline __main__ 启动时打印 [VERSION] git_commit=... git_branch=...，日志据此确认跑的是哪个 commit。

未注入（直接 zip、没跑注入脚本）时为 unset-*，提示你没注入版本号。
构建脚本（codelab 上打包前跑）：
    echo "COMMIT = '$(git rev-parse HEAD)'" > account_gang_profiling/_version.py
    echo "BRANCH = '$(git rev-parse --abbrev-ref HEAD)'" >> account_gang_profiling/_version.py
"""
COMMIT = "unset-built-without-version-inject"
BRANCH = "unset-built-without-version-inject"
