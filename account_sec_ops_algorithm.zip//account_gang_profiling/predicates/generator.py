# -*- coding: utf-8 -*-
"""
Predicate 候选生成：按字段类型分派生成候选 Predicate，并做 support/lift 初筛

输入：
- clue_df: 种子账号（正样本，通常是 CORE_SEED 的训练集切分）大宽表
- baseline_df: 背景/大盘账号大宽表（用于计算误伤率意义上的支持度对比）
- field_categories: {列名: 类型分类}，来自 feature_snapshot.field_types

输出：
- List[PredicateStats]：通过初筛（min_clue_support / max_baseline_support / min_lift）的候选
  Predicate 列表，按 lift 降序排列，供 rule_mining 作为第1层组合搜索的起点候选池

设计要点（性能）：
- numeric/boolean 字段：用 Spark 的 approxQuantile 批量算分位数阈值（一次调用可传多列），
  避免逐字段单独触发 action
- array 字段：跨字段用 stack() unpivot 成 (field_name, arr) 长表，再 explode +
  groupBy(field, value).count() 一次拿到全部 array 字段的全部取值频次（对齐 hopejob
  feature_engineer 的 stack 批量聚合模式，并扩展到 array 列），按元素类型分组分批
  stack 以保证 array_contains 的 value 类型与元素类型一致；原逐字段 explode+groupBy
  在数百 array 字段时会触发数百个 Spark action，job 调度开销压垮本阶段
- 高基数 array/map 字段（去重值过多，如设备ID/IP这种理论上限很高的字段）通过
  max_candidate_values_per_field 参数限制候选值数量（按 clue 侧频次降序取 top N），
  避免生成天量候选 Predicate 拖垮组合搜索阶段
"""
from dataclasses import dataclass
from typing import Any, Dict, List, Optional

from pyspark.sql import DataFrame, Window, functions as F
from pyspark.sql.types import ArrayType

from .predicate import (
    Predicate,
    OP_GTE,
    OP_EQ_BOOL,
    OP_ARRAY_CONTAINS,
    OP_MAP_HAS_KEY,
    OP_STRING_EQ,
)

# 避免循环 import：直接引用字符串常量值，与 feature_snapshot.field_types 保持一致
_CATEGORY_ARRAY = "array"
_CATEGORY_MAP = "map"
_CATEGORY_BOOLEAN = "boolean"
_CATEGORY_NUMERIC = "numeric"
_CATEGORY_STRING = "string"

# 高基数字段的候选值数量上限：只取 clue 侧出现频次最高的前 N 个具体取值参与候选生成，
# 防止如 ip_set/uuid_set 这类字段展开后产生成千上万个候选 Predicate
_MAX_CANDIDATE_VALUES_PER_FIELD = 50

# array 字段跨字段 unpivot 单次 stack 的字段数上限：账号宽表 array 字段可达数百量级，
# 一次性 stack 全部会构造过大的表达式撑爆 Catalyst 分析器；按此分批，每批一个 action，
# 数百字段也只需几次 action（替代原先逐字段 N 次 action）
_ARRAY_UNPIVOT_CHUNK = 200

# 字符串分类字段的取值基数上限：超过此基数视为"高基数无序字符串"（如自由文本/ID类字段），
# 不适合做等值 Predicate 枚举，直接跳过，避免生成大量无意义的候选
_MAX_STRING_CARDINALITY = 200


@dataclass
class PredicateStats:
    """
    单个 Predicate 及其在 clue/baseline 上的统计指标，用于初筛和后续组合搜索的排序依据。
    """
    predicate: Predicate
    clue_support: float       # 命中该 Predicate 的 clue 账号数 / clue 总账号数
    baseline_support: float   # 命中该 Predicate 的 baseline 账号数 / baseline 总账号数
    lift: float               # clue_support / max(baseline_support, epsilon)
    clue_hit_count: int
    baseline_hit_count: int


def _numeric_quantile_predicates(clue_df: DataFrame, numeric_cols: List[str],
                                  quantiles: List[float]) -> List[Predicate]:
    """
    对数值型字段，用 clue_df 的分位数分布生成候选阈值（>= 分位数值），
    approxQuantile 支持一次传入多列，一次 action 拿到全部字段的分位数结果。
    """
    if not numeric_cols:
        return []
    # approxQuantile(cols, probabilities, relativeError)：relativeError=0.01 在准确性和性能间取平衡，
    # 大宽表账号数可能达百万级，精确分位数(0误差)成本过高，没有必要
    quantile_results = clue_df.approxQuantile(numeric_cols, quantiles, 0.01)

    predicates = []
    for col_name, col_quantiles in zip(numeric_cols, quantile_results):
        if not col_quantiles:
            # 全 null 列没有分位数结果（该来源在所有 clue 账号上无数据），跳过
            continue
        seen_values = set()
        skipped_nonpositive = False
        for q, threshold in zip(quantiles, col_quantiles):
            # 同一字段不同分位数可能算出相同阈值（如字段本身取值高度集中），去重避免生成重复 Predicate
            if threshold is None or threshold in seen_values:
                continue
            if threshold <= 0:
                # 恒真谓词拦截：本特征体系的数值字段（_cntd 计数/请求次数/金额/天数/风险分）
                # 均非负，">= 0" 恒真（clue_support=100%）、不含任何信息；
                # 且在空 baseline 场景下会被 epsilon lift（clue_support/1e-6）吹到候选池头部，
                # 挤占组合搜索每层 top_m 的存活名额。zero-inflated 字段（P50=0）尤其高发。
                skipped_nonpositive = True
                continue
            seen_values.add(threshold)
            predicates.append(Predicate(
                field_name=col_name, op=OP_GTE, value=float(threshold),
                display_name=f"{col_name}(P{int(q * 100)})"
            ))
        # 零膨胀字段补"有无记录"谓词：P50=0 的字段经上方拦截后，分位数只会产出更陡的
        # 阈值（如 >=3），语义最干净的"有/无记录"（>=1）维度永远不会自然出现，
        # 而它恰是团伙共性刻画里最有解释力的谓词（如"97% 的团伙有强端注册记录"）。
        valid_quantiles = [v for v in col_quantiles if v is not None]
        if skipped_nonpositive and valid_quantiles and max(valid_quantiles) > 0 \
                and 1.0 not in seen_values:
            seen_values.add(1.0)
            predicates.append(Predicate(
                field_name=col_name, op=OP_GTE, value=1.0,
                display_name=f"{col_name}(has_any)"
            ))
    return predicates


def _boolean_predicates(boolean_cols: List[str]) -> List[Predicate]:
    """布尔字段固定生成一个 == 1 的候选 Predicate，无需依赖数据分布。"""
    return [Predicate(field_name=c, op=OP_EQ_BOOL) for c in boolean_cols]


def _array_value_predicates(clue_df: DataFrame, baseline_df: DataFrame,
                            array_cols: List[str], max_values_per_field: int,
                            clue_total: int, baseline_total: int) -> List[PredicateStats]:
    """
    对 array<string>/array<bigint>/array<double> 字段，clue + baseline 各做一次
    stack+explode+groupBy 拿值频次，join 后算 support/lift——**直接产出 PredicateStats，
    跳过 _batch_compute_stats 的逐候选 agg**（array 候选占 4512 里的 ~97%，这是 step3 瓶颈）。

    性能要点（对齐 hopejob feature_engineer 的 stack() unpivot 模式，并扩展到 array 列）：
    - 按元素类型分组（array_contains 的 value 必须与元素类型一致，混类型不能共用 stack），
      每组按 _ARRAY_UNPIVOT_CHUNK 分批，每批 clue+baseline 各一个 action（共 ~6-10 action），
      替代旧 _batch_compute_stats 的 23 批 × 2 agg = 46 action。
    - clue LEFT JOIN baseline：值只在 clue 出现 → baseline_count=0；按 clue_count 降序 top N。
    """
    if not array_cols:
        return []

    schema = {f.name: f.dataType for f in clue_df.schema.fields}
    groups: Dict[str, List[str]] = {}
    for c in array_cols:
        arr_type = schema.get(c)
        if not isinstance(arr_type, ArrayType):
            continue
        groups.setdefault(arr_type.elementType.simpleString(), []).append(c)

    epsilon = 1e-6
    w = Window.partitionBy("__field").orderBy(F.desc("clue_count"))
    stats: List[PredicateStats] = []
    for cols in groups.values():
        for i in range(0, len(cols), _ARRAY_UNPIVOT_CHUNK):
            chunk = cols[i:i + _ARRAY_UNPIVOT_CHUNK]
            pairs = []
            for c in chunk:
                pairs.append(f"'{c}'")
                pairs.append(f"`{c}`")
            stack_expr = f"stack({len(chunk)}, {', '.join(pairs)}) as (__field, __arr)"
            clue_freq = (clue_df.select(F.expr(stack_expr))
                .select(F.col("__field"), F.explode(F.col("__arr")).alias("__v"))
                .filter(F.col("__v").isNotNull())
                .groupBy("__field", "__v").count()
                .withColumnRenamed("count", "clue_count"))
            base_freq = (baseline_df.select(F.expr(stack_expr))
                .select(F.col("__field"), F.explode(F.col("__arr")).alias("__v"))
                .filter(F.col("__v").isNotNull())
                .groupBy("__field", "__v").count()
                .withColumnRenamed("count", "baseline_count"))
            top_rows = (clue_freq.join(base_freq, on=["__field", "__v"], how="left")
                .na.fill(0, ["baseline_count"])
                .withColumn("__rn", F.row_number().over(w))
                .filter(F.col("__rn") <= max_values_per_field)
                .collect())
            for row in top_rows:
                clue_hit = int(row["clue_count"] or 0)
                base_hit = int(row["baseline_count"] or 0)
                clue_support = clue_hit / clue_total if clue_total else 0.0
                base_support = base_hit / baseline_total if baseline_total else 0.0
                lift = clue_support / max(base_support, epsilon)
                stats.append(PredicateStats(
                    predicate=Predicate(field_name=row["__field"], op=OP_ARRAY_CONTAINS,
                                         value=row["__v"]),
                    clue_support=clue_support, baseline_support=base_support,
                    lift=lift, clue_hit_count=clue_hit, baseline_hit_count=base_hit))
    return stats


def _map_key_predicates(clue_df: DataFrame, map_cols: List[str],
                         max_values_per_field: int) -> List[Predicate]:
    """
    对 map<string,*> 字段，取 clue 侧出现频次最高的 top N 个 key，
    每个 key 生成一个 map_contains_key 候选 Predicate（暂不深入 value 做数值阈值扫描，
    value 语义因字段而异——如次数/子集合/字符串，统一按"存在该key"这一最通用的判断维度处理，
    value 相关的更细粒度规则留待后续增强）。
    """
    predicates = []
    for c in map_cols:
        top_keys = (
            clue_df.select(F.explode_outer(F.map_keys(F.col(c))).alias("__k"))
            .filter(F.col("__k").isNotNull())
            .groupBy("__k").count()
            .orderBy(F.desc("count"))
            .limit(max_values_per_field)
            .collect()
        )
        for row in top_keys:
            predicates.append(Predicate(field_name=c, op=OP_MAP_HAS_KEY, value=row["__k"]))
    return predicates


def _string_value_predicates(clue_df: DataFrame, string_cols: List[str],
                              max_values_per_field: int,
                              max_cardinality: int) -> List[Predicate]:
    """
    对字符串分类字段，先检查基数（避免自由文本/高基数ID字段生成无意义候选），
    基数可接受时取 clue 侧频次最高的 top N 个取值生成等值候选 Predicate。
    """
    predicates = []
    for c in string_cols:
        value_counts = (
            clue_df.filter(F.col(c).isNotNull() & (F.col(c) != "UNKNOWN"))
            .groupBy(c).count()
            .orderBy(F.desc("count"))
            .limit(max_cardinality + 1)
            .collect()
        )
        if len(value_counts) > max_cardinality:
            # 超过基数上限：视为高基数字段（如自由文本、唯一ID类），跳过整个字段
            continue
        for row in value_counts[:max_values_per_field]:
            predicates.append(Predicate(field_name=c, op=OP_STRING_EQ, value=row[c]))
    return predicates


def _batch_compute_stats(clue_df: DataFrame, baseline_df: DataFrame,
                          predicates: List[Predicate],
                          clue_total: int, baseline_total: int,
                          batch_size: int = 200) -> List[PredicateStats]:
    """
    批量计算一组 Predicate 在 clue/baseline 上的命中账号数，一次 agg 算完一批，
    避免为每个候选 Predicate 单独 filter().count()（这是决定候选生成阶段整体运行时长的
    关键优化点：候选 Predicate 可能有几百上千个，逐个 count 会触发同样数量的 Spark action）。

    batch_size 控制每次 agg 的表达式数量，过大的单次 agg 可能导致 Spark 生成的执行计划
    过于庞大（尤其 array/map 字段的 explode 场景不在这里，这里都是在原始未展开的 df 上
    直接用 to_column() 求值，成本主要在表达式数量而非数据量），分批可以控制单次查询复杂度。
    """
    epsilon = 1e-6
    stats = []
    for i in range(0, len(predicates), batch_size):
        batch = predicates[i:i + batch_size]
        clue_aggs = [F.sum(F.when(p.to_column(), 1).otherwise(0)).alias(f"c_{j}") for j, p in enumerate(batch)]
        baseline_aggs = [F.sum(F.when(p.to_column(), 1).otherwise(0)).alias(f"b_{j}") for j, p in enumerate(batch)]

        clue_row = clue_df.agg(*clue_aggs).collect()[0]
        baseline_row = baseline_df.agg(*baseline_aggs).collect()[0]

        for j, p in enumerate(batch):
            clue_hit = clue_row[f"c_{j}"] or 0
            baseline_hit = baseline_row[f"b_{j}"] or 0
            clue_support = clue_hit / clue_total if clue_total > 0 else 0.0
            baseline_support = baseline_hit / baseline_total if baseline_total > 0 else 0.0
            lift = clue_support / max(baseline_support, epsilon)
            stats.append(PredicateStats(
                predicate=p, clue_support=clue_support, baseline_support=baseline_support,
                lift=lift, clue_hit_count=clue_hit, baseline_hit_count=baseline_hit
            ))
    return stats


def _filter_fields_by_clue_coverage(clue_df: DataFrame, cols: List[str],
                                     min_coverage: float, clue_total: int,
                                     array_cols_set: set) -> List[str]:
    """
    用 clue 侧非空覆盖率预筛字段，丢弃覆盖率 < min_coverage 的整字段。

    目的：baseline 几乎全 ARRAY<STRING>（~470 列），_array_value_predicates 对每个字段
    stack+explode+groupBy，baseline 侧 285k 账号 × 多值 = 上亿行 shuffle，单 task OOM。
    先用 clue（1922 行小表）筛掉低覆盖/全空字段，baseline 只查有信号字段，扫描量大幅下降。

    预筛与最终过滤（generate_candidate_predicates 末尾的 min_clue_support）同阈值、同语义——
    被预筛砍掉的字段原本也会在末尾被 min_clue_support 过滤，故最终候选集不变，只是更早砍、
    省 baseline 扫描。一次 agg 算全部列（array 用 size(col)>0，标量用 isNotNull），只扫 clue。

    Args:
        array_cols_set: array 类型字段集合（用 size>0 判非空，空数组视为无信号）
    Returns:
        覆盖率 >= min_coverage 的列子集（保持原顺序）
    """
    if not cols or clue_total <= 0:
        return list(cols)
    aggs = []
    for c in cols:
        if c in array_cols_set:
            cond = (F.size(F.col(c)) > 0)
        else:
            cond = F.col(c).isNotNull()
        aggs.append(F.sum(F.when(cond, 1).otherwise(0)).alias(c))
    row = clue_df.agg(*aggs).collect()[0]
    kept = [c for c in cols if (row[c] or 0) / clue_total >= min_coverage]
    dropped = len(cols) - len(kept)
    print(f"[INFO] 字段预筛(min_clue_coverage={min_coverage:.0%}): {len(cols)} → {len(kept)}"
          f"（丢弃 {dropped} 个低覆盖/空字段）")
    return kept


def generate_candidate_predicates(clue_df: DataFrame, baseline_df: DataFrame,
                                   field_categories: Dict[str, str],
                                   exclude_fields: Optional[List[str]] = None,
                                   config: Optional[Dict[str, Any]] = None,
                                   baseline_total: Optional[int] = None) -> List[PredicateStats]:
    """
    主入口：按字段类型分派生成候选 Predicate，批量计算 support/lift 后按阈值初筛。

    Args:
        clue_df: 种子正样本大宽表（如 CORE_SEED 的训练集）
        baseline_df: 背景/大盘大宽表
        field_categories: 列名 -> 类型分类，来自 field_types.infer_field_categories_from_schema
        exclude_fields: 需要从候选池中排除的字段（如 whitelist_flag 字段、account_id 等元数据列）
        config: config.yaml 中的 predicate_generation 配置字典，包含：
            numeric_quantiles, min_clue_support, max_baseline_support, min_lift
        baseline_total: baseline 账号总数。调用方用单独 SQL count(*) 算好传入（不能用
            baseline_df.count()——会读全 535 列触发 OOM）。未传时回退 df.count()（仅小表安全）。

    Returns:
        通过初筛的 PredicateStats 列表，按 lift 降序排列
    """
    config = config or {}
    quantiles = config.get("numeric_quantiles", [0.5, 0.7, 0.8, 0.9, 0.95, 0.99])
    min_clue_support = config.get("min_clue_support", 0.1)
    max_baseline_support = config.get("max_baseline_support", 0.05)
    min_lift = config.get("min_lift", 10.0)

    exclude_fields = set(exclude_fields or [])
    active_categories = {c: cat for c, cat in field_categories.items() if c not in exclude_fields}

    numeric_cols = [c for c, cat in active_categories.items() if cat == _CATEGORY_NUMERIC]
    boolean_cols = [c for c, cat in active_categories.items() if cat == _CATEGORY_BOOLEAN]
    array_cols = [c for c, cat in active_categories.items() if cat == _CATEGORY_ARRAY]
    map_cols = [c for c, cat in active_categories.items() if cat == _CATEGORY_MAP]
    string_cols = [c for c, cat in active_categories.items() if cat == _CATEGORY_STRING]

    print(f"[INFO] 候选字段统计: numeric={len(numeric_cols)}, boolean={len(boolean_cols)}, "
          f"array={len(array_cols)}, map={len(map_cols)}, string={len(string_cols)}")

    # 【不 cache baseline】baseline 285k 行 × 535 列 eager cache 会 OOM（exit 137）。
    # baseline 靠 ORC 列裁剪按需读列：_array_value_predicates 显式 select(stack列)，
    # _batch_compute_stats 的 to_column() 只引用特定列。clue 1922 行小表 cache 无害且被多次用。
    clue_df = clue_df.cache()
    clue_total = clue_df.count()
    if baseline_total is None:
        baseline_total = baseline_df.count()
    if clue_total == 0:
        raise ValueError("clue_df（种子训练集）账号数为0，无法生成候选 Predicate")

    # 层1 字段预筛：clue 侧非空覆盖率 < min_clue_support 的整字段丢弃。
    # 被砍字段原本也会在末尾被 min_clue_support 过滤，最终候选集不变，只是更早砍、省 baseline 扫描。
    # boolean 只有 ~15 个且固定 ==1 谓词，不预筛。
    array_cols_set = set(array_cols)
    array_cols = _filter_fields_by_clue_coverage(clue_df, array_cols, min_clue_support, clue_total, array_cols_set)
    numeric_cols = _filter_fields_by_clue_coverage(clue_df, numeric_cols, min_clue_support, clue_total, array_cols_set)
    string_cols = _filter_fields_by_clue_coverage(clue_df, string_cols, min_clue_support, clue_total, array_cols_set)
    map_cols = _filter_fields_by_clue_coverage(clue_df, map_cols, min_clue_support, clue_total, array_cols_set)

    # array 候选：直接产出 PredicateStats（clue+baseline 值频次 join，跳过 batch_stats），
    # 占候选大头（~97%），避开 23 批 baseline agg 的 step3 瓶颈。
    array_stats = _array_value_predicates(clue_df, baseline_df, array_cols,
                                           _MAX_CANDIDATE_VALUES_PER_FIELD,
                                           clue_total, baseline_total)
    # 非 array 候选（numeric/boolean/map/string，~120 个）走 batch_stats（1 批搞定）
    non_array_predicates: List[Predicate] = []
    non_array_predicates.extend(_numeric_quantile_predicates(clue_df, numeric_cols, quantiles))
    non_array_predicates.extend(_boolean_predicates(boolean_cols))
    non_array_predicates.extend(_map_key_predicates(clue_df, map_cols, _MAX_CANDIDATE_VALUES_PER_FIELD))
    non_array_predicates.extend(_string_value_predicates(clue_df, string_cols,
                                                          _MAX_CANDIDATE_VALUES_PER_FIELD,
                                                          _MAX_STRING_CARDINALITY))

    all_predicates_count = len(array_stats) + len(non_array_predicates)
    print(f"[INFO] 生成候选 Predicate 总数（初筛前）: {all_predicates_count}"
          f"（array={len(array_stats)} 走值频次，非 array={len(non_array_predicates)} 走 batch_stats）")

    if all_predicates_count == 0:
        return []

    non_array_stats = _batch_compute_stats(clue_df, baseline_df, non_array_predicates,
                                            clue_total, baseline_total)
    all_stats = array_stats + non_array_stats

    filtered_stats = [
        s for s in all_stats
        if s.clue_support >= min_clue_support
        and s.baseline_support <= max_baseline_support
        and s.lift >= min_lift
    ]
    filtered_stats.sort(key=lambda s: s.lift, reverse=True)

    print(f"[INFO] 初筛后候选 Predicate 数量: {len(filtered_stats)}/{all_predicates_count} "
          f"(min_clue_support={min_clue_support}, max_baseline_support={max_baseline_support}, min_lift={min_lift})")

    return filtered_stats
