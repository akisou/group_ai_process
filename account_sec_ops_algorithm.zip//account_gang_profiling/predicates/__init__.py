# -*- coding: utf-8 -*-
"""
原子条件(Predicate)体系：定义、生成与标准化

包含：
- Predicate 数据结构定义（数值阈值/布尔/分类集合/名单集合/标签集合/排除逻辑）
- 数值特征的分位数扫描候选阈值生成
- 标签集合(label_set)类字段的 explode 展开与标准化匹配
"""

from .predicate import (
    Predicate,
    OP_GTE,
    OP_LTE,
    OP_EQ_BOOL,
    OP_ARRAY_CONTAINS,
    OP_MAP_HAS_KEY,
    OP_STRING_EQ,
)
from .generator import (
    PredicateStats,
    generate_candidate_predicates,
)
