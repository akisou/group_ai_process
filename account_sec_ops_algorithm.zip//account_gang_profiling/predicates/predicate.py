# -*- coding: utf-8 -*-
"""
Predicate（原子条件）数据结构定义

一个 Predicate 描述"账号在某个特征上满足的一个具体条件"，例如：
- 数值阈值：sel_ip_cntd_set >= 15  （字段名注意：实际是 _cntd 数值字段）
- 布尔：act_is_hit_black_ip == 1
- 集合包含：sel_dm_set 包含 'iPhone13ProMax'
- Map key 存在：unfreeze_entry_cnt_map_7d 存在 key 'reason_x'

设计要点：
- Predicate 本身只是不可变的元数据（字段名/类型/算子/取值），不持有 DataFrame，
  求值时才生成 Spark Column 表达式，这样同一个 Predicate 对象可以反复用于
  不同的 DataFrame（训练集/验证集/大盘全量）上的聚合评估，无需重复构造。
- to_column() 是 Predicate 与 Spark 计算引擎的唯一桥梁，rule_mining 的组合搜索
  只需要把多个 Predicate 的 to_column() 结果用 AND 拼起来即可得到组合条件，
  不需要关心每种类型内部具体怎么判断。
- to_readable() 生成人类可读的条件描述，供最终结果展示/审计使用。
"""

from dataclasses import dataclass, field
from typing import Any, Optional

from pyspark.sql import functions as F

# Predicate 算子类型
OP_GTE = "gte"                  # 数值 >= 阈值
OP_LTE = "lte"                  # 数值 <= 阈值（预留，当前生成逻辑只用 GTE，负向数值特征可用）
OP_EQ_BOOL = "eq_bool"          # 布尔 == 1
OP_ARRAY_CONTAINS = "array_contains"   # array 字段包含某个具体值
OP_MAP_HAS_KEY = "map_has_key"         # map 字段存在某个 key
OP_STRING_EQ = "string_eq"             # 字符串字段等值匹配（分类型字段）


@dataclass(frozen=True)
class Predicate:
    """
    不可变的原子条件描述。frozen=True 使其可哈希（可放入 set 做去重/剪枝候选管理），
    hash/eq 基于全部字段的默认实现，两个字段完全相同的 Predicate 视为同一个。
    """
    field_name: str          # 大宽表列名（已含前缀），如 'sel_ip_cntd', 'act_is_hit_black_ip'
    op: str                  # 算子类型，见 OP_* 常量
    value: Any = None        # 阈值/具体取值（数值阈值为 float，array_contains/string_eq 为具体值，
                              # map_has_key 为具体 key，eq_bool 为 None，语义固定为 ==1）
    display_name: Optional[str] = field(default=None, compare=False)
    # display_name 不参与 eq/hash 比较（compare=False），仅用于生成更友好的展示文案，
    # 避免同一字段因为展示名不同被误判为"不同的 Predicate"导致去重失效

    def to_column(self) -> "F.Column":
        """生成该 Predicate 对应的 Spark 布尔表达式，供 df.filter()/F.when() 使用。"""
        col = F.col(self.field_name)
        if self.op == OP_GTE:
            return col.cast("double") >= F.lit(self.value)
        if self.op == OP_LTE:
            return col.cast("double") <= F.lit(self.value)
        if self.op == OP_EQ_BOOL:
            return col.cast("int") == F.lit(1)
        if self.op == OP_ARRAY_CONTAINS:
            return F.array_contains(col, self.value)
        if self.op == OP_MAP_HAS_KEY:
            # 兼容 Spark 3.0.x：F.map_contains_key 的 PySpark 具名封装是 3.1+ 才提供的，
            # 在 3.0.2 上直接 AttributeError（与 F.transform 同类的版本坑）。
            # map_contains_key(m, k) 在 Spark 内部的实现就是 array_contains(map_keys(m), k)，
            # 而 F.map_keys/F.array_contains 在 3.0 均已存在，改写后语义完全等价。
            return F.array_contains(F.map_keys(col), self.value)
        if self.op == OP_STRING_EQ:
            return col.cast("string") == F.lit(self.value)
        raise ValueError(f"未知的 Predicate 算子: {self.op}")

    def to_readable(self) -> str:
        """生成人类可读的条件描述，用于最终结果展示/SQL拼装参考。"""
        name = self.display_name or self.field_name
        if self.op == OP_GTE:
            return f"{name} >= {self.value}"
        if self.op == OP_LTE:
            return f"{name} <= {self.value}"
        if self.op == OP_EQ_BOOL:
            return f"{name} = 1"
        if self.op == OP_ARRAY_CONTAINS:
            return f"{name} 包含 '{self.value}'"
        if self.op == OP_MAP_HAS_KEY:
            return f"{name} 存在key '{self.value}'"
        if self.op == OP_STRING_EQ:
            return f"{name} = '{self.value}'"
        return f"{name} <未知算子:{self.op}>"

    def to_sql_fragment(self) -> str:
        """
        生成可拼入 WHERE 子句的 SQL 片段（供 rule_selection/结果构建阶段生成 completeSql 使用）。
        字符串取值统一用单引号包裹并转义内部单引号，避免拼接出错误的 SQL。
        """
        def _quote(v: Any) -> str:
            return "'" + str(v).replace("'", "''") + "'"

        if self.op == OP_GTE:
            return f"{self.field_name} >= {self.value}"
        if self.op == OP_LTE:
            return f"{self.field_name} <= {self.value}"
        if self.op == OP_EQ_BOOL:
            return f"{self.field_name} = 1"
        if self.op == OP_ARRAY_CONTAINS:
            return f"array_contains({self.field_name}, {_quote(self.value)})"
        if self.op == OP_MAP_HAS_KEY:
            return f"map_contains_key({self.field_name}, {_quote(self.value)})"
        if self.op == OP_STRING_EQ:
            return f"{self.field_name} = {_quote(self.value)}"
        raise ValueError(f"未知的 Predicate 算子: {self.op}")

    def __repr__(self) -> str:
        return f"Predicate({self.to_readable()})"
