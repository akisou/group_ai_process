# -*- coding: utf-8 -*-
"""
种子账号分类 + 训练/验证集切分

背景：规则挖掘需要明确"谁是团伙账号（正样本/种子）"才能计算 support/lift 等统计量，
但账号特征大宽表（snapshot_builder 产出）本身不包含直接的 risk_score 字段，
只有若干与"是否命中过线索/CASE""是否触发人机风控"相关的原始信号列
（均来自 user_active 表，prefix=act_）。

本模块负责两件事：
1. risk_score 打分：把多个原始风险信号按业务权重合成一个 0~1 的账号级置信度分数
   （规则打分，非机器学习模型——与本项目其余模块保持一致的"可解释规则"风格）。
2. 种子分类 + 训练/验证切分：
   - CORE_SEED（risk_score >= high_conf_threshold）：高置信度团伙账号，
     参与规则挖掘（作为正样本）+ 参与验证
   - WEAK_SEED（low_conf_threshold <= risk_score < high_conf_threshold）：
     中等置信度，只参与验证（防止噪声样本污染训练阶段挖出的规则），不参与挖掘
   - EXCLUDED（risk_score < low_conf_threshold）：不参与挖掘也不参与验证，
     实际就是"大盘"账号，用于反证阶段的分母

打分权重设计（业务优先级从高到低）：
- act_is_mtsi_case_user=1：命中过安全侧已定性的 CASE，最强信号，直接给最高权重
- act_is_mtsi_clue_user=1：命中过线索（未必定性为团伙，置信度弱于 CASE）
- act_mtsi_case_cntd / act_mtsi_clue_cntd：命中次数越多，说明关联的团伙行为越持续，
  在基础权重上做小幅加成（避免单次误命中被过度加权，用 log 压缩边际递减）
- 人机风险分数（mt/dp_man_machine_risk_score）：通用风控信号，作为兜底权重，
  单独达到较高分数也可以拉到 WEAK_SEED 甚至 CORE_SEED（覆盖"命中过CASE/线索"之外
  但风控已经独立识别出的团伙账号，避免只依赖 hopejob 历史线索导致的种子过窄）
"""

import hashlib
import os
from typing import Any, Dict, Optional

import yaml
from pyspark.sql import DataFrame, functions as F
from pyspark.sql.types import DoubleType

SEED_CORE = "CORE_SEED"
SEED_WEAK = "WEAK_SEED"
SEED_EXCLUDED = "EXCLUDED"

SPLIT_TRAIN = "train"
SPLIT_VALIDATION = "validation"

# 种子判定模式（seed_classification.mode）：
# - risk_score（默认，生产全量跑批）：按三路信号合成的 risk_score 阈值切 CORE/WEAK/EXCLUDED；
# - sample_as_seed（CASE 调试/小样本挖掘）：样本即种子——样本账号全部 CORE_SEED，
#   仅排除"受保护账号"（whitelist_flag 字段组 / 高等级会员），不产生 WEAK_SEED。
#   该模式下 EXCLUDED 通常为空属预期，真实的对照组（baseline）应通过
#   market_baseline 机制接入真实大盘抽样快照（见 pipeline.step1b_build_market_baseline）。
SEED_MODE_RISK_SCORE = "risk_score"
SEED_MODE_SAMPLE_AS_SEED = "sample_as_seed"

# risk_score 打分权重：{"信号": 权重}，最终 risk_score = min(1.0, sum(命中信号的权重))
# 权重之和刻意设计为可能超过1.0（多信号同时命中时用 min 封顶），
# 这样"同时命中 CASE + 高人机风险分"的账号依然是 1.0，不会被平均拉低置信度
_CASE_WEIGHT = 0.9        # 命中过 CASE：单独即可判定为 CORE_SEED（0.9 >= high_conf_threshold=0.8）
_CLUE_WEIGHT = 0.55       # 命中过线索：单独判定为 WEAK_SEED（0.55 >= low_conf_threshold=0.5），
                          # 不足以单独判 CORE_SEED，需要叠加其他信号
_CNTD_BONUS_CAP = 0.15    # 命中次数加成的封顶值（log 压缩，避免线性放大）
_RISK_SCORE_HIGH_THRESHOLD = 80   # 人机风险分数（假设量纲 0~100）超过此值视为高风险，给 CORE_SEED 级权重
_RISK_SCORE_HIGH_WEIGHT = 0.85
_RISK_SCORE_MID_THRESHOLD = 60    # 中等风险分数，给 WEAK_SEED 级权重
_RISK_SCORE_MID_WEIGHT = 0.55


def load_config(config_path: Optional[str] = None) -> Dict[str, Any]:
    if config_path is not None:
        with open(config_path, "r", encoding="utf-8") as f:
            return yaml.safe_load(f)
    try:
        import importlib.resources as _ir
        return yaml.safe_load(_ir.read_text("account_gang_profiling.config", "config.yaml"))
    except Exception:
        _default = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
                                "config", "config.yaml")
        with open(_default, "r", encoding="utf-8") as f:
            return yaml.safe_load(f)


def compute_risk_score(snapshot_df: DataFrame) -> DataFrame:
    """
    基于大宽表中的原始风险信号列，合成账号级 risk_score（0.0~1.0）。

    依赖列（均来自 user_active 表，prefix=act_，由 snapshot_builder 保证存在且已做过
    string_boolean/string_numeric 类型规范化，可直接当 int/double 使用）：
    - act_is_mtsi_case_user, act_is_mtsi_clue_user: 0/1
    - act_mtsi_case_cntd, act_mtsi_clue_cntd: 命中次数（double）
    - act_mt_man_machine_risk_score, act_dp_man_machine_risk_score: 人机风险分数

    Returns:
        原 snapshot_df 基础上新增 risk_score 列（DoubleType）
    """
    required_cols = [
        "act_is_mtsi_case_user", "act_is_mtsi_clue_user",
        "act_mtsi_case_cntd", "act_mtsi_clue_cntd",
        "act_mt_man_machine_risk_score", "act_dp_man_machine_risk_score",
    ]
    missing = [c for c in required_cols if c not in snapshot_df.columns]
    if missing:
        raise ValueError(f"计算 risk_score 缺少必要列: {missing}，请确认 snapshot_df 来自 "
                          f"ba_rc.app_acc_sec_case_snapshot 且该预建表已正确接入 user_active 源表。"
                          f"注意：act_mtsi_case_cntd/act_mtsi_clue_cntd 在精简日表已移除，"
                          f"risk_score 模式需补这两列或改用 sample_as_seed 模式")

    # CASE 命中：基础权重 + 命中次数加成（log1p 压缩边际递减，封顶 _CNTD_BONUS_CAP）
    case_hit = F.col("act_is_mtsi_case_user").cast("int") == 1
    case_cntd_bonus = F.least(
        F.log1p(F.greatest(F.col("act_mtsi_case_cntd").cast("double"), F.lit(0.0))) * F.lit(0.05),
        F.lit(_CNTD_BONUS_CAP)
    )
    case_score = F.when(case_hit, F.lit(_CASE_WEIGHT) + case_cntd_bonus).otherwise(F.lit(0.0))

    # 线索命中：同样有基础权重 + 次数加成
    clue_hit = F.col("act_is_mtsi_clue_user").cast("int") == 1
    clue_cntd_bonus = F.least(
        F.log1p(F.greatest(F.col("act_mtsi_clue_cntd").cast("double"), F.lit(0.0))) * F.lit(0.05),
        F.lit(_CNTD_BONUS_CAP)
    )
    clue_score = F.when(clue_hit, F.lit(_CLUE_WEIGHT) + clue_cntd_bonus).otherwise(F.lit(0.0))

    # 人机风险分数：取 mt/dp 两端分数的较大值，分档给权重
    max_risk_score = F.greatest(
        F.coalesce(F.col("act_mt_man_machine_risk_score").cast("double"), F.lit(0.0)),
        F.coalesce(F.col("act_dp_man_machine_risk_score").cast("double"), F.lit(0.0)),
    )
    risk_score_component = F.when(max_risk_score >= _RISK_SCORE_HIGH_THRESHOLD, F.lit(_RISK_SCORE_HIGH_WEIGHT)) \
        .when(max_risk_score >= _RISK_SCORE_MID_THRESHOLD, F.lit(_RISK_SCORE_MID_WEIGHT)) \
        .otherwise(F.lit(0.0))

    # 三路信号取最大值（而非求和封顶）：语义是"任一维度达到某置信水平即可"，
    # 比如同时命中线索(0.55)+中等人机风险(0.55)不应该被认为比单独命中CASE(0.9)更可信，
    # 取max比sum更符合"多来源交叉验证但不重复计分"的直觉，避免弱信号简单叠加伪造出高分
    risk_score = F.greatest(case_score, clue_score, risk_score_component)
    risk_score = F.least(risk_score, F.lit(1.0)).cast(DoubleType())

    return snapshot_df.withColumn("risk_score", risk_score)


def _resolve_config(config: Optional[Dict[str, Any]], config_path: Optional[str]) -> Dict[str, Any]:
    """config 字典优先（调用方已加载/内存内调整过），否则按 config_path 从文件加载。"""
    return config if config is not None else load_config(config_path)


def _classify_sample_as_seed(snapshot_df: DataFrame, seed_cfg: Dict[str, Any],
                              config_path: Optional[str] = None,
                              config: Optional[Dict[str, Any]] = None) -> DataFrame:
    """
    sample_as_seed 模式的种子分类：样本即种子——快照内账号默认全部 CORE_SEED，
    仅"受保护账号"降级为 EXCLUDED。不产生 WEAK_SEED（样本是二值的：种子 or 受保护）。

    受保护账号判定（全部配置化，见 config.yaml seed_classification.sample_as_seed.protected_account）：
    1. use_whitelist_flags：复用 field_type_overrides.whitelist_flag 声明的字段组
       （在职员工/公司高价值/高影响），不硬编码列名，与 extract_whitelist_flags 同口径；
    2. member_level_field + member_level_protected_values：高等级会员（如黑钻），
       字段名/匹配方式（isin/contains）/受保护取值列表均可配——因为该字段的真实编码
       因上游口径而异，首次运行会打印取值分布 top20 供回填核对。

    同时补一列常量 risk_score（CORE=1.0 / EXCLUDED=0.0）：本模式不做三路信号打分
    （样本本身就是正样本定义，打分无语义），但下游（step3 的 exclude_fields 等）
    引用了该列名，schema 必须与 risk_score 模式保持一致。

    保护闸语义与 risk_score 模式不同：这里 min_seed_size（默认10）只拦截真实故障
    （样本为空 / 样本表 join 失败 / case_id 写错 / sample_sql 返回 0 行），
    而不是"种子太少无法可靠挖掘"的质量闸——CASE 样本天然只有几百个账号。
    """
    sas_cfg = seed_cfg.get("sample_as_seed", {}) or {}
    protected_cfg = sas_cfg.get("protected_account", {}) or {}
    min_seed_size = sas_cfg.get("min_seed_size", 10)

    # ---- 受保护条件 1：whitelist_flag 字段组 ----
    cond = None
    if protected_cfg.get("use_whitelist_flags", True):
        # 延迟导入避免模块级循环依赖（field_types 不依赖本模块，此处仅为防御）
        from .field_types import get_whitelist_flag_columns
        # config dict 优先（与 _resolve_config 同一契约），避免内存内调整的声明被静默忽略
        for c in get_whitelist_flag_columns(config_path, config=config):
            if c in snapshot_df.columns:
                c_cond = F.coalesce(F.col(c).cast("int"), F.lit(0)) == 1
                cond = c_cond if cond is None else (cond | c_cond)
            else:
                print(f"[WARN] sample_as_seed: whitelist_flag 列 {c} 不在快照中，已跳过该列")

    # ---- 受保护条件 2：高等级会员（如黑钻）----
    member_field = protected_cfg.get("member_level_field")
    protected_values = [str(v) for v in (protected_cfg.get("member_level_protected_values") or [])]
    if member_field and protected_values:
        if member_field in snapshot_df.columns:
            # 诊断日志：打印真实取值分布，解决"编码未知靠猜"的问题——
            # 若下方的受保护取值列表与真实编码不符，按此输出回填配置即可，无需改代码。
            # 取值确认稳定后可用 debug_value_distribution: false 关闭打印
            if protected_cfg.get("debug_value_distribution", True):
                print(f"[INFO] sample_as_seed: {member_field} 取值分布 top20"
                      f"（供核对 member_level_protected_values 编码；"
                      f"确认后可用 protected_account.debug_value_distribution: false 关闭）:")
                snapshot_df.groupBy(member_field).count().orderBy(F.desc("count")).show(20, truncate=False)

            match_mode = protected_cfg.get("member_level_match", "isin")
            member_col = F.trim(F.col(member_field).cast("string"))
            if match_mode == "isin":
                m_cond = member_col.isin(*protected_values)
            elif match_mode == "contains":
                # contains 会误中"非黑钻会员"/"黑钻体验卡"这类取值，仅在确认字段是
                # 自由文本编码时使用；默认 isin（trim 后精确匹配）更安全
                m_cond = None
                for v in protected_values:
                    v_cond = member_col.contains(v)
                    m_cond = v_cond if m_cond is None else (m_cond | v_cond)
            else:
                raise ValueError(f"未知的 member_level_match: {match_mode!r}（合法取值: isin/contains）")
            cond = m_cond if cond is None else (cond | m_cond)
        else:
            print(f"[WARN] sample_as_seed: member_level_field={member_field} 不在快照中，"
                  f"高等级会员排除未生效")
    elif member_field:
        print(f"[WARN] sample_as_seed: 已配置 member_level_field={member_field} 但 "
              f"member_level_protected_values 为空，高等级会员排除未生效")

    if cond is None:
        print("[WARN] sample_as_seed: 未生效任何受保护账号条件，全部账号都将划为 CORE_SEED")
        cond = F.lit(False)

    classified_df = snapshot_df.withColumn(
        "seed_type", F.when(cond, F.lit(SEED_EXCLUDED)).otherwise(F.lit(SEED_CORE)))

    # 补常量 risk_score 列（无条件覆盖，withColumn 幂等）：本模式语义要求 risk_score
    # 随 seed_type 派生（CORE=1.0/EXCLUDED=0.0）——若上游快照恰好已有同名列
    # （如对同一快照重跑 build_seed_and_split），保留旧值会让两列口径互相矛盾
    classified_df = classified_df.withColumn(
        "risk_score",
        F.when(F.col("seed_type") == SEED_CORE, F.lit(1.0))
         .otherwise(F.lit(0.0)).cast(DoubleType()))

    core_seed_count = classified_df.filter(F.col("seed_type") == SEED_CORE).count()
    excluded_count = classified_df.filter(F.col("seed_type") == SEED_EXCLUDED).count()
    if core_seed_count < min_seed_size:
        raise ValueError(
            f"[sample_as_seed] CORE_SEED 账号数({core_seed_count})低于最小要求({min_seed_size})。"
            f"该闸只用于拦截真实故障：样本为空 / 样本表 join 失败 / case_id 写错 / "
            f"sample_sql 返回 0 行——请检查样本来源是否正确"
            f"（本模式不再依赖 risk_score 阈值与 mtsi 标签回写）。"
        )
    print(f"[INFO] 种子账号分类完成（sample_as_seed 模式）: CORE_SEED={core_seed_count}, "
          f"EXCLUDED(受保护账号)={excluded_count}（本模式不产生 WEAK_SEED；"
          f"EXCLUDED 通常为空属预期，真实对照组请接入 market_baseline）")
    return classified_df


def classify_seed_accounts(snapshot_df: DataFrame, config_path: Optional[str] = None,
                            config: Optional[Dict[str, Any]] = None) -> DataFrame:
    """
    基于 risk_score 对账号做种子分类，新增 seed_type 列（CORE_SEED/WEAK_SEED/EXCLUDED）。

    若 snapshot_df 尚未包含 risk_score 列，会自动调用 compute_risk_score 补算。

    种子判定模式由 seed_classification.mode 决定（默认 risk_score）：
    - risk_score：按 risk_score 阈值切 CORE/WEAK/EXCLUDED（本函数下方的原始逻辑）；
    - sample_as_seed：样本即种子，仅排除受保护账号，委托 _classify_sample_as_seed。

    Args:
        config: 可选，已加载的配置字典（调用方内存内调整过时优先于 config_path 文件）
    """
    config = _resolve_config(config, config_path)
    seed_cfg = config.get("seed_classification", {})
    mode = seed_cfg.get("mode", SEED_MODE_RISK_SCORE)

    if mode == SEED_MODE_SAMPLE_AS_SEED:
        return _classify_sample_as_seed(snapshot_df, seed_cfg, config_path, config=config)
    if mode != SEED_MODE_RISK_SCORE:
        raise ValueError(f"未知的 seed_classification.mode: {mode!r}，合法取值: "
                         f"{SEED_MODE_RISK_SCORE!r} / {SEED_MODE_SAMPLE_AS_SEED!r}")

    high_conf_threshold = seed_cfg.get("high_conf_threshold", 0.8)
    low_conf_threshold = seed_cfg.get("low_conf_threshold", 0.5)
    min_seed_size = seed_cfg.get("min_seed_size", 500)

    if "risk_score" not in snapshot_df.columns:
        snapshot_df = compute_risk_score(snapshot_df)

    classified_df = snapshot_df.withColumn(
        "seed_type",
        F.when(F.col("risk_score") >= high_conf_threshold, F.lit(SEED_CORE))
         .when(F.col("risk_score") >= low_conf_threshold, F.lit(SEED_WEAK))
         .otherwise(F.lit(SEED_EXCLUDED))
    )

    core_seed_count = classified_df.filter(F.col("seed_type") == SEED_CORE).count()
    if core_seed_count < min_seed_size:
        raise ValueError(
            f"CORE_SEED 账号数({core_seed_count})低于最小要求({min_seed_size})，"
            f"无法开展可靠的规则挖掘。请检查 high_conf_threshold 阈值设置是否过严，"
            f"或确认线索/CASE/风控命中数据是否正常接入 user_active 表。"
        )

    weak_seed_count = classified_df.filter(F.col("seed_type") == SEED_WEAK).count()
    excluded_count = classified_df.filter(F.col("seed_type") == SEED_EXCLUDED).count()
    print(f"[INFO] 种子账号分类完成: CORE_SEED={core_seed_count}, WEAK_SEED={weak_seed_count}, "
          f"EXCLUDED={excluded_count}（阈值 high={high_conf_threshold}, low={low_conf_threshold}）")

    return classified_df


def _account_hash_mod(account_id_col: "F.Column", buckets: int = 1000) -> "F.Column":
    """
    对 account_id 做稳定哈希取模，用于幂等可复现的训练/验证集切分
    （同一账号在多次运行中始终落入同一个桶，不受 Spark 分区/执行顺序影响，
    这一点用随机数 F.rand() 做不到，必须基于账号ID本身的确定性哈希）。
    """
    return F.abs(F.crc32(account_id_col.cast("string"))) % F.lit(buckets)


def split_train_validation(classified_df: DataFrame, config_path: Optional[str] = None,
                            config: Optional[Dict[str, Any]] = None) -> DataFrame:
    """
    对种子账号做训练/验证集切分，新增 dataset_split 列（train/validation）。

    切分规则：
    - CORE_SEED：按 train_ratio 切分（哈希取模，幂等可复现），训练集用于规则挖掘，
      验证集用于 rule_validation 阶段的防过拟合检查（验证集覆盖率不能远低于训练集覆盖率）
    - WEAK_SEED：全部划入 validation（它们置信度不足以参与训练挖掘，但仍可作为
      验证阶段的正向参考样本，用于评估规则的泛化覆盖面）
    - EXCLUDED：全部划入 validation（作为背景/大盘账号，dataset_split 列在这类账号上
      无实际业务含义，仅为保持全表 schema 一致，rule_validation 阶段会按 seed_type
      而非 dataset_split 来区分这类账号的角色）

    Returns:
        新增 dataset_split 列的 DataFrame
    """
    config = _resolve_config(config, config_path)
    split_cfg = config.get("dataset_split", {})
    train_ratio = split_cfg.get("train_ratio", 0.8)

    buckets = 1000
    train_cutoff = int(train_ratio * buckets)
    bucket_col = _account_hash_mod(F.col("account_id"), buckets)

    split_df = classified_df.withColumn(
        "dataset_split",
        F.when(F.col("seed_type") == SEED_CORE,
               F.when(bucket_col < train_cutoff, F.lit(SPLIT_TRAIN)).otherwise(F.lit(SPLIT_VALIDATION)))
         .otherwise(F.lit(SPLIT_VALIDATION))
    )

    train_count = split_df.filter((F.col("seed_type") == SEED_CORE) & (F.col("dataset_split") == SPLIT_TRAIN)).count()
    val_count = split_df.filter((F.col("seed_type") == SEED_CORE) & (F.col("dataset_split") == SPLIT_VALIDATION)).count()
    print(f"[INFO] CORE_SEED 训练/验证切分完成: train={train_count}, validation={val_count} "
          f"(train_ratio={train_ratio}, 实际比例={train_count / (train_count + val_count):.2%})"
          if (train_count + val_count) > 0 else "[WARN] CORE_SEED 账号数为0，无法计算切分比例")

    return split_df


def build_seed_and_split(snapshot_df: DataFrame, config_path: Optional[str] = None,
                          config: Optional[Dict[str, Any]] = None) -> DataFrame:
    """
    主线入口：一次性完成 risk_score 计算 -> 种子分类 -> 训练/验证切分，
    供 rule_mining/rule_validation 直接消费。

    种子判定模式由 seed_classification.mode 决定：
    - risk_score（默认）：compute_risk_score -> classify -> split 三步；
    - sample_as_seed：跳过 compute_risk_score（打分对"样本即种子"无语义，且其依赖的
      act_mtsi_* 必需列在小样本场景可能缺失），直接 classify（内部走 sample_as_seed
      分支并自补常量 risk_score 列）-> split。

    Args:
        config: 可选，已加载的配置字典（优先于 config_path 文件，便于调用方内存内调整）

    Returns:
        在 snapshot_df 基础上新增 risk_score / seed_type / dataset_split 三列的 DataFrame
    """
    config = _resolve_config(config, config_path)
    mode = config.get("seed_classification", {}).get("mode", SEED_MODE_RISK_SCORE)
    if mode == SEED_MODE_SAMPLE_AS_SEED:
        classified_df = classify_seed_accounts(snapshot_df, config_path, config=config)
    else:
        scored_df = compute_risk_score(snapshot_df)
        classified_df = classify_seed_accounts(scored_df, config_path, config=config)
    split_df = split_train_validation(classified_df, config_path, config=config)
    return split_df
