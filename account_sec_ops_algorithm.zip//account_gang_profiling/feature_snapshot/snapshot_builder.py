# -*- coding: utf-8 -*-
"""
账号特征快照辅助工具。

5 表 collect_set 聚合 + FULL OUTER JOIN 的大宽表构建已移至 SQL xt 任务
（case_task2_snapshot_xt.sql → ba_rc.app_acc_sec_case_snapshot），
pipeline.step1/step1b 改为直接读预建表，不再在本地聚合。本模块只保留
下游 step2~step4b 仍依赖的辅助函数：

- load_config / build_feature_metadata：配置与字段元数据
- _load_account_id_sample / _apply_sample_filter：账号样本加载与过滤（step4b 时序复用）
- _get_existing_partitions / _date_range / log_with_time：分区探测（step4b event_timeseries 复用）
- _parse_json_map_array_column：JSON 字段展平（step4b event_timeseries 复用）
- extract_whitelist_flags：白名单标记提取（step2 误伤检测用）
"""

import os
import time
from datetime import datetime, timedelta
from typing import Dict, Any, List, Optional

import yaml
from pyspark.sql import DataFrame, SparkSession, functions as F
from pyspark.sql.utils import AnalysisException


def log_with_time(message: str, level: str = "INFO") -> None:
    ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    print(f"[{ts}] [{level}] {message}")


def load_config(config_path: Optional[str] = None) -> Dict[str, Any]:
    if config_path is not None:
        # 显式传入路径（外部/HDFS/ship 的 config.yaml）→ 直接 open
        with open(config_path, "r", encoding="utf-8") as f:
            return yaml.safe_load(f)
    # 未传 config_path：优先用 importlib.resources 从包内读 config.yaml
    # （MLP 把包打成 zip 时，__file__ 是 .../xxx.zip/account_gang_profiling/...，
    # open() 打不开 zip 内路径 → NotADirectoryError；importlib.resources 能读 zip 内资源）。
    # 用 read_text 而非 files().open()——后者是 Python 3.9+ API，
    # MLP 集群（Spark 3.0 配套 Python 3.7）没有 files()，read_text 在 3.7+ 通用。
    try:
        import importlib.resources as _ir
        return yaml.safe_load(_ir.read_text("account_gang_profiling.config", "config.yaml"))
    except Exception:
        # 退回 __file__ 相对路径（本地开发 / 未打 zip 的集群提交场景）
        _default = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
                                "config", "config.yaml")
        with open(_default, "r", encoding="utf-8") as f:
            return yaml.safe_load(f)


# 布尔语义的字符串取值，用于 string_boolean 类型字段的规范化转换
# 源表里"是否命中xxx"这类字段有时用 string 存 '1'/'0'/'true'/'false'/'是'/'否'，需统一识别
_TRUE_STRING_VALUES = ("1", "true", "yes", "y", "是")


def _date_range(end_dt: str, window_days: int) -> List[str]:
    """
    生成 [end_dt - window_days + 1, end_dt] 闭区间内的日期列表（含端点），格式与分区键一致（yyyymmdd）。
    例如 end_dt='20260726', window_days=90 -> 返回 20260426 ~ 20260726 共 90 个日期。
    """
    end_date = datetime.strptime(end_dt, "%Y%m%d")
    return [(end_date - timedelta(days=i)).strftime("%Y%m%d") for i in range(window_days - 1, -1, -1)]


def _load_account_id_sample(spark: SparkSession, config: Dict[str, Any],
                             case_id: Optional[str] = None,
                             sample_sql: Optional[str] = None) -> Optional[DataFrame]:
    """
    加载账号范围抽样表（可选功能，见 config.yaml 中 feature_snapshot.account_id_sample_table 注释）。

    未配置该项且未传 sample_sql 时返回 None，调用方需在 None 时跳过过滤逻辑
    （即构建全量账号大宽表，与未接入本功能之前的行为完全一致，保证向后兼容）。

    样本账号来源按优先级支持三种方式（多 CASE 任务化调试）：
    1. sample_sql（优先级最高）：完全自定义的样本查询 SQL，如
       "select distinct user_id from ba_rc_test.acc_sec_tmp_13_new_nanyang_m5w3_uid"，
       通常由命令行 --sample-sql / run 参数传入，结果集的第一个列作为账号ID；
    2. case_id 过滤：样本表（如 ba_rc.app_account_analysis_case_user_id）按
       case_id_field 配置的字段过滤出本次 CASE 的样本账号——一张表存全部 CASE
       的样本，每次任务用 case_id 取自己那批；
    3. 全表：不指定 case_id 时的老行为，取样本表全量去重 ID。

    返回的 DataFrame 只有一列 sample_account_id（string 类型，已去重），会被复用 join 到
    全部 5 张源表，因此这里显式 cache，避免每次 join 都重新扫描一次 Hive 表。
    """
    sample_cfg = config.get("feature_snapshot", {}).get("account_id_sample_table") or {}
    sample_sql = sample_sql or sample_cfg.get("sample_sql")

    if sample_sql:
        log_with_time(f"[INFO] 使用自定义样本 SQL 加载账号样本: {sample_sql}")
        raw_df = spark.sql(sample_sql)
        if not raw_df.columns:
            raise ValueError(f"样本 SQL 未返回任何列: {sample_sql}")
        id_col = raw_df.columns[0]
        sample_df = raw_df.select(F.col(id_col).cast("string").alias("sample_account_id")).distinct()
        source_desc = f"自定义SQL"
    elif sample_cfg:
        table = sample_cfg["table"]
        id_field = sample_cfg["id_field"]
        case_id_field = sample_cfg.get("case_id_field")
        if case_id_field and case_id:
            # 先探 schema（LIMIT 0 不扫数据，成本极低）：样本表若尚未增加 case_id 字段，
            # 直接拼 WHERE case_id=... 会抛 Spark 原生 AnalysisException（信息不直观），
            # 这里提前给出清晰可操作的报错。
            # 注意不能"字段缺失则静默退化为全表"——那会把其他 CASE 的账号混进本次样本，
            # 产出错误结论且难以察觉，必须显式失败。
            probe_df = spark.sql(f"SELECT * FROM {table} LIMIT 0")
            if case_id_field not in probe_df.columns:
                raise ValueError(
                    f"样本表 {table} 中不存在 {case_id_field} 字段（当前仅有列: {probe_df.columns}），"
                    f"无法按 case_id='{case_id}' 过滤样本账号。请先给样本表增加 {case_id_field} 字段"
                    f"并写入各 CASE 的样本账号，或改用 sample_sql/--sample-sql 传入自定义样本查询"
                )
            sql = (f"SELECT DISTINCT {id_field} AS sample_account_id FROM {table} "
                   f"WHERE {case_id_field} = '{case_id}'")
            source_desc = f"{table}（{case_id_field}={case_id}）"
        else:
            sql = f"SELECT DISTINCT {id_field} AS sample_account_id FROM {table}"
            source_desc = f"{table}（全表）"
        log_with_time(f"[INFO] 从样本表加载账号样本: {source_desc}")
        sample_df = spark.sql(sql).withColumn("sample_account_id",
                                               F.col("sample_account_id").cast("string"))
    else:
        return None

    sample_df = sample_df.filter(F.col("sample_account_id").isNotNull()).cache()
    sample_count = sample_df.count()
    log_with_time(f"[INFO] 账号样本加载完成（来源: {source_desc}），样本账号数: {sample_count}")
    if sample_count == 0:
        raise ValueError(f"账号样本为空（来源: {source_desc}），请检查样本数据/ case_id / SQL 是否正确")
    return sample_df


def _apply_sample_filter(df: DataFrame, id_field: str,
                          account_id_sample_df: DataFrame) -> DataFrame:
    """
    用账号范围抽样表对 df 做 inner join 过滤，只保留样本范围内账号的行。

    【性能关键】join key 的类型对齐方向必须是"小表 cast 成大表的原生类型"，
    而不是反过来：若把 df 侧（event_detail 全量明细 / user_active 亿级快照）
    的 id_field 逐行 cast 成 string 再做 join，大表每行都要付一次字符串转换 +
    字符串哈希探测的成本（user_active 亿级行规模下是可观的 CPU 开销，且会为
    大表额外物化出一列临时字符串列）；正确方向是把样本小表（通常几千行）的
    sample_account_id cast 成 df 侧 id_field 的原生类型（如 bigint），
    大表侧零改动，且整型哈希远快于字符串哈希。
    样本表中若有无法转换的脏 ID（cast 后为 null），join 时天然匹配不到任何行，
    等价于被丢弃，不会引入错误结果。
    """
    id_type = df.schema[id_field].dataType
    sample_aligned_df = account_id_sample_df.withColumn(
        "sample_account_id", F.col("sample_account_id").cast(id_type))
    return df.join(
        F.broadcast(sample_aligned_df),
        on=df[id_field] == sample_aligned_df["sample_account_id"],
        how="inner",
    ).drop("sample_account_id")


def _get_existing_partitions(spark: SparkSession, table: str, candidate_dts: List[str]) -> List[str]:
    """
    在候选日期列表中，筛选出该表实际存在的 dt 分区，跳过缺失分区（数据延迟/中断等场景），
    避免直接对不存在的分区做 SELECT 触发异常导致整个任务失败。

    实现方式：优先用 SHOW PARTITIONS 一次性获取全部分区再取交集（性能更好，只需一次 Hive 元数据查询），
    若目标表不支持 SHOW PARTITIONS（如非分区表/视图），兜底为“认为候选日期全部存在”，
    交由后续实际查询报错兜底。
    """
    try:
        partitions_df = spark.sql(f"SHOW PARTITIONS {table}")
        # SHOW PARTITIONS 返回形如 "dt=20260726" 的单列字符串，需要解析出 dt 取值
        existing_dts = set()
        for row in partitions_df.collect():
            partition_str = row[0]
            for kv in partition_str.split("/"):
                if kv.startswith("dt="):
                    existing_dts.add(kv[len("dt="):])
                    break
        result = [d for d in candidate_dts if d in existing_dts]
        missing = [d for d in candidate_dts if d not in existing_dts]
        if missing:
            log_with_time(f"  [WARN] 表 {table} 缺失 {len(missing)}/{len(candidate_dts)} 个候选分区，"
                          f"已跳过（如: {missing[:5]}{'...' if len(missing) > 5 else ''}）", level="WARN")
        return result
    except AnalysisException as e:
        log_with_time(f"  [WARN] 表 {table} 执行 SHOW PARTITIONS 失败（{e}），"
                      f"退化为假定全部候选分区存在，由实际查询兜底", level="WARN")
        return candidate_dts


def _parse_json_map_array_column(df: DataFrame, col_name: str, out_col_name: str) -> DataFrame:
    """
    将 df 中的 JSON 字符串列 col_name（结构为 map<分类, array<子标签>>，如
    '{"Network_VPN":["all_network_vpn_isvpn_env_fe"],"Category2":["tag1","tag2"]}'）
    解析为 array<string> 类型的新列 out_col_name，每个元素是"分类:子标签"格式的扁平字符串
    （如 "Network_VPN:all_network_vpn_isvpn_env_fe"），调用方只需对 out_col_name 做一层
    explode_outer 即可展开成标签粒度的多行，无需再做第二层展开。

    实现说明：全程只用 Spark SQL 内置字符串/高阶函数（regexp_replace/split/regexp_extract/
    transform/flatten，均为 Spark 2.4+ 支持，无版本兼容性风险），不使用 from_json/
    map_entries/F.transform（PySpark Python 具名封装）/自定义 UDF，原因是这几种方案
    都在 CodeLab 集群上先后踩坑：
    - F.transform（pyspark.sql.functions.transform）需要 Spark 3.1+，集群是 3.0.2，报
      AttributeError: module 'pyspark.sql.functions' has no attribute 'transform'
    - 自定义 Python UDF 在 executor 端反序列化时报
      ModuleNotFoundError: No module named 'account_gang_profiling'（executor 与 driver
      的 Python 环境/工作目录不一致，需要运维侧 --py-files 配合分发，不适合业务代码强依赖）
    - F.from_json(col, MapType(...)) 在 CodeLab 集群上报
      AnalysisException: cannot resolve 'jsontostructslegacy(...)' due to data type
      mismatch: Input schema map<string,array<string>> must be a struct or an array of
      structs —— 说明集群侧 from_json 的 legacy 实现只接受 struct/array<struct>，
      不接受 MapType 作为目标 schema（美团内部 Spark 分支的已知差异，社区版本本应支持）

    这里改用 SQL 字符串里的 transform/flatten 高阶函数表达式（通过 F.expr 调用）：
    这两个函数从 Spark 2.4 起就是 Spark SQL 内置能力，只是没有对应的
    pyspark.sql.functions 具名 Python 封装（那个封装是 3.1+ 才加的），通过 F.expr()
    传 SQL 字符串调用完全不受这个限制，属于两条独立的兼容性边界。

    解析步骤（在 SQL 表达式内完成，逐层拆解 JSON 文本）：
    1. 去掉最外层的 "{" "}"，得到 `"k1":["v1","v2"],"k2":["v3"]` 这样的内容
    2. 用零宽断言 `(?<=\\]),(?=")` 在 "]," 与下一个 "\"" 之间安全切分出每个 "k":[...] 键值对
       （不能直接按 "," 粗暴切分，会把同一个 key 下数组内的多个子标签错误切开）
    3. 用 transform 高阶函数遍历每个键值对，各自用 regexp_extract 取出 key（引号内，
       ":[" 之前）和 value 数组内容（"[" 与 "]" 之间的部分）
    4. 对 value 数组内容按 "," 切分成子标签数组，再用内层 transform 给每个子标签拼上
       "key:" 前缀（并去除子标签两端多余的引号/空格），最外层用 flatten 把
       array<array<string>> 拍平成 array<string>

    解析失败/空值/非法 JSON 时上述正则均取不到匹配，最终产出空数组（而非报错），
    调用方对空数组走 explode_outer 会得到一行 null，语义与"该账号无此类标签"一致。
    """
    inner_col_name = f"__{col_name}_json_inner"
    df = df.withColumn(
        inner_col_name,
        F.regexp_replace(F.col(col_name).cast("string"), r'^\s*\{|\}\s*$', "")
    )
    df = df.withColumn(out_col_name, F.expr(f"""
        flatten(
            transform(
                filter(
                    split(`{inner_col_name}`, '(?<=\\\\]),(?=")'),
                    pair -> pair is not null and trim(pair) <> ''
                            and regexp_extract(pair, '^\\\\s*"([^"]*)"\\\\s*:', 1) <> ''
                ),
                pair -> transform(
                    filter(
                        split(
                            regexp_extract(pair, '\\\\[(.*)\\\\]', 1),
                            '\\\\s*,\\\\s*'
                        ),
                        sub_tag -> trim(sub_tag) <> ''
                    ),
                    sub_tag -> concat(
                        regexp_extract(pair, '^\\\\s*"([^"]*)"\\\\s*:', 1),
                        ':',
                        regexp_replace(trim(sub_tag), '^"|"$', '')
                    )
                )
            )
        )
    """))
    return df.drop(inner_col_name)


def extract_whitelist_flags(snapshot_df: DataFrame, config_path: Optional[str] = None) -> DataFrame:
    """
    从账号特征大宽表中抽取"白名单豁免"类字段（如在职员工/公司高价值账号/高影响账号），
    独立成一张 account_id -> is_whitelisted 的判定表，供 rule_validation 阶段的
    误伤检测（白名单命中率）直接 join 使用，而不必在每次验证时重新拼接字段名。

    白名单判定逻辑：只要命中 whitelist_flag 分组下任意一个字段 == 1，即视为白名单账号。
    """
    config = load_config(config_path)
    source_tables_cfg = config.get("feature_snapshot", {}).get("source_tables", [])

    whitelist_cols = []
    for table_cfg in source_tables_cfg:
        prefix = table_cfg["prefix"]
        flags = table_cfg.get("field_type_overrides", {}).get("whitelist_flag", [])
        whitelist_cols.extend(f"{prefix}{f}" for f in flags)

    if not whitelist_cols:
        log_with_time("未声明任何 whitelist_flag 字段，返回全量账号 is_whitelisted=0", level="WARN")
        return snapshot_df.select("account_id").withColumn("is_whitelisted", F.lit(0))

    missing = [c for c in whitelist_cols if c not in snapshot_df.columns]
    if missing:
        raise ValueError(f"snapshot_df 中缺少声明的 whitelist_flag 字段: {missing}")

    cond = None
    for c in whitelist_cols:
        c_is_true = F.col(c).cast("int") == 1
        cond = c_is_true if cond is None else (cond | c_is_true)

    return snapshot_df.select(
        "account_id",
        F.when(cond, F.lit(1)).otherwise(F.lit(0)).alias("is_whitelisted")
    )


def build_feature_metadata(config_path: Optional[str] = None) -> List[Dict[str, Any]]:
    """
    生成特征血缘元数据（对应设计方案中的 feature_metadata 表），
    记录每个前缀对应的来源表，便于后续规则解释、审计追溯。
    """
    config = load_config(config_path)
    source_tables_cfg = config.get("feature_snapshot", {}).get("source_tables", [])
    metadata = []
    for table_cfg in source_tables_cfg:
        metadata.append({
            "source_name": table_cfg["name"],
            "source_table": table_cfg["table"],
            "id_field": table_cfg["id_field"],
            "feature_prefix": table_cfg["prefix"],
            "select_fields": table_cfg.get("select_fields") or "ALL",
        })
    return metadata


