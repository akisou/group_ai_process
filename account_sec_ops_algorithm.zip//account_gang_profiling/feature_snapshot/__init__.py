# -*- coding: utf-8 -*-
"""
账号特征快照辅助工具 + 种子分类。

大宽表构建已移至 SQL xt 任务（ba_rc.app_acc_sec_case_snapshot），
pipeline 直接读预建表。本包保留：
- 种子账号分类（CORE_SEED / WEAK_SEED / EXCLUDED）+ 训练/验证切分（seed_split.py）
- 特征字段元数据/分类（field_types.py）
- 快照辅助函数：配置加载、白名单提取、样本过滤、JSON 展平、分区探测（snapshot_builder.py）
"""

from .snapshot_builder import (
    build_feature_metadata,
    extract_whitelist_flags,
    load_config,
)
from .field_types import (
    build_field_category_map,
    infer_field_categories_from_schema,
    get_columns_by_category,
    get_whitelist_flag_columns,
    FIELD_CATEGORY_ARRAY,
    FIELD_CATEGORY_MAP,
    FIELD_CATEGORY_BOOLEAN,
    FIELD_CATEGORY_NUMERIC,
    FIELD_CATEGORY_STRING,
    FIELD_CATEGORY_WHITELIST_FLAG,
)
from .seed_split import (
    build_seed_and_split,
    compute_risk_score,
    classify_seed_accounts,
    split_train_validation,
    SEED_CORE,
    SEED_WEAK,
    SEED_EXCLUDED,
    SPLIT_TRAIN,
    SPLIT_VALIDATION,
    SEED_MODE_RISK_SCORE,
    SEED_MODE_SAMPLE_AS_SEED,
)
