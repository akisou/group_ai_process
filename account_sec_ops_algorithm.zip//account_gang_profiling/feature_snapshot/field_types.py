# -*- coding: utf-8 -*-
"""
账号特征字段类型解析工具

背景：账号特征大宽表由多张源表 JOIN 而成，字段类型混杂：
- 数值型（bigint/double/int/decimal）：直接用于数值阈值 Predicate
- 布尔型（int，取值0/1）：用于布尔 Predicate
- array<string>：集合类型（如 ip_set_7d、account_stability_label_set），
  需要 explode 展开后逐值生成候选 Predicate（不能整列做等值匹配）
- map<string,*>：键值集合类型（如 unfreeze_entry_cnt_map_7d、
  reg_login_mobile_user_cntd_30d_map_30d），key 本身是业务枚举/实体标识，
  value 是次数或子集合，需要按 key 展开后分别生成 Predicate
- whitelist_flag：白名单豁免类字段（如 is_on_job_employee），不参与规则挖掘候选池，
  仅供 rule_validation 阶段的误伤检测使用，需要单独识别以便从候选特征池中剔除

特别说明（源表类型不规范的兼容处理）：
个别字段在源表 schema 中被声明为 string，但语义其实是布尔/数值
（如 mart_mtsi.topic_user_active_ss_d 的 is_mtsi_clue_user 是 string 类型的 '1'/'0'）。
这类字段在 snapshot_builder._read_source_table 阶段已经被显式 cast 为规范类型
（string_boolean -> int，string_numeric -> double），因此进入大宽表后已经是"干净"的
numeric/boolean 类型，不再需要在本模块中特殊处理；这里仅做 config 中
string_boolean/string_numeric 声明到标准分类的归一化，避免声明类型和实际列类型不一致
导致下游误判。

本模块负责：
1. 结合 config.yaml 的 field_type_overrides 声明 + 实际列名前缀，
   推断每个（已加前缀的）大宽表列属于哪种类型
2. 提供给 predicates 模块统一查询接口，避免下游重复解析配置
"""

import os
from typing import Any, Dict, List, Optional

import yaml
from pyspark.sql import DataFrame
from pyspark.sql.types import ArrayType, MapType

FIELD_CATEGORY_ARRAY = "array"
FIELD_CATEGORY_MAP = "map"
FIELD_CATEGORY_BOOLEAN = "boolean"
FIELD_CATEGORY_NUMERIC = "numeric"
FIELD_CATEGORY_STRING = "string"
FIELD_CATEGORY_WHITELIST_FLAG = "whitelist_flag"

# config.yaml 中声明的分类名 -> 本模块标准分类名的归一化映射。
# string_boolean / string_numeric 只是描述"源表里的原始存储类型不规范"，
# 经 snapshot_builder 转换后，语义分类应等价于标准的 boolean / numeric，
# 而不应作为独立分类继续在下游（predicates等）出现，否则会被误认为未识别类型。
_CATEGORY_ALIASES = {
    "string_boolean": FIELD_CATEGORY_BOOLEAN,
    "string_numeric": FIELD_CATEGORY_NUMERIC,
}


def load_config(config_path: Optional[str] = None) -> Dict[str, Any]:
    if config_path is not None:
        with open(config_path, "r", encoding="utf-8") as f:
            return yaml.safe_load(f)
    try:
        import importlib.resources as _ir
        return yaml.safe_load(_ir.read_text("account_gang_profiling.config", "config.yaml"))
    except Exception:
        _default = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
                                "config", "config.yaml")
        with open(_default, "r", encoding="utf-8") as f:
            return yaml.safe_load(f)


def build_field_category_map(config_path: Optional[str] = None) -> Dict[str, str]:
    """
    汇总所有源表的字段类型声明，生成 {加前缀后的列名: 类型分类} 映射。
    未在此映射中出现的字段，后续由 infer_field_categories_from_schema
    根据 Spark 实际 schema 类型自动补全（numeric/string/array/map）。

    覆盖两种来源：
    1. table_type=snapshot 的表：读取显式声明的 field_type_overrides
    2. table_type=event_detail 的表：根据 agg_fields 自动推导——
       每个字段聚合后统一生成 {field}_set（array）；{field}_cntd（numeric）仅为
       cntd_fields 配置指定的字段派生（未配置则全部派生，见
       snapshot_builder._read_event_detail_table）。
       这里显式声明可以让下游（predicates模块）明确知道二者是同一原始字段的配对，
       而不必仅依赖 Spark 原生 schema 兜底推断（虽然兜底推断结果也是一致的）。

       其中 json_map_array_fields 声明的字段（如 deviceriskhitrulesv2new，
       原始值为 JSON 字符串 map<分类, array<子标签>>）在 snapshot_builder 中
       会被先展平成 "分类:子标签" 格式的 array<string>，再走同样的
       countDistinct/collect_set 聚合，最终生成的列名（{field}_cntd/{field}_set）
       与普通字段完全一致，因此这里无需对 json_map_array_fields 做区分处理，
       agg_fields 的统一分类逻辑已经自动覆盖。
    """
    config = load_config(config_path)
    feat_cfg = config.get("feature_snapshot", {})
    source_tables_cfg = feat_cfg.get("source_tables", [])
    # derive_cntd（可选，缺省 True=向后兼容）：false 时不为 event_detail 表派生 _cntd，
    # 分类映射也不标记 _cntd 为 NUMERIC（否则谓词池会引用不存在的列）。
    derive_cntd = feat_cfg.get("derive_cntd", True)

    category_map = {}
    for table_cfg in source_tables_cfg:
        prefix = table_cfg["prefix"]
        table_type = table_cfg.get("table_type", "snapshot")

        if table_type == "event_detail":
            # cntd_fields（可选）：配置后只有清单内字段实际派生 _cntd 列
            # （见 snapshot_builder._read_event_detail_table），分类映射需保持一致，
            # 未配置则全部 agg_fields 都派生（历史默认行为）
            cntd_only = table_cfg.get("cntd_fields")
            cntd_set = set(cntd_only) if cntd_only is not None else None
            for field_name in table_cfg.get("agg_fields", []):
                if derive_cntd and (cntd_set is None or field_name in cntd_set):
                    category_map[f"{prefix}{field_name}_cntd"] = FIELD_CATEGORY_NUMERIC
                category_map[f"{prefix}{field_name}_set"] = FIELD_CATEGORY_ARRAY
            continue

        overrides = table_cfg.get("field_type_overrides", {})
        for category, field_names in overrides.items():
            # string_boolean/string_numeric 归一化为标准 boolean/numeric，
            # whitelist_flag 保留原样（下游需要据此从候选特征池中剔除）
            normalized_category = _CATEGORY_ALIASES.get(category, category)
            for field_name in field_names:
                category_map[f"{prefix}{field_name}"] = normalized_category
    return category_map


def get_whitelist_flag_columns(config_path: Optional[str] = None,
                                config: Optional[Dict[str, Any]] = None) -> List[str]:
    """
    返回所有（已加前缀的）whitelist_flag 列名，供 predicates/rule_mining 阶段
    从候选特征池中显式剔除——这类字段只用于 rule_validation 的误伤检测，
    不应作为规则挖掘的候选 Predicate（否则可能挖出"命中在职员工"这种没有业务意义的规则）。

    Args:
        config: 可选，已加载的配置字典（优先于 config_path 文件，
            与 seed_split._resolve_config 同一契约，便于调用方内存内调整声明）
    """
    config = config if config is not None else load_config(config_path)
    source_tables_cfg = config.get("feature_snapshot", {}).get("source_tables", [])

    cols = []
    for table_cfg in source_tables_cfg:
        prefix = table_cfg["prefix"]
        flags = table_cfg.get("field_type_overrides", {}).get("whitelist_flag", [])
        cols.extend(f"{prefix}{f}" for f in flags)
    return cols


def infer_field_categories_from_schema(df: DataFrame,
                                        declared_category_map: Optional[Dict[str, str]] = None,
                                        exclude_cols=("account_id", "snapshot_version",
                                                      "snapshot_time", "window_end")) -> Dict[str, str]:
    """
    结合 config.yaml 中显式声明的类型（优先级最高，用于纠正 boolean 这类无法从
    Spark 原生类型区分出来的语义分类）+ Spark 实际 schema 类型（兜底），
    得到大宽表每一列的最终类型分类。

    Returns:
        {column_name: category}，category 取值见 FIELD_CATEGORY_* 常量
    """
    declared_category_map = declared_category_map or {}
    result = {}
    for field in df.schema.fields:
        if field.name in exclude_cols:
            continue
        if field.name in declared_category_map:
            result[field.name] = declared_category_map[field.name]
            continue
        if isinstance(field.dataType, ArrayType):
            result[field.name] = FIELD_CATEGORY_ARRAY
        elif isinstance(field.dataType, MapType):
            result[field.name] = FIELD_CATEGORY_MAP
        elif field.dataType.typeName() in ("int", "bigint", "double", "float", "long", "smallint", "decimal"):
            result[field.name] = FIELD_CATEGORY_NUMERIC
        else:
            result[field.name] = FIELD_CATEGORY_STRING
    return result


def get_columns_by_category(field_categories: Dict[str, str], category: str) -> List[str]:
    """按类型分类筛选列名，供 predicates 模块分别调用对应的生成逻辑"""
    return [col for col, cat in field_categories.items() if cat == category]
