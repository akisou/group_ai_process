# -*- coding: utf-8 -*-
"""
账号级团伙特征识别方案 (Account Gang Profiling)

设计目标：在现有请求级线索分析(hopejob/)基础上，扩展出一套面向账号维度的
团伙规则挖掘系统，融合：
- 账号级行为特征聚合（多事件表 -> 账号特征快照）
- 标准化原子条件(Predicate)体系，支持数值阈值/布尔/分类/名单/标签集合等类型
- 分层组合搜索 + Apriori式反单调剪枝 + 批量聚合（PySpark优化）
- 训练/验证集切分的防过拟合验证机制
- 大盘反证检查（含抽样 scale_factor 换算）与误伤检测
- 贪心集合覆盖的最终规则集选择

目录结构：
- predicates/      原子条件(Predicate)定义、生成与标准化
- feature_snapshot/ 账号特征快照构建（事件表 -> 大宽表）
- rule_mining/      规则挖掘算法（分层组合搜索）
- rule_validation/  规则验证（防过拟合、大盘反证、误伤检测）
- rule_selection/   最终规则集选择（贪心集合覆盖）
- config/           配置文件
"""
