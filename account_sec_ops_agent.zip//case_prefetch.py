"""case 数据预热：提纯捞全完成后，把详情页要读的数据提前落到 Supabase 缓存，
并预触发 AI Agent 判定——用户打开 case 时零 Hive 等待。

触发方：
  - pipeline_scheduler：提纯捞全 SUCCESS（主入口，warm_case 全流程）
  - canvas_scheduler：画布同步完成后（复用 SVG/ts_daily 批量预取 + Agent 预触发）

步骤（每步独立容错，失败只记日志）：
  ① sync_case_results      主切片落 PG（内部解析真实 experiment）
  ② SVG 批量预取            一条 Hive SQL 拉全 case SVG，按读端 cache_key 拆分落缓存
  ③ ts_daily 批量预取       一条 Hive SQL 拉全 combo 逐日三线，拆 per-combo 键
  ④ Agent 判定预触发        _rule_agent_run（flow_store 幂等）

并发控制：模块级 worker 池（默认 2），批量团伙完成时预热任务排队串行消化，
避免瞬时几十个 case 同时回源 Hive 打挂 Talos。
"""
from __future__ import annotations

import concurrent.futures as cf

from logger import sys_log

_pool = cf.ThreadPoolExecutor(max_workers=12, thread_name_prefix="case-warm")


def warm_case(case_id: str, experiment: str, dt: str):
    """提交全流程预热（非阻塞）。返回 Future（仅用于测试/观察，不等待）。"""
    return _pool.submit(_warm_case, case_id, experiment, dt)


def _warm_case(case_id: str, experiment: str, dt: str):
    sys_log("info", f"[CaseWarm] start case={case_id} dt={dt}")
    real_exp = experiment
    try:
        import result_cache
        r = result_cache.sync_case_results(case_id, experiment, dt)
        real_exp = r.get("experiment") or experiment
    except Exception as e:
        sys_log("warning", f"[CaseWarm] sync fail case={case_id}: {str(e)[:150]}")
    for step in (_prefetch_svgs_bulk, _prefetch_ts_daily_bulk, _prefetch_agent):
        try:
            step(case_id, real_exp, dt)
        except Exception as e:
            sys_log("warning", f"[CaseWarm] {step.__name__} fail case={case_id}: {str(e)[:150]}")
    # 自动分配（2026-09-20 用户定）：捞全完成跟随流水线自动分给配置的人（按权重），
    # 已分配不覆盖（人工分配优先）。dt 用 flow 的（处理日——与 CASE总览按天分栏一致），
    # 而非本函数入参 dt（pipeline 的团伙发现日——分配日期口径会串天）
    try:
        import flow_store as _fs
        _f = _fs.get_by_case_id(case_id)
        _adt = (_f or {}).get("dt") or dt
        _mis = _fs.auto_assign(case_id, _adt)
        if _mis:
            sys_log("info", f"[CaseWarm] 自动分配 case={case_id} → {_mis}")
    except Exception as e:
        sys_log("warning", f"[CaseWarm] auto assign fail case={case_id}: {str(e)[:120]}")
    sys_log("info", f"[CaseWarm] done case={case_id} dt={dt}")


# ── ② SVG 批量预取 ────────────────────────────────────────────────────────

def _prefetch_svgs_bulk(case_id: str, experiment: str, dt: str):
    """一条 SQL 拉全 case 的 SVG（combo_id, chart_type, svg_content, chart_label），
    逐 (combo|chart_type) 落 chart_svg 缓存键——与 /charts/svg 读端键格式一致。
    已缓存的键跳过（幂等）。"""
    import result_cache
    import sql_templates as Q
    from config import get_config
    from client.talos_client import TalosClient

    cfg = get_config()
    res = result_cache._run_hive(TalosClient(), Q.charts_svg_bulk_sql(cfg, case_id, experiment, dt))
    if res["status"] != "done" or not res.get("rows"):
        sys_log("info", f"[CaseWarm] no svg rows case={case_id} status={res['status']}")
        return
    cols = res["columns"]
    iC, iT, iS, iL = cols.index("combo_id"), cols.index("chart_type"), \
        cols.index("svg_content"), cols.index("chart_label")
    synced = 0
    for row in res["rows"]:
        key = result_cache.make_key("chart_svg", case_id, experiment, dt,
                                    f"{row[iC]}|{row[iT]}")
        if result_cache.get(key):
            continue
        try:
            result_cache.upsert(key, "chart_svg", case_id, experiment, dt,
                                ["svg_content", "chart_label"], [[row[iS], row[iL]]])
            synced += 1
        except Exception:
            pass
    sys_log("info", f"[CaseWarm] svg bulk done case={case_id} synced={synced}/{len(res['rows'])}")


# ── ③ ts_daily 批量预取 ───────────────────────────────────────────────────

def _prefetch_ts_daily_bulk(case_id: str, experiment: str, dt: str):
    """一条 SQL 拉全 combo 逐日三线（combo_id 省略 = 全 case），按 combo_id 分组
    落 per-combo ts_daily 缓存键——与 /ts_daily?combo_id=xx 读端键格式一致。"""
    import result_cache
    import sql_templates as Q
    from config import get_config
    from client.talos_client import TalosClient

    cfg = get_config()
    res = result_cache._run_hive(TalosClient(), Q.ts_daily_sql(cfg, case_id, None, experiment, dt))
    if res["status"] != "done" or not res.get("rows"):
        sys_log("info", f"[CaseWarm] no ts_daily rows case={case_id} status={res['status']}")
        return
    cols = res["columns"]
    iC = cols.index("combo_id")
    by_combo: dict[str, list] = {}
    for row in res["rows"]:
        by_combo.setdefault(str(row[iC]), []).append(row)
    synced = 0
    for cid, rows in by_combo.items():
        key = result_cache.make_key("ts_daily", case_id, experiment, dt, f"combo={cid}")
        if result_cache.get(key):
            continue
        try:
            result_cache.upsert(key, "ts_daily", case_id, experiment, dt, cols, rows)
            synced += 1
        except Exception:
            pass
    sys_log("info", f"[CaseWarm] ts_daily bulk done case={case_id} synced={synced}/{len(by_combo)}")


# ── ④ Agent 判定预触发 ────────────────────────────────────────────────────

def _prefetch_agent(case_id: str, experiment: str, dt: str):
    """预触发 Agent 判定（_rule_agent_run 内联调用，不走 HTTP），结果落 flow_store。
    flow_store 已有 rule_agent 结果则跳过（幂等）。"""
    import flow_store
    flow = flow_store.get_by_case_id(case_id)
    if flow and (flow.get("extra") or {}).get("rule_agent"):
        sys_log("info", f"[CaseWarm] Agent already judged case={case_id}, skip")
        return
    from api.routes import _rule_agent_run
    result = _rule_agent_run(case_id, experiment, dt)
    sys_log("info", f"[CaseWarm] Agent prefetch done case={case_id} "
                    f"high={result.get('high', 0)} low={result.get('low', 0)} "
                    f"fail={result.get('fail', 0)}")


# ── canvas_scheduler 复用入口（画布路径已自行 sync，只做 ②③④）────────────

def submit_after_sync(case_id: str, experiment: str, dt: str):
    """画布同步完成后提交预热（非阻塞，进同一 worker 池限并发）。"""
    return _pool.submit(prefetch_after_sync, case_id, experiment, dt)


def prefetch_after_sync(case_id: str, experiment: str, dt: str):
    """画布同步完成后执行：批量 SVG + ts_daily + Agent。"""
    for step in (_prefetch_svgs_bulk, _prefetch_ts_daily_bulk, _prefetch_agent):
        try:
            step(case_id, experiment, dt)
        except Exception as e:
            sys_log("warning", f"[CaseWarm] {step.__name__} fail case={case_id}: {str(e)[:150]}")
