"""
极简日志：sys_log 输出到 stdout + logs/app.log（按天滚动）。
无 Supabase sink，纯本地。
"""
from __future__ import annotations

import logging
import os
from logging.handlers import TimedRotatingFileHandler

_LOG_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "logs")
os.makedirs(_LOG_DIR, exist_ok=True)

_logger = logging.getLogger("account_agent")
_logger.setLevel(logging.INFO)
_logger.propagate = False

_fmt = logging.Formatter("%(asctime)s [%(levelname)s] %(message)s", "%Y-%m-%d %H:%M:%S")

_stream = logging.StreamHandler()
_stream.setFormatter(_fmt)
_logger.addHandler(_stream)

_file = TimedRotatingFileHandler(
    os.path.join(_LOG_DIR, "app.log"), when="midnight", backupCount=14, encoding="utf-8"
)
_file.setFormatter(_fmt)
_logger.addHandler(_file)


def sys_log(level: str, msg: str) -> None:
    getattr(_logger, level.lower(), _logger.info)(msg)
