"""
account_agent_dev 路由。
无鉴权（后续补）。Hive 查询走 TalosClient，画布触发走 CICanvasClient，图片走 SSO token 代理。
提纯/回捞数据走 5 张 Hive 表（sql_templates.py），按 case_id/experiment/dt 三分区查询。
"""
from __future__ import annotations

import json
import re
import time
from datetime import datetime, timedelta
from typing import Optional

import httpx
from fastapi import APIRouter, HTTPException, Request
from fastapi.responses import FileResponse, RedirectResponse, Response
from pydantic import BaseModel

from client.talos_client import TalosClient
from logger import sys_log
import result_cache
import sql_templates as Q

router = APIRouter()


def _cfg():
    from config import get_config
    return get_config()


def _talos() -> TalosClient:
    return TalosClient()


def _exp_dt(experiment: Optional[str], dt: Optional[str],
            case_id: Optional[str] = None) -> tuple[str, str]:
    """experiment 缺省取 config.default_experiment；dt 缺省取该 case 最新分区
    （查不到退到今天——挖掘 --dt=当天 落当天分区，默认昨天会查不到当天跑的 case）。
    latest_dt 走缓存（sync_case_results 完成时已主动刷新该缓存，无陈旧竞态）——
    详情页 8 个端点不再各自 force_refresh 直查 Hive（每个 7-8s）。"""
    exp = experiment or _cfg().default_experiment
    if not dt:
        if case_id:
            latest = _latest_dt_value(case_id)
            if latest:
                return exp, latest
        dt = datetime.now().strftime("%Y%m%d")
    return exp, dt


# ── 首页 ──────────────────────────────────────────────────────────────────

@router.get("/")
def index(request: Request):
    if not request.session.get("mis"):
        from urllib.parse import quote
        return RedirectResponse(f"/login?next=/")
    import os
    path = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
                        "static", "index.html")
    return FileResponse(path)


@router.get("/monitor/alive")
def monitor_alive():
    """美团监控/Octo 健康探测端点，返回 200。"""
    return {"status": "alive"}


# ── 图片代理（反爬同款：SSO token 拉链接 → 307 到 S3 预签名 URL → 取字节流）─────

@router.get("/api/image")
def proxy_image(url: str, request: Request):
    """代理加载需要 SSO token 认证的内网图片。"""
    from client.sso_auth import get_sso_manager
    mis = _cfg().sso.mis
    try:
        sso = get_sso_manager()
        token = sso.get_mtsi_token(mis)
        # follow_redirects=True：mtsi 验证 token 后会 307 到 S3 预签名 URL，需要跟随
        resp = httpx.get(url, headers={"access-token": token}, timeout=15.0, follow_redirects=True)

        content_type = resp.headers.get("content-type", "")
        if "text/html" in content_type:  # 落到 SSO 登录页说明 token 失效，刷新后重试一次
            sso.invalidate(mis)
            token = sso.get_mtsi_token(mis)
            resp = httpx.get(url, headers={"access-token": token}, timeout=15.0, follow_redirects=True)

        resp.raise_for_status()
        content_type = resp.headers.get("content-type", "image/jpeg")
        if "text/html" in content_type:
            raise HTTPException(502, "图片加载失败：mtsi 返回 HTML（token 可能已过期）")
        return Response(content=resp.content, media_type=content_type)
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(502, f"图片加载失败: {e}")


# ── Hive 读写 ─────────────────────────────────────────────────────────────

def _run_hive_sync(sql: str, max_wait_s: int = 60, interval_s: float = 2.0) -> dict:
    """提交 SQL 并轮询到 done/failed，或超时返回 pending + qid。talos 异常返回 failed 不抛。"""
    tc = _talos()
    try:
        qid = tc.submit_query(sql)
    except Exception as e:
        return {"qid": "", "status": "failed", "error": str(e)[:300], "columns": [], "rows": []}
    deadline = time.time() + max_wait_s
    while time.time() < deadline:
        try:
            result = tc.get_query_status(qid)
        except Exception as e:
            return {"qid": qid, "status": "failed", "error": str(e)[:300], "columns": [], "rows": []}
        if result["status"] != "pending":
            return {"qid": qid, **result}
        time.sleep(interval_s)
    return {"qid": qid, "status": "pending", "columns": [], "rows": [], "error": None}


# 各表缓存必须包含的关键列（SQL 模板加列后旧缓存视为陈旧，强制回源重填）。
# 2026-09-12：validation_result 在 463ef5c 加入 recalled_count/black_pool_detail（回捞精确口径），
# 旧进程写入的缓存缺这两列，命中会导致前端永久展示旧口径。
# 2026-09-12 晚：L1-6/L1-7 五列（geo_mismatch_*/loc_off_*）同样纳入——SQL 模板加列后旧缓存强制回源。
_REQUIRED_COLS = {
    "validation_result": {"recalled_count", "black_pool_detail",
                           "geo_mismatch_rate", "loc_strong_off_rate"},
}


def _cache_stale(table_key: str, hit: dict) -> bool:
    req = _REQUIRED_COLS.get(table_key)
    return bool(req) and not req.issubset(hit.get("columns") or [])


# 空结果负缓存（2026-09-14）：画布执行中的 case 各业务表无分区 → 查询返回空 →
# 原逻辑空结果不落 PG 缓存 → 详情页每次打开都全量回源 Hive（每接口 5-8s，页面 30s+）。
# 空结论进程内缓存 60s；画布落表后 sync_case_results 会 upsert 真值（负缓存自动失效——
# 查到非空即清除）。
_EMPTY_RES_CACHE: dict = {}   # cache_key → (过期时间戳, 空结果payload)
_EMPTY_TTL = 600.0   # 10 分钟：画布落表后增量同步（3min/轮）会落真值覆盖


def _cached(cache_key, table_key, case_id, experiment, dt, sql_fn):
    """PG 缓存优先，miss 回退 Hive 并回填。返回 {qid,status,columns,rows}。
    实验名双轨兼容：挖掘侧新表用 no_mark、画布/前端用 default——exp 键 miss 时
    依次尝试另一实验名（同 case 同 dt 的数据本体一致，键名双轨只是历史命名）。
    缓存命中但缺关键列（SQL 模板版本变更前的旧写入）同样视为 miss 回源。"""
    hit = result_cache.get(cache_key)
    if hit and not _cache_stale(table_key, hit):
        _EMPTY_RES_CACHE.pop(cache_key, None)
        return {"qid": "", "status": "done", "columns": hit["columns"], "rows": hit["rows"], "cached": True}
    # PG miss/失败 → 进程内兜底层（PG 502 期间写入的结果）
    mem = _MEM_CACHE.get(cache_key)
    if mem:
        if time.time() < mem[0]:
            _EMPTY_RES_CACHE.pop(cache_key, None)
            return {"qid": "", "status": "done", **mem[1], "cached": True}
        _MEM_CACHE.pop(cache_key, None)
    # 空结果负缓存命中（60s 内的"无数据"结论直接返回，不回源 Hive）
    neg = _EMPTY_RES_CACHE.get(cache_key)
    if neg:
        if time.time() < neg[0]:
            return neg[1]
        _EMPTY_RES_CACHE.pop(cache_key, None)
    # exp 键 miss → 尝试另一实验名（no_mark/default 双轨）
    if experiment:
        alt = "no_mark" if experiment == "default" else "default"
        hit = result_cache.get(result_cache.make_key(table_key, case_id, alt, dt))
        if hit and not _cache_stale(table_key, hit):
            _EMPTY_RES_CACHE.pop(cache_key, None)
            return {"qid": "", "status": "done", "columns": hit["columns"], "rows": hit["rows"], "cached": True}
    res = _run_hive_sync(sql_fn())
    if res["status"] == "done" and res.get("rows"):
        _try_upsert(cache_key, table_key, case_id, experiment, dt, res["columns"], res["rows"])
        _EMPTY_RES_CACHE.pop(cache_key, None)
    elif res["status"] == "done":
        # 空结果：负缓存 60s（画布执行中 case 重复打开详情页不再全量回源）
        _EMPTY_RES_CACHE[cache_key] = (time.time() + _EMPTY_TTL, res)
    return res


def _try_upsert(cache_key, table_key, case_id, experiment, dt, columns, rows):
    """缓存写入容错：PG 失败（网关 502/SSL 抖动）→ 进程内缓存兜底 5 分钟。
    否则查询结果只在当次响应存活——下次请求又回源 Hive（case_snapshot 12s/次实锤）。"""
    try:
        result_cache.upsert(cache_key, table_key, case_id, experiment, dt, columns, rows)
    except Exception as e:
        sys_log("warning", f"[routes] cache upsert fail key={cache_key} err={str(e)[:120]}")
        _MEM_CACHE[cache_key] = (time.time() + 300, {"columns": columns, "rows": rows})


# 进程内结果缓存（PG 不可用时的兜底层）：key → (过期, {columns, rows})
_MEM_CACHE: dict = {}


@router.get("/api/hive/query")
def hive_query(sql: str):
    """执行 SELECT，返回 {qid, status, columns, rows}。长查询超时返回 pending+qid。"""
    head = sql.strip().lower()
    if not head.startswith("select"):
        raise HTTPException(
            400,
            "query 接口仅允许 SELECT；SHOW/DESC 等元数据查询已下线，"
            "请用元数据服务 https://km.sankuai.com/collabpage/28314498",
        )
    return _run_hive_sync(sql)


class HiveExecuteRequest(BaseModel):
    sql: str
    max_wait_s: int = 120


@router.post("/api/hive/execute")
def hive_execute(body: HiveExecuteRequest):
    """执行 INSERT/DDL，返回 {qid, status, ...}。done 表示已落库。"""
    return _run_hive_sync(body.sql, max_wait_s=body.max_wait_s)


# ── 案件列表 ─────────────────────────────────────────────────────────────

def _filter_deleted(res: dict) -> dict:
    """从查询结果中过滤掉已删除（拉黑）的 case_id 行。"""
    import canvas_job_store as store
    deleted = store.list_deleted_cases()
    if not deleted or res.get("status") != "done" or not res.get("rows"):
        return res
    cols = res.get("columns") or []
    if "case_id" not in cols:
        return res
    iC = cols.index("case_id")
    res["rows"] = [r for r in res["rows"] if str(r[iC]) not in deleted]
    return res


@router.get("/api/cases")
def list_cases(dt: Optional[str] = None):
    """列 case（distinct case_id，带缓存，过滤已删除）。dt 给了按 dt 过滤，留空查所有 case。"""
    cache_key = result_cache.make_key("cases", "_ALL_", None, dt or "_ALL_")
    hit = result_cache.get(cache_key)
    if hit:
        return _filter_deleted({"qid": "", "status": "done", "columns": hit["columns"], "rows": hit["rows"], "cached": True})
    res = _run_hive_sync(Q.cases_sql(_cfg(), dt or ""))
    if res["status"] == "done" and res.get("rows"):
        _try_upsert(cache_key, "cases", "_ALL_", None, dt or "_ALL_", res["columns"], res["rows"])
    return _filter_deleted(res)


def _merge_flowing_cases(res: dict, dt: str = "") -> dict:
    """把全流程中尚未落 Hive 的 case 合并进 overview 结果（启动即上列表）。
    Hive 已有的 case_id 优先（数据全）；flow 独有的行由 flow 数据生成。
    dt 非空时只合并该 dt 的 flow（按日期筛选时不混入其他日期的进行中 case）。"""
    import flow_store
    if res.get("status") != "done":
        return res
    cols = res.get("columns") or []
    if "case_id" not in cols:
        return res
    iC = cols.index("case_id")
    hive_ids = {str(r[iC]) for r in (res.get("rows") or [])}
    try:
        flows = flow_store.list_flows(300)
    except Exception:
        flows = []
    add_rows = []
    for f in flows:
        cid = str(f.get("case_id") or "")
        if not cid or cid in hive_ids:
            continue
        if dt and str(f.get("dt") or "") != dt:
            continue
        # 生成与 case_list_sql 列结构一致的行
        row_map = {c: None for c in cols}
        row_map["case_id"] = cid
        row_map["case_name"] = f.get("case_name")
        row_map["latest_dt"] = f.get("dt")
        row_map["sample_count"] = None
        row_map["experiments"] = None
        add_rows.append([row_map.get(c) for c in cols])
    if add_rows:
        res["rows"] = (res.get("rows") or []) + add_rows
    return res


@router.get("/api/case_overview")
def case_overview(dt: Optional[str] = None, with_dts: bool = False):
    """所有 case 概述（带缓存，过滤已删除，合并进行中的 flow case——启动即上列表）。
    dt 给了按该日期分区筛选（页面按日期查看）。
    with_dts=true 附带 dt 分布列表（总览按天选项卡用；缓存 5 分钟防每刷必查）。"""
    dts = None
    if with_dts:
        # PG 聚合（2026-09-20 优化）：flow_jobs 按 dt 计数（373ms）替代 Hive
        # case_info GROUP BY（18.8s——总览页慢的主因）。flow 表就是总览展示的
        # 数据源，计数口径天然一致（case 数 = 当日 flow 数）。
        try:
            import flow_store as _fsb
            _rows = _fsb._sb().execute(
                "SELECT dt, count(*) AS n FROM flow_jobs WHERE dt IS NOT NULL "
                "GROUP BY dt ORDER BY dt DESC LIMIT 30")
            dts = [{"dt": r["dt"], "count": int(r["n"])} for r in _rows if r.get("dt")]
        except Exception:
            dts = []
    def _wrap(payload):
        if dts is not None:
            payload["dts"] = dts
        return payload
    cache_key = result_cache.make_key("case_overview", "_ALL_", None, dt or "_ALL_")
    hit = result_cache.get(cache_key)
    if hit:
        return _wrap(_merge_flowing_cases(_filter_deleted(
            {"qid": "", "status": "done", "columns": hit["columns"], "rows": hit["rows"], "cached": True}), dt or ""))
    res = _run_hive_sync(Q.case_list_sql(_cfg(), dt or ""), max_wait_s=30)
    if not (res["status"] == "done" and res["rows"]):
        # dt 模式的兜底：当天 Hive 分区未就绪（case_list_sql 返回空）时不能把
        # 全量 fallback 结果落进 dt 缓存键（2026-09-13 实锤：dt 键存了全量 1275 行，
        # 页面渲染 10×数据量）。dt 模式下空结果直接返回空，不 fallback 不缓存。
        if dt:
            return _wrap(_merge_flowing_cases(
                {"qid": "", "status": "done", "columns": ["case_id"], "rows": []}, dt))
        res = _run_hive_sync(Q.case_overview_sql(_cfg()))
    if res["status"] == "done" and res.get("rows"):
        _try_upsert(cache_key, "case_overview", "_ALL_", None, dt or "_ALL_", res["columns"], res["rows"])
    return _wrap(_merge_flowing_cases(_filter_deleted(res), dt or ""))


@router.post("/api/cases/{case_id}/delete")
def delete_case(case_id: str):
    """删除 case：拉黑（列表不再展示）+ 级联清理 Supabase 侧数据（缓存/画布job/全流程/预处理任务）。
    Hive 源数据不动；运行中的画布任务不再被跟踪（mtsi 侧仍在跑）。"""
    import canvas_job_store as store
    try:
        counts = store.delete_case_data(case_id)
    except Exception as e:
        raise HTTPException(500, f"删除失败: {e}")
    return {"case_id": case_id, "deleted": True, "counts": counts}


class BatchDeleteRequest(BaseModel):
    case_ids: list


@router.post("/api/cases/batch_delete")
def batch_delete_cases(body: BatchDeleteRequest):
    """批量删除 case（拉黑 + 级联清理）。返回每个 case 的结果。"""
    import canvas_job_store as store
    results = []
    for cid in body.case_ids:
        try:
            counts = store.delete_case_data(str(cid))
            results.append({"case_id": str(cid), "deleted": True, "counts": counts})
        except Exception as e:
            results.append({"case_id": str(cid), "deleted": False, "error": str(e)[:100]})
    ok = sum(1 for r in results if r.get("deleted"))
    sys_log("info", f"[delete] batch {len(body.case_ids)} 个，成功 {ok}")
    return {"deleted": ok, "total": len(body.case_ids), "results": results}


# ── case_info/seed_split/snapshot_info 表未写入时的 mock 兜底 ─────────────
# 用 13081001 的 pyspark 日志真实值（表里没落，日志有）。prod 写表后自动用真实，mock 不触发。
_MOCK_CASE_INFO = {
    "case_name": "new_nanyang_m5w3", "sample_count": 2000, "feature_col_count": 617,
    "window_days": 7, "core_seed_count": 1973, "train_count": 1599,
    "validation_count": 374, "excluded_count": 11, "baseline_count": 286196,
    "baseline_scale_factor": 2000.0, "market_total": 572392000,
    "temporal_window_days": 180, "seed_mode": "sample_as_seed",
    "experiments": "default", "run_experiments": False,
    "hard_negative_count": 273927, "whitelist_count": 273927,
}
_MOCK_SEED_SPLIT = {
    "seed_mode": "sample_as_seed", "core_seed_count": 1973, "excluded_count": 11,
    "weak_seed_count": 0, "train_count": 1599, "validation_count": 374,
    "train_ratio": 0.8, "baseline_count": 286196, "baseline_scale_factor": 2000.0,
    "hard_negative_count": 273927, "whitelist_count": 273927,
}
_MOCK_SNAPSHOT = [
    ["strong_end_login", "ba_rc.app_stra_account_strong_end_login_feature_info", "sel_", "event_detail", "user_id", 103, 34, True],
    ["strong_end_signup", "ba_rc.app_stra_account_strong_end_signup_feature_info", "ses_", "event_detail", "user_id", 93, 33, True],
    ["weak_end_login", "ba_rc.app_stra_account_week_end_login_feature_info", "wel_", "event_detail", "user_id", 142, 31, True],
    ["weak_end_signup", "ba_rc.app_stra_account_week_end_signup_feature_info", "wes_", "event_detail", "user_id", 118, 28, True],
    ["user_active", "mart_mtsi.topic_user_active_ss_d", "act_", "snapshot", "mt_user_id", 145, 0, False],
]


def _mock_case_info(case_id: str, dt: str) -> dict:
    cols = ["case_id","case_name","sample_count","feature_col_count","snapshot_dt","window_days",
            "core_seed_count","train_count","validation_count","excluded_count","baseline_count",
            "baseline_scale_factor","market_total","temporal_window_days","seed_mode","experiments",
            "run_experiments","hard_negative_count","whitelist_count","create_time"]
    m = _MOCK_CASE_INFO
    row = [case_id, m["case_name"], m["sample_count"], m["feature_col_count"], dt, m["window_days"],
           m["core_seed_count"], m["train_count"], m["validation_count"], m["excluded_count"],
           m["baseline_count"], m["baseline_scale_factor"], m["market_total"], m["temporal_window_days"],
           m["seed_mode"], m["experiments"], m["run_experiments"], m["hard_negative_count"],
           m["whitelist_count"], dt]
    return {"qid": "", "status": "done", "columns": cols, "rows": [row], "total": 1, "mock": True}


def _mock_seed_split() -> dict:
    cols = ["seed_mode","core_seed_count","excluded_count","weak_seed_count","train_count",
            "validation_count","train_ratio","baseline_count","baseline_scale_factor",
            "hard_negative_count","whitelist_count"]
    m = _MOCK_SEED_SPLIT
    row = [m["seed_mode"], m["core_seed_count"], m["excluded_count"], m["weak_seed_count"],
           m["train_count"], m["validation_count"], m["train_ratio"], m["baseline_count"],
           m["baseline_scale_factor"], m["hard_negative_count"], m["whitelist_count"]]
    return {"qid": "", "status": "done", "columns": cols, "rows": [row], "total": 1, "mock": True}


def _mock_snapshot_info() -> dict:
    cols = ["source_name","source_table","prefix","table_type","id_field",
            "agg_field_count","cntd_field_count","has_json_map"]
    return {"qid": "", "status": "done", "columns": cols, "rows": _MOCK_SNAPSHOT, "total": 5, "mock": True}


@router.get("/api/cases/{case_id}/info")
def case_info(case_id: str, dt: Optional[str] = None):
    """表6：case 基础信息。表未写入时返回 mock（13081001 日志值）。"""
    if not dt:
        dt = _latest_dt_value(case_id) or ""
    if dt:
        cache_key = result_cache.make_key("case_info", case_id, None, dt)
        res = _cached(cache_key, "case_info", case_id, None, dt,
                      lambda: Q.case_info_sql(_cfg(), case_id, dt))
        if res["status"] == "done" and res["rows"]:
            return res
    return _mock_case_info(case_id, dt or "20260810")


@router.get("/api/cases/{case_id}/seed_split")
def seed_split(case_id: str, dt: Optional[str] = None):
    """表8：种子分类 + 训练/验证切分。表未写入时返回 mock。"""
    if not dt:
        dt = _latest_dt_value(case_id) or ""
    if dt:
        cache_key = result_cache.make_key("seed_split", case_id, None, dt)
        res = _cached(cache_key, "seed_split", case_id, None, dt,
                      lambda: Q.seed_split_sql(_cfg(), case_id, dt))
        if res["status"] == "done" and res["rows"]:
            return res
    return _mock_seed_split()


@router.get("/api/cases/{case_id}/snapshot_info")
def snapshot_info(case_id: str, dt: Optional[str] = None):
    """表7：快照源表信息（5 行）。表未写入时返回 mock。"""
    if not dt:
        dt = _latest_dt_value(case_id) or ""
    if dt:
        cache_key = result_cache.make_key("snapshot_info", case_id, None, dt)
        res = _cached(cache_key, "snapshot_info", case_id, None, dt,
                      lambda: Q.snapshot_info_sql(_cfg(), case_id, dt))
        if res["status"] == "done" and res["rows"]:
            return res
    return _mock_snapshot_info()


@router.get("/api/cases/{case_id}/case_snapshot")
def case_snapshot(case_id: str, dt: Optional[str] = None, limit: int = 200):
    """case 实际快照数据（ba_rc.app_acc_sec_case_snapshot，SELECT * 自适应列）。
    dt 兜底顺序：传入 > flow 的 dt（预处理阶段就有，捞全未完成时用）> validation_result latest_dt。"""
    if not dt:
        try:
            import flow_store
            f = flow_store.get_by_case_id(case_id)
            if f and f.get("dt"):
                dt = f["dt"]
        except Exception:
            pass
    if not dt:
        dt = _latest_dt_value(case_id) or ""
    if not dt:
        return {"qid": "", "status": "done", "columns": [], "rows": [], "total": 0}
    # 快照不进 PG 缓存（2026-09-20 用户定）：200 行 × 400+ 列 ≈ 9MB，远超
    # Supabase 网关 1MB 请求体限制（写入必 500——历史全部 "Request body is
    # too large" 错误的根源）。前端快照区块异步加载，慢点可接受。
    res = _run_hive_sync(Q.case_snapshot_sql(_cfg(), case_id, dt, limit), max_wait_s=120)
    if res["status"] != "done":
        return {"qid": res.get("qid", ""), "status": res["status"],
                "error": (res.get("error") or "")[:200], "columns": [], "rows": [], "total": 0}
    return res


def _norm_dt(v) -> Optional[str]:
    """dt 规范化：None/''/'NULL'/'null'（Hive NULL 的字符串形态）→ None。"""
    s = str(v or "").strip()
    return s if s and s.upper() != "NULL" else None


# NULL latest_dt 的进程内负缓存（2026-09-14）：画布执行中的 case Hive 无分区 → latest_dt=NULL，
# 原逻辑不落缓存 → 详情页 N 个接口各重查一次 Hive（6-13s/次，页面打开 30-60s）。
# NULL 结论缓存 90 秒：期间重复请求直接返回 None；画布落表后 sync_case_results 会 upsert
# 真值（负缓存被覆盖）。
_NULL_DT_CACHE: dict = {}   # case_id → 过期时间戳
_NULL_DT_TTL = 90.0


def _latest_dt_value(case_id: str, force_refresh: bool = False) -> Optional[str]:
    """同步取最新 dt（供 info/seed_split/latest_experiment 端点内部用，带缓存）。
    force_refresh=True 时跳过缓存直查 Hive（case 刚跑完新分区时缓存可能陈旧）。"""
    cache_key = result_cache.make_key("latest_dt", case_id, None, "_")
    if not force_refresh:
        hit = result_cache.get(cache_key)
        if hit and hit["rows"]:
            _NULL_DT_CACHE.pop(case_id, None)   # 有真值即清负缓存
            return _norm_dt(hit["rows"][0][0])
        if case_id in _NULL_DT_CACHE:
            if time.time() < _NULL_DT_CACHE[case_id]:
                return None   # 负缓存命中：90s 内不重查 Hive
            _NULL_DT_CACHE.pop(case_id, None)
    res = _run_hive_sync(Q.latest_dt_sql(_cfg(), case_id), max_wait_s=30)
    if res["status"] == "done" and res["rows"]:
        dt_val = _norm_dt(res["rows"][0][0])
        if dt_val:
            _try_upsert(cache_key, "latest_dt", case_id, None, "_", res["columns"], res["rows"])
            _NULL_DT_CACHE.pop(case_id, None)
            return dt_val
    # 查无分区 → 负缓存（90s TTL）
    _NULL_DT_CACHE[case_id] = time.time() + _NULL_DT_TTL
    return None


@router.get("/api/cases/{case_id}/latest_dt")
def latest_dt(case_id: str):
    """查某 case 的最新 dt 分区（前端 loadDetail 首先调这个取 dt）。
    走缓存（sync_case_results 完成时已刷新，无陈旧竞态）。"""
    return {"dt": _latest_dt_value(case_id) or ""}


@router.get("/api/cases/{case_id}/latest_experiment")
def latest_experiment(case_id: str):
    """查某 case 实际使用的 experiment（带缓存）。优先 case_info.experiments（首个），fallback result 最新 dt 的 experiment。"""
    cache_key = result_cache.make_key("latest_experiment", case_id, None, "_")
    hit = result_cache.get(cache_key)
    if hit and hit["rows"]:
        r = hit["rows"][0]
        return {"experiment": r[0], "experiments": r[1], "cached": True}
    dt = _latest_dt_value(case_id)
    # 1. 优先 case_info.experiments
    if dt:
        info = _run_hive_sync(Q.experiments_sql(_cfg(), case_id, dt), max_wait_s=30)
        if info["status"] == "done" and info["rows"]:
            exps = str(info["rows"][0][0] or "")
            first = (exps.split(",")[0].strip() if exps else "")
            if first:
                _try_upsert(cache_key, "latest_experiment", case_id, None, "_",
                            ["experiment", "experiments"], [[first, exps]])
                return {"experiment": first, "experiments": exps}
    # 2. fallback：result 最新 dt 的 experiment
    sql = Q.latest_experiment_sql(_cfg(), case_id)
    res = _run_hive_sync(sql, max_wait_s=30)
    exp_val = ""
    if res["status"] == "done" and res["rows"]:
        exp_val = str(res["rows"][0][0] or "")
    if exp_val:
        _try_upsert(cache_key, "latest_experiment", case_id, None, "_",
                    ["experiment", "experiments"], [[exp_val, exp_val]])
    return {"experiment": exp_val, "experiments": exp_val}


# ── 提纯：规则验证结果（表1）──────────────────────────────────────────────

@router.get("/api/cases/{case_id}/validation/result")
def validation_result(case_id: str, experiment: Optional[str] = None, dt: Optional[str] = None):
    """规则验证结果主表，按 rule_rank 排序。
    维度6 列自动降级（2026-09-13）：hive 老表由挖掘侧部署时 _ensure_table_columns 加列——
    部署前裸引用会 Sinux 报"字段不存在"打挂整个查询（页面全量"无规则"，26091300252 实锤）。
    先试实列版，报缺列则回退 NULL 占位版（页面维度6 显示 —）。"""
    exp, dt = _exp_dt(experiment, dt, case_id)
    cache_key = result_cache.make_key("validation_result", case_id, exp, dt)
    res = _cached(cache_key, "validation_result", case_id, exp, dt,
                  lambda: Q.validation_result_sql(_cfg(), case_id, exp, dt))
    _DIM6_COLS = ("whitelist_rate", "member_rate", "high_value_rate", "member_detail")
    if (res.get("status") == "failed" and res.get("error")
            and "不存在" in res["error"]
            and any(c in res["error"] for c in _DIM6_COLS)):
        res = _cached(cache_key, "validation_result", case_id, exp, dt,
                      lambda: Q.validation_result_sql(_cfg(), case_id, exp, dt, dim6=False))
    return res


@router.get("/api/cases/{case_id}/validation/combo")
def validation_combo_detail(case_id: str, combo_id: str,
                            experiment: Optional[str] = None, dt: Optional[str] = None):
    """单条 combo 的 SQL 片段 / predicates / reasons 明细。"""
    exp, dt = _exp_dt(experiment, dt, case_id)
    cache_key = result_cache.make_key("validation_combo", case_id, exp, dt, f"combo={combo_id}")
    return _cached(cache_key, "validation_combo", case_id, exp, dt,
                   lambda: Q.validation_combo_detail_sql(_cfg(), case_id, exp, dt, combo_id))


@router.get("/api/cases/{case_id}/ts_daily")
def ts_daily(case_id: str, combo_id: Optional[str] = None,
             experiment: Optional[str] = None, dt: Optional[str] = None):
    """时序明细长表：单 combo（或全 case）的天粒度三线（hits/sample_hits/nt_hits）+ t0 标记。
    Step3 combo 详情卡片的迷你曲线数据源（与判定/大图同源 ts_daily 表）。"""
    exp, dt = _exp_dt(experiment, dt, case_id)
    cache_key = result_cache.make_key("ts_daily", case_id, exp, dt, f"combo={combo_id or 'all'}")
    return _cached(cache_key, "ts_daily", case_id, exp, dt,
                   lambda: Q.ts_daily_sql(_cfg(), case_id, combo_id, exp, dt))


# ── 提纯：候选 Predicate（表2）─────────────────────────────────────────────

@router.get("/api/cases/{case_id}/predicates")
def candidate_predicates(case_id: str, experiment: Optional[str] = None,
                         dt: Optional[str] = None, limit: int = 500):
    """候选 Predicate 初筛（默认返回全部，前端排序切换）。"""
    exp, dt = _exp_dt(experiment, dt, case_id)
    cache_key = result_cache.make_key("candidate_predicates", case_id, exp, dt, f"limit={limit}")
    return _cached(cache_key, "candidate_predicates", case_id, exp, dt,
                   lambda: Q.candidate_predicates_sql(_cfg(), case_id, exp, dt, limit))


# ── 提纯：挖掘过程（表3）──────────────────────────────────────────────────

@router.get("/api/cases/{case_id}/mining")
def mining_process(case_id: str, experiment: Optional[str] = None, dt: Optional[str] = None):
    """挖掘过程，按 v_score 降序。"""
    exp, dt = _exp_dt(experiment, dt, case_id)
    cache_key = result_cache.make_key("mining_process", case_id, exp, dt)
    return _cached(cache_key, "mining_process", case_id, exp, dt,
                   lambda: Q.mining_process_sql(_cfg(), case_id, exp, dt))


# ── 提纯：时序图 SVG（表0）─────────────────────────────────────────────────

@router.get("/api/cases/{case_id}/charts")
def charts_list(case_id: str, experiment: Optional[str] = None, dt: Optional[str] = None):
    """列出某 case 的全部时序图（combo_id, chart_type, chart_label）。"""
    exp, dt = _exp_dt(experiment, dt, case_id)
    cache_key = result_cache.make_key("validation_charts", case_id, exp, dt)
    return _cached(cache_key, "validation_charts", case_id, exp, dt,
                   lambda: Q.charts_list_sql(_cfg(), case_id, exp, dt))


@router.get("/api/cases/{case_id}/charts/svg")
def chart_svg(case_id: str, combo_id: str, chart_type: str,
              experiment: Optional[str] = None, dt: Optional[str] = None):
    """取单张 SVG 内容。返回 {svg_content, chart_label}。"""
    exp, dt = _exp_dt(experiment, dt, case_id)
    cache_key = result_cache.make_key("chart_svg", case_id, exp, dt, f"{combo_id}|{chart_type}")
    res = _cached(cache_key, "chart_svg", case_id, exp, dt,
                  lambda: Q.chart_svg_sql(_cfg(), case_id, exp, dt, combo_id, chart_type))
    if res["status"] == "done" and res["rows"]:
        cols = res["columns"]
        row = res["rows"][0]
        svg = row[cols.index("svg_content")] if "svg_content" in cols else row[0]
        label = row[cols.index("chart_label")] if "chart_label" in cols else ""
        return {"svg_content": svg, "chart_label": label}
    return {"svg_content": "", "chart_label": ""}


# ── 回捞：捞全账号（表4）──────────────────────────────────────────────────

@router.get("/api/cases/{case_id}/recall/summary")
def recall_summary(case_id: str, experiment: Optional[str] = None, dt: Optional[str] = None):
    """每条规则捞了多少账号（按 rule_rank 聚合）。"""
    exp, dt = _exp_dt(experiment, dt, case_id)
    cache_key = result_cache.make_key("recall_summary", case_id, exp, dt)
    return _cached(cache_key, "recall_summary", case_id, exp, dt,
                   lambda: Q.recall_summary_sql(_cfg(), case_id, exp, dt))


@router.get("/api/cases/{case_id}/recall/accounts")
def recall_accounts(case_id: str, experiment: Optional[str] = None, dt: Optional[str] = None,
                    rule_rank: Optional[int] = None, limit: int = 100):
    """捞回的账号列表。可按 rule_rank 过滤。"""
    exp, dt = _exp_dt(experiment, dt, case_id)
    cache_key = result_cache.make_key("recall_accounts", case_id, exp, dt, f"rank={rule_rank}|limit={limit}")
    return _cached(cache_key, "recall_accounts", case_id, exp, dt,
                   lambda: Q.recall_accounts_sql(_cfg(), case_id, exp, dt, rule_rank, limit))


@router.get("/api/cases/{case_id}/recall/multi")
def recall_multi_hit(case_id: str, experiment: Optional[str] = None, dt: Optional[str] = None):
    """被多条规则命中的账号（重点核查对象）。"""
    exp, dt = _exp_dt(experiment, dt, case_id)
    cache_key = result_cache.make_key("recall_multi", case_id, exp, dt)
    return _cached(cache_key, "recall_multi", case_id, exp, dt,
                   lambda: Q.recall_multi_hit_sql(_cfg(), case_id, exp, dt))


@router.get("/api/cases/{case_id}/final_rules")
def final_rules(case_id: str, experiment: Optional[str] = None, dt: Optional[str] = None):
    """Step4 最终规则集（acc_sec_gang_final_rules 独立表，含完整指标）。"""
    exp, dt = _exp_dt(experiment, dt, case_id)
    cache_key = result_cache.make_key("final_rules", case_id, exp, dt)
    return _cached(cache_key, "final_rules", case_id, exp, dt,
                   lambda: Q.final_rules_sql(_cfg(), case_id, exp, dt))


# ── mlp 触发（mtsi 画布）─────────────────────────────────────────────────

class AnalyzeRequest(BaseModel):
    global_param: Optional[str] = None


@router.post("/api/cases/{case_id}/analyze")
def trigger_analyze(case_id: str, body: Optional[AnalyzeRequest] = None):
    """建画布 job（pending），调度器下一轮 pick up 提交。返回 job_id。
    异步模式：对标反爬，端点只建 job，不阻塞提交。
    body.global_param：直接传完整参数串（如 dt=20260824 --case_id=x --case_name=y），
    调度器提交时原样透传；留空走 config 模板。"""
    import canvas_job_store as store
    import re
    from datetime import datetime
    experiment = _cfg().default_experiment
    gp = (body.global_param if body and body.global_param else "").strip()
    # 从 global_param 解析 dt（submit_dt 用于 job.submit_dt + unique_key 占位）
    submit_dt = datetime.now().strftime("%Y%m%d")
    if gp:
        m = re.search(r'dt=(\d{8})', gp)
        if m:
            submit_dt = m.group(1)
    placeholder = f"pending_{case_id}_{submit_dt}"
    job = store.create_job(case_id, experiment, submit_dt, placeholder)
    store.update_extra(job["id"], {"global_param": gp})  # 空串也存，调度器按空走模板
    return {"job_id": job["id"], "case_id": case_id, "status": "pending"}


@router.get("/api/cases/{case_id}/analyze/status")
def analyze_status(case_id: str):
    """查某 case 的画布 job 列表（按创建时间降序）。"""
    import canvas_job_store as store
    jobs = store.list_jobs(case_id)
    return {"case_id": case_id, "jobs": jobs}


@router.post("/api/cases/{case_id}/analyze/refresh")
def analyze_refresh(case_id: str, job_id: str):
    """手动查询一次画布状态：调 offlineQueryCanvasStatusForAccount，写回 job.extra 并返回。
    用于前端「查询状态」按钮，即时取画布运行状态 + 完整报文。"""
    import canvas_job_store as store
    from client.ci_canvas_client import CICanvasClient
    job = store.get_job(job_id)
    if not job:
        raise HTTPException(404, "job 不存在")
    unique_key = job.get("unique_key") or ""
    if not unique_key or unique_key.startswith("pending_"):
        raise HTTPException(400, "画布尚未提交，无 unique_key 可查询")
    try:
        res = CICanvasClient().query_status(unique_key)
    except Exception as e:
        raise HTTPException(502, f"查询画布状态失败: {e}")
    status = res["status"]
    store.update_extra(job_id, {
        "canvas_status": status,
        "query_canvas_request": res.get("request"),
        "query_canvas_response": res.get("response"),
    })
    # 失败/成功终态同步推进 job 状态（与调度器 _poll_canvas 一致）
    if status in ("FAILED", "KILLED"):
        store.update_status(job_id, "failed", error_message=f"画布执行 {status}")
    sys_log("info", f"[analyze] 手动查询 case={case_id} job={job_id} status={status}")
    return {
        "job_id": job_id,
        "canvas_status": status,
        "response": res.get("response"),
        "success": status == "SUCCEEDED",
    }


# ── CASE 预处理任务调度（与 laoquan 画布任务完全隔离，独立 store/client/scheduler）──

class PreprocessTaskCreateRequest(BaseModel):
    group_id: str
    dt: Optional[str] = None            # 留空=今日 YYYYMMDD


@router.post("/api/preprocess/task_create")
def preprocess_task_create(body: PreprocessTaskCreateRequest):
    """创建预处理任务：原子取号生成 case_id（dt[2:]+5位序号）→ 建 preprocess 任务（独立表，调度器 pick up）。
    sceneKey 硬编码 accountsec_agent_preprocess，绝不沾 laoquan。
    返回 {code, message, response, case_id, dt, job_id}（1 成功 / 0 失败）。"""
    import preprocess_store as store
    from datetime import datetime
    if not body.group_id:
        return {"code": 0, "message": "FAILURE", "response": "group_id 不能为空"}
    dt = body.dt or datetime.now().strftime("%Y%m%d")
    try:
        case_id = store.allocate_case_id(dt)
    except Exception as e:
        sys_log("error", f"[preprocess] allocate_case_id failed: {str(e)[:200]}")
        return {"code": 0, "message": "FAILURE", "response": f"取号失败: {e}"}
    global_param = f"dt={dt}\ngroup_id={body.group_id}\ncase_id={case_id}"
    try:
        task = store.create_task(case_id, body.group_id, dt, global_param)
    except Exception as e:
        sys_log("error", f"[preprocess] create_task failed: {str(e)[:200]}")
        return {"code": 0, "message": "FAILURE", "response": f"建任务失败: {e}"}
    sys_log("info", f"[preprocess] task_create group_id={body.group_id} dt={dt} case_id={case_id} task={task['id']}")
    return {"code": 1, "message": "SUCCESS", "response": "SUCCESS",
            "case_id": case_id, "dt": dt, "job_id": task["id"]}


@router.get("/api/preprocess/task_status")
def preprocess_task_status(group_id: str):
    """查预处理任务状态（按 group_id 查最新 preprocess 任务）。返回 {status, data, message}。"""
    import preprocess_store as store
    task = store.get_by_group(group_id)
    if not task:
        return {"status": 0, "data": {"code": 1, "error_msg": "无任务"}, "message": "FAILURE"}
    status = task["status"]
    extra = task.get("extra") or {}
    canvas_status = extra.get("canvas_status") or ""
    if status == "done":
        return {"status": 1, "data": {"code": 0, "error_msg": "SUCCESS",
                                     "code_and_status_msg": f"{canvas_status}/done"}, "message": "SUCCESS"}
    if status == "failed":
        return {"status": 0, "data": {"code": 1,
                                      "error_msg": task.get("error_message") or "FAILURE"}, "message": "FAILURE"}
    return {"status": 1, "data": {"code": 0, "error_msg": "RUNNING",
                                  "code_and_status_msg": canvas_status or status}, "message": "RUNNING"}


@router.get("/api/preprocess/tasks")
def preprocess_list_tasks(limit: int = 50):
    """预处理任务列表（独立 preprocess_jobs 表，按创建时间降序）。返回完整任务（含 extra 报文）。"""
    import preprocess_store as store
    return {"tasks": store.list_tasks(limit)}


@router.post("/api/preprocess/refresh")
def preprocess_refresh(job_id: str):
    """手动查询一次预处理画布状态（调 PreprocessClient.query_status），写回 extra 并返回。"""
    import preprocess_store as store
    from client.preprocess_client import PreprocessClient
    task = store.get_task(job_id)
    if not task:
        raise HTTPException(404, "任务不存在")
    unique_key = task.get("unique_key") or ""
    if not unique_key or unique_key.startswith("pending_"):
        raise HTTPException(400, "画布尚未提交，无 unique_key 可查询")
    try:
        res = PreprocessClient().query_status(unique_key)
    except Exception as e:
        raise HTTPException(502, f"查询画布状态失败: {e}")
    status = res["status"]
    store.update_extra(job_id, {
        "canvas_status": status,
        "query_canvas_request": res.get("request"),
        "query_canvas_response": res.get("response"),
    })
    if status in ("FAILED", "KILLED"):
        store.update_status(job_id, "failed", error_message=f"画布执行 {status}")
    sys_log("info", f"[preprocess] 手动查询 task={job_id} status={status}")
    return {"job_id": job_id, "canvas_status": status,
            "response": res.get("response"), "success": status == "SUCCEEDED"}


@router.post("/api/preprocess/retry")
def preprocess_retry(job_id: str):
    """手动重试：failed → pending，调度器重新提交。"""
    import preprocess_store as store
    if not store.reset_to_pending(job_id):
        raise HTTPException(400, "重置失败（仅 failed 可重试）")
    return {"job_id": job_id, "status": "pending"}


# ── 全流程串联（预处理→snapshot→提纯捞全→完成）──────────────────────────────

class FlowStartRequest(BaseModel):
    group_id: str
    dt: Optional[str] = None
    case_name: Optional[str] = None


@router.post("/api/flow/start")
def flow_start(body: FlowStartRequest):
    """启动全流程：发码生成 case_id → 建 flow_job（FlowScheduler 自动串联 4 阶段）。
    返回 flow_id + case_id。"""
    import flow_store as store
    import preprocess_store as pp
    from datetime import datetime
    if not body.group_id:
        raise HTTPException(400, "group_id 必填")
    dt = body.dt or datetime.now().strftime("%Y%m%d")
    try:
        case_id = pp.allocate_case_id(dt)
    except Exception as e:
        raise HTTPException(500, f"取号失败: {e}")
    case_name = body.case_name or f"case_{case_id}"
    flow = store.create_flow(body.group_id, dt, case_id, case_name)
    sys_log("info", f"[flow] start group_id={body.group_id} dt={dt} case_id={case_id} flow={flow['id']}")
    return {"flow_id": flow["id"], "case_id": case_id, "dt": dt, "case_name": case_name, "stage": "preprocess"}


@router.get("/api/flow/list")
def flow_list(limit: int = 20, offset: int = 0, dt: Optional[str] = None,
              stage: Optional[str] = None, q: Optional[str] = None):
    """全流程列表（分页，按创建时间降序）。dt 按天 / stage 阶段（含 laoquan_done 虚拟阶段）/
    q 搜索（case_id 或 group_id 包含匹配）过滤。附加子任务 unique_key（供日志关联展示）。
    2026-09-11 批量化：N+1 查询（每 flow 4 次 Supabase）改为批量 JOIN/IN 查询。"""
    import flow_store as store
    flows = store.list_flows(min(limit, 200), max(offset, 0), dt or "",
                              stage or "", q or "")
    if not flows:
        return {"flows": [], "total": store.count_flows(dt or "", stage or "", q or ""),
                "limit": limit, "offset": offset, "dts": store.list_flow_dts(30)}
    # 批量取所有子任务（替代逐 flow 查 N+1）
    case_ids = [f.get("case_id") or "" for f in flows if f.get("case_id")]
    pp_ids = [f["preprocess_task_id"] for f in flows if f.get("preprocess_task_id")]
    cs_ids = [f["laoquan_job_id"] for f in flows if f.get("laoquan_job_id")]
    # 一次查全部 preprocess tasks
    pp_map = {}
    if pp_ids:
        try:
            import preprocess_store as pp
            rows = pp._sb().execute(
                f"SELECT id, unique_key FROM preprocess_jobs WHERE id IN ({','.join(pp._sb()._escape(i) for i in pp_ids)})")
            pp_map = {str(r["id"]): r.get("unique_key") or "" for r in rows}
        except Exception:
            pass
    # 一次查全部 canvas jobs
    cs_map = {}
    if cs_ids:
        try:
            import canvas_job_store as cs
            rows = cs._sb().execute(
                f"SELECT id, unique_key, status FROM canvas_jobs WHERE id IN ({','.join(cs._sb()._escape(i) for i in cs_ids)})")
            cs_map = {str(r["id"]): r for r in rows}
        except Exception:
            pass
    # 一次查全部 injury_eval jobs（按 case_id IN）
    ie_map = {}  # {case_id: [{combo_id, status, job_id}]}
    if case_ids:
        try:
            import injury_eval_store as ie
            rows = ie._sb().execute(
                f"SELECT combo_id, status, id AS job_id, case_id, created_at FROM injury_eval_jobs "
                f"WHERE case_id IN ({','.join(ie._sb()._escape(c) for c in case_ids)}) "
                f"ORDER BY created_at DESC")
            for r in rows:
                cid = str(r.get("case_id") or "")
                ie_map.setdefault(cid, {})
                ie_map[cid].setdefault(r["combo_id"], {
                    "combo_id": r["combo_id"], "status": r["status"], "job_id": r["job_id"]})
        except Exception:
            pass
    # 一次查全部 punish_check jobs
    pc_map = {}
    if case_ids:
        try:
            import punish_check_store as pc
            rows = pc._sb().execute(
                f"SELECT combo_id, status, id AS job_id, case_id, check_info, unique_key, created_at "
                f"FROM punish_check_jobs "
                f"WHERE case_id IN ({','.join(pc._sb()._escape(c) for c in case_ids)}) "
                f"ORDER BY created_at DESC")
            for r in rows:
                cid = str(r.get("case_id") or "")
                pc_map.setdefault(cid, {})
                pc_map[cid].setdefault(r["combo_id"], {
                    "combo_id": r["combo_id"], "status": r["status"], "job_id": r["job_id"],
                    "check_info": r.get("check_info"), "unique_key": r.get("unique_key") or ""})
        except Exception:
            pass
    # 组装结果（从批量 map 取，不再逐 flow 查）
    for f in flows:
        pp_id = f.get("preprocess_task_id")
        f["preprocess_unique_key"] = pp_map.get(str(pp_id), "") if pp_id else ""
        cs_id = f.get("laoquan_job_id")
        cs_row = cs_map.get(str(cs_id)) if cs_id else None
        f["laoquan_unique_key"] = (cs_row or {}).get("unique_key") or ""
        f["laoquan_job_status"] = (cs_row or {}).get("status") or ""
        cid = f.get("case_id") or ""
        f["injury_jobs"] = list(ie_map.get(cid, {}).values())
        f["punish_jobs"] = list(pc_map.get(cid, {}).values())
    return {"flows": flows, "total": store.count_flows(dt or "", stage or "", q or ""),
            "limit": limit, "offset": offset, "dts": store.list_flow_dts(30)}


@router.get("/api/flow/status")
def flow_status(flow_id: str):
    """查全流程进度（stage/status/子任务 id/错误）。"""
    import flow_store as store
    flow = store.get_flow(flow_id)
    if not flow:
        raise HTTPException(404, "flow 不存在")
    return flow


@router.get("/api/flow/by_case/{case_id}")
def flow_by_case(case_id: str):
    """按 case_id 精确查 flow（详情页基本信息区用——flow/list limit=300 在批量日
    （单日 4500+ flow）根本盖不住新 case，导致上游 dify 入参（团伙定性/处置动作/
    判定原因）整块不展示）。
    附加 pipeline_full_reason：四环节定性的完整判定依据（risks.{env}.reason）+
    团伙判定列表（perception.reason）——详情页"报出原因"完整展示（2026-09-20 用户定：
    原只有汇总串，需完整原因）。"""
    import flow_store as store
    flow = store.get_by_case_id(case_id)
    if not flow:
        return {"flow": None}
    # 从 pipeline job 拼完整原因（flow extra 里没有 risks——那是 pipeline_jobs 的字段）
    try:
        import pipeline_store as _ps
        jrows = _ps._sb().execute(
            "SELECT extra FROM pipeline_jobs WHERE extra->>'tichun_case_id'=$1 ORDER BY created_at DESC LIMIT 1",
            [case_id])
        # 兜底（2026-09-21）：双实例并发时 job.tichun_case_id 被后写的覆盖（85/86 双 case 实锤），
        # 按 case_id 查不到 → 用 flow 的 group_id 反查（同 group 的判定数据一致）
        if not jrows and flow.get("group_id"):
            jrows = _ps._sb().execute(
                "SELECT extra FROM pipeline_jobs WHERE group_id=$1 ORDER BY created_at DESC LIMIT 1",
                [flow["group_id"]])
        jex = (jrows[0].get("extra") or {}) if jrows else {}
        if isinstance(jex, str):
            import json as _j2
            try:
                jex = _j2.loads(jex)
            except Exception:
                jex = {}
        risks = jex.get("risks") or {}
        env_names = {"register": "register", "login": "login", "unfreeze": "unfreeze", "token": "token"}
        parts = []
        # 团伙判定列表（is_group 的 risk_type 清单）
        perc_reason = str((jex.get("perception") or {}).get("reason") or "")
        if perc_reason and perc_reason not in ("None", ""):
            parts.append(f"团伙判定：{perc_reason}")
        # 四环节完整依据
        for env, label in (("register", "注册"), ("login", "登录"),
                           ("unfreeze", "解冻"), ("token", "Token")):
            rr = risks.get(env) or []
            for item in rr:
                if not isinstance(item, dict):
                    continue
                res_v = str(item.get("result") or "")
                rsn = str(item.get("reason") or "")
                if res_v and res_v != "无风险" and rsn:
                    parts.append(f"{label}·{res_v}：{rsn}")
        # 处罚判定
        pen = jex.get("penalty") or {}
        if isinstance(pen, dict) and pen.get("penalty"):
            parts.append(f"处罚判定：{pen.get('penalty')}（{pen.get('reason') or ''}）")
        flow.setdefault("extra", {})
        if isinstance(flow["extra"], str):
            try:
                import json as _j3
                flow["extra"] = _j3.loads(flow["extra"])
            except Exception:
                flow["extra"] = {}
        flow["extra"]["pipeline_full_reason"] = "\n".join(parts)
    except Exception:
        pass
    return {"flow": flow}


class CaseNoteRequest(BaseModel):
    note: str


# ── 任务分配（捞全完成的 case 按环节均衡分配到人）────────────────────────

class AssignRequest(BaseModel):
    mis_list: list                       # 分配人 MIS 列表
    dt: Optional[str] = None             # 按日期筛选（缺省 = 全部）
    scope: Optional[str] = None          # 分配范围：unassigned（仅未分配，默认）/ all（重新分配全部）
    people: Optional[list] = None        # 带权重的人配置 [{mis, weight}]——传了则保存为默认配置


@router.get("/api/assignments/config")
def assignments_config_get():
    """查分配人配置（自动分配与加权分配共用）。"""
    import flow_store as store
    return store.get_assign_config()


@router.put("/api/assignments/config")
def assignments_config_put(body: dict, request: Request):
    """保存分配人配置（[{mis, weight}]）。"""
    people = body.get("people") or []
    if not people or not all(p.get("mis") for p in people):
        raise HTTPException(400, "people 格式错误（需 [{mis, weight}]）")
    import flow_store as store
    store.save_assign_config(people)
    sys_log("info", f"[Assign] 配置已保存 {len(people)} 人 by={request.session.get('mis')}")
    return {"status": 1, "people": people}


@router.get("/api/assignments")
def assignments_get(dt: Optional[str] = None, mis: Optional[str] = None):
    """查当前分配列表（case → mis）。dt 按天 / mis 按人过滤。"""
    import flow_store as store
    items = store.list_assignments(dt or "")
    if mis:
        items = [a for a in items if a.get("mis") == mis]
    return {"assignments": items}


@router.get("/api/assignments/dts")
def assignments_dts():
    """分配页日期选项：已分配的日期 + 捞全完成但未分配的日期（并集，带计数）。"""
    import flow_store as store
    sb = store._sb()
    # 已分配的
    a_dts = {}
    try:
        for r in sb.execute("SELECT dt, count(*) AS n FROM case_assignments GROUP BY dt"):
            if r["dt"]:
                a_dts[r["dt"]] = r["n"]
    except Exception:
        pass
    # 捞全完成未分配的
    try:
        existing = {a["case_id"] for a in store.list_assignments("")}
        rows = sb.execute(
            "SELECT case_id, dt FROM flow_jobs WHERE stage IN ('injury_eval','punish','done') "
            "AND status='running' AND dt IS NOT NULL")
        for r in rows:
            if r["case_id"] not in existing:
                a_dts[r["dt"]] = a_dts.get(r["dt"], 0) + 1
    except Exception:
        pass
    dts = [{"dt": k, "count": v} for k, v in sorted(a_dts.items(), reverse=True)]
    return {"dts": dts}


@router.post("/api/assignments/distribute")
def assignments_distribute(body: AssignRequest, request: Request):
    """捞全完成的 case 均衡分配到人：
    ① 取目标 case（stage ≥ injury_eval 的 flow，即提纯捞全完成）
    ② 按【主风险环节】分类（登录/注册/解冻/Token——处罚 risk_types 或各环节 result 命中关键词）
    ③ 蛇形轮转分配：每个环节的 case 依次发给各人，保证每人分到每个环节（case 数 ≥ 人数×环节数时）
    ④ scope=unassigned 时已有分配的 case 不动；all 重分全部。"""
    if not body.mis_list:
        raise HTTPException(400, "mis_list 不能为空")
    import flow_store as store
    sb = store._sb()
    # 带权重配置 → 保存为默认（自动分配也用它）
    if body.people:
        try:
            store.save_assign_config(body.people)
        except Exception as e:
            sys_log("warning", f"[Assign] save config fail: {str(e)[:100]}")
    # ① 目标 case + 环节
    dt_cond = "AND f.dt=$1" if body.dt else ""
    dt_params = [body.dt] if body.dt else []
    flows = sb.execute(
        f"SELECT f.case_id, f.dt, f.extra->'penalty'->>'risk_types' AS rt, "
        f"f.extra->>'login_result' AS lr, f.extra->>'register_result' AS rr, "
        f"f.extra->>'unfreeze_result' AS ur, f.extra->>'token_result' AS tr "
        f"FROM flow_jobs f WHERE f.stage IN ('injury_eval','punish','done') "
        f"AND f.status='running' {dt_cond}", dt_params)
    # scope 过滤
    existing = {a["case_id"] for a in store.list_assignments("")}
    targets = []
    for f in flows:
        if body.scope == "all" or f["case_id"] not in existing:
            targets.append(f)
    if not targets:
        return {"status": 1, "assigned": 0, "message": "无待分配 case"}

    # ② 主风险环节分类
    def env_of(f) -> str:
        rt = str(f.get("rt") or "")
        rr, lr = str(f.get("rr") or ""), str(f.get("lr") or "")
        ur, tr = str(f.get("ur") or ""), str(f.get("tr") or "")
        if "批量注册" in (rt + rr):
            return "注册"
        if "批量解冻" in (rt + ur):
            return "解冻"
        if "token" in (rt + tr).lower() or "伪造" in (rt + tr):
            return "Token"
        if "众包" in (rt + lr) or "租借" in (rt + lr) or "批量登录" in (rt + lr) or "黑产自持" in (rt + lr) or "转卖" in (rt + lr):
            return "登录"
        return "登录"   # 无明确环节信息的默认归登录（处罚来自登录定性）
    by_env: dict = {}
    for f in targets:
        by_env.setdefault(env_of(f), []).append(f)

    # ③ 加权轮转（2026-09-20 用户定）：按权重比例分配（如 25/25/35/15——
    # 35% 的人分到约 1.4 倍的 case）。无权重时均分（每人等量）。
    people = [str(m).strip() for m in body.mis_list if str(m).strip()]
    weights = {}
    if body.people:
        for p in body.people:
            mis = str(p.get("mis") or "").strip()
            if mis in people:
                weights[mis] = float(p.get("weight") or 0)
    # 加权序列（2026-09-20 二次修复）：逐位置贪心——每个位置分给
    # 「分完后占比与目标占比缺口最大」的人，序列天然交错且任意前缀逼近权重比
    # （35/25/15/25 的前 60 个 ≈ 21/15/9/15，不再是分块拼接时前 60 全给高权重块）。
    seq = []
    if weights and all(w > 0 for w in weights.values()) and len(weights) == len(people):
        total_w = sum(weights.values())
        N = 100
        counts_seq = {m: 0 for m in people}
        for _pos in range(N):
            best_m, best_gap = None, None
            for m in people:
                gap = weights[m] / total_w - (counts_seq[m] + 1) / (_pos + 1)
                if best_m is None or gap > best_gap:
                    best_m, best_gap = m, gap
            seq.append(best_m)
            counts_seq[best_m] += 1
    else:
        seq = people[:]   # 均分
    assignments = []
    for env, flist in by_env.items():
        for i, f in enumerate(flist):
            mis = seq[i % len(seq)]
            assignments.append({"case_id": f["case_id"], "mis": mis, "dt": f.get("dt")})
    n = store.upsert_assignments(assignments)
    # 统计（每人 × 环节）
    stat: dict = {}
    for a in assignments:
        env = env_of(next(f for f in targets if f["case_id"] == a["case_id"]))
        stat.setdefault(a["mis"], {}).setdefault(env, 0)
        stat[a["mis"]][env] += 1
    sys_log("info", f"[Assign] 分配完成 {n} 个 case 给 {len(people)} 人 by={request.session.get('mis')}")
    return {"status": 1, "assigned": n, "total_cases": len(targets),
            "per_person": stat, "per_env": {k: len(v) for k, v in by_env.items()}}


@router.delete("/api/assignments/{case_id}")
def assignment_delete(case_id: str):
    """清除单个 case 的分配。"""
    import flow_store as store
    store.delete_assignment(case_id)
    return {"status": 1, "case_id": case_id}


class AssignDoneRequest(BaseModel):
    done: bool


@router.put("/api/assignments/{case_id}/done")
def assignment_done(case_id: str, body: AssignDoneRequest):
    """勾选/取消完成（人工处理标记）。"""
    import flow_store as store
    if not store.toggle_done(case_id, body.done):
        raise HTTPException(500, "更新失败")
    return {"status": 1, "case_id": case_id, "done": body.done}


@router.get("/api/cases/{case_id}/perception")
def case_perception(case_id: str):
    """感知表上下文（2026-09-22 用户定）：label / platform_app_partner / risk_level / items_str
    （感知原因）——与"报出原因"（团伙定性）互补，运营可同时看到团伙判定原因与感知原因。
    按 flow.group_id + dt-2 窗口查感知表（感知日比处理日早 2 天）。"""
    import flow_store as store
    flow = store.get_by_case_id(case_id)
    if not flow or not flow.get("group_id"):
        return {"status": 0, "message": "无 flow"}
    gid = flow["group_id"]
    # 优先读 extra.perception_context（2026-09-22 用户定：建 case 时预存，零 Hive 毫秒级）
    pc = (flow.get("extra") or {}).get("perception_context") or {}
    if pc.get("items_str"):
        return {"status": 1, "group_id": gid, "perception": {
            "dt": pc.get("perception_dt") or "",
            "label": pc.get("label") or "",
            "platform_app_partner": pc.get("platform_app_partner") or "",
            "risk_level": pc.get("risk_level") or "",
            "items_str": pc.get("items_str") or "",
        }}
    # 感知数据延迟两天：处理日 20260920 → 感知日 20260918。窗口锚定 flow 自身 dt（往回 4 天），
    # 不能锚定今天——复盘历史 case 时感知日早已滑出"今天往前"的滚动窗口导致查不到
    from datetime import datetime, timedelta
    anchor = flow.get("dt") or datetime.now().strftime("%Y%m%d")
    try:
        base = datetime.strptime(str(anchor), "%Y%m%d")
    except ValueError:
        base = datetime.now()
    dts = [(base - timedelta(days=d)).strftime("%Y%m%d") for d in range(0, 5)]
    in_list = ",".join(f"'{d}'" for d in dts)   # dts 是本地生成的 YYYYMMDD，无注入面
    sql = (
        f"SELECT dt, label, platform_app_partner, risk_level, items_str "
        f"FROM ba_rc.app_account_risk_group_perception_result_dt "
        f"WHERE group_id='{gid.replace(chr(39), chr(39)*2)}' AND dt IN ({in_list}) ORDER BY dt DESC LIMIT 1"
    )
    res = _run_hive_sync(sql, max_wait_s=60)
    if res["status"] != "done" or not res.get("rows"):
        return {"status": 0, "message": "感知表无该 group 记录", "rows": []}
    cols = res["columns"]
    row = res["rows"][0]
    return {"status": 1, "group_id": gid,
            "perception": {c: row[i] for i, c in enumerate(cols)}}


@router.get("/api/cases/{case_id}/note")
def case_note_get(case_id: str):
    """查 case 备注（分析思路/结论，存 flow extra.case_note）。无 flow 或未写返回空。"""
    import flow_store as store
    flow = store.get_by_case_id(case_id)
    if not flow:
        return {"note": ""}
    return {"note": str((flow.get("extra") or {}).get("case_note") or "")}


@router.put("/api/cases/{case_id}/note")
def case_note_put(case_id: str, body: CaseNoteRequest, request: Request):
    """写 case 备注（CASE总览卡片/详情页展示，唯一人工分析记录字段）。"""
    import flow_store as store
    flow = store.get_by_case_id(case_id)
    if not flow:
        raise HTTPException(404, "case 不存在（无 flow）")
    note = (body.note or "").strip()[:2000]
    store.update_extra(flow["id"], {"case_note": note})
    sys_log("info", f"[note] case={case_id} 备注已保存（{len(note)} 字） by={request.session.get('mis')}")
    return {"note": note}


class BatchFlowRequest(BaseModel):
    case_ids: list


@router.post("/api/cases/combo_sqls")
def cases_combo_sqls(body: BatchFlowRequest):
    """批量取 case 的规则 SQL（combo_sql，从 result_cache 的 validation_result 行提取）。
    CASE总览卡片展示用——真 flow 路径（flow/list）不携带，前端对缺的 case 异步补拉。"""
    import pipeline_store as store
    sb = store._sb()
    case_ids = [str(c) for c in (body.case_ids or []) if c][:200]
    if not case_ids:
        return {"sqls": {}}
    in_list = ",".join(sb._escape(c) for c in case_ids)
    out: dict = {}
    try:
        for vr in sb.execute(
                f"SELECT case_id, rows FROM result_cache WHERE table_key='validation_result' "
                f"AND case_id IN ({in_list})"):
            try:
                sqls = [str(r[3]) for r in (vr.get("rows") or []) if len(r) > 3 and r[3]]
                if sqls:
                    out[vr["case_id"]] = sqls
            except Exception:
                continue
    except Exception:
        pass
    return {"sqls": out}


@router.post("/api/flow/batch_by_case")
def flow_batch_by_case(body: BatchFlowRequest):
    """批量按 case_id 查 flow + 服务端算阶段归类（Case 总览回填用——
    原 500 个 case 逐个 GET 的 13 批网络往返是总览页卡顿主因）。
    返回 {case_id: {stage_class, flow 精简字段}}——阶段归类规则与前端 caseStage 同构：
    skipped / failed / done(+selected_rules→completed|pending_select) / 运行中按 stage。"""
    import flow_store as store
    sb = store._sb()
    case_ids = [str(c) for c in (body.case_ids or []) if c][:1000]
    if not case_ids:
        return {"flows": {}}
    in_list = ",".join(sb._escape(c) for c in case_ids)
    rows = sb.execute(
        f"SELECT case_id, group_id, stage, status, case_name, dt, error_message, extra "
        f"FROM flow_jobs WHERE case_id IN ({in_list}) ORDER BY created_at DESC")
    # 从 result_cache 的 validation_result 行提取 combo_sql（2026-09-20：总览卡片展示规则 SQL）
    _combo_map: dict = {}
    try:
        for vr in sb.execute(
                f"SELECT case_id, rows FROM result_cache WHERE table_key='validation_result' "
                f"AND case_id IN ({in_list})"):
            try:
                vrows = vr.get("rows") or []
                vcols = vr.get("rows") and None
                # rows 是 [[...]]，列序按 validation_result_sql：combo_id(0), rule_rank(1),
                # predicates(2), combo_sql(3) ... 取 combo_sql
                sqls = [str(r[3]) for r in vrows if len(r) > 3 and r[3]]
                if sqls:
                    _combo_map[vr["case_id"]] = sqls
            except Exception:
                continue
    except Exception:
        pass
    # 同 case 多条取最新（ORDER BY 已按时间倒序，首见即最新）
    out = {}
    for r in rows:
        cid = str(r.get("case_id") or "")
        if not cid or cid in out:
            continue
        ex = r.get("extra") or {}
        if isinstance(ex, str):
            try:
                import json as _json
                ex = _json.loads(ex or "{}")
            except Exception:
                ex = {}
        # 阶段归类（与前端 caseStage 同构）
        stage, status = r.get("stage"), r.get("status")
        if stage == "skipped":
            cls = "skipped"
        elif status == "failed":
            cls = "failed"
        elif status == "done":
            sel = ex.get("selected_rules")
            cls = "completed" if (sel and (isinstance(sel, list) and len(sel) or isinstance(sel, str) and sel)) else "pending_select"
        else:
            cls = stage or "preprocess"
        # Agent 判定统计（卡片展示高准确/低准确/不通过数）
        ra = ex.get("rule_agent") or {}
        out[cid] = {
            "stage_class": cls,
            "stage": stage, "status": status, "case_name": r.get("case_name"),
            "group_id": r.get("group_id"), "dt": r.get("dt"),
            "error_message": r.get("error_message") or "",
            # 上游 dify 入参（总览卡片标签/筛选用）
            "external_result": ex.get("external_result") or "",
            "external_action_type": ex.get("external_action_type") or "",
            "selected_rules": bool(ex.get("selected_rules")),
            "ra_high": ra.get("high"), "ra_low": ra.get("low"),
            "ra_fail": ra.get("fail"), "ra_total": ra.get("total"),
            "combo_sqls": _combo_map.get(cid, []),   # 全部规则的 SQL（总览卡片完整展示）
        }
    return {"flows": out}


@router.post("/api/flow/terminate")
def flow_terminate(flow_id: str):
    """终止 flow：停止调度推进 + 子任务标 failed（画布平台侧若已在跑不受影响，仅停止跟踪/后续阶段）。"""
    import flow_store as store
    if not store.terminate_flow(flow_id):
        raise HTTPException(400, "终止失败（仅 running 中的 flow 可终止）")
    return {"flow_id": flow_id, "status": "terminated"}


class BatchTerminateRequest(BaseModel):
    flow_ids: list


@router.post("/api/flow/batch_terminate")
def flow_batch_terminate(body: BatchTerminateRequest):
    """批量终止 flow（仅 running/pending 生效）。返回每个的结果。"""
    import flow_store as store
    results = []
    for fid in body.flow_ids:
        try:
            ok = store.terminate_flow(str(fid))
            results.append({"flow_id": str(fid), "terminated": bool(ok)})
        except Exception as e:
            results.append({"flow_id": str(fid), "terminated": False, "error": str(e)[:100]})
    ok = sum(1 for r in results if r.get("terminated"))
    sys_log("info", f"[flow] batch_terminate {len(body.flow_ids)} 个，成功 {ok}")
    return {"terminated": ok, "total": len(body.flow_ids), "results": results}


@router.post("/api/flow/clear_pending_queues")
def flow_clear_pending_queues(request: Request):
    """清空所有排队任务（置 failed，调度器不再 pick up）——释放并发池排队位给新任务。
    覆盖四类任务队列：捞全 canvas_jobs / 预处理 preprocess_jobs / 误伤 injury_eval_jobs /
    处置 punish_check_jobs 的 pending；关联的 running/pending flow 一并置 failed
    （flow 无法继续推进到下一阶段）。已在执行的（submitted/running）不受影响。仅管理员。"""
    if not _is_admin(request):
        raise HTTPException(403, "仅管理员可操作")
    import canvas_job_store as cs
    import preprocess_store as pp
    import injury_eval_store as ie
    import punish_check_store as pc
    import flow_store as fs
    sb = cs._sb()
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    msg = "排队位已清空（管理员清空排队）"
    cleared = {}
    # 1. 四类任务队列 pending → failed
    for name, tbl in [("laoquan", "canvas_jobs"), ("preprocess", "preprocess_jobs"),
                      ("injury_eval", "injury_eval_jobs"), ("punish_check", "punish_check_jobs")]:
        try:
            rows = sb.execute(
                f"UPDATE {tbl} SET status='failed', error_message=$1, updated_at=$2 "
                f"WHERE status='pending' RETURNING id", [msg, now])
            cleared[name] = len(rows)
        except Exception as e:
            cleared[name] = -1
            sys_log("warning", f"[flow] clear_pending {name} 失败: {str(e)[:120]}")
    # 2. 关联 flow：引用被清任务的 running flow 置 failed（子任务已 failed，推进不出结果）
    flows_failed = 0
    try:
        flows = sb.execute(
            "SELECT id FROM flow_jobs WHERE status='running'")
        for f in flows:
            try:
                flow = fs.get_flow(f["id"])
                if not flow:
                    continue
                # 只处理子任务被本次清空影响的 flow：任一子任务 failed 且非终态
                affected = False
                pid = flow.get("preprocess_task_id")
                if pid:
                    r = sb.execute("SELECT status FROM preprocess_jobs WHERE id=$1", [pid])
                    if r and r[0]["status"] == "failed":
                        affected = True
                if not affected:
                    jid = flow.get("laoquan_job_id")
                    if jid:
                        r = sb.execute("SELECT status FROM canvas_jobs WHERE id=$1", [jid])
                        if r and r[0]["status"] == "failed" and flow.get("stage") in ("laoquan",):
                            affected = True
                if affected:
                    sb.execute(
                        "UPDATE flow_jobs SET status='failed', error_message=$1, updated_at=$2 WHERE id=$3",
                        [msg, now, f["id"]])
                    flows_failed += 1
            except Exception:
                continue
    except Exception as e:
        sys_log("warning", f"[flow] clear_pending flow 关联失败: {str(e)[:120]}")
    total = sum(v for v in cleared.values() if v > 0)
    sys_log("info", f"[flow] 清空排队任务 {total} 个 {cleared}，关联 flow 置 failed {flows_failed} 个 "
                    f"by={request.session.get('mis')}")
    return {"status": 1, "cleared": cleared, "total": total, "flows_failed": flows_failed}


@router.post("/api/flow/retry")
def flow_retry(flow_id: str, force: bool = False, stage: str = ""):
    """重跑 flow。
    stage 参数（优先）：从指定阶段重跑（preprocess/snapshot/laoquan），其后阶段重新执行。
    force=false（默认）：仅 failed 可用，从失败阶段续跑（重置失败子任务）。
    force=true：任意状态可用，从头重跑（清子任务引用，FlowScheduler 重建全新任务）。"""
    import flow_store as store
    flow = store.get_flow(flow_id)
    if not flow:
        raise HTTPException(404, "flow 不存在")
    if stage:
        if not store.retry_from_stage(flow_id, stage):
            raise HTTPException(400, f"阶段重跑失败（stage 需为 {store.RETRY_STAGES} 之一）")
        return {"flow_id": flow_id, "status": "running", "stage": stage, "retry_from": stage}
    stage = flow.get("stage")
    if force:
        # 从头重跑：清子任务引用 → 调度器建全新 preprocess 任务
        store.update_flow(flow_id, stage="preprocess", status="running",
                          preprocess_task_id=None, laoquan_job_id=None,
                          snapshot_last_check=None, error_message=None)
        store.update_extra(flow_id, {
            "stage_snapshot_at": None, "stage_laoquan_at": None, "stage_done_at": None,
        })
        sys_log("info", f"[flow] re-run(force) flow={flow_id} case={flow.get('case_id')} → 从头重跑")
        return {"flow_id": flow_id, "status": "running", "stage": "preprocess", "rerun": True}
    # 续跑（仅 failed）
    if flow.get("status") != "failed":
        raise HTTPException(400, "仅 failed 可重试；如需从头重跑请传 force=true")
    if stage == "preprocess":
        import preprocess_store as pp
        tid = flow.get("preprocess_task_id")
        if tid:
            try:
                pp.reset_to_pending(tid)
            except Exception:
                pass
    elif stage == "laoquan":
        import canvas_job_store as cs
        jid = flow.get("laoquan_job_id")
        if jid:
            try:
                cs.reset_to_pending(jid)
            except Exception:
                pass
    store.update_flow(flow_id, status="running", error_message=None)
    sys_log("info", f"[flow] retry flow={flow_id} stage={stage} → running")
    return {"flow_id": flow_id, "status": "running", "stage": stage}


# ── 数据监控（各表每日数据量）─────────────────────────────────────────────

@router.get("/api/monitor/canvas_pool")
def monitor_canvas_pool():
    """画布并发池状态（任务调度页徽章用）：running/pending/limit。
    running 走 mlp_switch.global_running_count()（四类画布合计，与提交闸门口径一致——
    只统计捞全会导致"实际 31/30 满载但徽章显示 14/30"的误导）。
    pending 保留捞全排队数（占比最大），另附各分项。"""
    import canvas_job_store as store
    from mlp_switch import global_limit, global_running_count
    running = global_running_count()
    if running < 0:
        running = store.count_running()
    rows = store._sb().execute("SELECT count(*) AS n FROM canvas_jobs WHERE status='pending'")
    pending = int(rows[0]["n"]) if rows else 0
    # 分项（徽章 hover 用）
    detail = {}
    try:
        import preprocess_store as _pp
        detail["preprocess"] = int(_pp._sb().execute(
            "SELECT count(*) AS n FROM preprocess_jobs WHERE status='submitted'")[0]["n"])
    except Exception:
        pass
    detail["laoquan"] = store.count_running()
    # running 四类分项 + pending 四类分项（徽章点击展开明细用）
    running_detail = {"laoquan": detail.get("laoquan", 0),
                     "preprocess": detail.get("preprocess", 0)}
    try:
        import injury_eval_store as _ie
        running_detail["injury_eval"] = int(_ie._sb().execute(
            "SELECT count(*) AS n FROM injury_eval_jobs WHERE status='submitted'")[0]["n"])
    except Exception:
        running_detail["injury_eval"] = 0
    try:
        import punish_check_store as _pc
        running_detail["punish_check"] = int(_pc._sb().execute(
            "SELECT count(*) AS n FROM punish_check_jobs WHERE status='submitted'")[0]["n"])
    except Exception:
        running_detail["punish_check"] = 0
    pending_detail = {"laoquan": pending}
    try:
        import preprocess_store as _pp
        pending_detail["preprocess"] = int(_pp._sb().execute(
            "SELECT count(*) AS n FROM preprocess_jobs WHERE status='pending'")[0]["n"])
    except Exception:
        pending_detail["preprocess"] = 0
    try:
        import injury_eval_store as _ie2
        pending_detail["injury_eval"] = int(_ie2._sb().execute(
            "SELECT count(*) AS n FROM injury_eval_jobs WHERE status='pending'")[0]["n"])
    except Exception:
        pending_detail["injury_eval"] = 0
    try:
        import punish_check_store as _pc2
        pending_detail["punish_check"] = int(_pc2._sb().execute(
            "SELECT count(*) AS n FROM punish_check_jobs WHERE status='pending'")[0]["n"])
    except Exception:
        pending_detail["punish_check"] = 0
    return {"running": running, "pending": pending, "limit": global_limit(),
            "running_detail": running_detail, "pending_detail": pending_detail}


@router.get("/api/monitor/baseline_layers")
def monitor_baseline_layers(dt: str = ""):
    """数据监控：14 天窗口 baseline 快照账号分层抽样（pmod 抽样，预估各层量级）。
    dt 缺省=今天；窗口 = [dt-13, dt]。四层：强登录/弱登录/强注册/弱注册。"""
    from datetime import datetime, timedelta
    if not dt:
        dt = datetime.now().strftime("%Y%m%d")
    try:
        d = datetime.strptime(dt, "%Y%m%d")
    except ValueError:
        raise HTTPException(400, "dt 格式应为 YYYYMMDD")
    dt_start = (d - timedelta(days=13)).strftime("%Y%m%d")
    cache_key = result_cache.make_key("baseline_layers", "_ALL_", None, dt)
    hit = result_cache.get(cache_key)
    if hit and hit.get("rows"):
        return {"dt": dt, "window": [dt_start, dt], "layers": hit["rows"]}
    sql = f"""
    SELECT 'strong_login' AS layer, count(DISTINCT a.user_id) AS n
    FROM ba_rc.app_stra_account_strong_end_login_feature_info a
    WHERE a.dt BETWEEN '{dt_start}' AND '{dt}' AND pmod(a.user_id, 1000) = 0
    UNION ALL
    SELECT 'weak_login', count(DISTINCT a.user_id)
    FROM ba_rc.app_stra_account_week_end_login_feature_info a
    WHERE a.dt BETWEEN '{dt_start}' AND '{dt}' AND pmod(a.user_id, 5000) = 0
    UNION ALL
    SELECT 'strong_signup', count(DISTINCT a.user_id)
    FROM ba_rc.app_stra_account_strong_end_signup_feature_info a
    WHERE a.dt BETWEEN '{dt_start}' AND '{dt}' AND pmod(a.user_id, 200) = 0
    UNION ALL
    SELECT 'weak_signup', count(DISTINCT a.user_id)
    FROM ba_rc.app_stra_account_week_end_signup_feature_info a
    WHERE a.dt BETWEEN '{dt_start}' AND '{dt}' AND pmod(a.user_id, 200) = 0
    """
    res = _run_hive_sync(sql, max_wait_s=120)
    if res["status"] != "done":
        return {"dt": dt, "window": [dt_start, dt],
                "layers": [], "error": (res.get("error") or "")[:200]}
    iL, iN = res["columns"].index("layer"), res["columns"].index("n")
    layers = [{"layer": str(r[iL]), "count": int(r[iN] or 0)} for r in res["rows"]]
    try:
        result_cache.upsert(cache_key, "baseline_layers", "_ALL_", None, dt,
                            res["columns"], res["rows"])
    except Exception:
        pass
    return {"dt": dt, "window": [dt_start, dt], "layers": layers}


@router.get("/api/monitor/tables")
def monitor_tables():
    """数据监控：逐表查 dt/count 聚合（倒序，缓存 10min）。返回每表最新量+环比。"""
    from config import get_config
    cfg = get_config()
    result = []
    for t in cfg.data_monitors.tables:
        entry = {"key": t["key"], "name": t["name"], "table": t["table"],
                 "rows": [], "latest_dt": "", "latest_count": None, "prev_count": None,
                 "status": "pending", "error": None}
        cache_key = result_cache.make_key("data_monitor", t["key"], None, "_")
        hit = result_cache.get(cache_key)
        if hit and hit.get("rows"):
            rows = hit["rows"]
        else:
            sql = f"SELECT dt, count(*) AS cnt FROM {t['table']} GROUP BY dt ORDER BY dt DESC LIMIT 60"
            res = _run_hive_sync(sql, max_wait_s=60)
            if res["status"] != "done":
                entry["status"] = "failed"
                entry["error"] = (res.get("error") or "")[:150]
                result.append(entry)
                continue
            rows = sorted(res["rows"], key=lambda r: str(r[0]), reverse=True)[:60]
            try:
                result_cache.upsert(cache_key, "data_monitor", t["key"], None, "_",
                                    ["dt", "count"], rows)
            except Exception:
                pass
        entry["rows"] = [[str(r[0]), int(r[1])] for r in rows]
        if rows:
            entry["latest_dt"] = str(rows[0][0])
            entry["latest_count"] = int(rows[0][1])
            if len(rows) > 1:
                entry["prev_count"] = int(rows[1][1])
        entry["status"] = "done"
        result.append(entry)
    return {"tables": result}


@router.get("/api/monitor/audit")
def monitor_audit(case_id: str = "", unique_key: str = "", dt: str = "",
                  mlp_name: str = "", limit: int = 300):
    """阶段审计：查 mlp 任务执行日志（ba_rc.app_acc_sec_case_run_log，preprocess/profiling 共用）。
    阶段行解析 [stage=xxx] 前缀分组；status='log' 行作为完整日志单独返回。
    查询条件至少一个：case_id / unique_key / dt（可选 mlp_name 过滤）。"""
    import re as _re

    def q(s):
        return s.replace("'", "''")
    conds = []
    if case_id:
        conds.append(f"case_id='{q(case_id)}'")
    if unique_key:
        conds.append(f"unique_key='{q(unique_key)}'")
    if dt:
        conds.append(f"dt='{q(dt)}'")
    if mlp_name:
        conds.append(f"mlp_name='{q(mlp_name)}'")
    if not conds:
        raise HTTPException(400, "至少传一个条件：case_id / unique_key / dt")
    where = " AND ".join(conds)
    # 阶段行：regexp_replace 清掉 message 换行（多行字符串会让 fetch_all 行数校验失败）
    stage_sql = (
        f"SELECT mlp_name, run_id, case_id, group_id, unique_key, status, "
        f"regexp_replace(message, '(\\r|\\n)+', ' '), log_time "
        f"FROM ba_rc.app_acc_sec_case_run_log WHERE {where} AND status!='log' "
        f"ORDER BY run_id, log_time LIMIT {min(int(limit), 400)}"
    )
    res = _run_hive_sync(stage_sql, max_wait_s=90)
    if res["status"] != "done":
        return {"status": "failed", "error": (res.get("error") or "")[:200], "runs": []}
    runs, by_run = [], {}
    for r in res["rows"]:
        run_key = f"{r[0]}:{r[1]}"
        if run_key not in by_run:
            entry = {"mlp_name": str(r[0]), "run_id": str(r[1]), "case_id": str(r[2]),
                     "group_id": str(r[3] or ""), "unique_key": str(r[4] or ""),
                     "stages": [], "full_log": ""}
            by_run[run_key] = entry
            runs.append(entry)
        status = str(r[5] or "")
        msg = str(r[6] or "")
        m = _re.match(r"\[stage=([a-zA-Z0-9_]+)\]\s*(.*)", msg, _re.S)
        by_run[run_key]["stages"].append({
            "stage": m.group(1) if m else "",
            "status": status,
            "message": m.group(2) if m else msg,
            "log_time": str(r[7] or ""),
        })
    # 完整日志行（status='log'，单行大文本可数万字符）：仅在指定 case_id/unique_key 时取（按天取全部会巨大）
    if case_id or unique_key:
        log_sql = (
            f"SELECT mlp_name, run_id, message FROM ba_rc.app_acc_sec_case_run_log "
            f"WHERE {where} AND status='log' ORDER BY log_time LIMIT 20"
        )
        lres = _run_hive_sync(log_sql, max_wait_s=60)
        if lres["status"] == "done":
            for r in lres["rows"]:
                run_key = f"{r[0]}:{r[1]}"
                if run_key in by_run:
                    by_run[run_key]["full_log"] = str(r[2] or "")
    return {"status": "done", "runs": runs, "total": len(res["rows"])}


# ── 评估：Step5 误伤评估（回捞后新节点，sceneKey=accountsec_agent_group_evaluation）──

# action_type 中文 → 处罚类型枚举（kickout=踢登 / freeze=冻结 / freeze_forbit=冻结禁止解冻）
ACTION_TYPE_MAP = {"踢登": "kickout", "冻结": "freeze", "冻结禁止解冻": "freeze_forbit",
                    "冻结加禁止解冻": "freeze_forbit"}   # pipeline 判定输出的写法（多个"加"字）


@router.get("/api/cases/{case_id}/injury_eval")
def injury_eval(case_id: str, experiment: Optional[str] = None, dt: Optional[str] = None):
    """Step5 误伤评估：展示上游选择的规则 + 携带给下游（sceneKey=accountsec_agent_group_evaluation）的参数。
    规则优先级：flow.extra.selected_rules（Step3 人工勾选）> final_rules（Step4 自动推荐）。
    target_sql_b64 = recall_sql（捞回账号 SQL）做 urlsafe_b64 去 padding；
    recall_sql 为空时回退 combo_sql（规则条件，老数据兜底）。action_type 中文映射 kickout/freeze/freeze_forbit。"""
    import base64
    import flow_store
    cfg = _cfg()
    exp, dt = _exp_dt(experiment, dt, case_id)

    def b64(sql_text: str) -> str:
        return base64.urlsafe_b64encode((sql_text or "").encode("utf-8")).decode("utf-8").rstrip("=")

    # 1. 确定规则集合：人工勾选优先
    selected, rules_src = [], "auto"
    try:
        f = flow_store.get_by_case_id(case_id)
        if f:
            selected = (f.get("extra") or {}).get("selected_rules") or []
            group_id = (f.get("extra") or {}).get("group_id") or f.get("group_id") or ""
            action_type_raw = (f.get("extra") or {}).get("external_action_type") or ""
        else:
            group_id, action_type_raw = "", ""
    except Exception:
        group_id, action_type_raw = "", ""

    if selected:
        rules_src = "manual"
        # 从 validation_result 取勾选规则的 combo_sql
        rules = []
        for combo_id in selected:
            sql = Q.validation_combo_detail_sql(cfg, case_id, exp, dt, combo_id)
            cache_key = result_cache.make_key("validation_combo", case_id, exp, dt, f"combo={combo_id}")
            res = _cached(cache_key, "validation_combo", case_id, exp, dt, lambda s=sql: s)
            if res["status"] == "done" and res.get("rows"):
                cols = res["columns"]
                row = res["rows"][0]
                rules.append({"combo_id": combo_id,
                              "combo_sql": row[cols.index("combo_sql")] if "combo_sql" in cols else "",
                              "recall_sql": row[cols.index("recall_sql")] if "recall_sql" in cols else ""})
    else:
        # 默认规则集：AI Agent 判「高准确」的 combo（2026-09-13 用户定——替换原 final_rules
        # 固定算法推荐）。动态读取 rule_agent 最新结果（重跑判定后默认规则自动更新）；
        # 人工一旦提交过 selected_rules 永久优先（上面 manual 分支）。全部非高准确/未判定 → 空。
        rules = []
        agent_high = []
        try:
            f2 = flow_store.get_by_case_id(case_id)
            if f2:
                ra = (f2.get("extra") or {}).get("rule_agent") or {}
                agent_high = [str(v.get("combo_id")) for v in (ra.get("results") or [])
                              if v.get("grade") == "高准确" and v.get("combo_id")]
        except Exception:
            agent_high = []
        if agent_high:
            rules_src = "agent"
        for combo_id in agent_high:
            sql = Q.validation_combo_detail_sql(cfg, case_id, exp, dt, combo_id)
            cache_key = result_cache.make_key("validation_combo", case_id, exp, dt, f"combo={combo_id}")
            res = _cached(cache_key, "validation_combo", case_id, exp, dt, lambda s=sql: s)
            if res["status"] == "done" and res.get("rows"):
                cols = res["columns"]
                row = res["rows"][0]
                rules.append({"combo_id": combo_id,
                              "combo_sql": row[cols.index("combo_sql")] if "combo_sql" in cols else "",
                              "recall_sql": row[cols.index("recall_sql")] if "recall_sql" in cols else ""})
        # 兜底 group_id/action_type（无 flow 时从最新规则行取不到，置空）
        if not group_id:
            try:
                f = flow_store.get_by_case_id(case_id)
                if f:
                    group_id = (f.get("extra") or {}).get("group_id") or f.get("group_id") or ""
                    action_type_raw = (f.get("extra") or {}).get("external_action_type") or ""
            except Exception:
                pass

    action_type_enum = ACTION_TYPE_MAP.get(str(action_type_raw).strip(), "")
    # 规则指标（Step5 确认表格用）：从 validation_result 全量缓存取 rule_rank/combo_size/precision/recall/v_score
    rule_metrics = []
    try:
        vr_key = result_cache.make_key("validation_result", case_id, exp, dt)
        vr = result_cache.get(vr_key)
        if vr and vr.get("rows"):
            cols = vr["columns"]
            iC, iR, iS, iV, iP, iRC = (cols.index("combo_id"), cols.index("rule_rank"),
                                        cols.index("combo_size"), cols.index("v_score"),
                                        cols.index("precision"), cols.index("recall"))
            by_cid = {str(r[iC]): {"combo_id": str(r[iC]), "rule_rank": r[iR], "combo_size": r[iS],
                                    "v_score": r[iV], "precision": r[iP], "recall": r[iRC]} for r in vr["rows"]}
            rule_metrics = [by_cid[r["combo_id"]] for r in rules if r["combo_id"] in by_cid]
    except Exception:
        pass
    return {
        "case_id": case_id, "dt": dt, "experiment": exp,
        "scene_key": "accountsec_agent_group_evaluation",
        "rules_source": rules_src,
        "rules": rules,  # [{combo_id, combo_sql}]
        "rule_metrics": rule_metrics,
        "params": {
            "dt": dt,
            "group_id": group_id,
            # 下游按 combo_id 维度传参：每个规则一个 case_combo_id + target_sql_b64
            # target_sql 原文 = recall_sql（严格：空则 b64 为空串，不允许回退 combo_sql）
            "items": [{"case_combo_id": r["combo_id"],
                       "target_sql_b64": b64(r.get("recall_sql") or "")} for r in rules],
            "action_type": action_type_enum or action_type_raw,  # 映射失败给原值便于排查
            "action_type_raw": action_type_raw,
            "action_type_mapped": bool(action_type_enum),
        },
    }


class InjuryEvalStartRequest(BaseModel):
    combo_ids: list                # 勾选要评估的 combo
    dt: Optional[str] = None
    experiment: Optional[str] = None


@router.post("/api/cases/{case_id}/injury_eval/start")
def injury_eval_start(case_id: str, body: InjuryEvalStartRequest):
    """Step6 启动误伤评估：为每个勾选 combo 建评估任务（sceneKey=accountsec_agent_group_evaluation）。
    参数（dt/group_id/target_sql_b64=recall_sql b64/action_type 枚举）由调度器提交时携带。"""
    import injury_eval_store as store
    import base64 as _b64
    if not body.combo_ids:
        raise HTTPException(400, "combo_ids 不能为空")
    # 复用 injury_eval 的参数计算（规则 + b64 + action_type）
    eval_res = injury_eval(case_id, experiment=body.experiment, dt=body.dt)
    items = {it["case_combo_id"]: it for it in eval_res["params"]["items"]}
    p = eval_res["params"]
    # action_type：中文映射枚举；映射失败（如上游传 auto/空）→ default 传下游
    action_type = p["action_type"] if p["action_type_mapped"] else "default"
    created = []
    # 先校验全部 combo 的 recall_sql 非空（有一条空就整体拒绝，不允许部分启动）
    empty = [c for c in body.combo_ids if not (items.get(c) or {}).get("target_sql_b64")]
    if empty:
        raise HTTPException(400, f"combo {', '.join(empty)} 的 recall_sql 为空（validation_result.recall_sql 未落表），"
                                 f"不允许启动误伤评估")
    for combo_id in body.combo_ids:
        item = items.get(combo_id)
        if not item:
            raise HTTPException(400, f"combo {combo_id} 不在确认规则集内")
        job = store.create_job(
            case_id=case_id, combo_id=combo_id, dt=p["dt"],
            group_id=p["group_id"], action_type=action_type,
            target_sql_b64=item["target_sql_b64"],
        )
        created.append({"job_id": job["id"], "combo_id": combo_id, "status": "pending"})
    sys_log("info", f"[injury_eval] start case={case_id} combos={body.combo_ids} jobs={len(created)}")
    return {"case_id": case_id, "scene_key": eval_res["scene_key"],
            "action_type": action_type, "jobs": created}


@router.post("/api/cases/{case_id}/injury_eval/jobs/{job_id}/retry")
def injury_eval_job_retry(case_id: str, job_id: str):
    """单个 combo 误伤评估重试：failed → pending（InjuryEvalScheduler 重新提交）。"""
    import injury_eval_store as store
    j = store.get_job(job_id)
    if not j or j.get("case_id") != case_id:
        raise HTTPException(404, "任务不存在")
    if j["status"] not in ("failed",):
        raise HTTPException(400, f"仅 failed 可重试，当前 {j['status']}")
    # failed → pending 清错误（unique_key 占位待重提）
    store.update_status(job_id, "pending", error_message=None)
    store._sb().execute("UPDATE injury_eval_jobs SET unique_key=$1, updated_at=$2 WHERE id=$3",
                        [f"pending_{case_id}_{j['combo_id']}", store._now(), job_id])
    sys_log("info", f"[injury_eval] job retry job={job_id} combo={j['combo_id']} → pending")
    return {"job_id": job_id, "combo_id": j["combo_id"], "status": "pending"}


@router.get("/api/cases/{case_id}/injury_eval/results")
def injury_eval_results(case_id: str, dt: Optional[str] = None):
    """Step6 误伤评估结果：查 fact_stra_perception_group_punish_info_d（按 case_combo_id 维度）。
    case_combo_id = 误伤评估任务维度（case 的确认规则 combo），该 case 下每个 combo 可能多行（distinct）。"""
    if not dt:
        dt = _latest_dt_value(case_id) or ""
    if not dt:
        return {"status": "done", "columns": [], "rows": [], "dt": ""}
    cache_key = result_cache.make_key("injury_eval_results", case_id, None, dt)
    hit = result_cache.get(cache_key)
    if hit and hit.get("rows"):
        return {"status": "done", "dt": dt, "cached": True,
                "columns": hit["columns"], "rows": hit["rows"]}
    sql = (f"SELECT distinct case_combo_id, action_type, user_cnt, risk_cnt, risk_ratio, "
           f"high_value_cnt, high_value_ratio, white_tag_info "
           f"FROM ba_rc.fact_stra_perception_group_punish_info_d "
           f"WHERE dt='{dt}' AND case_combo_id LIKE '{case_id}%'")
    res = _run_hive_sync(sql, max_wait_s=90)
    if res["status"] != "done":
        return {"status": "failed", "error": (res.get("error") or "")[:200],
                "columns": [], "rows": [], "dt": dt}
    rows = res.get("rows") or []
    if rows:
        _try_upsert(cache_key, "injury_eval_results", case_id, None, dt,
                    res["columns"], rows)
    return {"status": "done", "dt": dt, "columns": res["columns"], "rows": rows}


# ── 处置：Step7 团伙处置（sceneKey=accountsec_agent_group_punish_check）──

class PunishCheckRequest(BaseModel):
    combo_id: str
    check_info: int                  # 0 不处罚 / 1 处罚
    dt: Optional[str] = None


@router.post("/api/cases/{case_id}/punish_check")
def punish_check(case_id: str, body: PunishCheckRequest):
    """Step7 团伙处置确认：人工选择处罚(1)/不处罚(0) → 建处置校验任务。
    调度器提交画布（sceneKey=accountsec_agent_group_punish_check，globalParam=dt/case_combo_id/check_info）。"""
    import punish_check_store as store
    if body.check_info not in (0, 1):
        raise HTTPException(400, "check_info 只能 0（不处罚）或 1（处罚）")
    dt = body.dt or _latest_dt_value(case_id or "") or ""
    job = store.create_job(case_id, body.combo_id, dt, body.check_info)
    sys_log("info", f"[punish_check] case={case_id} combo={body.combo_id} check_info={body.check_info} job={job['id']}")
    return {"case_id": case_id, "combo_id": body.combo_id, "check_info": body.check_info,
            "scene_key": "accountsec_agent_group_punish_check", "job": {"job_id": job["id"], "status": "pending"}}


@router.get("/api/cases/{case_id}/punish_check/jobs")
def punish_check_jobs(case_id: str):
    """Step7 处置任务列表（每 combo 最新一条）。"""
    import punish_check_store as store
    return {"jobs": store.list_by_case(case_id)}


# ── 监控：Step8 处置监控（sceneKey=app_stra_perception_group_punish_monitor 的观测指标）──

@router.get("/api/cases/{case_id}/punish_monitor")
def punish_monitor(case_id: str, dt: Optional[str] = None):
    """Step8 处置监控：查 app_stra_group_monitor_info_pending 按 case_combo_id 聚合的观测指标。
    指标：处罚进度（分桶/用户数）、成功率、重登、解冻、客诉、回滚。"""
    if not dt:
        dt = _latest_dt_value(case_id) or ""
    if not dt:
        return {"status": "done", "dt": "", "columns": [], "rows": []}
    cache_key = result_cache.make_key("punish_monitor", case_id, None, dt)
    hit = result_cache.get(cache_key)
    if hit and hit.get("rows"):
        return {"status": "done", "dt": dt, "cached": True, "columns": hit["columns"], "rows": hit["rows"]}
    # 注意：punish_fail_reason/rollback_reason 两列在聚合(max)查询里会导致 talos fetch 失败（平台怪癖，
    # raw/DISTINCT 查询正常）——主聚合不含这两列，用独立 DISTINCT 小查询补文本。
    sql = (
        f"SELECT dt, case_combo_id, "
        f"count(distinct user_id) AS cnt, "
        f"max(total_bucket_cnt) AS total_bucket_cnt, max(completed_bucket_cnt) AS completed_bucket_cnt, "
        f"max(punished_user_cnt) AS punished_user_cnt, max(punish_success_cnt) AS punish_success_cnt, "
        f"max(punish_success_ratio) AS punish_success_ratio, "
        f"max(relogin_cnt) AS relogin_cnt, max(relogin_ratio) AS relogin_ratio, "
        f"max(relogin_success_cnt) AS relogin_success_cnt, max(relogin_success_ratio) AS relogin_success_ratio, "
        f"max(unfreeze_cnt) AS unfreeze_cnt, max(unfreeze_ratio) AS unfreeze_ratio, "
        f"max(unfreeze_success_cnt) AS unfreeze_success_cnt, max(unfreeze_success_ratio) AS unfreeze_success_ratio, "
        f"max(kesu_user_cnt) AS kesu_user_cnt, max(kesu_ratio) AS kesu_ratio, "
        f"max(rollback_flag) AS rollback_flag "
        f"FROM ba_rc.app_stra_group_monitor_info_pending "
        f"WHERE dt='{dt}' AND case_combo_id LIKE '{case_id}%' "
        f"GROUP BY dt, case_combo_id ORDER BY case_combo_id"
    )
    res = _run_hive_sync(sql, max_wait_s=90)
    if res["status"] != "done":
        return {"status": "failed", "dt": dt, "error": (res.get("error") or "")[:200],
                "columns": [], "rows": []}
    rows = res.get("rows") or []
    # 补 reason 文本（独立 DISTINCT 查询；聚合里查会 fetch 失败）
    reasons = {}
    try:
        rsql = (f"SELECT DISTINCT case_combo_id, punish_fail_reason, rollback_reason "
                f"FROM ba_rc.app_stra_group_monitor_info_pending "
                f"WHERE dt='{dt}' AND case_combo_id LIKE '{case_id}%' LIMIT 50")
        rres = _run_hive_sync(rsql, max_wait_s=60)
        if rres["status"] == "done":
            iC = rres["columns"].index("case_combo_id")
            iF = rres["columns"].index("punish_fail_reason")
            iR = rres["columns"].index("rollback_reason")
            for r in rres["rows"]:
                cid = str(r[iC])
                fr = r[iF] if r[iF] not in (None, "NULL") else ""
                rr = r[iR] if r[iR] not in (None, "NULL") else ""
                if cid not in reasons or fr or rr:
                    reasons[cid] = (str(fr or ""), str(rr or ""))
    except Exception:
        pass
    if rows:
        # reason 列插到末尾
        cols = list(res["columns"]) + ["punish_fail_reason", "rollback_reason"]
        rows = [list(r) + list(reasons.get(str(r[1]), ("", ""))) for r in rows]
        _try_upsert(cache_key, "punish_monitor", case_id, None, dt, cols, rows)
    return {"status": "done", "dt": dt, "columns": cols, "rows": rows}


@router.get("/api/cases/{case_id}/injury_eval/jobs")
def injury_eval_jobs(case_id: str):
    """Step6 任务列表（该 case 的误伤评估任务，含画布状态/报文）。"""
    import injury_eval_store as store
    return {"jobs": store.list_by_case(case_id)}


# ── 对外接口（外部系统调，协议格式）────────────────────────────────────────
# 不走 SSO 登录体系（路径无 /api 前缀，APIAuthGuard 不拦），改用 biz 白名单鉴权。

def _allowed_biz() -> set:
    """允许调外部接口的 biz 集合：system_config 表 allowed_biz。"""
    try:
        import canvas_job_store as _cjs
        rows = _cjs._sb().execute(
            "SELECT value FROM system_config WHERE category='access' AND key='allowed_biz'")
        if rows:
            import json as _json
            val = rows[0].get("value")
            if isinstance(val, str):
                val = _json.loads(val)
            return set(val or [])
    except Exception:
        pass
    return set()


def _biz_denied(biz: Optional[str]) -> Optional[str]:
    """biz 白名单校验，返回错误消息（None = 放行）。"""
    if not biz:
        return "FAILURE: biz 不能为空（业务来源标记必填）"
    if biz not in _allowed_biz():
        return f"FAILURE: biz={biz} 不在白名单"
    return None


class ExternalTaskCreateRequest(BaseModel):
    group_id: str                     # 团伙 ID，必填
    result: Optional[str] = None      # 团伙类型（批量注册/批量登录/Token盗用）
    action_type: Optional[str] = None # 动作类型（冻结/踢登）
    reason: Optional[str] = None      # 原因，json 格式
    biz: Optional[str] = None         # 业务来源标记（如 acc_sec_agent_pipline），白名单鉴权用
    batch_id: Optional[str] = None    # 流水线批次号（pipeline 路径透传，前端溯源用）
    perception_context: Optional[dict] = None   # 感知上下文（items_str/risk_level/perception_dt）


@router.post("/agent/tichunlaoquan/task_create")
def external_task_create(body: ExternalTaskCreateRequest):
    """对外：创建提纯捞全任务 = 启动全流程（预处理→snapshot→提纯捞全→完成）。
    返回 {status, data:{case_id}, message}。biz 白名单鉴权。
    result/action_type 含「无风险」→ 不进入流程（stage=skipped, status=done），
    只记录上游入参供追溯（排查 dify 工作流为何判定无风险）。"""
    import flow_store as store
    import preprocess_store as pp
    from datetime import datetime
    err = _biz_denied(body.biz)
    if err:
        sys_log("warning", f"[external] task_create 拒绝 biz={body.biz or '-'} group_id={body.group_id}")
        return {"status": 0, "data": {"case_id": ""}, "message": err}
    if not body.group_id:
        return {"status": 0, "data": {"case_id": ""}, "message": "FAILURE: group_id 不能为空"}
    # 不复用（2026-09-14 用户定）：同 group 每次建新 case——旧 case 归属旧日期分区，
    # CASE总览按天分栏导致新批次运行不可见（"提纯捞全完成 1 但找不到 case"实锤）。
    # 重跑同 group = 新 case 全流程（预处理→捞全→评估），旧 case 保留不动。
    dt = datetime.now().strftime("%Y%m%d")
    try:
        case_id = pp.allocate_case_id(dt)
    except Exception as e:
        sys_log("error", f"[external] allocate_case_id failed: {str(e)[:200]}")
        return {"status": 0, "data": {"case_id": ""}, "message": f"FAILURE: 取号失败 {str(e)[:100]}"}
    case_name = f"case_{case_id}"
    # 无风险拦截：result/action_type 含「无风险」，或 action_type 缺失且 reason 为整体无风险判定
    # （reason 部分环节含"无风险"字样不算——如"Token风险 + 登录无风险"混合，仍走流程）
    combined = f"{body.result or ''}{body.action_type or ''}"
    reason_txt = (body.reason or "").strip()
    overall_no_risk = not combined.strip() and bool(
        re.fullmatch(r"(风险汇总：?)?无风险", reason_txt))
    skip_hit = "无风险" in combined or overall_no_risk
    # 风险类型拦截（与 pipeline_scheduler._do_tichun_create 同口径）：result 命中拦截清单
    # （页面实时配置，如 token伪造/批量解冻）→ 不建流程直接返回。2026-09-13 补：原该端点
    # 只有"无风险"拦截——dify 直调此端点可绕过 pipeline 侧的风险类型拦截（凌晨 272 孤儿
    # 事故的成因之一）。命中时走 skipped 记录（同无风险拦截的形态，便于追溯）。
    blocked_type = ""
    if not skip_hit:
        from pipeline_scheduler import tichun_blocked_risk_types
        for bt in tichun_blocked_risk_types():
            if bt and bt in (body.result or ""):
                blocked_type = bt
                break
    if blocked_type:
        skip_hit = True
    if skip_hit:
        if blocked_type:
            skip_reason = f"风险类型「{blocked_type}」命中拦截开关（不入提纯）"
        elif overall_no_risk:
            skip_reason = "reason 整体判定无风险"
        else:
            skip_reason = "result/action_type 含「无风险」"
        try:
            flow = store.create_flow(body.group_id, dt, case_id, case_name, stage="skipped")
            store.update_flow(flow["id"], status="done",
                              error_message=f"上游判定不入提纯：{skip_reason}")
            store.update_extra(flow["id"], {
                "biz": body.biz or "",
                "external_result": body.result or "",
                "external_action_type": body.action_type or "",
                "external_reason": body.reason or "",
                "skipped_reason": skip_reason,
                "stage_done_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            })
        except Exception as e:
            sys_log("error", f"[external] create_flow(skipped) failed: {str(e)[:200]}")
            return {"status": 0, "data": {"case_id": case_id}, "message": f"FAILURE: 建流程失败 {str(e)[:100]}"}
        sys_log("info", f"[external] task_create 跳过（{skip_reason}）biz={body.biz or '-'} group_id={body.group_id} "
                        f"case_id={case_id} action_type={body.action_type} reason={(body.reason or '')[:100]}")
        return {"status": 1, "data": {"case_id": case_id}, "message": "SUCCESS"}
    try:
        flow = store.create_flow(body.group_id, dt, case_id, case_name)
        # 外部参数存 extra 供追溯（biz = 请求来源标记）
        extra_up = {}
        if body.biz:
            extra_up["biz"] = body.biz
        if body.batch_id:
            extra_up["pipeline_batch_id"] = body.batch_id
        if body.perception_context:
            extra_up["perception_context"] = body.perception_context
        if body.result or body.action_type or body.reason:
            extra_up.update({
                "external_result": body.result or "",
                "external_action_type": body.action_type or "",
                "external_reason": body.reason or "",
            })
        if extra_up:
            store.update_extra(flow["id"], extra_up)
    except Exception as e:
        sys_log("error", f"[external] create_flow failed: {str(e)[:200]}")
        return {"status": 0, "data": {"case_id": case_id}, "message": f"FAILURE: 建流程失败 {str(e)[:100]}"}
    sys_log("info", f"[external] task_create biz={body.biz or '-'} group_id={body.group_id} case_id={case_id} "
                    f"flow={flow['id']} result={body.result} action_type={body.action_type}")
    return {"status": 1, "data": {"case_id": case_id}, "message": "SUCCESS"}


class ExternalTaskStatusRequest(BaseModel):
    case_id: str
    biz: Optional[str] = None         # 业务来源标记（如 acc_sec_agent_pipline），白名单鉴权用


@router.post("/agent/tichunhuilao/task_status")
def external_task_status(body: ExternalTaskStatusRequest):
    """对外：查提纯捞全任务状态（按 case_id 查全流程）。
    返回 {status, data:{case_id, case_task_status_msg, case_task_status_stage}, message}。
    case_task_status_msg: SUCCESS / RUNNING / FAILURE；case_task_status_stage: 阶段/状态。
    biz 白名单鉴权。"""
    import flow_store as store
    sys_log("info", f"[external] task_status biz={body.biz or '-'} case_id={body.case_id}")
    err = _biz_denied(body.biz)
    if err:
        return {"status": 0, "data": {"case_id": body.case_id or "",
                                      "case_task_status_msg": "FAILURE",
                                      "case_task_status_stage": "biz 白名单校验失败"}, "message": err}
    if not body.case_id:
        return {"status": 1, "data": {"case_id": body.case_id, "case_task_status_msg": "FAILURE",
                                       "case_task_status_stage": "case_id 不能为空"}, "message": "FAILURE"}
    flow = store.get_by_case_id(body.case_id)
    if not flow:
        return {"status": 1, "data": {"case_id": body.case_id, "case_task_status_msg": "FAILURE",
                                       "case_task_status_stage": "case_id 不存在"}, "message": "FAILURE"}
    stage, status = flow.get("stage", ""), flow.get("status", "")
    if stage == "skipped":
        # 上游判定无风险被跳过：返回 SUCCESS（无规则），附 skip 标记和上游判定原文供管道排查
        ex = flow.get("extra") or {}
        return {"status": 1, "data": {"case_id": body.case_id, "case_task_status_msg": "SUCCESS",
                                       "case_task_status_stage": "skipped/done",
                                       "skipped_reason": ex.get("skipped_reason") or "上游判定无风险",
                                       "external_action_type": ex.get("external_action_type") or "",
                                       "external_reason": ex.get("external_reason") or "",
                                       "rules": {}}, "message": "SUCCESS"}
    # 提纯捞全完成判定：flow 全链路 done，或已过捞全阶段（injury_eval/punish 中）——
    # 后者是"捞全完成、流程自然延伸到评估/处置"，对外（管道方/流水线轮询）均算本任务 SUCCESS
    tichun_done = (status == "done") or (status == "running" and stage in ("injury_eval", "punish"))
    if tichun_done:
        try:
            rules = _flow_rules_map(body.case_id, flow)
        except Exception as e:
            sys_log("warning", f"[external] rules map fail case={body.case_id}: {str(e)[:150]}")
            rules = {}
        return {"status": 1, "data": {"case_id": body.case_id, "case_task_status_msg": "SUCCESS",
                                       "case_task_status_stage": f"{stage}/{status}", "rules": rules}, "message": "SUCCESS"}
    if status == "failed":
        return {"status": 1, "data": {"case_id": body.case_id, "case_task_status_msg": "FAILURE",
                                       "case_task_status_stage": f"{stage}/failed: {(flow.get('error_message') or '')[:80]}"},
                "message": "FAILURE"}
    # running
    return {"status": 1, "data": {"case_id": body.case_id, "case_task_status_msg": "RUNNING",
                                   "case_task_status_stage": f"{stage}/running"}, "message": "RUNNING"}


class ExternalRuleSelectRequest(BaseModel):
    case_id: str
    combo_ids: list            # 人工选择的规则 combo_id 列表


@router.post("/api/flow/select_rules")
def flow_select_rules(body: ExternalRuleSelectRequest):
    """页面「确定」按钮调：把 Step3 人工选择的规则存到 flow.extra.selected_rules。
    task_status 成功时优先返回这些规则（无选择则返回 Step4 自动推荐规则集）。"""
    import flow_store as store
    flow = store.get_by_case_id(body.case_id)
    if not flow:
        raise HTTPException(404, "case_id 不存在")
    store.update_extra(flow["id"], {"selected_rules": body.combo_ids})
    sys_log("info", f"[flow] select_rules case={body.case_id} rules={body.combo_ids}")
    return {"case_id": body.case_id, "selected_rules": body.combo_ids}


def _flow_rules_map(case_id: str, flow: dict) -> dict:
    """task_status 成功时的规则 map：{combo_id: combo_sql}。
    优先 flow.extra.selected_rules（Step3 人工选择，查 validation_result）；
    无选择则用 Step4 自动推荐规则集（final_rules 表）。"""
    import sql_templates as Q
    from config import get_config
    cfg = get_config()
    selected = (flow.get("extra") or {}).get("selected_rules") or []
    dt = flow.get("dt") or ""
    # experiment：优先取该 case 缓存里记录的真实值（画布同步时写的，default 等），
    # 兜底 config 默认——直接用默认会 key 不匹配 miss 缓存
    exp = None
    try:
        rows = result_cache._sb().execute(
            "SELECT experiment FROM result_cache WHERE case_id=$1 AND experiment IS NOT NULL LIMIT 1",
            [case_id])
        if rows and rows[0].get("experiment"):
            exp = rows[0]["experiment"]
    except Exception:
        pass
    if not exp:
        exp = cfg.default_experiment
    if selected:
        # 人工选择：优先从 validation_result 整表缓存取 combo_sql（画布同步时已缓存，夜间可用），
        # miss 再走 combo 明细查询。有选择就只返回选择（部分查不到也不 fallthrough 到推荐集）
        m = {}
        vr_key = result_cache.make_key("validation_result", case_id, exp, dt)
        vr = result_cache.get(vr_key)
        if vr and vr.get("rows"):
            cols = vr["columns"]
            iC, iS = cols.index("combo_id"), cols.index("combo_sql")
            rows_by_cid = {str(r[iC]): (r[iS] or "") for r in vr["rows"]}
            for combo_id in selected:
                if combo_id in rows_by_cid:
                    m[combo_id] = rows_by_cid[combo_id]
        else:
            for combo_id in selected:
                sql = Q.validation_combo_detail_sql(cfg, case_id, exp, dt, combo_id)
                cache_key = result_cache.make_key("validation_combo", case_id, exp, dt, f"combo={combo_id}")
                res = _cached(cache_key, "validation_combo", case_id, exp, dt, lambda s=sql: s)
                if res["status"] == "done" and res.get("rows"):
                    cols = res["columns"]
                    row = res["rows"][0]
                    m[combo_id] = row[cols.index("combo_sql")] if "combo_sql" in cols else ""
        return m
    # 无选择（或选择查不到）：Step4 自动推荐规则集
    sql = Q.final_rules_sql(cfg, case_id, exp, dt)
    cache_key = result_cache.make_key("final_rules", case_id, exp, dt)
    res = _cached(cache_key, "final_rules", case_id, exp, dt, lambda: sql)
    if res["status"] == "done" and res.get("rows"):
        cols = res["columns"]
        iC, iS = cols.index("combo_id"), cols.index("combo_sql")
        return {str(r[iC]): (r[iS] or "") for r in res["rows"]}
    return {}


@router.get("/api/canvas/jobs")
def list_canvas_jobs(limit: int = 50):
    """全局最近画布 job 列表。"""
    import canvas_job_store as store
    return {"jobs": store.list_recent(limit)}


@router.get("/api/canvas/jobs/{job_id}")
def get_canvas_job(job_id: str):
    """单 job 详情。"""
    import canvas_job_store as store
    job = store.get_job(job_id)
    if not job:
        raise HTTPException(404, "job 不存在")
    return job


@router.post("/api/canvas/jobs/{job_id}/retry")
def retry_canvas_job(job_id: str):
    """手动重试：needs_reconcile/failed → pending，调度器重新提交画布。"""
    import canvas_job_store as store
    job = store.get_job(job_id)
    if not job:
        raise HTTPException(404, "job 不存在")
    if job["status"] not in ("needs_reconcile", "failed"):
        raise HTTPException(400, f"仅 needs_reconcile/failed 可重试，当前 {job['status']}")
    if not store.reset_to_pending(job_id):
        raise HTTPException(400, "重置失败")
    return {"job_id": job_id, "status": "pending"}


# ── 登录 / 登出（SSO CIBA，移植自反爬 migrate-from-clue-agent）──────────

class LoginRequest(BaseModel):
    mis: str


def _allowed_mis() -> set:
    """允许登录的 MIS 列表：Supabase system_config 表优先，硬编码兜底。"""
    fallback = {"wucheng17"}
    try:
        import canvas_job_store as _cjs
        rows = _cjs._sb().execute(
            "SELECT value FROM system_config WHERE category='access' AND key='allowed_mis'")
        if rows:
            import json as _json
            val = rows[0].get("value")
            if isinstance(val, str):
                val = _json.loads(val)
            allowed = set(val or [])
            if allowed:
                return allowed
    except Exception:
        pass
    return fallback


@router.post("/api/auth/login")
async def auth_login(body: LoginRequest, request: Request):
    """发起登录：调 Rhino AI CIBA 获取 SSO token。
    - 200 ok：登录成功，写 session
    - 200 pending_auth：需大象授权，返回 auth_url 供前端展示"""
    from client.sso_auth import get_sso_manager
    raw = body.mis.strip()
    if not raw:
        raise HTTPException(400, "mis 不能为空")
    is_admin = raw.startswith("admin_")
    mis = raw[len("admin_"):] if is_admin else raw
    if not is_admin and mis not in _allowed_mis():
        raise HTTPException(403, "未授权用户")
    try:
        get_sso_manager().get_mtsi_token(mis)
        request.session["mis"] = mis
        request.session["is_admin"] = is_admin
        return {"status": "ok", "mis": mis}
    except RuntimeError as e:
        msg = str(e)
        if "大象授权" in msg:
            import re
            m = re.search(r'https?://\S+', msg)
            return {"status": "pending_auth", "auth_url": m.group(0) if m else ""}
        raise HTTPException(500, msg)


@router.post("/api/auth/login/poll")
async def auth_login_poll(body: LoginRequest, request: Request):
    """轮询登录状态：大象授权后前端轮询此接口直到成功。"""
    from client.sso_auth import get_sso_manager
    raw = body.mis.strip()
    is_admin = raw.startswith("admin_")
    mis = raw[len("admin_"):] if is_admin else raw
    if not is_admin and mis not in _allowed_mis():
        raise HTTPException(403, "未授权用户")
    try:
        get_sso_manager().get_mtsi_token(mis)
        request.session["mis"] = mis
        request.session["is_admin"] = is_admin
        return {"status": "ok", "mis": mis}
    except RuntimeError as e:
        if "大象授权" in str(e):
            return {"status": "pending_auth"}
        raise HTTPException(500, str(e))


@router.post("/api/auth/logout")
async def auth_logout(request: Request):
    mis = request.session.pop("mis", "")
    if mis:
        from client.sso_auth import get_sso_manager
        get_sso_manager().invalidate(mis)
    return {"status": "ok"}


@router.get("/api/auth/me")
async def auth_me(request: Request):
    mis = request.session.get("mis", "")
    return {"mis": mis, "logged_in": bool(mis), "is_admin": request.session.get("is_admin", False)}


# ── 白名单管理（仅管理员）─────────────────────────────────────────────────

def _admin_mis() -> set:
    """管理员 MIS 集合：system_config 表 admin_mis，wucheng17 兜底。"""
    try:
        import canvas_job_store as _cjs
        rows = _cjs._sb().execute(
            "SELECT value FROM system_config WHERE category='access' AND key='admin_mis'")
        if rows:
            import json as _json
            val = rows[0].get("value")
            if isinstance(val, str):
                val = _json.loads(val)
            admins = set(val or [])
            if admins:
                return admins
    except Exception:
        pass
    return {"wucheng17"}


def _is_admin(request: Request) -> bool:
    return bool(request.session.get("is_admin")
                or request.session.get("mis") in _admin_mis())


def _now_iso() -> str:
    from datetime import datetime as _d
    return _d.now().strftime("%Y-%m-%d %H:%M:%S")


def _save_config_list(key: str, values: list) -> None:
    import json as _json
    from datetime import datetime
    import canvas_job_store as _cjs
    _cjs._sb().execute(
        "INSERT INTO system_config (category, key, value, updated_at) "
        "VALUES ('access', $1, $2::jsonb, $3) "
        "ON CONFLICT (category, key) DO UPDATE SET value=EXCLUDED.value, updated_at=EXCLUDED.updated_at",
        [key, _json.dumps(values), datetime.now().strftime("%Y-%m-%d %H:%M:%S")])


@router.get("/api/auth/allowed_mis")
async def get_allowed_mis(request: Request):
    """查白名单 + 管理员列表（仅管理员）。"""
    if not _is_admin(request):
        raise HTTPException(403, "仅管理员可查看白名单")
    return {"allowed_mis": sorted(_allowed_mis()), "admin_mis": sorted(_admin_mis())}


class AllowedMisRequest(BaseModel):
    mis_list: list


@router.put("/api/auth/allowed_mis")
async def put_allowed_mis(body: AllowedMisRequest, request: Request):
    """保存白名单（仅管理员）。管理员 MIS 会被强制保留（防自锁）。"""
    if not _is_admin(request):
        raise HTTPException(403, "仅管理员可修改白名单")
    cleaned = sorted({str(m).strip() for m in body.mis_list if str(m).strip()})
    admins = _admin_mis()
    missing_admins = admins - set(cleaned)
    if missing_admins:
        cleaned = sorted(set(cleaned) | admins)
        sys_log("warning", f"[auth] 白名单保存自动补回管理员: {sorted(missing_admins)}")
    _save_config_list("allowed_mis", cleaned)
    sys_log("info", f"[auth] 白名单已更新 by={request.session.get('mis')} n={len(cleaned)}")
    return {"allowed_mis": cleaned, "auto_added_admins": sorted(missing_admins)}


class AllowedBizRequest(BaseModel):
    biz_list: list


@router.get("/api/auth/allowed_biz")
async def get_allowed_biz(request: Request):
    """查外部接口 biz 白名单（仅管理员）。"""
    if not _is_admin(request):
        raise HTTPException(403, "仅管理员可查看业务白名单")
    return {"allowed_biz": sorted(_allowed_biz())}


@router.put("/api/auth/allowed_biz")
async def put_allowed_biz(body: AllowedBizRequest, request: Request):
    """保存外部接口 biz 白名单（仅管理员）。"""
    if not _is_admin(request):
        raise HTTPException(403, "仅管理员可修改业务白名单")
    cleaned = sorted({str(b).strip() for b in body.biz_list if str(b).strip()})
    _save_config_list("allowed_biz", cleaned)
    sys_log("info", f"[auth] biz 白名单已更新 by={request.session.get('mis')} n={len(cleaned)}")
    return {"allowed_biz": cleaned}


# ── 风险事件排查流水线（移植自 pipline/agent_pipline v9）───────────────────

class PipelineStartRequest(BaseModel):
    dt: Optional[str] = None              # 缺省 = 今天
    sample_pct: int = 100                 # 采样比例
    max_groups: Optional[int] = None      # 最大处理条数
    concurrency: Optional[int] = None     # 批次并发数（空 = 全局默认 4）
    manual: bool = False                  # 手工指定分析：扫感知表全分区 risk_level='9'，每个 group_id 取最新 dt


@router.get("/api/pipeline/manual_scan")
def pipeline_manual_scan(dt: Optional[str] = None):
    """手工指定分析·扫描（独立页面用）：查指定日期分区 risk_level='9' 的团伙清单。
    dt 缺省 = 今天。只查询不建批——前端展示列表（含已分析标记）供用户勾选确认。"""
    import pipeline_store as store
    from config import get_config
    from datetime import datetime as _dt
    scan_dt = (dt or _dt.now().strftime("%Y%m%d")).replace("-", "")
    sql = (f"SELECT group_id, max(dt) AS latest_dt, max(platform_app_partner) AS pap, "
           f"max(label) AS label, max(items_str) AS items_str "
           f"FROM {get_config().pipeline.perception_table} "
           f"WHERE dt='{scan_dt}' AND risk_level='9' AND group_id IS NOT NULL AND group_id != '' "
           f"GROUP BY group_id")
    try:
        res = _run_hive_sync(sql, max_wait_s=300)
    except Exception as e:
        return {"status": 0, "message": f"扫描失败: {str(e)[:200]}"}
    if res["status"] != "done":
        return {"status": 0, "message": f"读感知表失败: {(res.get('error') or '')[:200]}"}
    rows = res.get("rows") or []
    # 已分析标记：pipeline_jobs 中已有该 group_id 的记录（不区分成败——同 group 不重复分析）
    analyzed = set()
    try:
        for r in store._sb().execute("SELECT DISTINCT group_id FROM pipeline_jobs"):
            analyzed.add(str(r.get("group_id") or ""))
    except Exception:
        pass
    records = []
    for r in rows:
        gid = str(r[0])
        records.append({"group_id": gid, "dt": str(r[1]),
                        "platform_app_partner": str(r[2] or ""),
                        "label": str(r[3] or ""),
                        "items_str": str(r[4] or "")[:500],
                        "analyzed": gid in analyzed})
    return {"status": 1, "dt": scan_dt, "total": len(records), "groups": records}


class ManualStartRequest(BaseModel):
    dt: Optional[str] = None                   # 扫描日期（页面上选的，随记录回传）
    group_ids: list                             # 勾选的 group_id 列表
    records: Optional[list] = None             # 勾选记录全量回传（group_id/dt/pap/label/items_str）
    concurrency: Optional[int] = None


@router.post("/api/pipeline/manual_start")
def pipeline_manual_start(body: ManualStartRequest):
    """手工指定分析·启动（独立页面用）：只对勾选的 group 建批。
    记录从前端回传（扫描结果），后端再按 pipeline_jobs 去重兜底。"""
    import pipeline_store as store
    from datetime import datetime as _dt
    if not body.group_ids:
        return {"status": 0, "message": "未勾选任何团伙"}
    dt = (body.dt or _dt.now().strftime("%Y%m%d")).replace("-", "")
    # 优先用前端回传的完整记录；缺字段时以 dt 兜底
    by_gid = {str(r.get("group_id")): r for r in (body.records or []) if r.get("group_id")}
    records = []
    for gid in body.group_ids:
        r = by_gid.get(str(gid)) or {}
        records.append({"group_id": str(gid),
                        "dt": str(r.get("dt") or dt),
                        "platform_app_partner": str(r.get("platform_app_partner") or ""),
                        "label": str(r.get("label") or ""),
                        "risk_level": "9",
                        "items_str": str(r.get("items_str") or "")[:5000]})
    try:
        batch_id = store.create_manual_batch(records, body.concurrency)
    except Exception as e:
        sys_log("error", f"[manual_start] 批次创建失败: {type(e).__name__}: {str(e)[:300]}")
        return {"status": 0, "message": f"批次创建失败: {str(e)[:200] or type(e).__name__}"}
    if not batch_id:
        return {"status": 0, "message": "勾选的团伙全部已分析过（无新增）"}
    sys_log("info", f"[manual_start] 手工指定分析批次 dt={dt} batch={batch_id[:8]} "
                    f"勾选={len(body.group_ids)} 建批={len(records)}")
    return {"status": 1, "batch_id": batch_id, "dt": dt, "total": len(records)}


@router.post("/api/pipeline/start")
def pipeline_start(body: PipelineStartRequest):
    """启动风险事件排查流水线：读感知表当日团伙 → 建 pipeline_jobs 批次（PipelineScheduler 逐个推进）。"""
    import pipeline_store as store
    from config import get_config
    from datetime import datetime as _dt
    dt = body.dt or _dt.now().strftime("%Y%m%d")
    # 双表：感知表出 group 清单，judge 表出团伙判定三字段（is_risk_group/reason/is_missed）。
    # 感知表是明细行（同 group_id 数数百行，单日 700 万+），SQL 侧 GROUP BY 去重——
    # 只拉 distinct group，不在服务进程里吞明细（Python 侧 create_batch 仍保底再去重一次）。
    # risk_level 过滤放开（2026-10-13 用户定）：不再限制 1/2，3 也入流水线——
    # 当前 case 量级完全消费得完；9（手工指定）仍走独立手工通道不混入定时批次。
    sql = (f"SELECT group_id, max(platform_app_partner) AS platform_app_partner, max(label) AS label, "
           f"max(risk_level) AS risk_level, max(items_str) AS items_str "
           f"FROM {get_config().pipeline.perception_table} "
           f"WHERE dt='{dt}' AND group_id IS NOT NULL AND group_id != '' "
           f"AND risk_level != '9' GROUP BY group_id")
    res = _run_hive_sync(sql, max_wait_s=300)
    if res["status"] != "done":
        return {"status": 0, "message": f"读感知表失败: {(res.get('error') or '')[:150]}"}
    rows = res.get("rows") or []
    cols = res["columns"]
    iG, iP, iL = cols.index("group_id"), cols.index("platform_app_partner"), cols.index("label")
    jres = _run_hive_sync(
        f"SELECT group_id, is_risk_group, reason, is_missed FROM {get_config().pipeline.judge_table} "
        f"WHERE dt='{dt}'", max_wait_s=120)
    judge = {}
    if jres["status"] == "done" and jres.get("rows"):
        jc = jres["columns"]
        jiG, jiR, jiRs, jiM = (jc.index("group_id"), jc.index("is_risk_group"),
                                jc.index("reason"), jc.index("is_missed"))
        for r in jres["rows"]:
            judge[str(r[jiG])] = ("1" if str(r[jiR]) == "1" else "0",
                                  str(r[jiRs] or ""), "1" if str(r[jiM]) == "1" else "0")
    else:
        return {"status": 0, "message": f"读团伙判定表失败: {(jres.get('error') or '')[:150]}"}
    records = []
    for r in rows:
        gid = str(r[iG])
        j = judge.get(gid)
        records.append({"group_id": gid, "platform_app_partner": r[iP], "label": r[iL],
                        "is_risk_group": j[0] if j else "0",
                        "reason": j[1] if j else "judge 表无该 group 当日记录",
                        "is_missed": j[2] if j else "0"})
    if not records:
        return {"status": 0, "message": f"dt={dt} 感知表无数据"}
    batch_id = store.create_batch(dt, records, body.sample_pct, body.max_groups, body.concurrency)
    return {"status": 1, "batch_id": batch_id, "dt": dt, "total": len(records),
            "sample_pct": body.sample_pct, "max_groups": body.max_groups,
            "concurrency": body.concurrency, "message": "SUCCESS"}


@router.get("/api/pipeline/batches")
def pipeline_batches(limit: int = 20):
    """流水线批次列表。"""
    import pipeline_store as store
    return {"batches": store.list_batches(min(limit, 100))}


@router.get("/api/pipeline/batch/{batch_id}")
def pipeline_batch_detail(batch_id: str, stage: Optional[str] = None,
                          dt: Optional[str] = None, is_group: Optional[str] = None,
                          penalty: Optional[str] = None, tichun: Optional[str] = None,
                          risk: Optional[str] = None, q: Optional[str] = None,
                          tree: Optional[str] = None,
                          page: int = 1, limit: int = 100):
    """批次详情：分层统计 + 任务明细分页。
    stage 树节点 / dt 日期 / penalty 处置动作 / risk 团伙定性（批量注册等，包含匹配）/
    tichun 提纯链路细分（queue/pre_done/pre_fail/lq_done/lq_fail/inj_done）/
    tree 批次状态流程树节点（与状态列完全同口径，含 flow 联动桶）过滤。"""
    import pipeline_store as store
    store.ensure_batch_rows()
    limit = min(max(limit, 1), 200)
    page = max(page, 1)
    # PG 瞬断容错：1 次重试，仍失败返回结构化 JSON（前端可显示错误信息而非解析崩溃）
    try:
        jobs = store.list_by_batch(batch_id, limit=limit, offset=(page - 1) * limit,
                                   stage=stage, dt=dt, is_group=is_group, penalty=penalty,
                                   tichun=tichun, risk=risk, q=q, tree=tree)
    except Exception as e:
        import time as _time
        _time.sleep(1)
        try:
            jobs = store.list_by_batch(batch_id, limit=limit, offset=(page - 1) * limit,
                                       stage=stage, dt=dt, is_group=is_group, penalty=penalty,
                                       tichun=tichun, risk=risk, q=q, tree=tree)
        except Exception:
            sys_log("warning", f"[pipeline] 批次明细查询失败 batch={batch_id[:8]}: {str(e)[:150]}")
            return {"batch_id": batch_id, "jobs": [], "stats": {}, "page": page,
                    "limit": limit, "total": 0, "pages": 0, "dts": [],
                    "error": f"数据库连接异常（瞬断），请稍后刷新: {str(e)[:100]}"}
    total = store.count_jobs(batch_id, stage=stage, dt=dt, is_group=is_group,
                             penalty=penalty, tichun=tichun, risk=risk, q=q, tree=tree)
    return {"batch_id": batch_id, "jobs": jobs, "stats": store.batch_stats(batch_id),
            "page": page, "limit": limit, "total": total,
            "pages": (total + limit - 1) // limit, "dts": store.list_batch_dts(batch_id)}


@router.post("/api/pipeline/jobs/{job_id}/retry")
def pipeline_job_retry(job_id: str):
    """单个 group 重跑：failed → pending。"""
    import pipeline_store as store
    job = store.get_job(job_id)
    if not job:
        raise HTTPException(404, "job 不存在")
    if job["status"] != "failed":
        raise HTTPException(400, f"仅 failed 可重试，当前 {job['status']}")
    store.update_stage(job_id, "pending", status="running", error_message=None)
    return {"job_id": job_id, "status": "pending"}


# ── mlp 提交总开关（页面可控，实时生效）────────────────────────────────────

def _mlp_submit_enabled() -> bool:
    from mlp_switch import mlp_submit_enabled
    return mlp_submit_enabled()


@router.get("/api/mlp_submit/enabled")
def get_mlp_submit(request: Request):
    """查 mlp 提交开关状态（登录即可见）。"""
    return {"enabled": _mlp_submit_enabled()}


@router.put("/api/mlp_submit/enabled")
async def set_mlp_submit(body: AllowedBizRequest, request: Request):
    """设置 mlp 提交开关（仅管理员）。AllowedBizRequest 复用：biz_list=[true/false]。"""
    if not _is_admin(request):
        raise HTTPException(403, "仅管理员可操作")
    val = bool((body.biz_list or [False])[0])
    _save_config_list("mlp_submit", [val])
    sys_log("info", f"[mlp_submit] 开关已设为 {val} by={request.session.get('mis')}")
    return {"enabled": val}


@router.get("/api/mlp_submit/limit")
def get_mlp_limit(request: Request):
    """查全局并发上限与当前在跑数（登录即可见）。"""
    from mlp_switch import global_limit, global_running_count
    return {"limit": global_limit(), "running": global_running_count()}


@router.put("/api/mlp_submit/limit")
async def set_mlp_limit(body: AllowedBizRequest, request: Request):
    """设置全局并发上限（仅管理员，1-100）。AllowedBizRequest 复用：biz_list=[数值]。"""
    if not _is_admin(request):
        raise HTTPException(403, "仅管理员可操作")
    try:
        val = int((body.biz_list or [20])[0])
    except (TypeError, ValueError):
        raise HTTPException(400, "limit 需为整数")
    if not 1 <= val <= 100:
        raise HTTPException(400, "limit 需在 1-100 之间")
    _save_config_list("mlp_global_limit", [val])
    sys_log("info", f"[mlp_submit] 全局并发上限已设为 {val} by={request.session.get('mis')}")
    return {"limit": val}


# ── 风险流水线运行控制（开关 + 全局并发，页面实时生效）──────────────────────

@router.get("/api/pipeline/control")
def get_pipeline_control(request: Request):
    """查流水线运行开关 + 全局并发配置 + 当前负载（DB 跨实例口径）。"""
    from pipeline_scheduler import (pipeline_enabled, pipeline_concurrency,
                                    PIPELINE_HARD_CAP, tichun_blocked_risk_types)
    import pipeline_store as store
    return {"enabled": pipeline_enabled(),
            "concurrency": pipeline_concurrency(),
            "hard_cap": PIPELINE_HARD_CAP,  # 代码级硬上限（任何配置不可突破）
            "inflight": store.count_inflight(),          # 在推进的 group 数（判定/定性/建提纯，跨实例）
            "tichun_polling": store.count_by_stage("tichun_poll"),  # 提纯轮询中（轻量，不占并发配额）
            "blocked_risk_types": tichun_blocked_risk_types()}      # 提纯拦截的风险类型清单


class PipelineControlRequest(BaseModel):
    enabled: Optional[bool] = None       # 开关
    concurrency: Optional[int] = None    # 全局并发（1-100）
    blocked_risk_types: Optional[list] = None   # 提纯拦截的风险类型（空列表=不拦截）


@router.put("/api/pipeline/control")
async def set_pipeline_control(body: PipelineControlRequest, request: Request):
    """设置流水线开关/全局并发/提纯风险类型拦截（仅管理员，实时生效无需重启）。"""
    if not _is_admin(request):
        raise HTTPException(403, "仅管理员可操作")
    if body.enabled is not None:
        _save_config_list("pipeline_enabled", [bool(body.enabled)])
        sys_log("info", f"[pipeline] 开关已设为 {body.enabled} by={request.session.get('mis')}")
    if body.concurrency is not None:
        if not 1 <= body.concurrency <= 100:
            raise HTTPException(400, "concurrency 需在 1-100 之间")
        # 写入即 clamp 到硬上限（代码焊死，改库也会被读取端二次 clamp）
        from pipeline_scheduler import PIPELINE_HARD_CAP
        eff = min(int(body.concurrency), PIPELINE_HARD_CAP)
        _save_config_list("pipeline_concurrency", [eff])
        sys_log("info", f"[pipeline] 全局并发已设为 {eff} by={request.session.get('mis')}")
    if body.blocked_risk_types is not None:
        types = [str(t).strip() for t in body.blocked_risk_types if str(t).strip()]
        _save_config_list("tichun_blocked_risk_types", types)
        sys_log("info", f"[pipeline] 提纯拦截风险类型已设为 {types} by={request.session.get('mis')}")
    from pipeline_scheduler import pipeline_enabled, pipeline_concurrency, tichun_blocked_risk_types
    return {"enabled": pipeline_enabled(), "concurrency": pipeline_concurrency(),
            "blocked_risk_types": tichun_blocked_risk_types()}


class RecallAccountsRequest(BaseModel):
    recall_sql: str
    combo_id: Optional[str] = None     # 全局 combo_id（case_id_cNNN）：表4 预落账号直查键
    experiment: Optional[str] = None   # 表4 查询分区（缺省 = default）
    dt: Optional[str] = None          # 表4 查询分区（缺省 = 自动取最新）


@router.post("/api/cases/{case_id}/recall_accounts")
def recall_accounts(case_id: str, body: RecallAccountsRequest):
    """Step3 A 区「查询捞回账号」：recall_sql 走 Talos 实查。
    兼容两种落表格式：(SELECT ...) 子查询（包一层 distinct）；
    SELECT ... FROM (...) 完整 SQL（直接查，取首列）。
    返回 {status, total, accounts:[user_id...]}（最多 5000，防大结果）。"""
    import re as _re
    # 表4 预落账号直查（2026-10-12 加）：step4b 已把每 combo 的 recall_sql 结果落
    # acc_sec_gang_recall_accounts（0d908ee），这里秒查免现场回捞 90 天窗扫描。
    # 未落（老 case / 回捞 0 人 / 写表失败）→ 回退 recall_sql 实查。
    if body.combo_id:
        try:
            from sql_templates import recall_ids_by_combo_sql
            exp_r = body.experiment or "default"
            res_r = None
            dt_r = body.dt
            if not dt_r:
                # 自动取该 case 最新分区（同 latest_dt_sql 语义，直接内联小查询）
                j = _run_hive_sync(
                    f"SELECT max(dt) AS d FROM {_cfg().hive_tables.recall_accounts} "
                    f"WHERE case_id='{body.combo_id.split('_c')[0]}'", max_wait_s=60)
                dt_r = (j.get("rows") or [[""]])[0][0] if j.get("status") == "done" else None
            if dt_r:
                sql_r = recall_ids_by_combo_sql(_cfg(), body.combo_id.split("_c")[0],
                                                exp_r, dt_r, body.combo_id)
                res_r = _run_hive_sync(sql_r, max_wait_s=60)
            if res_r and res_r.get("status") == "done" and (res_r.get("rows") or []):
                _rows = res_r["rows"]
                return {"status": "done", "total": len(_rows),
                        "accounts": [str(r[0]) for r in _rows[:5000]],
                        "truncated": len(_rows) > 5000, "source": "precomputed"}
            sys_log("info", f"[recall_accounts] 表4 无 {body.combo_id} 预落数据"
                            f"（dt={dt_r}），回退 recall_sql 实查")
        except Exception as e:
            sys_log("warning", f"[recall_accounts] 表4 直查异常（回落实查）: {str(e)[:150]}")
    recall_sql = (body.recall_sql or "").strip().rstrip(";")
    if not recall_sql:
        raise HTTPException(400, "recall_sql 不能为空")
    # 安全校：只允许 SELECT 开头（防注入/误写；非 DDL/DML）。
    # 分号仅禁止出现在字符串常量外（UA 等常量里合法含分号，如 "hwstore; ADA-AL00"）
    if not _re.match(r"^(\(\s*)?SELECT\b", recall_sql, _re.I):
        raise HTTPException(400, "recall_sql 需为 SELECT 查询")
    if _re.search(r";", _re.sub(r"'[^']*'", "", recall_sql)):
        raise HTTPException(400, "recall_sql 不允许包含分号")
    if _re.match(r"^\(\s*SELECT", recall_sql, _re.I):
        # 子查询无表别名（r0.user_id 找不到——2026-09-22 实锤"r0.user_id字段不存在"），
        # 直接选裸 user_id（子查询首列即账号列）
        sql = f"SELECT DISTINCT user_id FROM {recall_sql}"
    else:
        sql = recall_sql  # 完整 SQL（SELECT r0.user_id FROM (...)），首列即 user_id
    res = _run_hive_sync(sql, max_wait_s=120)
    if res["status"] != "done":
        return {"status": "failed", "error": (res.get("error") or "")[:200], "total": 0, "accounts": []}
    rows = res.get("rows") or []
    accounts = [str(r[0]) for r in rows[:5000]]
    return {"status": "done", "total": len(rows), "accounts": accounts,
            "truncated": len(rows) > 5000}


@router.post("/api/pipeline/batch/{batch_id}/stop")
def pipeline_batch_stop(batch_id: str, request: Request):
    """停止批次：未终态 job 置 cancelled，不再被调度器拉取。
    在跑的判定/画布（≤并发数）自然跑完当前步骤后停止推进。仅管理员。"""
    if not _is_admin(request):
        raise HTTPException(403, "仅管理员可操作")
    import pipeline_store as store
    r = store.stop_batch(batch_id)
    sys_log("info", f"[pipeline] 批次已停止 batch={batch_id[:8]} 取消 job={r['cancelled']} "
                    f"联动终止 flow={r.get('flows_terminated', 0)} by={request.session.get('mis')}")
    return {"status": 1, "batch_id": batch_id, "cancelled": r["cancelled"],
            "flows_terminated": r.get("flows_terminated", 0)}


@router.post("/api/pipeline/batch/{batch_id}/retry_failed")
def pipeline_batch_retry_failed(batch_id: str, kind: Optional[str] = None):
    """批量重试批次内 failed 的 job。
    kind=judge（默认）只重试无法判定（无 is_group 结果的 failed）；
    kind=all 重试全部 failed。返回重置数量。"""
    import pipeline_store as store
    from datetime import datetime as _dt
    now = _dt.now().strftime("%Y-%m-%d %H:%M:%S")
    try:
        if kind == "all":
            rows = store._sb().execute(
                "SELECT id FROM pipeline_jobs WHERE batch_id=$1 AND status='failed'", [batch_id])
        else:
            rows = store._sb().execute(
                "SELECT id FROM pipeline_jobs WHERE batch_id=$1 AND status='failed' "
                "AND extra->'is_group'->>'is_risk_group' IS NULL", [batch_id])
        n = 0
        for r in rows:
            store._sb().execute(
                "UPDATE pipeline_jobs SET stage='pending', status='running', "
                "error_message=NULL, updated_at=$1 WHERE id=$2", [now, r["id"]])
            n += 1
        sys_log("info", f"[pipeline] 批量重试 batch={batch_id[:8]} kind={kind or 'judge'} 重置 {n} 个")
        return {"status": 1, "reset": n, "kind": kind or "judge"}
    except Exception as e:
        raise HTTPException(500, f"批量重试失败: {str(e)[:200]}")


@router.post("/api/pipeline/batch/{batch_id}/retry_flow_failed")
def pipeline_batch_retry_flow_failed(batch_id: str, flow_stage: str):
    """批量重试批次内提纯链路失败的 flow（按阶段：preprocess/laoquan）。
    调 flow_store.retry_from_stage 从失败阶段续跑。返回重置数量。"""
    import pipeline_store as pstore
    import flow_store
    if flow_stage not in ("preprocess", "laoquan"):
        raise HTTPException(400, "flow_stage 需为 preprocess 或 laoquan")
    try:
        rows = pstore._sb().execute(
            "SELECT f.id AS fid FROM flow_jobs f "
            "JOIN pipeline_jobs p ON f.case_id = p.extra->>'tichun_case_id' "
            "WHERE p.batch_id=$1 AND f.status='failed' AND f.stage=$2", [batch_id, flow_stage])
        n = 0
        for r in rows:
            if flow_store.retry_from_stage(r["fid"], flow_stage):
                n += 1
        sys_log("info", f"[pipeline] 批量重试flow batch={batch_id[:8]} stage={flow_stage} 重置 {n} 个")
        return {"status": 1, "reset": n, "flow_stage": flow_stage}
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(500, f"批量重试失败: {str(e)[:200]}")


@router.post("/api/cases/{case_id}/urgent")
def case_urgent(case_id: str, request: Request):
    """给 case 的 pending 画布任务打加急标记（extra.priority=1）。
    覆盖四类画布任务（提纯捞全/预处理/误伤评估/处置）中 status=pending 的——
    已提交的改不了（MLP 平台侧已开跑）。加急任务提交时走独立并发槽
    （全局 limit + urgent_extra，加急自身并发 ≤ urgent_extra）。"""
    if not _is_admin(request):
        raise HTTPException(403, "仅管理员可操作")
    marked = []
    try:
        import canvas_job_store as cjs
        rows = cjs._sb().execute(
            "UPDATE canvas_jobs SET extra = COALESCE(extra,'{}'::jsonb) || '{\"priority\":1}'::jsonb, "
            "updated_at=$1 WHERE case_id=$2 AND status='pending' RETURNING id",
            [_now_iso(), case_id])
        marked += [f"laoquan:{r['id'][:8]}" for r in rows]
    except Exception as e:
        sys_log("warning", f"[urgent] laoquan 标记失败 case={case_id}: {str(e)[:150]}")
    try:
        import preprocess_store as pp
        rows = pp._sb().execute(
            "UPDATE preprocess_jobs SET extra = COALESCE(extra,'{}'::jsonb) || '{\"priority\":1}'::jsonb, "
            "updated_at=$1 WHERE case_id=$2 AND status='pending' RETURNING id",
            [_now_iso(), case_id])
        marked += [f"preprocess:{r['id'][:8]}" for r in rows]
    except Exception as e:
        sys_log("warning", f"[urgent] preprocess 标记失败 case={case_id}: {str(e)[:150]}")
    try:
        import injury_eval_store as ies
        rows = ies._sb().execute(
            "UPDATE injury_eval_jobs SET extra = COALESCE(extra,'{}'::jsonb) || '{\"priority\":1}'::jsonb, "
            "updated_at=$1 WHERE case_id=$2 AND status='pending' RETURNING id",
            [_now_iso(), case_id])
        marked += [f"injury_eval:{r['id'][:8]}" for r in rows]
    except Exception as e:
        sys_log("warning", f"[urgent] injury_eval 标记失败 case={case_id}: {str(e)[:150]}")
    try:
        import punish_check_store as pcs
        rows = pcs._sb().execute(
            "UPDATE punish_check_jobs SET extra = COALESCE(extra,'{}'::jsonb) || '{\"priority\":1}'::jsonb, "
            "updated_at=$1 WHERE case_id=$2 AND status='pending' RETURNING id",
            [_now_iso(), case_id])
        marked += [f"punish_check:{r['id'][:8]}" for r in rows]
    except Exception as e:
        sys_log("warning", f"[urgent] punish_check 标记失败 case={case_id}: {str(e)[:150]}")
    if not marked:
        return {"status": 0, "message": "该 case 无 pending 状态的画布任务（可能已提交或未建任务）", "marked": []}
    sys_log("info", f"[urgent] case={case_id} 加急标记 by={request.session.get('mis')}: {', '.join(marked)}")
    return {"status": 1, "marked": marked, "message": f"已加急 {len(marked)} 个任务"}


@router.get("/api/mlp_submit/urgent_limit")
def get_urgent_limit():
    """查加急并发槽数。"""
    from mlp_switch import urgent_extra, urgent_running_count
    return {"urgent_extra": urgent_extra(), "urgent_running": max(urgent_running_count(), 0)}


@router.put("/api/mlp_submit/urgent_limit")
async def set_urgent_limit(body: AllowedBizRequest, request: Request):
    """设置加急并发槽数（仅管理员）。AllowedBizRequest 复用：biz_list=[n]，0-50。"""
    if not _is_admin(request):
        raise HTTPException(403, "仅管理员可操作")
    try:
        n = int(body.biz_list[0])
    except (IndexError, TypeError, ValueError):
        raise HTTPException(400, "需提供 [n]")
    if not 0 <= n <= 50:
        raise HTTPException(400, "加急槽数需在 0-50 之间")
    _save_config_list("mlp_urgent_limit", [n])
    sys_log("info", f"[mlp_submit] 加急并发槽已设为 {n} by={request.session.get('mis')}")
    from mlp_switch import urgent_extra
    return {"urgent_extra": urgent_extra()}


@router.get("/api/mlp_submit/ban_hours")
def get_ban_hours(request: Request):
    """查提交禁止时段（登录可见）：{start, end, in_ban}。start==end 表示无限制。"""
    from mlp_switch import ban_hours, _in_ban_window
    s, e = ban_hours()
    return {"start": s, "end": e, "in_ban": _in_ban_window()}


@router.put("/api/mlp_submit/ban_hours")
async def set_ban_hours(body: AllowedBizRequest, request: Request):
    """设置提交禁止时段（仅管理员）。AllowedBizRequest 复用：biz_list=[start, end] 小时。
    start==end 表示无限制（全时段可提交）。"""
    if not _is_admin(request):
        raise HTTPException(403, "仅管理员可操作")
    try:
        s, e = int(body.biz_list[0]), int(body.biz_list[1])
    except (IndexError, TypeError, ValueError):
        raise HTTPException(400, "需提供 [start_hour, end_hour]")
    if not (0 <= s <= 24 and 0 <= e <= 24):
        raise HTTPException(400, "小时需在 0-24 之间")
    _save_config_list("submit_ban_hours", [s, e])
    sys_log("info", f"[mlp_submit] 禁止提交时段已设为 {s}:00-{e}:00 by={request.session.get('mis')}")
    from mlp_switch import ban_hours, _in_ban_window
    s2, e2 = ban_hours()
    return {"start": s2, "end": e2, "in_ban": _in_ban_window()}


@router.get("/api/flow/stats")
def flow_stats(dt: Optional[str] = None, stage: Optional[str] = None, q: Optional[str] = None):
    """全流程各阶段数量统计（跟随列表筛选条件）。
    dt/stage/q 与 /api/flow/list 同参（统计基线 = 筛掉的其他条件、放宽 stage 维度）。
    dt 缺省 = 今日+昨日。"""
    import flow_store as store
    from datetime import datetime as _dt, timedelta as _td
    if not dt:
        today = _dt.now().strftime("%Y%m%d")
        yesterday = (_dt.now() - _td(days=1)).strftime("%Y%m%d")
        dts = [today, yesterday]
    else:
        dts = [dt]
    counts = {}
    total = 0
    for d in dts:
        rows = store._sb().execute(
            "SELECT stage, status, count(*) AS n FROM flow_jobs "
            "WHERE dt=$1 GROUP BY stage, status", [d])
        for r in rows:
            key = _stage_bucket(r["stage"], r["status"])
            counts[key] = counts.get(key, 0) + int(r["n"])
            total += int(r["n"])
    # q 搜索时需逐条过滤（量小可接受）——stage 筛选不影响分桶统计（展示全部桶）
    if q:
        rows = store._sb().execute(
            "SELECT stage, status FROM flow_jobs WHERE dt = ANY($1) AND "
            "(case_id LIKE $2 OR group_id LIKE $2)", [dts, f"%{q}%"])
        counts, total = {}, 0
        for r in rows:
            key = _stage_bucket(r["stage"], r["status"])
            counts[key] = counts.get(key, 0) + 1
            total += 1
    return {"total": total, "counts": counts,
            "dts": dts, "today": dts[0] if len(dts) == 1 else None}


def _stage_bucket(stage: str, status: str) -> str:
    """flow stage/status → 统计桶（与列表节点一致）。"""
    if stage == "preprocess":
        return "preprocess"
    if stage == "snapshot":
        return "snapshot"
    if stage == "laoquan":
        return "laoquan"
    if stage in ("injury_eval", "punish") and status == "running":
        return "laoquan_done"      # 已过捞全（评估/处置中）
    if stage == "injury_eval":
        return "injury_eval"
    if stage == "punish":
        return "punish"
    if stage == "done":
        return "done"
    if status == "failed":
        return "failed"
    if stage == "skipped":
        return "skipped"
    return stage


# ── 规则判定 Agent（CatX 五维度判定 → 替换 Step4 自动推荐标准）───────────

# recall_sql 地理条件字段（出现即说明"地理最大占比"是按 SQL 先验选定的地域，
# 命中人群天然集中——geo_pass 的高占比是构造结果而非自发聚集）
_GEO_COND_FIELDS = ("mobileprovince", "ipprovince", "ipcity", "province", "city",
                    "district", "coordinates", "gps", "location", "region",
                    "longitude", "latitude")

# 网络/IP 风险类条件字段（2026-10-10 用户定）：recall_sql 用这些因子筛选人群时，
# 黑产池指标（black_pool ≥0.9）是先验选定的必然结果，交叉验证失效须降级。
_NET_COND_FIELDS = ("ipipriskaction", "isproxy", "proxy", "vpn", "iprisk", "idc", "秒拨")

# 设备风险类条件（2026-10-10 扫描 261009 全量 1401 条 recall_sql 后补充）：
# 字段形态：deviceriskhitrulesv2new 标签串字段（instr 匹配）。
_DEVICE_COND_FIELDS = ("deviceriskhitrules",)

# 定位关闭类条件（2026-10-12 用户定，26101000132_c008 实锤）：SQL 用
# "coordinates='0.0000000000|0.0000000000'"（坐标全零=从未开定位）筛选人群时，
# loc_strong_off_rate（强端定位关闭率 ≥0.3）是先验选定的必然结果，自证失效。
_LOC_COND_FIELDS = ("coordinates", "latitude", "longitude", "gps", "location")

# 设备/网络风险因子【值】关键词（出现在 SQL 字符串常量中）：
# 'ios_execution_mocklocation_...'、'all_network_vpn_...'、'factor_xxx_proxy_...' 等。
_DEVICE_FACTOR_KW = ("mocklocation", "tamper", "multisource", "device_id_illegal",
                      "signature_data_integrity", "emulator", "reset_time")
_NET_FACTOR_KW = ("isproxy", "vpn", "proxy", "iprisk", "idc", "秒拨")
# 定位关闭因子值：坐标零值（'0.0000000000|0.0000000000' 变体）/mock_location 类因子
_LOC_COND_KW = ("0.0000000000", "mock_location", "gps_close", "location_off")

# 黑产因子直筛（mtsi_markedstrategy/hit_rules 因子值含 _black）：SQL 直接按
# "黑产标签"筛选人群时，黑产池指标 100% 是筛选本身，比网络因子更直接。
# 261009 扫描：275 条 SQL 含 factor_*_black 直筛。
_BLACK_FACTOR_PAT = "_black"


def _cond_hits(recall_sql: str, fields: tuple) -> list:
    """检测 recall_sql 是否含指定类别的筛选条件，返回命中字段列表（空=无）。
    匹配三种形态（2026-10-10 扫描 261009 全量 SQL 后穷举）：
    1. 运算符条件：field = / like / in / between
    2. 函数式条件：array_contains(field,...)——set 字段（mobileprovince_set 等）走此形态
    3. instr 条件：instr(`field`, 'xxx')——deviceriskhitrulesv2new 等标签串字段走此形态
    注：因子值里的关键词（如 'xxx_mocklocation_yyy'）不在本函数范围——
    那是值匹配（_factor_value_hits），与字段匹配分开。"""
    import re as _re
    if not recall_sql:
        return []
    low = recall_sql.lower()
    hits = []
    for f in sorted(fields, key=len, reverse=True):   # 长名优先
        if f in hits:
            continue
        if (_re.search(rf"`?{f}`?\s*(=|!=| like | in | between )", low, _re.I)
                or _re.search(rf"(array_)?contains\s*\(\s*`?\w*{f}", low, _re.I)
                or _re.search(rf"instr\s*\(\s*`?{f}", low, _re.I)):
            # 排除已被更长字段覆盖的情况（如 mobileprovince 命中后不再报 province）
            if not any(f in h and h != f for h in hits):
                hits.append(f)
    return hits


def _factor_value_hits(recall_sql: str, keywords: tuple) -> list:
    """检测因子【值】（SQL 字符串常量）中是否含指定关键词。
    261009 扫描发现大量因子值含设备/网络风险语义：
    'ios_execution_mocklocation_location_type'、'all_network_vpn_isvpn_env_fe_realtime'、
    'factor_sig_siua_layout_sdkversion_black' 等——按值关键词分类。"""
    low = (recall_sql or "").lower()
    return [k for k in keywords if k in low]


def _geo_conditioned(recall_sql: str) -> list:
    """检测 recall_sql 是否含地理位置类条件，返回命中的字段列表（空=无地理条件）。"""
    return _cond_hits(recall_sql, _GEO_COND_FIELDS)


def _net_conditioned(recall_sql: str) -> list:
    """检测 recall_sql 是否含网络/IP 风险类条件（机房/秒拨/代理/VPN 因子）。"""
    return _cond_hits(recall_sql, _NET_COND_FIELDS)


def _device_conditioned(recall_sql: str) -> list:
    """检测 recall_sql 是否含设备风险类条件（设备风险标签/模拟定位/篡改因子）。"""
    return _cond_hits(recall_sql, _DEVICE_COND_FIELDS)


def _black_factor_conditioned(recall_sql: str) -> bool:
    """检测 recall_sql 是否直接按黑产因子筛选（因子值含 _black）。
    mtsi_markedstrategy/hit_rules 的 array_contains(...,'factor_xxx_black') ——
    261009 扫描：688 条 SQL 用 mtsi 因子筛选，275 条含 _black 黑产因子。"""
    return _BLACK_FACTOR_PAT in (recall_sql or "").lower()


def _rule_agent_metrics(r: dict, i, recall_count: Optional[int]) -> dict:
    """单 combo 的五维度子项达标计算（阈值沿用挖掘现有配置）。
    r=validation_result 行, i=列索引函数, recall_count=recall_sql 真实命中量（None=查询失败）。
    新列（geo_mismatch_rate/loc_strong_off_rate 等 2026-09-12 加）旧 case 表无——
    用 _opt_num 容错取，缺列返回 None 不进判定。"""
    def _opt_num(k):
        try:
            return _to_num(r[i(k)])
        except ValueError:
            return None
    num = _opt_num
    # 维度1 大盘覆盖：真实命中量 <10万（recall_sql）且 lift>10（2026-10-10 用户定：双达标制）
    hit_lt_100k = (recall_count is not None and recall_count < 100000)
    lift_val = num("lift")
    lift_gt_10 = lift_val is not None and lift_val > 10 and lift_val < 1e10
    market_pass = hit_lt_100k and lift_gt_10
    # 维度2 硬特征（沿用：设备簇≥50% 或共享≥70%——表里只落 max，用≥0.5 近似；黑产池≥90%；下游≥90%）
    device, ja3, black, downstream = num("device_max_ratio"), num("ja3_max_ratio"), num("black_pool_rate"), num("downstream_rate")
    hf = {
        "device_cluster": (device or 0) >= 0.5,
        "ja3_cluster": (ja3 or 0) > 0,
        "black_pool": (black or 0) >= 0.9,
        "downstream": (downstream or 0) >= 0.9,
    }
    # L1-6 归属地-IP 异地 / L1-7 定位关闭（2026-09-12 新轴，旧 case 无列→None 不判定）
    geo_mm, loc_off, loc_strong = num("geo_mismatch_rate"), num("loc_off_rate"), num("loc_strong_off_rate")
    if geo_mm is not None:
        hf["geo_mismatch"] = geo_mm >= 0.5
        hf["geo_mismatch_rate"] = geo_mm
        hf["geo_mismatch_note"] = ("手机号归属地与IP归属地不一致占比（90天回捞，省份前2字符归一，"
                                   "有交集即一致）。大盘水位约20%（差旅/打工/携转底噪），≥50%≈2.5×lift "
                                   "才成立；单向高触发——本地卡团伙异地率反而低，低分不降级")
    if loc_strong is not None:
        hf["loc_off"] = loc_strong >= 0.3
        hf["loc_strong_off_rate"] = loc_strong
        if loc_off is not None:
            hf["loc_off_rate_overall"] = loc_off
        hf["loc_off_note"] = ("强端(sel/ses)表定位关闭账号占比（90天从未上报真实GPS坐标，"
                              "latitude恒为0变体或弱端授权false）。团伙实测38% vs 大盘5%（模拟器/"
                              "群控无GPS）；≥30%成立。整体loc_off_rate含弱端小程序容器偏置，仅观测")
    hf["any_pass"] = any(v for k, v in hf.items() if isinstance(v, bool))
    # ── 交叉验证失效检测（2026-10-10 用户定 + 261009 全量 1401 条 SQL 扫描定稿）──
    # 原则：SQL 已用作筛选的因子，对应指标是"先验选定的必然结果"，非独立证据。
    # 双通道检测：字段名匹配（ipcity='周口' / instr(`deviceriskhitrulesv2new`,...)）
    #           + 因子值关键词匹配（'factor_xxx_black' / 'all_network_vpn_...'）
    recall_sql_raw = r[i("recall_sql")] or ""
    net_fields = _net_conditioned(recall_sql_raw) + _factor_value_hits(recall_sql_raw, _NET_FACTOR_KW)
    device_fields = _device_conditioned(recall_sql_raw) + _factor_value_hits(recall_sql_raw, _DEVICE_FACTOR_KW)
    black_factor = _black_factor_conditioned(recall_sql_raw)
    # 黑产池自证三源：黑产因子直筛（factor_xxx_black）> 网络/IP 风险 > 设备风险
    bp_sources = []
    if black_factor:
        bp_sources.append("黑产因子直筛(factor_*_black)")
    if net_fields:
        bp_sources.append("网络/IP风险(" + ",".join(sorted(set(net_fields))) + ")")
    if device_fields:
        bp_sources.append("设备风险(" + ",".join(sorted(set(device_fields))) + ")")
    if bp_sources:
        hf["black_pool_conditioned_by_sql"] = True
        hf["black_pool_condition_sources"] = bp_sources
        hf["black_pool_weight_note"] = ("recall_sql 已用以下条件筛选人群：" + "；".join(bp_sources) +
                                        "——黑产池率 100% 是筛选的必然结果而非独立证据，"
                                        "black_pool 子项视为不成立")
    # 设备簇自证：SQL 用设备风险标签/异常因子筛选时，设备聚集（device_max_ratio）
    # 同样是先验结果（人群本来就按设备特征选的）
    if device_fields:
        hf["device_cluster_conditioned_by_sql"] = True
        hf["device_condition_fields"] = device_fields
        hf["device_cluster_weight_note"] = ("recall_sql 含设备风险条件（" + ",".join(sorted(set(device_fields))) +
                                            "），设备簇聚集是筛选的必然结果，device_cluster 子项视为不成立")
    # 定位关闭自证（2026-10-12 用户定，26101000132_c008 实锤）：recall_sql 用
    # coordinates='0.0000000000|0.0000000000'（坐标全零=从未开定位）等条件筛选时，
    # loc_strong_off_rate（强端定位关闭 ≥0.3）是先验选定的必然结果，loc_off 子项不成立。
    loc_cond = (_cond_hits(recall_sql_raw, _LOC_COND_FIELDS)
                or _factor_value_hits(recall_sql_raw, _LOC_COND_KW))
    if loc_cond:
        hf["loc_off_conditioned_by_sql"] = True
        hf["loc_condition_fields"] = loc_cond
        hf["loc_off_weight_note"] = ("recall_sql 含定位关闭类条件（" + ",".join(sorted(set(loc_cond))) +
                                     "，坐标全零/定位关闭因子筛选），强端定位关闭率是筛选的必然结果，"
                                     "loc_off 子项视为不成立")
    # 维度3 同伙聚集度（沿用：地理≥50% 或 70%；号段/WiFi≥70%）——pass 已由挖掘算好落表
    geo_p, seg_p, wifi_p = _is_true(r[i("geo_pass")]), _is_true(r[i("segment_pass")]), _is_true(r[i("wifi_pass")])
    # 地理偏置检测：recall_sql 含地理条件（如 mobileprovince='广东'）时，"地理最大占比
    # 1.0≥0.5" 是 SQL 先验选定的结果（人群天然集中在选定地域），非自发聚集——权重应下降
    geo_fields = _geo_conditioned(r[i("recall_sql")] or "")
    clustering = {"geo": geo_p, "segment": seg_p, "wifi": wifi_p}
    clustering["pass_count"] = sum([geo_p, seg_p, wifi_p])
    if geo_fields:
        clustering["geo_conditioned_by_sql"] = True
        clustering["geo_condition_fields"] = geo_fields
        clustering["geo_weight_note"] = ("recall_sql 含地理条件（" + ",".join(geo_fields) +
                                         "），地理最大占比是该条件筛选的必然结果而非团伙自发聚集，"
                                         "geo 子项判定权重下降；聚集度以号段/WiFi/时序为准")
    # 维度4 流量趋势（沿用：growth≥3 且 rate_rise>0.001；起量前稀疏 history_pct_pass）
    surge_p, nontrust_p, hist_p = _is_true(r[i("surge_pass")]), _is_true(r[i("nontrust_pass")]), _is_true(r[i("history_pct_pass")])
    growth_val = num("combo_growth")
    growth_p = (growth_val or 0) >= 3
    trend = {"surge": surge_p, "growth": growth_p, "nontrust": nontrust_p, "history_sparse": hist_p}
    trend["all_required_pass"] = surge_p and growth_p and hist_p
    trend["all_four_pass"] = surge_p and growth_p and nontrust_p and hist_p
    # 维度5 消费用户（真人度<5% = 非真人团伙；-1=不可评估）
    # F 保护对象子维度（2026-10-10 用户定）：member_rate 黑金黑钻会员占比、
    # high_value_rate 高价值用户占比——批量注册/批量登录类团伙的高准确判定门槛。
    consumer_rate = num("consumer_rate")
    member_rate = num("member_rate")
    high_value_rate = num("high_value_rate")
    return {
        "market_coverage": {"hit_lt_100k": hit_lt_100k, "real_hit_count": recall_count,
                            "lift": lift_val, "lift_gt_10": lift_gt_10, "pass": market_pass,
                            # 回捞 0 人 = 规则在当前大盘不生效（recall_sql 查不到任何账号），
                            # 无覆盖能力 → 一票否决不通过（代码侧另有硬守卫强制覆写）
                            "recall_zero": recall_count == 0},
        "hard_features": hf,
        "clustering": clustering,
        "trend": trend,
        "consumer": {"real_person_ratio": consumer_rate,
                      "non_human": consumer_rate is not None and 0 <= consumer_rate < 0.05,
                      "evaluable": consumer_rate is not None and consumer_rate >= 0,
                      # F 维度：批量注册/批量登录团伙的高准确保护线（三条件须全过，
                      # 不满足任一 → 最高只能低准确，prompt 侧执行）
                      "member_rate": member_rate if (member_rate is not None and member_rate >= 0) else None,
                      "high_value_rate": high_value_rate if (high_value_rate is not None and high_value_rate >= 0) else None,
                      "protection_note": ("member_rate=黑金黑钻会员占比、high_value_rate=高价值用户占比"
                                          "（-1 或 null=该 case 无此维度数据，不参与判定）。"
                                          "上游 dify 定性为批量注册/批量登录时：真人度需 <30% 且 "
                                          "member_rate <5% 且 high_value_rate <5%，任一不满足 → 不得判「高准确」")},
    }


def _to_num(v):
    try:
        n = float(v)
        # NaN / Infinity（表里 lift='Infinity'）→ None：非有限值序列化成 JSON 会炸（PG/CatX 均拒收）
        return n if (n == n and n not in (float("inf"), float("-inf"))) else None
    except (TypeError, ValueError):
        return None


def _is_true(v) -> bool:
    return v is True or str(v).strip().lower() in ("true", "1")


class RuleAgentRequest(BaseModel):
    experiment: Optional[str] = None
    dt: Optional[str] = None


def _fetch_trend_series(case_id: str, exp: str, dt: str, combo_ids: list) -> dict:
    """ts_daily 表 → 每 combo 的时序三线数值 + t0 + 预计算摘要（纯文本 Agent 的"看图"通道）。
    长表行 (d, stat_name, stat_value, is_t0) 转宽格式；旧 case 无数据返回空 dict。"""
    if not combo_ids:
        return {}
    ids = ",".join(f"'{c.replace(chr(39), '')}'" for c in combo_ids)
    sql = (f"SELECT combo_id, d, stat_name, stat_value, is_t0 "
           f"FROM ba_rc.acc_sec_gang_validation_ts_daily "
           f"WHERE case_id='{case_id}' AND experiment='{exp}' AND dt='{dt}' "
           f"AND combo_id IN ({ids}) ORDER BY combo_id, d, stat_name")
    res = _run_hive_sync(sql, max_wait_s=90)
    if res["status"] != "done" or not res.get("rows"):
        return {}
    cols = res["columns"]
    ic, idd, isn, isv, it0 = (cols.index("combo_id"), cols.index("d"),
                               cols.index("stat_name"), cols.index("stat_value"), cols.index("is_t0"))
    by_combo: dict = {}
    for r in res["rows"]:
        c = r[ic]
        m = by_combo.setdefault(c, {"days": [], "hits": [], "sample": [], "nt": [], "t0_day": None, "_idx": {}})
        day, stat, val = str(r[idd]), str(r[isn]), _to_num(r[isv]) or 0
        if day not in m["_idx"]:
            m["_idx"][day] = len(m["days"])
            m["days"].append(day)
            m["hits"].append(0), m["sample"].append(0), m["nt"].append(0)
        k = m["_idx"][day]
        if stat == "hits":
            m["hits"][k] = int(val)
        elif stat == "sample_hits":
            m["sample"][k] = int(val)
        elif stat == "nt_hits":
            m["nt"][k] = int(val)
        if str(r[it0]).lower() == "true":
            m["t0_day"] = day
    out = {}
    for c, m in by_combo.items():
        # 预计算摘要：t0 前后均值/峰值/倍数/衰减——模型免算防错，引用有据
        days, hits = m["days"], m["hits"]
        t0_i = days.index(m["t0_day"]) if m["t0_day"] in days else None
        pre = hits[:t0_i] if t0_i is not None else hits
        post = hits[t0_i:] if t0_i is not None else []
        pre_mean = sum(pre) / len(pre) if pre else 0
        post_peak = max(post) if post else 0
        surge = round(post_peak / pre_mean, 1) if pre_mean > 0 else None
        decay = None
        if post and len(post) >= 3:
            tail = sum(post[-3:]) / 3
            decay = round(1 - tail / post_peak, 2) if post_peak > 0 else None
        out[c] = {
            "days_span": f"{days[0]}~{days[-1]}" if days else "",
            "n_days": len(days),
            "combo_daily": hits,
            "sample_daily": m["sample"],
            "nontrust_daily": m["nt"],
            "t0_day": m["t0_day"],
            "computed": {
                "pre_t0_mean": round(pre_mean, 1),
                "post_t0_peak": post_peak,
                "surge_ratio": surge,
                "post_peak_decay_pct": decay,
            },
        }
    sys_log("info", f"[rule_agent] trend_series: {len(out)}/{len(combo_ids)} combo 有时序数据")
    return out


@router.post("/api/cases/{case_id}/rule_agent")
def rule_agent(body: RuleAgentRequest, case_id: str):
    """规则判定 Agent：对 Step3 全部候选规则做五维度准确率判定。
    前置计算（代码）→ CatX Agent 综合判定（LLM）→ 结果落 flow extra.rule_agent。"""
    exp, dt = _exp_dt(body.experiment, body.dt, case_id)
    return _rule_agent_run(case_id, exp, dt, trigger="manual")


def _rule_agent_prompt_version() -> str:
    """CatX Agent 当前 system prompt 版本指纹（sha256 前 8 位）。
    prompt 线上改动频繁（一票否决/组合达标/交叉验证失效/F 保护线等），
    判定结果与 prompt 版本必须可对齐排查——每次判定记录当时的版本指纹。"""
    try:
        import hashlib
        import httpx as _hx
        from config import get_config as _gc
        _c = _gc().catx
        _r = _hx.get(f"https://api.catpaw.sankuai.com/v1/agents/{_c.agent_id}",
                     headers={"X-Api-Key": _c.api_key}, timeout=15)
        _s = _r.json().get("system") or ""
        return hashlib.sha256(_s.encode()).hexdigest()[:8] if _s else "unknown"
    except Exception:
        return "fetch_failed"


def _rule_agent_run(case_id: str, experiment: str, dt: str, trigger: str = "manual") -> dict:
    """Agent 判定核心逻辑（HTTP 端点 + canvas_scheduler 预触发共用）。
    前置计算五维指标 + recall_sql 命中量 → CatX Agent 逐 combo 判定 → 落 flow extra。
    trigger：判定触发方式（auto=回捞完成自动 / manual=页面手动 / rerun=批量重判脚本），
    随判定历史记录（flow extra.rule_agent_history，供前端展示判定版本溯源）。"""
    from client.catx_client import CatXClient
    import flow_store
    import base64
    import concurrent.futures as cf
    from datetime import datetime as _dtt
    exp, dt = _exp_dt(experiment, dt, case_id)
    # 判定元信息：prompt 版本指纹 + 触发时间/方式（落 flow extra，前端展示）
    _t_start = time.time()
    run_meta = {"trigger": trigger, "prompt_version": _rule_agent_prompt_version(),
                "triggered_at": _dtt.now().strftime("%Y-%m-%d %H:%M:%S")}
    # 1. 取 Step3 全量候选规则
    sql = Q.validation_result_sql(_cfg(), case_id, exp, dt)
    res = _run_hive_sync(sql, max_wait_s=120)
    if res["status"] != "done" or not res.get("rows"):
        return {"status": 0, "message": "无候选规则数据"}
    cols = res["columns"]
    i = lambda n: cols.index(n)
    # 2.5 时序折线图数值通道（提前取：recall 降级数据源）：
    # ts_daily 表逐日三线（hits/sample_hits/nt_hits）+ t0 + 预计算摘要。
    # 纯文本模型（glm-5.3）看不了图，数值序列等价于图的数据本体。旧 case 无此表数据时 trend_series=None。
    trend_map = _fetch_trend_series(case_id, exp, dt, [r[i("combo_id")] for r in res["rows"]])
    # 2. recall_sql 真实命中量（并发查，限制并发避免打挂 Talos）。
    # 降级链（2026-10-12 用户定）：recall_sql 现场查超时/失败 → 用 ts_daily 90 天逐日
    # 命中的总和替代——挖掘阶段已产出的全量真实命中（非抽样），与页面"回捞大盘总数"
    # 同源同值（26101000211 实锤：ts_daily 总和 285 ≈ 页面 284）。90 天大 JOIN 的
    # recall_sql 引擎 5 分钟跑不完（每次判定重付成本），ts_daily 是现成的等价数据。
    recalls = {}
    def _count_recall(row):
        cid_row = row[i("combo_id")]
        rsql = (row[i("recall_sql")] or "").strip()
        if not rsql:
            return cid_row, None
        # 上游两种格式：老格式带外层括号 (SELECT ...)；新格式裸 SELECT（26101000211_c001 实锤）。
        # 统一补括号再嵌 count（presto 要求子查询括号包裹）；此前只认 (SELECT 开头——
        # 裸 SELECT 被当"查询失败"返回 None，触发 fail-closed 硬守卫误判不通过。
        if not rsql.upper().startswith("(SELECT"):
            rsql = f"({rsql})"
        try:
            r = _run_hive_sync(f"SELECT count(*) AS n FROM {rsql}", max_wait_s=60)
            if r["status"] == "done" and r.get("rows"):
                return cid_row, int(r["rows"][0][0])
        except Exception:
            pass
        # 降级：ts_daily 逐日 hits 总和（全量真实命中，挖掘阶段已算好）
        ts = trend_map.get(cid_row) or {}
        daily = ts.get("combo_daily") or []
        if daily:
            sys_log("info", f"[rule_agent] {cid_row} recall 超时/失败，降级用 ts_daily "
                            f"90 天命中总和={sum(daily)}（挖掘期全量数据）")
            return cid_row, sum(int(x) for x in daily)
        return cid_row, None
    with cf.ThreadPoolExecutor(max_workers=5) as exe:
        for cid, n in exe.map(_count_recall, res["rows"]):
            recalls[cid] = n
    # 3. 逐 combo 前置计算 + Agent 判定
    try:
        client = CatXClient()
    except RuntimeError as e:
        return {"status": 0, "message": str(e)}
    # 上游 dify 工作流判定结果（external_task_create 存 flow extra，Agent 判定时参考）
    upstream = {}
    flow = flow_store.get_by_case_id(case_id)
    if flow:
        ex = flow.get("extra") or {}
        upstream = {
            "result": ex.get("external_result") or "",
            "action_type": ex.get("external_action_type") or "",
            "reason": (ex.get("external_reason") or "")[:1500],  # 截断防 payload 过大
        }
    results = []

    def _judge_one_combo(row):
        """单 combo 判定（payload 构建 → CatX 调用 → 解析 → 硬守卫）。
        2026-10-10 抽函数：combo 循环改 4 线程并发（每 judge 独立 session 无冲突），
        单 case 24 combo 从串行 ~3 分钟 → 并发 ~50 秒。"""
        cid = row[i("combo_id")]
        payload = {
            "combo_id": cid,
            "upstream_dify_verdict": upstream,  # 上游 dify 风险判定（报出原因 reason），供 Agent 参考
            "mining_reasons": row[i("reasons")] or "",  # 挖掘 pipeline 的判定级别原因（模板串）
            **_rule_agent_metrics(row, i, recalls.get(cid)),
        }
        ts = trend_map.get(cid)
        if ts:
            payload["trend_series"] = ts
        try:
            reply = client.judge(payload, timeout_s=300)
            if not reply.strip():
                raise ValueError("CatX 回复超时/为空")
            txt = reply.strip().removeprefix("```json").removeprefix("```").removesuffix("```").strip()
            # 提取首个完整 JSON 对象（2026-10-12 加强）：此前用 rfind("}") 截到
            # 最后一个右括号——LLM 在 JSON 后追加解释文字（含 {}/示例）时会切进
            # 多余内容 → json.loads 抛 "Extra data"（26101000208_c001 实锤，
            # v3 全量重判 30 例判定失败的主因）。括号深度配平扫描第一个完整对象
            # （跳过字符串内的括号），正确处理"JSON+尾部废话"与"多 JSON 拼接"。
            s = txt.find("{")
            if s >= 0:
                depth, in_str, esc_ = 0, False, False
                for pos in range(s, len(txt)):
                    ch = txt[pos]
                    if in_str:
                        if esc_:
                            esc_ = False
                        elif ch == "\\":
                            esc_ = True
                        elif ch == '"':
                            in_str = False
                    else:
                        if ch == '"':
                            in_str = True
                        elif ch == "{":
                            depth += 1
                        elif ch == "}":
                            depth -= 1
                            if depth == 0:
                                txt = txt[s:pos + 1]
                                break
            try:
                verdict = json.loads(txt)
            except json.JSONDecodeError:
                # LLM 输出的 JSON 格式瑕疵（2026-09-18：Invalid control character /
                # 中文引号 / 尾随多余字符——当天 6 例判定失败主因）宽容修复再解析：
                fixed = (txt
                         .replace("\\\n", "\\n")            # 值内换行转义形如 "\<LF>"
                         .replace("\n", " ")               # 控制字符换行（值未转义）
                         .replace("，", ",")                # 中文逗号
                         .replace("：", ":"))               # 中文冒号
                fixed = re.sub(r",\s*([}\]])", r"\1", fixed)  # 尾随逗号
                verdict = json.loads(fixed)
            if not isinstance(verdict, dict) or "grade" not in verdict:
                raise ValueError(f"回复缺 grade 字段: {str(verdict)[:100]}")
        except Exception as e:
            verdict = {"grade": "判定失败", "reason": str(e)[:150], "key_dimensions": [], "upgrade_path": "none"}
        verdict["combo_id"] = cid  # Agent 回复不含 combo_id，统一回填（前端 Step3 按 combo_id 匹配）
        # 硬守卫（2026-09-12）：回捞大盘 0 人 = 规则不生效（recall_sql 在大盘查不到任何账号），
        # 无论 LLM 判什么都强制「不通过」——0 命中说明该规则无覆盖能力，其余维度再强也无意义
        if recalls.get(cid) == 0 and verdict.get("grade") != "不通过":
            sys_log("info", f"[rule_agent] {cid} 回捞0人硬守卫: {verdict.get('grade')} → 不通过")
            verdict = {"grade": "不通过",
                       "reason": "回捞大盘 0 人——recall_sql 在当前大盘查不到任何账号，规则不生效（无覆盖能力）",
                       "key_dimensions": ["market_coverage"],
                       "upgrade_path": "none",
                       "guard": "recall_zero"}
        # 硬守卫（2026-10-10）：真实命中量 ≥5万 → 一票否决（26100900250_c004 实锤：
        # LLM 在 76,982≥50,000 时仍判高准确——prompt 是概率性的，代码守卫才是兜底）。
        # 命中面过大必伤真人，无论 lift 多高、其他维度多强。
        rc = recalls.get(cid)
        if rc is not None and rc >= 50000 and verdict.get("grade") != "不通过":
            sys_log("info", f"[rule_agent] {cid} 命中量硬守卫: {rc}≥50000, {verdict.get('grade')} → 不通过")
            verdict = {"grade": "不通过",
                       "reason": f"大盘真实命中量 {rc} ≥ 50,000（一票否决：命中面过大必伤真人，无论 lift 或其他维度多强）",
                       "key_dimensions": ["market_coverage"],
                       "upgrade_path": "none",
                       "guard": "hit_count_50k"}
        # 硬守卫（2026-10-10）：真实命中量查询失败（None）→ fail-closed 不通过。
        # 覆盖能力无法评估时不得放行（c001/c003 实锤：LLM 有时判不通过但原因栏引用错数据）。
        if rc is None and verdict.get("grade") != "不通过":
            sys_log("info", f"[rule_agent] {cid} 命中量null硬守卫: {verdict.get('grade')} → 不通过")
            verdict = {"grade": "不通过",
                       "reason": "真实命中量查询失败（recall_sql 无法评估覆盖面）——fail-closed 不通过，不得仅凭 lift 放行",
                       "key_dimensions": ["market_coverage"],
                       "upgrade_path": "none",
                       "guard": "hit_count_unknown"}
        # 硬守卫（2026-10-12 用户定）：组合达标制 A&E&(C||D)——代码级重算，不信 LLM。
        # 26101000203 实锤：LLM reason 自述"C/D均无独立证据，但按A+E组合路径成立"仍判
        # 高准确——prompt 是概率性的，LLM 会把 A+E 曲解为独立路径。代码按 metrics
        # 里的布尔子项重算：C/D 均无独立证据（自证失效子项已排除）时强制降「低准确」。
        # 组合达标守卫（2026-10-12 用户定）：A&E&(C||D)——代码级重算，双向纠正 LLM。
        # 26101000203 实锤（LLM 宽松）：reason 自述"C/D 均无独立证据，但按 A+E 组合
        #   路径成立"仍判高准确 → C/D 均无独立证据时强制降「低准确」。
        # 26101000156_c002 实锤（LLM 过严）：C 硬特征 downstream+geo_mismatch 两项独立
        #   成立，组合制已满足，LLM 却以"D 的 geo 子项被自证削弱、证据链偏弱"降为
        #   低准确——OR 语义下 C 成立即组合成立，D 是否存在根本不参与判定。
        #   → A&E 达标且有独立 C 或 D 证据时强制升「高准确」（F 保护线由 LLM 判，
        #   升级仅当 LLM 未以 F 为降级理由——F 超线降级是用户定的另一条规则）。
        m = payload
        hf = m.get("hard_features") or {}
        cl = m.get("clustering") or {}
        tr = m.get("trend") or {}
        # C 硬特征独立证据：设备簇/ja3/黑产池/下游/归属地-IP异常/强端定位关闭
        # （排除 SQL 自证失效的 black_pool / device_cluster）
        c_keys_full = ("device_cluster", "ja3_cluster", "black_pool", "downstream",
                       "geo_mismatch", "loc_off")
        c_keys = tuple(k for k in c_keys_full
                       if not (k == "black_pool" and hf.get("black_pool_conditioned_by_sql"))
                       and not (k == "device_cluster" and hf.get("device_cluster_conditioned_by_sql"))
                       and not (k == "loc_off" and hf.get("loc_off_conditioned_by_sql")))
        c_evidence = any(hf.get(k) for k in c_keys)
        # D 同伙聚集度独立证据：号段/WiFi（地理被 SQL 自证时排除）
        d_evidence = cl.get("segment") or cl.get("wifi") \
            if cl.get("geo_conditioned_by_sql") \
            else (cl.get("geo") or cl.get("segment") or cl.get("wifi"))
        # A 大盘覆盖：一票否决未命中（rec 有值且 <5万）且 lift>10
        a_pass = (recalls.get(cid) is not None and recalls.get(cid) < 50000
                  and (m.get("market_coverage") or {}).get("lift_gt_10"))
        # E 流量趋势三项
        e_pass = tr.get("surge") and tr.get("growth") and tr.get("history_sparse")
        combo_ok = a_pass and e_pass and (c_evidence or d_evidence)

        if verdict.get("grade") == "高准确" and not combo_ok:
            sys_log("info", f"[rule_agent] {cid} 组合达标硬守卫(降): 组合不成立，高准确 → 低准确 "
                            f"(A={a_pass} E={e_pass} C={c_evidence} D={d_evidence})")
            verdict = {"grade": "低准确",
                       "reason": (str(verdict.get("reason") or "")[:150]
                                  + " ｜ 守卫：A/E 达标但 C 硬特征与 D 同伙聚集度均无独立证据（自证失效子项已排除），"
                                    "按组合达标制 A&E&(C||D) 降为低准确"),
                       "key_dimensions": verdict.get("key_dimensions") or [],
                       "upgrade_path": "none",
                       "guard": "combo_cd_required"}
        elif verdict.get("grade") == "低准确" and combo_ok:
            # F 保护线以 LLM reason 为准：LLM 明确以 F 超线降级时不升级
            reason_txt = str(verdict.get("reason") or "")
            f_blocked = ("保护" in reason_txt and "超线" in reason_txt) or "保护对象占比超线" in reason_txt
            if not f_blocked:
                sys_log("info", f"[rule_agent] {cid} 组合达标硬守卫(升): A&E&(C||D) 全成立且 F 未超线，"
                                f"低准确 → 高准确 (A={a_pass} E={e_pass} C={c_evidence} D={d_evidence})")
                verdict = {"grade": "高准确",
                           "reason": (reason_txt[:150]
                                      + " ｜ 守卫：A&E 达标且 C/D 有独立交叉验证证据（自证失效子项已排除），"
                                        "组合达标制 A&E&(C||D) 全部满足，应为高准确（D 缺失不影响——OR 语义）"),
                           "key_dimensions": verdict.get("key_dimensions") or [],
                           "upgrade_path": "hard_feature",
                           "guard": "combo_cd_satisfied"}
        # 守卫（2026-10-12）："不通过"授予权完全收归代码——一票否决四条
        # （命中量≥5万 / =0 / null / lift≤10）是"不通过"的唯一来源，由上面的
        # recall_zero / hit_count_50k / hit_count_unknown 守卫执行（带 guard 标记）。
        # LLM 自主给的不通过（笔误 26101000116_c001"最高只能低准确"却写不通过、
        # 或自造第五条否决"命中量过小覆盖不足"）一律纠正为「低准确」——
        # 组合制不满足只降级到低准确，不到不通过。
        if verdict.get("grade") == "不通过" and not verdict.get("guard"):
            rc2 = recalls.get(cid)
            lift_v = (m.get("market_coverage") or {}).get("lift")
            veto = (rc2 is None or rc2 == 0
                    or (rc2 is not None and rc2 >= 50000)
                    or (lift_v is not None and lift_v <= 10))
            if not veto:
                reason_txt2 = str(verdict.get("reason") or "")
                sys_log("info", f"[rule_agent] {cid} 不通过越权守卫: LLM 自主不通过"
                                f"（未触发一票否决）→ 纠正为低准确")
                verdict = {"grade": "低准确",
                           "reason": (reason_txt2[:180]
                                      + " ｜ 守卫：「不通过」仅由一票否决产生（命中量≥5万/=0/查询失败/lift≤10），"
                                        "均未触发；LLM 自主判不通过越权，按组合制纠正为低准确"),
                           "key_dimensions": verdict.get("key_dimensions") or [],
                           "upgrade_path": "none",
                           "guard": "no_veto_no_fail"}
        verdict["metrics"] = json.loads(json.dumps(payload, ensure_ascii=False, allow_nan=False, default=str))
        return verdict

    with cf.ThreadPoolExecutor(max_workers=4) as _jexe:
        results = list(_jexe.map(_judge_one_combo, res["rows"]))
    for verdict in results:
        sys_log("info", f"[rule_agent] {verdict.get('combo_id')} → {verdict.get('grade')} ({verdict.get('reason', '')[:60]})")
    # 4. 判定结果落 flow extra
    passed = [v for v in results if v["grade"] in ("高准确", "低准确")]
    flow = flow_store.get_by_case_id(case_id)
    if flow:
        from datetime import datetime as _dtt2
        ra_payload = {
            "dt": dt, "experiment": exp, "total": len(results),
            "high": len([v for v in results if v["grade"] == "高准确"]),
            "low": len([v for v in results if v["grade"] == "低准确"]),
            "fail": len([v for v in results if v["grade"] == "不通过"]),
            "results": results,
            # 判定元信息（2026-10-13 用户定）：当前判定用的 prompt 版本指纹 + 触发时间/方式
            "prompt_version": run_meta["prompt_version"],
            "triggered_at": run_meta["triggered_at"],
            "trigger": run_meta["trigger"],
            "duration_s": round(time.time() - _t_start),
        }
        # 判定历史（每次触发追加一条，前端展示版本溯源列表；上限 20 条防 extra 膨胀）
        try:
            _hist = (flow.get("extra") or {}).get("rule_agent_history") or []
            _hist.append({**run_meta, "duration_s": ra_payload["duration_s"],
                          "high": ra_payload["high"], "low": ra_payload["low"],
                          "fail": ra_payload["fail"], "total": len(results)})
            flow_store.update_extra(flow["id"], {
                "rule_agent": ra_payload,
                "rule_agent_history": _hist[-20:],
            })
        except Exception as _he:
            sys_log("warning", f"[rule_agent] history 记录失败 case={case_id}: {str(_he)[:120]}")
            flow_store.update_extra(flow["id"], {"rule_agent": ra_payload})
    return {"status": 1, "case_id": case_id, "total": len(results),
            "high": len([v for v in results if v["grade"] == "高准确"]),
            "low": len([v for v in results if v["grade"] == "低准确"]),
            "fail": len([v for v in results if v["grade"] == "不通过"]),
            "results": results}


@router.get("/api/cases/{case_id}/rule_agent")
def rule_agent_result(case_id: str):
    """查该 case 的 Agent 判定结果（flow extra.rule_agent）。"""
    import flow_store
    flow = flow_store.get_by_case_id(case_id)
    if not flow:
        return {"status": 0, "results": []}
    ra = (flow.get("extra") or {}).get("rule_agent")
    if not ra:
        return {"status": 0, "results": []}
    return {"status": 1, **ra}


# ── 复盘（case_reviews）────────────────────────────────────────────

class ReviewRequest(BaseModel):
    case_id: str
    category_l1: str
    category_l2: str
    env: Optional[str] = None
    gang_verdict: Optional[str] = None
    problem_desc: str = ""
    follow_up: Optional[str] = None
    reviewer: Optional[str] = None      # 缺省取登录 MIS


@router.post("/api/reviews")
def review_create(body: ReviewRequest, request: Request):
    """发起复盘（case 详情页）。case_id 锁定单值；group_id/团伙定性/报出原因自动快照。"""
    import flow_store as store
    if not body.case_id:
        raise HTTPException(400, "case_id 不能为空")
    if body.category_l1 not in store.L1_OPTIONS:
        raise HTTPException(400, f"category_l1 需为 {store.L1_OPTIONS}")
    if body.category_l2 not in store.L2_OPTIONS:
        raise HTTPException(400, f"category_l2 需为 {store.L2_OPTIONS}")
    # 已复盘则拒绝（一 case 一复盘；改走 PUT）
    if store.get_review_by_case(body.case_id):
        raise HTTPException(409, "该 case 已有复盘记录（一 case 一复盘）")
    flow = store.get_by_case_id(body.case_id)
    if not flow:
        raise HTTPException(404, "case 无 flow 记录")
    ex = flow.get("extra") or {}
    # 团伙定性 = 处罚 penalty；报出原因快照 = pipeline_full_reason（详情页同款拼装）
    pen = (ex.get("penalty") or {})
    gang_verdict = body.gang_verdict or (ex.get("external_result") or pen.get("risk_types") or "")
    reason_snapshot = ex.get("pipeline_full_reason") or ex.get("external_reason") or ""
    # pipeline_full_reason 可能不在 extra（flow_by_case 才拼）——动态拼一次
    if not reason_snapshot:
        try:
            rf = flow_by_case(body.case_id)
            reason_snapshot = ((rf.get("flow") or {}).get("extra") or {}).get("pipeline_full_reason") or ""
        except Exception:
            pass
    data = {
        "case_id": body.case_id,
        "group_id": flow.get("group_id") or "",
        "category_l1": body.category_l1,
        "category_l2": body.category_l2,
        "env": body.env or "",
        "gang_verdict": gang_verdict,
        "problem_desc": body.problem_desc,
        "follow_up": body.follow_up or "",
        "reviewer": body.reviewer or (request.session.get("mis") or ""),
        "reason_snapshot": reason_snapshot,
        "dt": flow.get("dt") or "",
    }
    rec = store.create_review(data)
    sys_log("info", f"[Review] 新增复盘 case={body.case_id} l1={body.category_l1} "
                    f"l2={body.category_l2} by={data['reviewer']}")
    return {"status": 1, "review": rec}


@router.get("/api/reviews")
def review_list(date_from: str = "", date_to: str = "",
                 l1: str = "", env: str = "", case_id: str = ""):
    """复盘列表（日期范围/一级分类/环节筛选）。case_id 给了查单 case 的复盘。"""
    import flow_store as store
    if case_id:
        rec = store.get_review_by_case(case_id)
        return {"reviews": [rec] if rec else []}
    return {"reviews": store.list_reviews(date_from, date_to, l1, env)}


class ReviewUpdateRequest(BaseModel):
    category_l1: Optional[str] = None
    category_l2: Optional[str] = None
    env: Optional[str] = None
    gang_verdict: Optional[str] = None
    problem_desc: Optional[str] = None
    follow_up: Optional[str] = None
    reviewer: Optional[str] = None


@router.put("/api/reviews/{rid}")
def review_update(rid: str, body: ReviewUpdateRequest):
    import flow_store as store
    if not store.update_review(rid, body.dict(exclude_none=True)):
        raise HTTPException(400, "无可更新字段")
    return {"status": 1, "review": store.get_review(rid)}


@router.delete("/api/reviews/{rid}")
def review_delete(rid: str):
    import flow_store as store
    store.delete_review(rid)
    return {"status": 1}


@router.get("/api/reviews/summary")
def review_summary(date_from: str = "", date_to: str = ""):
    """聚合统计：一级分类计数（含"运营通过"）+ 一级×二级矩阵。"""
    import flow_store as store
    reviews = store.list_reviews(date_from, date_to)
    l1_count, matrix = {}, {}
    for r in reviews:
        a, b = r.get("category_l1") or "—", r.get("category_l2") or "—"
        l1_count[a] = l1_count.get(a, 0) + 1
        matrix.setdefault(a, {})
        matrix[a][b] = matrix[a].get(b, 0) + 1
    # 缺口：该时段捞全完成 case 数 vs 已复盘数
    import pipeline_store as _ps
    try:
        df = date_from or "20260915"
        dt_to = date_to or datetime.now().strftime("%Y%m%d")
        rows = _ps._sb().execute(
            "SELECT count(DISTINCT case_id) AS n FROM flow_jobs WHERE dt >= $1 AND dt <= $2 "
            "AND stage IN ('injury_eval','punish','done') AND status IN ('running','done')",
            [df, dt_to])
        total = int(rows[0]["n"])
    except Exception:
        total = None
    reviewed_cases = len({r.get("case_id") for r in reviews})
    return {"l1_count": l1_count, "matrix": matrix,
            "total_cases": total, "reviewed_cases": reviewed_cases}
