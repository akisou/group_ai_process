#!/usr/bin/env bash
set -e

# ── 构建脚本：创建虚拟环境 + 安装依赖 ──────────────────────────────
# 内网 PyPI 源（pypi.sankuai.com），含 pytalos 等内部包

virtualenv venv
source venv/bin/activate
pip install -r requirements.txt \
    -i http://pypi.sankuai.com/simple \
    --trusted-host pypi.sankuai.com
