#!/usr/bin/env python3
"""批量重跑指定 dt 所有 case 的 AI 模型判定（rule_agent）。
用法：python scripts/rerun_judge.py <dt> [并发数，默认 6]
背景：CatX Agent 提示词多次迭代（5万硬守卫/fail-closed/A+E+C/D 组合达标制/
     F 保护线/交叉验证失效降级），历史判定需按最新口径重刷。
2026-10-12：从 rerun_261009_judge.py 泛化，dt 参数化。
"""
import sys, os, time
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import threading
from concurrent.futures import ThreadPoolExecutor, as_completed

import flow_store

if len(sys.argv) < 2:
    print("用法: python scripts/rerun_judge.py <dt> [并发数，默认 6]")
    sys.exit(1)
DT = sys.argv[1].replace("-", "")
CONCURRENCY = int(sys.argv[2]) if len(sys.argv) > 2 else 6

_print_lock = threading.Lock()
_counter = {"done": 0}


def _log(msg):
    with _print_lock:
        print(msg, flush=True)


def judge_one(case_id, total):
    from api.routes import _rule_agent_run
    t0 = time.time()
    try:
        res = _rule_agent_run(case_id, 'default', DT, trigger='rerun')
        dt = time.time() - t0
        _counter["done"] += 1
        if res.get('status') == 1:
            return (case_id, True,
                    f"[{_counter['done']}/{total}] {case_id} ✓ 高准确={res.get('high', 0)} "
                    f"低准确={res.get('low', 0)} 不通过={res.get('fail', 0)} ({dt:.1f}s)")
        return (case_id, False,
                f"[{_counter['done']}/{total}] {case_id} ✗ {res.get('message', '')[:100]}")
    except Exception as e:
        _counter["done"] += 1
        return (case_id, False,
                f"[{_counter['done']}/{total}] {case_id} ✗ {type(e).__name__}: {str(e)[:120]}")


def main():
    flows = flow_store._sb().execute(
        "SELECT case_id FROM flow_jobs WHERE dt=$1 ORDER BY case_id", [DT])
    case_ids = [r['case_id'] for r in flows]
    total = len(case_ids)
    _log(f"dt={DT} 共 {total} 个 case 待重判，并发 {CONCURRENCY}")

    success, fail = [], []
    with ThreadPoolExecutor(max_workers=CONCURRENCY) as exe:
        futs = {exe.submit(judge_one, cid, total): cid for cid in case_ids}
        for fut in as_completed(futs):
            cid, ok, msg = fut.result()
            _log(msg)
            (success if ok else fail).append(cid)

    _log(f"\n完成: {len(success)} 成功, {len(fail)} 失败")
    if fail:
        _log("失败 case: " + ', '.join(sorted(fail)[:30]))


if __name__ == '__main__':
    main()
