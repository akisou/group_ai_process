"""
CatX（CatPaw Managed Agents）客户端——规则判定 Agent 调用。
流程：创建会话 → POST events 发消息 → 轮询 GET events 取 agent.message 回复。
鉴权：X-Api-Key（config.local.yaml 的 catx 段，不进 git）。
"""
from __future__ import annotations

import json
import time

import httpx

from logger import sys_log

BASE_URL = "https://api.catpaw.sankuai.com/v1"


def _cfg():
    from config import get_config
    cfg = get_config()
    return cfg.catx if hasattr(cfg, "catx") else None


class CatXClient:
    """规则判定 Agent 客户端（无状态）。"""

    def __init__(self):
        c = _cfg()
        if not c or not c.api_key:
            raise RuntimeError("catx.api_key 未配置（config.local.yaml 的 catx 段）")
        self.api_key = c.api_key
        self.agent_id = c.agent_id
        self.environment_id = c.environment_id

    def _headers(self) -> dict:
        return {"X-Api-Key": self.api_key, "Content-Type": "application/json"}

    def create_session(self, title: str = "rule-judge") -> str:
        """创建会话，返回 session id。"""
        r = httpx.post(f"{BASE_URL}/sessions", headers=self._headers(),
                       json={"agent": self.agent_id, "environment_id": self.environment_id,
                             "title": title}, timeout=30)
        r.raise_for_status()
        return r.json()["id"]

    def send_message(self, session_id: str, text: str) -> None:
        """发送用户消息。"""
        r = httpx.post(f"{BASE_URL}/sessions/{session_id}/events", headers=self._headers(),
                       json={"events": [{"type": "user.message",
                                        "content": [{"type": "text", "text": text}]}]},
                       timeout=30)
        r.raise_for_status()

    def get_reply(self, session_id: str, timeout_s: int = 120, interval_s: float = 1.5) -> str:
        """轮询取 Agent 回复（agent.message 的 text）。超时返回空串。

        单次 GET 的网络异常（SSL 握手超时/连接重置/网关抖动）不中断轮询——
        2026-09-13 修复：原实现任何一次 httpx.get 抛异常直接把整个轮询炸掉，
        上层只拿到"超时/为空"，实际回复可能早已到达（超时率 11/20 的主因）。
        5xx 同样跳过等下轮（平台侧瞬时错误）。"""
        deadline = time.time() + timeout_s
        err_streak = 0
        while time.time() < deadline:
            try:
                r = httpx.get(f"{BASE_URL}/sessions/{session_id}/events",
                              headers=self._headers(), timeout=20)
                if r.status_code == 200:
                    err_streak = 0
                    for e in r.json().get("data", []):
                        if e.get("type") == "agent.message":
                            for c in e.get("content", []):
                                if c.get("type") == "text" and c.get("text"):
                                    return c["text"]
                elif r.status_code >= 500:
                    err_streak += 1
            except Exception:
                err_streak += 1
            # 连续错误超过 30 次才放弃（3s×30=90s 纯网络失败，远超正常抖动窗口）
            if err_streak >= 30:
                sys_log("warning", f"[CatX] 轮询连续异常 {err_streak} 次，放弃 session={session_id}")
                return ""
            time.sleep(interval_s)
        return ""

    def judge(self, payload: dict, timeout_s: int = 300) -> str:
        """便捷入口：建会话 + 发判定请求 + 取回复文本。
        失败自动重试 1 次（重新建会话——平台侧偶发 session 无响应）。"""
        for attempt in (1, 2):
            try:
                sid = self.create_session()
                self.send_message(sid, json.dumps(payload, ensure_ascii=False))
            except Exception as e:
                sys_log("warning", f"[CatX] 建会话/发送失败（attempt {attempt}）: {str(e)[:120]}")
                time.sleep(3)
                continue
            reply = self.get_reply(sid, timeout_s=timeout_s)
            if reply:
                return reply
            sys_log("warning", f"[CatX] 判定超时（{timeout_s}s）attempt={attempt} session={sid}")
            if attempt == 1:
                time.sleep(5)   # 重试前稍等（平台负载高时第二个会话更容易成功）
        return ""
