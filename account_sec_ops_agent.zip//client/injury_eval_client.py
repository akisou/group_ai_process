"""
误伤评估客户端（sceneKey=accountsec_agent_group_evaluation）。
与 preprocess/laoquan 隔离：独立 sceneKey + 独立提交参数（dt/group_id/case_combo_id/target_sql_b64/action_type）。
鉴权：CIBA access-token（与 preprocess/laoquan 共用 SSO 取票，客户端实例独立）。
"""
from __future__ import annotations

import httpx
from logger import sys_log

SCENE_KEY = "accountsec_agent_group_evaluation"
START_URL = "https://mtsi-clue.sankuai.com/api/case/autoCutLoss/offlineStartCanvasForAccount"
STATUS_URL = "https://mtsi-clue.sankuai.com/api/case/autoCutLoss/offlineQueryCanvasStatusForAccount"

TERMINAL = {"FAILED", "SUCCEEDED", "KILLED"}
FAILED = {"FAILED", "KILLED"}


class InjuryEvalClient:
    """误伤评估画布客户端（无状态，直接实例化）。"""

    def _mis(self) -> str:
        from config import get_config
        return get_config().mtsi_canvas.mis_id

    def _token(self) -> str:
        from client.sso_auth import get_sso_manager
        return get_sso_manager().get_mtsi_token(self._mis())

    def _headers(self) -> dict:
        return {"Content-Type": "application/json", "access-token": self._token()}

    def _post(self, url: str, **kwargs) -> dict:
        mis = self._mis()
        try:
            with httpx.Client(timeout=30.0, follow_redirects=False) as c:
                resp = c.post(url, headers=self._headers(), **kwargs)
            if resp.status_code == 401:
                from client.sso_auth import get_sso_manager
                get_sso_manager().invalidate(mis)
                with httpx.Client(timeout=30.0, follow_redirects=False) as c:
                    resp = c.post(url, headers=self._headers(), **kwargs)
            body = resp.json()
            if isinstance(body, dict) and (body.get("data") or {}).get("code") in (30001, 30002):
                from client.sso_auth import get_sso_manager
                get_sso_manager().invalidate(mis)
                with httpx.Client(timeout=30.0, follow_redirects=False) as c:
                    resp = c.post(url, headers=self._headers(), **kwargs)
                body = resp.json()
            return body
        except Exception as e:
            return {"success": False, "message": str(e)}

    def submit(self, case_id: str, dt: str, combo_id: str,
               target_sql_b64: str, action_type: str, group_id: str = "") -> dict:
        """提交误伤评估画布。globalParam 多行：dt/case_combo_id/target_sql_b64/action_type（不传 group_id）。"""
        from datetime import datetime
        ts = datetime.now().strftime("%Y%m%d%H%M%S")
        # uniqueKey 平台上限 64 字符（实测 65 即被拒）。缩写前缀 18 字符 + 完整 case_combo_id + ts：
        # accsec_agent_eval_26090300102_c001_20260903203342 = 50 字符
        unique_key = f"accsec_agent_eval_{combo_id}_{ts}"
        global_param = (f"dt={dt}\ncase_combo_id={combo_id}\n"
                        f"target_sql_b64={target_sql_b64}\naction_type={action_type}")
        payload = {
            "sceneKey": SCENE_KEY,
            "globalParam": global_param,
            "uniqueKey": unique_key,
            "misId": self._mis(),
        }
        sys_log("info", f"[InjuryEval] 提交任务 case={case_id} combo={combo_id} uniqueKey={unique_key}")
        body = self._post(START_URL, json=payload)
        result = {
            "unique_key": unique_key,
            "request": {"method": "POST", "url": START_URL, "body": payload},
            "response": {"status_code": 200, "body": body},
        }
        if body.get("success"):
            sys_log("info", f"[InjuryEval] 提交成功 uniqueKey={unique_key}")
            return result
        err = body.get("message") or body.get("msg") or str(body)
        sys_log("warning", f"[InjuryEval] 提交失败 case={case_id} combo={combo_id}: {err} | 完整响应: {str(body)[:300]}")
        raise RuntimeError(f"误伤评估画布提交失败: {err}")

    def query_status(self, unique_key: str) -> dict:
        """查询画布状态。返回 {status, request, response}。"""
        body = self._post(STATUS_URL, params={"uniqueKey": unique_key})
        status = str(body.get("result") or "UNKNOWN").upper()
        result = {
            "status": status,
            "request": {"method": "POST", "url": STATUS_URL, "params": {"uniqueKey": unique_key}},
            "response": {"status_code": 200, "body": body},
        }
        if not body.get("success"):
            sys_log("warning", f"[InjuryEval] 状态查询失败 {unique_key}: {body.get('message','')}")
        return result
