"""
SSOTokenManager — 封装美团 SSO OIDC Token 获取与缓存。

mtsi 操作：按用户 MIS 独立缓存，target=com.sankuai.rc.mtsi.harp
鉴权方式：access-token header（mtsi）

Token 通过 Rhino AI CIBA 流程获取，首次需用户在大象授权，之后缓存 25h。
"""
from __future__ import annotations

from typing import Optional
import time
import threading
import httpx
from logger import sys_log

MTSI_TARGET_CLIENT_ID = "com.sankuai.rc.mtsi.harp"
_TOKEN_REFRESH_BEFORE = 300  # 提前 5 分钟刷新


class SSOTokenManager:
    def __init__(
        self,
        rhino_ai_base: str,
        fallback_mis: str,
        ciba_timeout_s: int = 60,
    ):
        self._rhino_ai_base = rhino_ai_base
        self._fallback_mis = fallback_mis
        self._ciba_timeout_s = ciba_timeout_s
        # {f"{mis}:{target_client_id}": {"token": str, "expires_at": float}}
        self._cache: dict[str, dict] = {}
        self._locks: dict[str, threading.Lock] = {}
        self._meta_lock = threading.Lock()

    def get_mtsi_token(self, mis: str) -> str:
        """获取指定用户 MIS 的 mtsi AT token，自动缓存与刷新。
        mis 为空时 fallback 到 fallback_mis。
        """
        effective_mis = mis if mis else self._fallback_mis
        if not mis:
            sys_log("debug", f"[SSO] mis 为空，fallback 到 {effective_mis}")
        return self._get_cached(effective_mis, MTSI_TARGET_CLIENT_ID)

    def _get_cached(self, mis: str, target_client_id: str) -> str:
        cache_key = f"{mis}:{target_client_id}"
        entry = self._cache.get(cache_key)
        if entry and time.time() < entry["expires_at"] - _TOKEN_REFRESH_BEFORE:
            return entry["token"]
        with self._meta_lock:
            if cache_key not in self._locks:
                self._locks[cache_key] = threading.Lock()
            key_lock = self._locks[cache_key]
        with key_lock:
            entry = self._cache.get(cache_key)
            if entry and time.time() < entry["expires_at"] - _TOKEN_REFRESH_BEFORE:
                return entry["token"]
            token = self._fetch_token_via_mis(mis, target_client_id)
            self._cache[cache_key] = {"token": token, "expires_at": time.time() + 25 * 3600}
            return token

    def _fetch_token_via_mis(self, mis: str, target_client_id: str) -> str:
        """
        通过 Rhino AI /openapi-v2/sso/token 走 CIBA 流程获取 AT token。
        - 200：成功返回 token
        - 202：CIBA 授权中，轮询等待最多 ciba_timeout_s
        """
        url = f"{self._rhino_ai_base}/openapi-v2/sso/token"
        params = {"mis": mis, "mcpClientId": target_client_id}
        sys_log("info", f"[SSO] 获取 token mis={mis} target={target_client_id}")

        resp = httpx.get(url, params=params, timeout=15.0)
        resp.raise_for_status()
        body = resp.json()
        code = str(body.get("code", ""))

        if code == "200":
            token = body.get("result", {}).get("token")
            if not token:
                raise ValueError(f"[SSO] 响应中无 token: {body}")
            sys_log("info", f"[SSO] token 获取成功 mis={mis}")
            return token

        if code == "202":
            auth_url = body.get("result", {}).get("authUrl", "")
            sys_log("info", f"[SSO] CIBA 授权中 mis={mis}，轮询等待（authUrl={auth_url[:60]}）")
            deadline = time.time() + self._ciba_timeout_s
            interval = 2
            while time.time() < deadline:
                time.sleep(interval)
                resp = httpx.get(url, params=params, timeout=15.0)
                resp.raise_for_status()
                body = resp.json()
                code = str(body.get("code", ""))
                if code == "200":
                    token = body.get("result", {}).get("token")
                    if not token:
                        raise ValueError(f"[SSO] 响应中无 token: {body}")
                    sys_log("info", f"[SSO] CIBA 授权完成，token 获取成功 mis={mis}")
                    return token
                if code != "202":
                    break
                interval = min(interval * 2, 10)
            raise RuntimeError(
                f"[SSO] CIBA 授权超时（60s），mis={mis}，请手动在大象 App 授权：{auth_url}"
            )

        raise RuntimeError(f"[SSO] 获取 token 失败: {body}")

    def invalidate(self, mis: str) -> None:
        """主动失效某用户的 mtsi token 缓存。"""
        effective_mis = mis if mis else self._fallback_mis
        self._cache.pop(f"{effective_mis}:{MTSI_TARGET_CLIENT_ID}", None)


# ── 全局单例，由 main.py lifespan 初始化 ──────────────────
_sso_manager: Optional[SSOTokenManager] = None


def get_sso_manager() -> SSOTokenManager:
    if _sso_manager is None:
        raise RuntimeError("SSOTokenManager 尚未初始化，请检查 main.py lifespan")
    return _sso_manager


def init_sso_manager(manager: SSOTokenManager) -> None:
    global _sso_manager
    _sso_manager = manager
