"""
画布任务客户端（mlp 触发器）
调用 mtsi offlineStartCanvas / offlineQueryCanvasStatus 接口。
画布内跑 pyspark（产出 rule 等数据并落 Hive），平台只负责提交 + 轮询状态。

scene_key / urls / mis_id / global_param_template 均从 config 读取，
原 migrate 分支为模块常量。
"""
from __future__ import annotations

import httpx
from logger import sys_log

# 画布运行状态枚举（StatusEnum）
# NEW / READY / STARTING / RUNNING / ON_KILLED / FAILED / SUCCEEDED / KILLED
TERMINAL_STATUSES = {"FAILED", "SUCCEEDED", "KILLED"}
FAILED_STATUSES = {"FAILED", "KILLED"}


class CICanvasClient:
    """画布任务客户端（无状态，直接实例化使用）。"""

    def _cfg(self):
        from config import get_config
        return get_config().mtsi_canvas

    def _token(self) -> str:
        """画布接口鉴权 access-token：CIBA 用户 token（与反爬一致，按 mis 取）。"""
        from client.sso_auth import get_sso_manager
        return get_sso_manager().get_mtsi_token(self._cfg().mis_id)

    def _headers(self) -> dict:
        return {"Content-Type": "application/json", "access-token": self._token()}

    def _lookup_case_name(self, case_id: str, dt: str) -> str:
        """从 case_info 表查 case_name（查不到返回空，submit 用 case_id 兜底）。"""
        try:
            import time
            import sql_templates as Q
            from config import get_config
            from client.talos_client import TalosClient
            cfg = get_config()
            tc = TalosClient()
            qid = tc.submit_query(Q.case_info_sql(cfg, case_id, dt))
            deadline = time.time() + 30
            while time.time() < deadline:
                r = tc.get_query_status(qid)
                if r["status"] != "pending":
                    if r["status"] == "done" and r.get("rows"):
                        cols = r["columns"]
                        i = cols.index("case_name")
                        return str(r["rows"][0][i] or "")
                    return ""
                time.sleep(2)
        except Exception:
            pass
        return ""

    def _post(self, url: str, **kwargs) -> dict:
        mis_id = self._cfg().mis_id
        try:
            with httpx.Client(timeout=30.0, follow_redirects=False) as c:
                resp = c.post(url, headers=self._headers(), **kwargs)
            # 401：token 失效，刷新 SSO 缓存重试一次
            if resp.status_code == 401:
                from client.sso_auth import get_sso_manager
                get_sso_manager().invalidate(mis_id)
                with httpx.Client(timeout=30.0, follow_redirects=False) as c:
                    resp = c.post(url, headers=self._headers(), **kwargs)
            body = resp.json()
            # 30001/30002 = ssoid 过期，刷新 token 重试一次
            if isinstance(body, dict) and (body.get("data") or {}).get("code") in (30001, 30002):
                from client.sso_auth import get_sso_manager
                get_sso_manager().invalidate(mis_id)
                with httpx.Client(timeout=30.0, follow_redirects=False) as c:
                    resp = c.post(url, headers=self._headers(), **kwargs)
                body = resp.json()
            return body
        except Exception as e:
            return {"success": False, "message": str(e)}

    # ── 提交画布任务 ────────────────────────────────────────────────────────

    def submit(self, case_id: str, dt: str = "", case_name: str = "",
               global_param: str = "") -> dict:
        """
        提交画布任务（laoquan 提纯捞全）。返回 {unique_key, request, response}（含完整请求/返回报文）。
        global_param 传了用原样透传；不传则用 config 模板 + dt/case_name 拼接。
        sceneKey 固定用 config.mtsi_canvas.scene_key（laoquan），预处理任务用独立的 PreprocessClient。
        """
        from datetime import datetime
        cfg = self._cfg()
        if not cfg.scene_key:
            raise RuntimeError("mtsi_canvas.scene_key 未配置，请在 config.yaml 填写画布 sceneKey")

        ts = datetime.now().strftime("%Y%m%d%H%M%S")
        unique_key = f"{cfg.scene_key}_{case_id}_{ts}"
        if not dt:
            dt = datetime.now().strftime("%Y%m%d")
        if not global_param:
            if not case_name:
                case_name = self._lookup_case_name(case_id, dt) or f"case_{case_id}"
            global_param = cfg.global_param_template.format(dt=dt, case_id=case_id, case_name=case_name)
        # unique_key 追加进 globalParam（供 mlp 日志与系统侧关联），仅在未含时拼
        if "unique_key=" not in global_param:
            global_param = f"{global_param} --unique_key={unique_key}"

        payload = {
            "sceneKey": cfg.scene_key,
            "globalParam": global_param,
            "uniqueKey": unique_key,
            "misId": cfg.mis_id,
        }
        sys_log("info", f"[Canvas] 提交画布任务 case_id={case_id} dt={dt} uniqueKey={unique_key} globalParam={global_param}")
        body = self._post(cfg.start_url, json=payload)
        result = {
            "unique_key": unique_key,
            "request": {"method": "POST", "url": cfg.start_url, "body": payload},
            "response": {"status_code": 200, "body": body},
        }
        if body.get("success"):
            sys_log("info", f"[Canvas] 提交成功 uniqueKey={unique_key}")
            return result
        err = body.get("message") or body.get("msg") or str(body)
        sys_log("warning", f"[Canvas] 提交失败 case_id={case_id}: {err}")
        raise RuntimeError(f"offlineStartCanvas 失败: {err}")

    # ── 查询画布状态 ────────────────────────────────────────────────────────

    def query_status(self, unique_key: str) -> dict:
        """
        查询画布任务状态。返回 {status, request, response}（含完整请求/返回报文）。
        """
        cfg = self._cfg()
        body = self._post(cfg.status_url, params={"uniqueKey": unique_key})
        status = str(body.get("result") or "UNKNOWN").upper()
        result = {
            "status": status,
            "request": {"method": "POST", "url": cfg.status_url, "params": {"uniqueKey": unique_key}},
            "response": {"status_code": 200, "body": body},
        }
        if not body.get("success"):
            sys_log("warning", f"[Canvas] 状态查询失败 {unique_key}: {body.get('message','')}")
        sys_log("debug", f"[Canvas] 状态 {unique_key} → {status}")
        return result
