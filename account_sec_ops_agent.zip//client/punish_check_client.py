"""
团伙处置校验客户端（sceneKey=accountsec_agent_group_punish_check）。
Step7 人工确认处罚后调用：globalParam = dt/case_combo_id/check_info（0 不处罚 / 1 处罚）。
鉴权：CIBA access-token（共用 SSO 取票，客户端实例独立）。
"""
from __future__ import annotations

import httpx
from logger import sys_log

SCENE_KEY = "accountsec_agent_group_punish_check"
START_URL = "https://mtsi-clue.sankuai.com/api/case/autoCutLoss/offlineStartCanvasForAccount"
STATUS_URL = "https://mtsi-clue.sankuai.com/api/case/autoCutLoss/offlineQueryCanvasStatusForAccount"

FAILED = {"FAILED", "KILLED"}


class PunishCheckClient:
    """团伙处置校验画布客户端（无状态）。"""

    def _mis(self) -> str:
        from config import get_config
        return get_config().mtsi_canvas.mis_id

    def _token(self) -> str:
        from client.sso_auth import get_sso_manager
        return get_sso_manager().get_mtsi_token(self._mis())

    def _headers(self) -> dict:
        return {"Content-Type": "application/json", "access-token": self._token()}

    def _post(self, url: str, **kwargs) -> dict:
        mis = self._mis()
        try:
            with httpx.Client(timeout=30.0, follow_redirects=False) as c:
                resp = c.post(url, headers=self._headers(), **kwargs)
            if resp.status_code == 401:
                from client.sso_auth import get_sso_manager
                get_sso_manager().invalidate(mis)
                with httpx.Client(timeout=30.0, follow_redirects=False) as c:
                    resp = c.post(url, headers=self._headers(), **kwargs)
            body = resp.json()
            if isinstance(body, dict) and (body.get("data") or {}).get("code") in (30001, 30002):
                from client.sso_auth import get_sso_manager
                get_sso_manager().invalidate(mis)
                with httpx.Client(timeout=30.0, follow_redirects=False) as c:
                    resp = c.post(url, headers=self._headers(), **kwargs)
                body = resp.json()
            return body
        except Exception as e:
            return {"success": False, "message": str(e)}

    def submit(self, case_id: str, combo_id: str, dt: str, check_info: int) -> dict:
        """提交处置校验画布。globalParam：dt/case_combo_id/check_info。check_info 0=不处罚 1=处罚。"""
        from datetime import datetime
        ts = datetime.now().strftime("%Y%m%d%H%M%S")
        # uniqueKey 平台 64 字符上限：缩写前缀 18 + combo + ts
        unique_key = f"accsec_agent_punish_{combo_id}_{ts}"
        global_param = f"dt={dt}\ncase_combo_id={combo_id}\ncheck_info={int(check_info)}"
        payload = {
            "sceneKey": SCENE_KEY,
            "globalParam": global_param,
            "uniqueKey": unique_key,
            "misId": self._mis(),
        }
        sys_log("info", f"[PunishCheck] 提交 case={case_id} combo={combo_id} check_info={check_info} uniqueKey={unique_key}")
        body = self._post(START_URL, json=payload)
        result = {
            "unique_key": unique_key,
            "request": {"method": "POST", "url": START_URL, "body": payload},
            "response": {"status_code": 200, "body": body},
        }
        if body.get("success"):
            sys_log("info", f"[PunishCheck] 提交成功 uniqueKey={unique_key}")
            return result
        err = body.get("message") or body.get("msg") or str(body)
        sys_log("warning", f"[PunishCheck] 提交失败 combo={combo_id}: {err} | 完整响应: {str(body)[:300]}")
        raise RuntimeError(f"团伙处置画布提交失败: {err}")

    def query_status(self, unique_key: str) -> dict:
        body = self._post(STATUS_URL, params={"uniqueKey": unique_key})
        status = str(body.get("result") or "UNKNOWN").upper()
        return {
            "status": status,
            "request": {"method": "POST", "url": STATUS_URL, "params": {"uniqueKey": unique_key}},
            "response": {"status_code": 200, "body": body},
        }
