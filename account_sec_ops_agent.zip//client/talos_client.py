"""
TalosClient — 封装 pytalos 查询提交和状态查询。
支持系统账号和个人 MIS 场景鉴权。
网络瞬断容错：get_query_status 对 RemoteDisconnected / ReadTimeout 等网络异常
做 3 次退避重试（qid 幂等，结果在 Talos 侧缓存 ~1h，重试安全）。
"""
from __future__ import annotations

from typing import Optional

from pytalos.client import AsyncTalosClient, SDKScene

_DONE_STATUSES = {"FINISHED"}
_FAILED_STATUSES = {"QUERY_TIMEOUT", "FAILED", "KILLED"}

# 网络瞬断类异常（可安全重试——qid 幂等，Talos 侧缓存查询结果）
_NETWORK_ERRORS = (
    ConnectionError,
    ConnectionResetError,
    ConnectionAbortedError,
    TimeoutError,
)


class TalosClient:
    def __init__(self, endpoint: Optional[str] = None,
                 username: Optional[str] = None,
                 password: Optional[str] = None,
                 scene: Optional[str] = None):
        from config import get_config
        cfg = get_config().talos
        self._endpoint = endpoint or cfg.endpoint
        self._username = username or cfg.username
        self._password = password or cfg.password
        self._scene = scene or cfg.scene

    def _new_client(self) -> AsyncTalosClient:
        sdk_scene = SDKScene.MIS if self._scene == "mis" else SDKScene.SYSTEM_ACCOUNT
        return AsyncTalosClient(
            username=self._username,
            password=self._password,
            endpoint=self._endpoint,
            sdk_scene=sdk_scene,
        )

    def submit_query(self, sql: str, engine: str = "presto") -> str:
        """提交查询，返回 qid。秒级返回，不阻塞等待结果。
        默认 presto（无 08:00-23:00 时间窗限制，夜间可查）；hive 引擎受时间窗限制。"""
        client = self._new_client()
        try:
            client.open_session()
            qid = client.submit(statement=sql, engine=engine)
            return qid
        finally:
            try:
                client.close_session()
            except Exception:
                pass

    def _query_once(self, qid: str) -> dict:
        """单次查询 qid 状态（打开会话 → 查 info → 下载结果 → 关闭会话）。"""
        client = self._new_client()
        try:
            client.open_session()
            info = client.get_query_info(qid)
            status = info.get("status", "")

            if status in _DONE_STATUSES:
                total = int(info.get("total") or 0)
                if total < 0:
                    raise RuntimeError(f"Talos qid={qid} 返回非法 total={total}")
                if total > 10000:
                    rows = list(client.download(qid))
                else:
                    fa = client.fetch_all(qid)
                    rows = fa["data"] if isinstance(fa, dict) else []
                    if rows is None:
                        rows = []
                if len(rows) != total:
                    raise RuntimeError(
                        f"Talos qid={qid} 结果不完整: expected={total} fetched={len(rows)}")
                end = info.get("endTime", 0)
                start = info.get("createTime", 0)
                return {
                    "status": "done",
                    "columns": [c["name"] for c in info.get("columns", [])],
                    "rows": rows,
                    "total": total,
                    "execution_time_ms": (end - start) if end and start else None,
                    "error": None,
                }
            elif status in _FAILED_STATUSES or status.upper().startswith("ERROR"):
                return {
                    "status": "failed",
                    "error": info.get("message", f"查询失败: {status}"),
                    "columns": [],
                    "rows": [],
                    "execution_time_ms": None,
                }
            else:
                return {
                    "status": "pending",
                    "columns": [],
                    "rows": [],
                    "total": None,
                    "error": None,
                }
        finally:
            try:
                client.close_session()
            except Exception:
                pass

    def get_query_status(self, qid: str) -> dict:
        """
        查询单个 qid 的当前状态，不轮询。
        返回: {status: pending|done|failed, rows, columns, execution_time_ms, error}

        网络瞬断容错：对 ConnectionError（含 requests 抛出的 RemoteDisconnected，
        requests 的 ConnectionError 继承自 IOError——故同时兜底捕获 IOError 中的连接
        异常子类）/ TimeoutError 做 3 次退避重试（5s/10s/15s）。
        业务失败（QUERY_TIMEOUT/FAILED/KILLED）不重试，直接返回 failed。
        """
        import time as _time
        import requests as _requests

        attempt = 0
        while True:
            try:
                return self._query_once(qid)
            except _requests.exceptions.ConnectionError as e:
                attempt += 1
                if attempt >= 3:
                    raise RuntimeError(f"Talos 查询 {qid} 网络异常（已重试 {attempt} 次）: {str(e)[:200]}") from e
                wait = 5 * attempt
                print(f"[TalosClient] 网络瞬断（第 {attempt}/3 次），{wait}s 后重试 qid={qid}: {str(e)[:120]}", flush=True)
                _time.sleep(wait)
            except (_requests.exceptions.Timeout, TimeoutError) as e:
                attempt += 1
                if attempt >= 3:
                    raise RuntimeError(f"Talos 查询 {qid} 超时（已重试 {attempt} 次）: {str(e)[:200]}") from e
                wait = 5 * attempt
                print(f"[TalosClient] 查询超时（第 {attempt}/3 次），{wait}s 后重试 qid={qid}", flush=True)
                _time.sleep(wait)
            except OSError as e:
                # requests 底层 socket 异常（RemoteDisconnected 表现为 http.client.RemoteDisconnected
                # → requests.exceptions.ConnectionError），部分场景裸露为 OSError
                attempt += 1
                if attempt >= 3:
                    raise RuntimeError(f"Talos 查询 {qid} 网络异常（OSError，已重试 {attempt} 次）: {str(e)[:200]}") from e
                wait = 5 * attempt
                print(f"[TalosClient] 网络异常 OSError（第 {attempt}/3 次），{wait}s 后重试 qid={qid}: {str(e)[:120]}", flush=True)
                _time.sleep(wait)
