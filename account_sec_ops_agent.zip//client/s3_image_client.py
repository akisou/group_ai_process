"""
S3plus 图片上传器（仿反爬 hopejob / gang_validation 的 image_uploader）。
时序折线图（SVG/PNG）上传对象存储，返回公开 URL。
幂等：同 name+同内容 → 同 key，重复上传不产生垃圾对象。
失败返回 None 不抛异常（不阻断调用方主流程）。

认证双模式（config s3_upload.auth）：
- kms（默认，同反爬）：S3Connection(kms_appkey=appkey)，密钥由运行环境 KMS agent
  （127.0.0.1:5269）透明托管——需容器/虚机开通 pc.use.kms=true，本地 Mac 不可用。
- ak：S3Connection(aws_access_key_id=access_key, aws_secret_access_key=secret_key)，
  S3plus 平台 service 账号密钥，任何环境可用。
"""
from __future__ import annotations

import hashlib
from typing import Optional

from logger import sys_log


def _cfg():
    from config import get_config
    c = get_config()
    return getattr(c, "s3_upload", None)


class S3ImageUploader:
    """S3plus 图片上传（kms_appkey 或 access_key/secret_key 认证）。"""

    def __init__(self, endpoint: str, bucket_name: str, image_prefix: str = "rule_agent",
                 auth: str = "kms", appkey: str = "",
                 access_key: str = "", secret_key: str = ""):
        self.endpoint = endpoint
        self.bucket_name = bucket_name
        self.image_prefix = image_prefix
        self.auth = auth
        self.appkey = appkey
        self.access_key = access_key
        self.secret_key = secret_key
        self._bucket = None

    def _ensure_conn(self):
        if self._bucket is not None:
            return
        from mssapi.s3.connection import S3Connection
        if self.auth == "kms":
            conn = S3Connection(
                kms_appkey=self.appkey,
                is_secure=False,
                host=self.endpoint,
            )
        else:
            conn = S3Connection(
                aws_access_key_id=self.access_key,
                aws_secret_access_key=self.secret_key,
                host=self.endpoint,
                is_secure=False,
            )
        self._bucket = conn.get_bucket(self.bucket_name)

    def _key(self, name: str, content_hash: str, ext: str) -> str:
        return f"{self.image_prefix}_{name}_{content_hash}.{ext}"

    def upload(self, image_bytes: bytes, name: str, ext: str = "svg") -> Optional[str]:
        """上传图片字节，返回公开 URL。失败 None（记日志）。"""
        try:
            self._ensure_conn()
            content_hash = hashlib.md5(image_bytes).hexdigest()[:16]
            key = self._bucket.new_key(self._key(name, content_hash, ext))
            content_type = "image/svg+xml" if ext == "svg" else "image/png"
            key.set_contents_from_string(image_bytes, headers={"Content-Type": content_type})
            return f"http://{self.endpoint}/{self.bucket_name}/{self._key(name, content_hash, ext)}"
        except Exception as e:
            sys_log("warning", f"[S3] 上传失败({name}): {str(e)[:200]}")
            return None


def get_uploader() -> Optional[S3ImageUploader]:
    """从 config 取 s3_upload 段构建上传器；未配置/未启用返回 None。"""
    c = _cfg()
    if not c or not c.enabled:
        return None
    return S3ImageUploader(
        endpoint=c.endpoint,
        bucket_name=c.bucket,
        image_prefix=c.image_prefix,
        auth=c.auth,
        appkey=c.appkey,
        access_key=c.access_key,
        secret_key=c.secret_key,
    )
