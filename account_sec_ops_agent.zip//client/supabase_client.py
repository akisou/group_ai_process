"""
SupabaseClient — 通过 /pg/query 端点执行 SQL（对标反爬 client/supabase_client.py）。
鉴权：apikey + Authorization: Bearer header。
用于 canvas_jobs 表持久化（替代 SQLite）。
"""
from __future__ import annotations

import json
import traceback
from typing import Optional

import httpx

from logger import sys_log


class SupabaseClient:
    def __init__(self, base_url: Optional[str] = None, service_key: Optional[str] = None):
        from config import get_config
        cfg = get_config()
        self.base_url = (base_url or cfg.supabase.base_url).rstrip("/")
        self.service_key = service_key or cfg.supabase.service_key
        if not self.service_key:
            raise RuntimeError("supabase.service_key 未配置（环境变量 SUPABASE_SERVICE_KEY 或 config.local.yaml）")
        self._http = httpx.Client(
            headers={
                "apikey": self.service_key,
                "Authorization": f"Bearer {self.service_key}",
                "Content-Type": "application/json",
            },
            timeout=httpx.Timeout(connect=5.0, read=25.0, write=5.0, pool=5.0),
            limits=httpx.Limits(max_connections=20, max_keepalive_connections=10),
        )

    @staticmethod
    def _escape(v) -> str:
        """把 Python 值安全内联进 SQL（/pg/query 不支持参数化）。"""
        if v is None:
            return "NULL"
        if isinstance(v, bool):
            return "TRUE" if v else "FALSE"
        if isinstance(v, (int, float)):
            return str(v)
        if isinstance(v, (dict, list)):
            safe = json.dumps(v, ensure_ascii=False).replace("'", "''").replace("\x00", "")
            return "'" + safe + "'::jsonb"
        return "'" + str(v).replace("'", "''").replace("\x00", "") + "'"

    def _query(self, sql: str, params: Optional[list] = None) -> list[dict]:
        """执行 SQL，返回行列表（dict）。"""
        func = "cli"
        try:
            frames = traceback.extract_stack(limit=5)[:-1]
            func = next(
                (f"{f.filename.split('/')[-1].replace('.py','')}:{f.name}"
                 for f in reversed(frames)
                 if 'supabase_client' not in f.filename and '<string>' not in f.filename),
                'cli'
            )
        except Exception:
            pass
        sql = f"/* app=account_agent_dev; func={func} */ " + sql.lstrip()
        if params:
            for i in range(len(params), 0, -1):
                sql = sql.replace(f"${i}::uuid", self._escape(params[i-1]))
                sql = sql.replace(f"${i}::jsonb", self._escape(params[i-1]))
                sql = sql.replace(f"${i}", self._escape(params[i-1]))
        try:
            resp = self._http.post(f"{self.base_url}/pg/query", json={"query": sql})
            if not resp.is_success:
                sys_log("warning", f"[Supabase] HTTP {resp.status_code} body: {resp.text[:300]}")
            resp.raise_for_status()
            return resp.json()
        except Exception as e:
            # 连接层异常 str(e) 可能为空（SSLEOFError 等），补异常类型名保证日志可排查
            sys_log("error", f"[Supabase] query failed: {str(e).strip() or type(e).__name__} "
                            f"({type(e).__name__}) | sql={sql[:120]}")
            raise

    def execute(self, sql: str, params: Optional[list] = None) -> list[dict]:
        """执行 INSERT/UPDATE/DDL，返回行列表（通常空）。"""
        return self._query(sql, params)
