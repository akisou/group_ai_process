"""
CASE 预处理任务客户端 —— 与 laoquan 画布客户端（ci_canvas_client）完全隔离。

硬编码 sceneKey=accountsec_agent_preprocess + ForAccount 接口，无 scene_key 参数、
无 laoquan 兜底，确保预处理任务绝不会误触发 laoquan 画布。
鉴权：CIBA access-token（与 laoquan 共用 SSO 取票机制，但客户端实例独立）。
"""
from __future__ import annotations

import httpx
from logger import sys_log

# 硬编码：预处理任务专用，不读 config.mtsi_canvas（避免和 laoquan 混）
SCENE_KEY = "accountsec_agent_preprocess"
START_URL = "https://mtsi-clue.sankuai.com/api/case/autoCutLoss/offlineStartCanvasForAccount"
STATUS_URL = "https://mtsi-clue.sankuai.com/api/case/autoCutLoss/offlineQueryCanvasStatusForAccount"

TERMINAL = {"FAILED", "SUCCEEDED", "KILLED"}
FAILED = {"FAILED", "KILLED"}


class PreprocessClient:
    """预处理画布客户端（无状态，直接实例化）。"""

    def _mis(self) -> str:
        from config import get_config
        return get_config().mtsi_canvas.mis_id

    def _token(self) -> str:
        from client.sso_auth import get_sso_manager
        return get_sso_manager().get_mtsi_token(self._mis())

    def _headers(self) -> dict:
        return {"Content-Type": "application/json", "access-token": self._token()}

    def _post(self, url: str, **kwargs) -> dict:
        mis = self._mis()
        try:
            with httpx.Client(timeout=30.0, follow_redirects=False) as c:
                resp = c.post(url, headers=self._headers(), **kwargs)
            if resp.status_code == 401:
                from client.sso_auth import get_sso_manager
                get_sso_manager().invalidate(mis)
                with httpx.Client(timeout=30.0, follow_redirects=False) as c:
                    resp = c.post(url, headers=self._headers(), **kwargs)
            body = resp.json()
            if isinstance(body, dict) and (body.get("data") or {}).get("code") in (30001, 30002):
                from client.sso_auth import get_sso_manager
                get_sso_manager().invalidate(mis)
                with httpx.Client(timeout=30.0, follow_redirects=False) as c:
                    resp = c.post(url, headers=self._headers(), **kwargs)
                body = resp.json()
            return body
        except Exception as e:
            return {"success": False, "message": str(e)}

    def submit(self, case_id: str, dt: str, group_id: str) -> dict:
        """提交预处理画布。globalParam 多行格式 dt/group_id/case_id/unique_key（unique_key 供 mlp 日志关联）。"""
        from datetime import datetime
        ts = datetime.now().strftime("%Y%m%d%H%M%S")
        unique_key = f"{SCENE_KEY}_{case_id}_{ts}"
        global_param = f"dt={dt}\ngroup_id={group_id}\ncase_id={case_id}\nunique_key={unique_key}"
        payload = {
            "sceneKey": SCENE_KEY,
            "globalParam": global_param,
            "uniqueKey": unique_key,
            "misId": self._mis(),
        }
        sys_log("info", f"[Preprocess] 提交任务 case_id={case_id} uniqueKey={unique_key} globalParam={global_param}")
        body = self._post(START_URL, json=payload)
        result = {
            "unique_key": unique_key,
            "request": {"method": "POST", "url": START_URL, "body": payload},
            "response": {"status_code": 200, "body": body},
        }
        if body.get("success"):
            sys_log("info", f"[Preprocess] 提交成功 uniqueKey={unique_key}")
            return result
        err = body.get("message") or body.get("msg") or str(body)
        sys_log("warning", f"[Preprocess] 提交失败 case_id={case_id}: {err}")
        raise RuntimeError(f"预处理画布提交失败: {err}")

    def query_status(self, unique_key: str) -> dict:
        """查询预处理画布状态。返回 {status, request, response}。"""
        body = self._post(STATUS_URL, params={"uniqueKey": unique_key})
        status = str(body.get("result") or "UNKNOWN").upper()
        result = {
            "status": status,
            "request": {"method": "POST", "url": STATUS_URL, "params": {"uniqueKey": unique_key}},
            "response": {"status_code": 200, "body": body},
        }
        if not body.get("success"):
            sys_log("warning", f"[Preprocess] 状态查询失败 {unique_key}: {body.get('message','')}")
        return result
