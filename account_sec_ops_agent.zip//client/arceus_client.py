"""
Arceus（dify）工作流客户端——风险事件排查流水线用。
5 个工作流：团伙判定 / 风险判定-注册/登录/解冻/Token。
鉴权：Bearer api_key（应用级，API key 在 config.pipeline 配置）。
流式 SSE 调用，等待 workflow_finished 事件取 outputs。
"""
from __future__ import annotations

import json
from typing import Any, Dict, Optional

import httpx

from logger import sys_log

ARCEUS_BASE_URL = "https://arceusllm-api.sankuai.com/v1/workflows/run"


def _pipeline_cfg():
    from config import get_config
    return get_config().pipeline


def call_workflow(api_key: str, inputs: Dict[str, Any], workflow_name: str,
                  user: str, timeout: int = 600) -> Dict[str, Any]:
    """流式调用 Arceus 工作流，返回 {status, outputs} 或 {status: failed, error}。"""
    headers = {"Content-Type": "application/json", "Authorization": f"Bearer {api_key}"}
    payload = {"inputs": inputs, "response_mode": "streaming", "user": user}
    try:
        outputs: Dict[str, Any] = {}
        with httpx.Client(timeout=timeout) as client:
            with client.stream("POST", ARCEUS_BASE_URL, headers=headers, json=payload) as resp:
                resp.raise_for_status()
                for line in resp.iter_lines():
                    if not line or not line.startswith("data:"):
                        continue
                    data_str = line[5:].strip()
                    if not data_str or data_str == "[DONE]":
                        continue
                    try:
                        event = json.loads(data_str)
                    except json.JSONDecodeError:
                        continue
                    if event.get("event") == "workflow_finished":
                        outputs = (event.get("data") or {}).get("outputs") or {}
                        break
                    # node_finished 的 text/result/answer 兜底（登录工作流的输出在节点层）
                    if event.get("event") == "node_finished":
                        node_out = (event.get("data") or {}).get("outputs") or {}
                        if isinstance(node_out, dict):
                            for key in ("text", "result", "answer", "output"):
                                if node_out.get(key):
                                    outputs.setdefault(key, node_out[key])
        return {"status": "succeeded", "outputs": outputs}
    except Exception as e:
        sys_log("warning", f"[Arceus] [{workflow_name}] 调用失败: {str(e)[:200]}")
        return {"status": "failed", "outputs": {}, "error": str(e)[:300]}


# ── 4 个风险判定工作流的输入封装（团伙判定已改读感知表，不调 dify）─────────

def call_risk_register(group_id: str, platform_app_partner: str, label: str, dt: str) -> Dict[str, Any]:
    cfg = _pipeline_cfg()
    return call_workflow(
        cfg.api_key_risk_register,
        {"group_id": group_id, "user_id": "-", "label": label,
         "platform_app_partner": platform_app_partner, "dt": dt},
        "风险判定-注册", cfg.user_risk_register)


def call_risk_login(group_id: str, platform_app_partner: str, label: str, dt: str) -> Dict[str, Any]:
    cfg = _pipeline_cfg()
    return call_workflow(
        cfg.api_key_risk_login,
        {"group_id": group_id, "user_id": "-", "label": label,
         "platform_app_partner": platform_app_partner, "dt": dt},
        "风险判定-登录", cfg.user_risk_login)


def call_risk_unfreeze(group_id: str, platform_app_partner: str, label: str, dt: str) -> Dict[str, Any]:
    cfg = _pipeline_cfg()
    return call_workflow(
        cfg.api_key_risk_unfreeze,
        {"group_id": group_id, "user_id": "-", "label": label,
         "platform_app_partner": platform_app_partner, "dt": dt},
        "风险判定-解冻", cfg.user_risk_unfreeze)


def call_risk_token(group_id: str, platform_app_partner: str, label: str, dt: str) -> Dict[str, Any]:
    cfg = _pipeline_cfg()
    return call_workflow(
        cfg.api_key_risk_token,
        {"dt": dt, "group_id": group_id, "label": label,
         "platform_app_partner": platform_app_partner, "is_risk_group": "1"},
        "风险判定-Token", cfg.user_risk_token)
