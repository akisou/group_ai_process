"""
误伤评估任务持久化层（Supabase）——sceneKey=accountsec_agent_group_evaluation。
一个 combo 一条任务（case_combo_id 维度），独立表 injury_eval_jobs。
status：pending → submitted → done / failed
"""
from __future__ import annotations

import json
import uuid
from datetime import datetime
from typing import Optional

from client.supabase_client import SupabaseClient
from logger import sys_log

_SCHEMA = """
CREATE TABLE IF NOT EXISTS injury_eval_jobs (
  id TEXT PRIMARY KEY,
  case_id TEXT NOT NULL,
  combo_id TEXT NOT NULL,
  dt TEXT,
  group_id TEXT,
  action_type TEXT,
  target_sql_b64 TEXT,
  unique_key TEXT,
  status TEXT NOT NULL DEFAULT 'pending',
  error_message TEXT,
  extra JSONB DEFAULT '{}'::jsonb,
  created_at TEXT,
  updated_at TEXT
);
CREATE INDEX IF NOT EXISTS idx_ie_case ON injury_eval_jobs(case_id);
CREATE INDEX IF NOT EXISTS idx_ie_status ON injury_eval_jobs(status);
"""

_sb_client = None


def _sb():
    global _sb_client
    if _sb_client is None:
        _sb_client = SupabaseClient()
    return _sb_client


def _now() -> str:
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")


def _row_to_dict(row) -> dict:
    if not row:
        return {}
    d = dict(row)
    extra = d.get("extra")
    if isinstance(extra, str):
        try:
            d["extra"] = json.loads(extra)
        except Exception:
            d["extra"] = {}
    elif extra is None:
        d["extra"] = {}
    return d


def ensure_schema():
    try:
        _sb().execute(_SCHEMA)
        sys_log("info", "[InjuryEval] schema ensured (injury_eval_jobs table)")
    except Exception as e:
        sys_log("error", f"[InjuryEval] ensure_schema failed: {str(e)[:200]}")


def create_job(case_id: str, combo_id: str, dt: str, group_id: str,
               action_type: str, target_sql_b64: str) -> dict:
    """建 pending 任务（原子写全部参数）。"""
    job_id = str(uuid.uuid4())
    now = _now()
    placeholder = f"pending_{case_id}_{combo_id}"
    extra = json.dumps({"dt": dt}, ensure_ascii=False)
    _sb().execute(
        "INSERT INTO injury_eval_jobs (id, case_id, combo_id, dt, group_id, action_type, "
        "target_sql_b64, unique_key, status, extra, created_at, updated_at) "
        "VALUES ($1,$2,$3,$4,$5,$6,$7,$8,'pending',$9::jsonb,$10,$11)",
        [job_id, case_id, combo_id, dt, group_id, action_type, target_sql_b64,
         placeholder, extra, now, now],
    )
    sys_log("info", f"[InjuryEval] created job={job_id} case={case_id} combo={combo_id}")
    return get_job(job_id)


def get_job(job_id: str) -> Optional[dict]:
    rows = _sb().execute("SELECT * FROM injury_eval_jobs WHERE id=$1", [job_id])
    return _row_to_dict(rows[0]) if rows else None


def list_by_case(case_id: str) -> list:
    rows = _sb().execute(
        "SELECT * FROM injury_eval_jobs WHERE case_id=$1 ORDER BY created_at DESC", [case_id])
    return [_row_to_dict(r) for r in rows]


def list_running() -> list:
    rows = _sb().execute(
        "SELECT * FROM injury_eval_jobs WHERE status IN ('pending','submitted') ORDER BY updated_at")
    return [_row_to_dict(r) for r in rows]


def claim_for_submit(job_id: str) -> bool:
    now = _now()
    rows = _sb().execute(
        "UPDATE injury_eval_jobs SET status='submitted', updated_at=$1 "
        "WHERE id=$2 AND status='pending' RETURNING id", [now, job_id])
    return bool(rows)


def update_status(job_id: str, status: str, **fields) -> None:
    allowed = {"unique_key", "error_message"}
    sets, vals = ["status=$1", "updated_at=$2"], [status, _now()]
    idx = 3
    for k, v in fields.items():
        if k in allowed:
            sets.append(f"{k}=${idx}")
            vals.append(v)
            idx += 1
    vals.append(job_id)
    _sb().execute(f"UPDATE injury_eval_jobs SET {','.join(sets)} WHERE id=${idx}", vals)


def update_extra(job_id: str, extra_dict: dict) -> None:
    _sb().execute(
        "UPDATE injury_eval_jobs SET extra = COALESCE(extra,'{}'::jsonb) || $1::jsonb, updated_at=$2 WHERE id=$3",
        [json.dumps(extra_dict, ensure_ascii=False), _now(), job_id],
    )
