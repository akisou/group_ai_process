"""
画布 job 调度器（APScheduler 后台轮询）。
对标反爬 case_intelligence/job_manager.py 的 _submit_canvas_job / _poll_canvas_job。

两阶段：
  canvas_polling → 等待 offlineQueryCanvasStatus 返回 SUCCEEDED
  verifying      → Talos SELECT count(*) 校验结果表非空（防画布报成功但表没落）

fail-closed 哲学：Talos qid 持久化失败 → needs_reconcile，不自动重试。
"""
from __future__ import annotations

from datetime import datetime, timedelta
from threading import Thread

from apscheduler.schedulers.background import BackgroundScheduler

import canvas_job_store as store
from client.ci_canvas_client import CICanvasClient, FAILED_STATUSES
from client.talos_client import TalosClient
from logger import sys_log


class CanvasScheduler:
    def __init__(self):
        from config import get_config
        cfg = get_config().canvas_scheduler
        self.interval = cfg.poll_interval_seconds
        self.pool_limit = cfg.canvas_pool_limit
        self.verify_sql_template = cfg.verify_sql_template
        self._sched: BackgroundScheduler | None = None

    def start(self):
        if self._sched is not None:
            return
        self._sched = BackgroundScheduler(timezone="Asia/Shanghai")
        self._sched.add_job(self._poll_all, "interval", seconds=self.interval, id="canvas_poll",
                            max_instances=1, coalesce=True, misfire_grace_time=10)
        self._sched.start()
        sys_log("info", f"[CanvasScheduler] started, interval={self.interval}s, pool_limit={self.pool_limit}")

    def shutdown(self):
        if self._sched is not None:
            self._sched.shutdown(wait=False)
            self._sched = None
            sys_log("info", "[CanvasScheduler] shutdown")

    def _poll_all(self):
        """每轮：pick up pending（提交画布）+ 推进 submitted/verifying。"""
        try:
            for job in store.get_running_jobs():
                try:
                    self._advance(job)
                except Exception as e:
                    sys_log("warning", f"[CanvasScheduler] job={job.get('id')} advance error: {str(e)[:200]}")
        except Exception as e:
            sys_log("error", f"[CanvasScheduler] poll_all error: {str(e)[:200]}")

    def _advance(self, job: dict):
        jid = job["id"]
        status = job["status"]
        phase = job.get("canvas_phase", "canvas_polling")

        if status == "pending":
            self._submit(job)
            return

        if status == "submitted" and phase == "canvas_polling":
            self._poll_canvas(job)
            return

        if status == "verifying":
            self._poll_verify(job)
            return

        if status == "syncing":
            self._check_syncing_timeout(job)
            return

    # ── 阶段 0：提交画布 ──────────────────────────────────────────────────
    def _submit(self, job: dict):
        jid = job["id"]
        case_id = job["case_id"]
        # mlp 全局强限制：总开关 + 全局并发（跨调度器合计）；priority=1 走加急通道（+10 独享槽）
        urgent = bool(((job.get("extra") or {}).get("priority"))
                      or str(job.get("priority") or "") not in ("", "0", "None"))
        from mlp_switch import mlp_can_submit
        if not mlp_can_submit("laoquan", urgent=urgent):
            return
        # CAS 抢占：pending → submitted
        if not store.claim_for_submit(jid):
            return  # 已被其他实例抢占或状态变了
        try:
            extra = job.get("extra") or {}
            custom = extra.get("global_param") or ""
            submit_dt = extra.get("submit_dt") or job.get("submit_dt") or ""
            res = CICanvasClient().submit(case_id, dt=submit_dt, global_param=custom)
            unique_key = res["unique_key"]
            sys_log("info", f"[CanvasScheduler] submit returned job={jid} unique_key={unique_key} has_request={bool(res.get('request'))}")
            # 先存 extra（含接口报文），再改 status
            try:
                store.update_extra(jid, {
                    "canvas_status": "SUBMITTED",
                    "start_canvas_request": res.get("request"),
                    "start_canvas_response": res.get("response"),
                })
            except Exception as ex_err:
                sys_log("warning", f"[CanvasScheduler] store start_canvas报文失败 job={jid}: {str(ex_err)[:200]}")
            store.update_status(jid, "submitted", unique_key=unique_key, canvas_phase="canvas_polling")
            sys_log("info", f"[CanvasScheduler] submitted job={jid} case={case_id} unique_key={unique_key}")
        except Exception as e:
            err = str(e)
            store.update_status(jid, "failed", error_message=err[:500])
            store.update_extra(jid, {"submit_error": err[:500]})
            sys_log("warning", f"[CanvasScheduler] submit failed job={jid}: {err[:200]}")

    # ── 阶段一：轮询画布状态 ──────────────────────────────────────────────
    def _poll_canvas(self, job: dict):
        jid = job["id"]
        unique_key = job.get("unique_key") or ""
        if not unique_key or unique_key.startswith("pending_"):
            # 旧快照竞态：提交线程可能刚写完真实 uk（本快照是轮询开始时读的）。回查 DB 再判。
            fresh = store.get_job(jid)
            unique_key = (fresh or {}).get("unique_key") or ""
            if not unique_key or unique_key.startswith("pending_"):
                store.update_status(jid, "failed", error_message="canvas_polling 阶段 unique_key 为空（回查仍为空）")
                return
        try:
            res = CICanvasClient().query_status(unique_key)
            status = res["status"]
        except Exception as e:
            store.update_extra(jid, {"canvas_status": "UNKNOWN", "last_error": str(e)[:200]})
            return
        store.update_extra(jid, {
            "canvas_status": status,
            "query_canvas_request": res["request"],
            "query_canvas_response": res["response"],
        })

        if status == "SUCCEEDED":
            # 画布完成 → 提交 Talos 校验 SQL，转 verifying
            self._submit_verify(job)
            return
        if status in FAILED_STATUSES:
            store.update_status(jid, "failed", error_message=f"画布执行 {status}")
            sys_log("warning", f"[CanvasScheduler] canvas failed job={jid} status={status}")
            return
        # 仍在运行（NEW/READY/STARTING/RUNNING/ON_KILLED），等下轮

    # ── 阶段二：提交校验 SQL ──────────────────────────────────────────────
    def _submit_verify(self, job: dict):
        jid = job["id"]
        case_id = job["case_id"]
        submit_dt = (job.get("extra") or {}).get("submit_dt") or job.get("submit_dt") or ""
        if not submit_dt:
            # 用 case 最新 dt 兜底
            from api.routes import _latest_dt_value
            submit_dt = _latest_dt_value(case_id) or ""
        # 校验查询：final_rules + validation_result 两表之和（profiling 新逻辑写 final_rules，
        # 老路径写 validation_result，任一有数据即通过）
        from config import get_config
        ht = get_config().hive_tables
        sql = (
            f"SELECT (SELECT count(*) FROM {ht.final_rules} WHERE case_id='{case_id}' AND dt='{submit_dt}') "
            f"+ (SELECT count(*) FROM {ht.validation_result} WHERE case_id='{case_id}' AND dt='{submit_dt}') AS cnt"
        )
        try:
            qid = TalosClient().submit_query(sql)
        except Exception as e:
            err = str(e)
            # 不自动重试：校验提交失败直接 failed（画布已 SUCCEEDED，人工确认后可「重跑提纯捞全」重验）
            store.update_status(jid, "failed", error_message=f"校验提交失败（不自动重试）: {err[:300]}")
            sys_log("warning", f"[CanvasScheduler] verify submit fail job={jid}: {err[:150]}")
            return
        # qid 持久化失败必须 fail closed（否则下轮重复提交校验 SQL）
        try:
            store.update_status(jid, "verifying", hive_qid=qid, canvas_phase="verifying")
            store.update_extra(jid, {"hive_qid": qid, "submit_dt": submit_dt})
            sys_log("info", f"[CanvasScheduler] canvas SUCCEEDED, verify qid={qid} job={jid}")
        except Exception as e:
            store.mark_needs_reconcile(jid, f"校验 qid 持久化失败: {str(e)}", hive_qid=qid)

    # ── 阶段三：轮询校验结果 ──────────────────────────────────────────────
    def _poll_verify(self, job: dict):
        jid = job["id"]
        qid = job.get("hive_qid") or ""
        if not qid:
            store.update_status(jid, "failed", error_message="verifying 阶段 qid 为空")
            return
        try:
            result = TalosClient().get_query_status(qid)
        except Exception as e:
            err = str(e)
            # 不自动重试：任何校验查询异常直接 failed（画布已 SUCCEEDED，人工可「重跑提纯捞全」重验）
            store.update_status(jid, "failed", error_message=f"校验查询失败（不自动重试）: {err[:300]}")
            sys_log("warning", f"[CanvasScheduler] verify poll fail job={jid}: {err[:150]}")
            return

        status = result.get("status")
        if status == "done":
            rows = result.get("rows", [])
            count = 0
            if rows:
                try:
                    count = int(rows[0][0])
                except Exception:
                    count = 0
            if count > 0:
                # 画布结果已落 Hive → 后台同步到 PG 缓存，完成后置 done（不阻塞轮询）
                store.update_status(jid, "syncing", row_count=count, canvas_phase="syncing")
                submit_dt = (job.get("extra") or {}).get("submit_dt") or job.get("submit_dt") or ""
                experiment = (job.get("extra") or {}).get("experiment") or job.get("experiment") or ""
                Thread(target=self._sync_and_finish,
                       args=(jid, job["case_id"], experiment, submit_dt, count),
                       daemon=True).start()
                sys_log("info", f"[CanvasScheduler] canvas done, syncing to PG job={jid} rows={count}")
            else:
                # 画布报成功但结果表空 → failed（异常，需人工查）
                store.update_status(jid, "failed", error_message="画布 SUCCEEDED 但结果表为空")
                sys_log("warning", f"[CanvasScheduler] canvas SUCCEEDED but empty result job={jid}")
        elif status == "failed":
            store.update_status(jid, "failed", error_message=f"校验 Talos 失败: {result.get('error','')[:200]}")
        # pending：等下轮

    # ── 阶段四：画布结果同步到 PG 缓存 + 预取 SVG + Agent 判定（后台线程）────
    def _sync_and_finish(self, jid: str, case_id: str, experiment: str, dt: str, count: int):
        """同步该 case+dt 主切片到 result_cache，成功置 done，失败置 failed（可 retry）。
        同步完成后提交 case_prefetch 预热（批量 SVG/ts_daily 落缓存 + Agent 判定预触发），
        失败不影响画布 done 状态（数据已落 Hive，用户手动触发仍可）。"""
        try:
            import result_cache
            r = result_cache.sync_case_results(case_id, experiment, dt)
            store.update_status(jid, "done", row_count=count)
            sys_log("info", f"[CanvasScheduler] job done (synced) job={jid} rows={count}")
        except Exception as e:
            store.update_status(jid, "failed", error_message=f"同步落库失败: {str(e)[:400]}")
            sys_log("warning", f"[CanvasScheduler] sync failed job={jid}: {str(e)[:200]}")
            return  # 同步失败不继续预取
        # 预取 SVG/ts_daily（批量一条 SQL）+ Agent 判定（提交到 case_prefetch worker 池，
        # 失败只 log，不影响 done 状态；用 sync 解析出的真实 experiment）
        try:
            import case_prefetch
            case_prefetch.submit_after_sync(case_id, r.get("experiment") or experiment, dt)
        except Exception as e:
            sys_log("warning", f"[CanvasScheduler] prefetch submit fail case={case_id}: {str(e)[:150]}")

    def _check_syncing_timeout(self, job: dict):
        """syncing 卡住超 10min 置 failed（线程崩溃兜底）。"""
        jid = job["id"]
        updated = job.get("updated_at") or ""
        try:
            t = datetime.strptime(updated, "%Y-%m-%d %H:%M:%S")
            if datetime.now() - t > timedelta(minutes=10):
                store.update_status(jid, "failed", error_message="同步落库超时(>10min)")
                sys_log("warning", f"[CanvasScheduler] sync timeout job={jid}")
        except Exception:
            pass
