"""
全流程串联调度器 —— 编排 4 阶段，复用已有 PreprocessScheduler / CanvasScheduler 跑画布。

stage 流转：
  preprocess → snapshot → laoquan → done

- preprocess：建预处理任务（preprocess_store），PreprocessScheduler 提交+轮询画布到 SUCCEEDED
- snapshot：Talos 查 ba_rc.app_acc_sec_case_status，
  case_id 对应 status=done 才推进（每 5min 轮询，受 Talos 08-23 提交窗口限制）
- laoquan：建提纯捞全 job（canvas_job_store），CanvasScheduler 提交+校验+同步到 done，
  再查 recall_accounts 非空 → 最终规则集落入 → flow done
"""
from __future__ import annotations

import time
from datetime import datetime, timedelta

from apscheduler.schedulers.background import BackgroundScheduler

import flow_store as store
from logger import sys_log

# snapshot 就绪判断表（优先 ba_rc.app_acc_sec_case_status，有 status=done 数据）
SNAPSHOT_TABLES = [
    "ba_rc.app_acc_sec_case_status",
]
SNAPSHOT_POLL_INTERVAL = 300  # 5 分钟

_DONE_CANVAS = {"SUCCEEDED"}
_FAILED_CANVAS = {"FAILED", "KILLED"}


class FlowScheduler:
    def __init__(self):
        from config import get_config
        cfg = get_config().canvas_scheduler
        self.interval = max(cfg.poll_interval_seconds, 30)
        self._sched: BackgroundScheduler | None = None

    def start(self):
        if self._sched is not None:
            return
        self._sched = BackgroundScheduler(timezone="Asia/Shanghai")
        self._sched.add_job(self._poll_all, "interval", seconds=self.interval, id="flow_poll",
                            max_instances=1, coalesce=True, misfire_grace_time=10)
        self._sched.start()
        sys_log("info", f"[FlowScheduler] started, interval={self.interval}s")

    def shutdown(self):
        if self._sched is not None:
            self._sched.shutdown(wait=False)
            self._sched = None
            sys_log("info", "[FlowScheduler] shutdown")

    def _poll_all(self):
        try:
            for flow in store.list_running():
                try:
                    self._advance(flow)
                except Exception as e:
                    sys_log("warning", f"[FlowScheduler] flow={flow.get('id')} advance error: {str(e)[:200]}")
            self._backfill_agent()
            # 分配兜底节流（2026-09-21 用户定：每 10 分钟一次）：捞全完成未分配的
            # case 自动按权重分配——CaseWarm 的即时钩子为主，本兜底扫漏网
            import time as _tmod
            if not hasattr(self, "_last_assign_fill") or _tmod.time() - self._last_assign_fill >= 600:
                self._last_assign_fill = _tmod.time()
                self._backfill_assign()
        except Exception as e:
            sys_log("error", f"[FlowScheduler] poll_all error: {str(e)[:200]}")

    def _backfill_assign(self):
        """分配兜底（2026-09-21）：捞全完成但 case_assignments 无记录的 case →
        自动按权重分配。覆盖 warm 失败导致的漏分配（CaseWarm 失败时自动分配
        钩子不执行）。幂等：已有分配跳过（assign_single ON CONFLICT DO NOTHING）。
        每 10 分钟触发一次（poll_all 节流），单轮上限 50 个。
        dt 用 flow 的（处理日——与 CASE总览按天分栏一致）。"""
        try:
            import flow_store as _fs
            import pipeline_store as _ps
            existing = {a["case_id"] for a in _fs.list_assignments("")}
            rows = _ps._sb().execute(
                "SELECT case_id, dt FROM flow_jobs WHERE stage IN ('injury_eval','punish') "
                "AND status='running' AND dt >= '20260915' ORDER BY updated_at DESC LIMIT 120")
            n = 0
            for r in rows:
                if r["case_id"] in existing:
                    continue
                mis = _fs.auto_assign(r["case_id"], r.get("dt") or "")
                if mis:
                    n += 1
                if n >= 50:
                    break
            if n:
                sys_log("info", f"[FlowScheduler] 分配兜底本轮补 {n} 个 case")
        except Exception:
            pass

    # 兜底去重（2026-09-14）：判定进行中（无结果但已提交）的 case 记录提交时间，
    # 10 分钟内不重复提交——否则每 30s 轮询重复排队同一任务挤占 worker 池。
    _backfill_inflight: dict = {}   # case_id → 提交时间戳

    def _backfill_agent(self):
        """Agent 判定兜底（2026-09-13）：捞全完成（已过 laoquan 阶段）但 flow.extra 无
        rule_agent 的 → 自动补提交预热。覆盖两类遗漏：① 预热 worker 池队列任务丢失
        （00297 实锤）② 进程重启丢队列任务。幂等：已有判定跳过；每轮最多补 2 个
        （CatX 平台并发承受有限——20 并发实锤全部超时失败，回落保守值）。
        同一 case 10 分钟内只补提交一次（判定全流程含队列等待约 5-15 分钟，
        重复提交只是往池里塞重复任务）。"""
        import time as _time
        try:
            rows = store._sb().execute(
                "SELECT case_id, dt FROM flow_jobs WHERE status='running' "
                "AND stage IN ('injury_eval','punish') "
                "AND (extra->>'rule_agent' IS NULL OR extra->>'rule_agent'='null') "
                "AND dt >= '20260913' ORDER BY updated_at DESC LIMIT 6")
            for r in rows:
                cid, dt = r["case_id"], r["dt"]
                ts = self._backfill_inflight.get(cid)
                if ts and _time.time() - ts < 600:
                    continue   # 10 分钟内已提交过，判定进行中
                self._backfill_inflight[cid] = _time.time()
                import case_prefetch
                case_prefetch.submit_after_sync(cid, "default", dt)
                sys_log("info", f"[FlowScheduler] Agent 兜底补判 case={cid} dt={dt}")
        except Exception:
            pass

    def _advance(self, flow: dict):
        fid = flow["id"]
        stage = flow["stage"]
        if stage == "preprocess":
            self._stage_preprocess(flow)
        elif stage == "snapshot":
            self._stage_snapshot(flow)
        elif stage == "laoquan":
            self._stage_laoquan(flow)
        elif stage == "injury_eval":
            self._stage_injury_eval(flow)

    # ── 阶段四：误伤评估（捞全 done 后自动建评估任务，全部完成置 flow done）──
    def _stage_injury_eval(self, flow: dict):
        """捞全完成后：不再自动建误伤评估任务（2026-09-13 用户定——评估须人工在 Step6
        勾选 combo 后点「启动误伤评估」才提交）。本阶段仅监控：有任务且全部终态后
        flow 置 done；无任务时保持 injury_eval 等待人工启动。"""
        fid = flow["id"]
        case_id = flow["case_id"]
        try:
            import injury_eval_store as ie_store
            jobs = ie_store.list_by_case(case_id)
            if not jobs:
                return  # 无任务：等人工启动（保持 injury_eval 阶段）
            self._check_injury_done(flow)
        except Exception as e:
            sys_log("warning", f"[Flow] {fid} 误伤评估监控异常: {str(e)[:200]}")

    def _check_injury_done(self, flow: dict):
        fid = flow["id"]
        import injury_eval_store as ie_store
        jobs = ie_store.list_by_case(flow["case_id"])
        if not jobs:
            # 无任务：等人工启动（2026-09-13 用户定——不自动跳 done，保持 injury_eval 阶段）
            return
        active = [j for j in jobs if j["status"] in ("pending", "submitted")]
        if active:
            return  # 还有评估在跑，等下轮
        failed = [j for j in jobs if j["status"] == "failed"]
        store.update_flow(fid, stage="done", status="done")
        extra = {"stage_done_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S")}
        if failed:
            extra["injury_eval_failed"] = [j["combo_id"] for j in failed]
        store.update_extra(fid, extra)
        sys_log("info", f"[Flow] {fid} 误伤评估完成（{len(jobs)-len(failed)}/{len(jobs)} 成功）→ done")


    # ── 阶段1：预处理任务（建任务→等 PreprocessScheduler 跑完）──
    def _stage_preprocess(self, flow: dict):
        fid = flow["id"]
        pid = flow.get("preprocess_task_id")
        if not pid:
            # 建预处理任务（PreprocessScheduler 会 pick up 提交+轮询）
            import preprocess_store as pp
            case_id = flow["case_id"]
            dt = flow["dt"]
            group_id = flow["group_id"]
            global_param = f"dt={dt}\ngroup_id={group_id}\ncase_id={case_id}"
            try:
                task = pp.create_task(case_id, group_id, dt, global_param)
                if not store.claim_preprocess_task(fid, task["id"]):
                    # 另一轮轮询已绑定（竞态）：作废本条，走别人的
                    pp.update_status(task["id"], "failed", error_message="竞态丢弃：另一轮已建")
                    sys_log("warning", f"[Flow] {fid} preprocess 竞态，丢弃重复任务 {task['id'][:8]}")
                    return
                store.update_extra(fid, {"preprocess_task_id": task["id"],
                                         "stage_preprocess_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S")})
                sys_log("info", f"[Flow] {fid} preprocess 任务已建 task={task['id']}")
            except Exception as e:
                store.update_flow(fid, status="failed", error_message=f"建预处理任务失败: {str(e)[:300]}")
            return
        # 查预处理任务状态
        import preprocess_store as pp
        task = pp.get_task(pid)
        if not task:
            store.update_flow(fid, status="failed", error_message="预处理任务不存在")
            return
        status = task["status"]
        if status == "done":
            store.update_flow(fid, stage="snapshot")
            store.update_extra(fid, {"stage_snapshot_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S")})
            sys_log("info", f"[Flow] {fid} preprocess done → snapshot")
        elif status == "failed":
            err = task.get("error_message") or ""
            if "竞态丢弃" in err or "阶段重跑废弃" in err:
                # 绑定的是被废弃的重复任务：清引用下轮重建（真任务可能还在跑，重建也无害——CAS 保证只有一条被绑定）
                store.update_flow(fid, preprocess_task_id=None)
                sys_log("warning", f"[Flow] {fid} 绑定了废弃任务 {pid[:8]}，清引用重建")
            else:
                store.update_flow(fid, status="failed", error_message=f"预处理失败: {err[:200]}")

    # ── 阶段2：snapshot 就绪（Talos 查 status 表，5min 节流）──
    def _stage_snapshot(self, flow: dict):
        fid = flow["id"]
        # 5min 节流
        last = flow.get("snapshot_last_check") or ""
        if last:
            try:
                t = datetime.strptime(last, "%Y-%m-%d %H:%M:%S")
                if datetime.now() - t < timedelta(seconds=SNAPSHOT_POLL_INTERVAL):
                    return  # 未到 5min，跳过本轮
            except Exception:
                pass
        store.update_flow(fid, snapshot_last_check=datetime.now().strftime("%Y-%m-%d %H:%M:%S"))
        # Talos 查 status 表
        from client.talos_client import TalosClient
        case_id = flow["case_id"]
        tc = TalosClient()
        status_val = None
        for tbl in SNAPSHOT_TABLES:
            sql = f"SELECT status FROM {tbl} WHERE case_id='{case_id}' LIMIT 1"
            try:
                res = self._run_hive(tc, sql)
                if res["status"] == "done" and res.get("rows"):
                    status_val = str(res["rows"][0][0] or "").strip().lower()
                    if status_val:
                        break
            except Exception as e:
                sys_log("debug", f"[Flow] snapshot 查 {tbl} 失败: {str(e)[:120]}")
        if status_val == "done":
            store.update_flow(fid, stage="laoquan")
            store.update_extra(fid, {"stage_laoquan_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S")})
            sys_log("info", f"[Flow] {fid} snapshot done → laoquan")
        # 否则继续等下轮（5min 后）

    # ── 阶段3：提纯捞全（建 job→等 CanvasScheduler 跑完→查 recall_accounts）──
    def _stage_laoquan(self, flow: dict):
        fid = flow["id"]
        ljid = flow.get("laoquan_job_id")
        if not ljid:
            import canvas_job_store as cs
            from config import get_config
            cfg = get_config()
            case_id = flow["case_id"]
            dt = flow["dt"]
            experiment = cfg.default_experiment
            placeholder = f"pending_{case_id}_{dt}"
            try:
                job = cs.create_job(case_id, experiment, dt, placeholder)
                if not store.claim_laoquan_job(fid, job["id"]):
                    # 另一轮轮询已绑定（竞态）：作废本条，走别人的
                    cs.update_status(job["id"], "failed", error_message="竞态丢弃：另一轮已建")
                    sys_log("warning", f"[Flow] {fid} laoquan 竞态，丢弃重复 job {job['id'][:8]}")
                    return
                cs.update_extra(job["id"], {"global_param": cfg.mtsi_canvas.global_param_template.format(
                    dt=dt, case_id=case_id, case_name=flow.get("case_name") or f"case_{case_id}")})
                store.update_extra(fid, {"laoquan_job_id": job["id"]})
                sys_log("info", f"[Flow] {fid} 提纯捞全 job 已建 job={job['id']}")
            except Exception as e:
                store.update_flow(fid, status="failed", error_message=f"建提纯捞全 job 失败: {str(e)[:300]}")
            return
        # 查 laoquan job 状态
        import canvas_job_store as cs
        job = cs.get_job(ljid)
        if not job:
            store.update_flow(fid, status="failed", error_message="提纯捞全 job 不存在")
            return
        status = job["status"]
        if status == "done":
            # 查 final_rules 是否落入最终规则（非空即成功）
            if self._recall_has_rules(flow["case_id"], flow["dt"]):
                store.update_flow(fid, stage="injury_eval")
                store.update_extra(fid, {"stage_injury_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S")})
                sys_log("info", f"[Flow] {fid} 捞全 done → 误伤评估")
            else:
                store.update_flow(fid, status="done", stage="done",
                                  error_message="提纯完成但 final_rules 无最终规则")
                store.update_extra(fid, {"stage_done_at": datetime.now().strftime("%Y-%m-%d %H:%M:%M")})
        elif status == "failed":
            err = job.get("error_message") or ""
            if "竞态丢弃" in err or "阶段重跑废弃" in err:
                # 绑定的是被废弃的重复 job：清引用下轮重建（真 job 可能还在跑，CAS 保证只绑一条）
                store.update_flow(fid, laoquan_job_id=None)
                sys_log("warning", f"[Flow] {fid} 绑定了废弃捞全 job {ljid[:8]}，清引用重建")
            else:
                store.update_flow(fid, status="failed", error_message=f"提纯捞全失败: {err[:200]}")

    def _recall_has_rules(self, case_id: str, dt: str) -> bool:
        """final_rules 表该 case_id 有数据即说明最终规则集已落入。"""
        from client.talos_client import TalosClient
        from config import get_config
        ht = get_config().hive_tables
        tc = TalosClient()
        sql = f"SELECT count(*) AS n FROM {ht.final_rules} WHERE case_id='{case_id}' AND dt='{dt}'"
        try:
            res = self._run_hive(tc, sql)
            if res["status"] == "done" and res.get("rows"):
                return int(res["rows"][0][0] or 0) > 0
        except Exception as e:
            sys_log("debug", f"[Flow] final_rules 查询失败: {str(e)[:120]}")
        return False

    def _run_hive(self, tc, sql: str, max_wait_s: int = 60) -> dict:
        """提交+轮询（受 Talos 08-23 提交窗口限制，窗口外 submit 报错返回 failed）。"""
        from api.routes import _run_hive_sync
        return _run_hive_sync(sql, max_wait_s=max_wait_s)
