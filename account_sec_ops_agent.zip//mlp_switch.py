"""mlp 画布提交控制：总开关（DB 驱动实时生效）+ 全局并发强限制（管理员页面可配）。

全局限制 = 四个画布调度器（laoquan/预处理/误伤评估/团伙处置）已提交未终态的任务
**合计**不超过限制值（默认 20，system_config 表 mlp_global_limit 可调，管理员页面配置）。
这是硬上限——mlp 平台侧总并发，任何调度器提交前必须检查。

加急通道（2026-10-09）：extra.priority=1 的任务独享额外并发槽（默认 +10，可配）。
普通任务受 limit 约束；加急任务上限 = limit + urgent_extra，且加急任务自身并发
不超过 urgent_extra——即加急只用多出来的槽，不挤占普通任务的 60 个基础槽。
"""
from logger import sys_log

DEFAULT_GLOBAL_LIMIT = 20
DEFAULT_URGENT_EXTRA = 10   # 加急额外并发槽（加急任务独享，普通任务不可用）


def mlp_submit_enabled() -> bool:
    """总开关：system_config 表 mlp_submit 优先，config.yaml 兜底。实时生效无需重启。"""
    try:
        import canvas_job_store as _cjs
        rows = _cjs._sb().execute(
            "SELECT value FROM system_config WHERE category='access' AND key='mlp_submit'")
        if rows:
            v = rows[0].get("value")
            # 存储格式 [true]/[false]（jsonb list），兼容裸 bool/字符串
            if isinstance(v, list) and v:
                return bool(v[0])
            return str(v).lower() in ("true", "1")
    except Exception:
        pass
    from config import get_config
    return get_config().mlp_submit.enabled


def global_limit() -> int:
    """全局并发上限：system_config 表 mlp_global_limit 优先（管理员页面配），默认 20。
    配置非法（0/负数/解析失败）一律回落 20——fail-safe。"""
    try:
        import canvas_job_store as _cjs
        rows = _cjs._sb().execute(
            "SELECT value FROM system_config WHERE category='access' AND key='mlp_global_limit'")
        if rows:
            v = rows[0].get("value")
            if isinstance(v, list) and v:
                v = v[0]
            n = int(v)
            if n > 0:
                return n
    except Exception:
        pass
    return DEFAULT_GLOBAL_LIMIT


def global_running_count() -> int:
    """全局已提交画布数（四类任务 submitted 状态合计，不含 pending）。查询失败返回 -1（fail-closed 不提交）。"""
    return _running_counts()[0]


def urgent_running_count() -> int:
    """已提交的加急任务数（extra.priority=1）。查询失败返回 -1。"""
    return _running_counts()[1]


def _running_counts() -> tuple:
    """(全局已提交数, 其中加急数) 一次遍历四表统计。任一表查询失败返回 (-1, -1)（fail-closed）。"""
    total, urgent = 0, 0
    for store_mod, table, statuses in (
        ("canvas_job_store", "canvas_jobs", "('submitted','verifying','syncing')"),
        ("preprocess_store", "preprocess_jobs", "('submitted')"),
        ("injury_eval_store", "injury_eval_jobs", "('submitted')"),
        ("punish_check_store", "punish_check_jobs", "('submitted')"),
    ):
        try:
            mod = __import__(store_mod)
            rows = mod._sb().execute(
                f"SELECT count(*) AS n, "
                f"count(*) FILTER (WHERE COALESCE(extra->>'priority','0') != '0') AS u "
                f"FROM {table} WHERE status IN {statuses}")
            total += int(rows[0]["n"]) if rows else 0
            urgent += int(rows[0]["u"]) if rows else 0
        except Exception:
            return (-1, -1)
    return (total, urgent)


def urgent_extra() -> int:
    """加急额外并发槽数：system_config 表 mlp_urgent_limit 优先，默认 10。非法回落 10。"""
    try:
        import canvas_job_store as _cjs
        rows = _cjs._sb().execute(
            "SELECT value FROM system_config WHERE category='access' AND key='mlp_urgent_limit'")
        if rows:
            v = rows[0].get("value")
            if isinstance(v, list) and v:
                v = v[0]
            n = int(v)
            if n >= 0:
                return n
    except Exception:
        pass
    return DEFAULT_URGENT_EXTRA


# 提交时间窗（默认 23:00-07:00 不提交新任务，夜里上游数据/平台窗口不稳）。
# 时段 DB 可配（system_config 表 submit_ban_hours = [start, end]），页面实时调整。
DEFAULT_BAN_START = 23
DEFAULT_BAN_END = 7


def ban_hours() -> tuple:
    """提交禁止时段 (start_hour, end_hour)：DB 优先，默认 23-7。
    start > end 表示跨午夜（23-7）；start == end 表示无限制。"""
    try:
        import canvas_job_store as _cjs
        rows = _cjs._sb().execute(
            "SELECT value FROM system_config WHERE category='access' AND key='submit_ban_hours'")
        if rows:
            v = rows[0].get("value")
            if isinstance(v, list) and len(v) == 2:
                s, e = int(v[0]), int(v[1])
                if 0 <= s <= 24 and 0 <= e <= 24:
                    return (s, e)
    except Exception:
        pass
    return (DEFAULT_BAN_START, DEFAULT_BAN_END)


def _in_ban_window() -> bool:
    from datetime import datetime
    s, e = ban_hours()
    if s == e:
        return False  # 无限制
    h = datetime.now().hour
    if s > e:
        # 跨午夜窗口（如 23-7）
        return h >= s or h < e
    return s <= h < e


def mlp_can_submit(scheduler: str = "", urgent: bool = False) -> bool:
    """提交前统一检查：总开关开启 且 时间窗允许 且 并发未超限。
    urgent=True（任务 extra.priority=1）：上限放宽 limit+urgent_extra，且加急自身并发
    < urgent_extra——加急任务只占额外槽，不挤占普通任务的 limit 池。"""
    if not mlp_submit_enabled():
        return False
    if _in_ban_window():
        s, e = ban_hours()
        sys_log("debug", f"[mlp] {scheduler} 处于禁止提交时段（{s}:00-{e}:00），跳过")
        return False
    total, urgent_n = _running_counts()
    if total < 0:
        # 查询失败 fail-closed：宁可少提交不可超限
        sys_log("warning", f"[mlp] {scheduler} 并发计数查询失败，fail-closed 暂不提交")
        return False
    limit = global_limit()
    if urgent:
        extra = urgent_extra()
        if urgent_n >= extra:
            sys_log("debug", f"[mlp] {scheduler} 加急并发 {urgent_n}/{extra} 已满，跳过提交")
            return False
        if total >= limit + extra:
            sys_log("debug", f"[mlp] {scheduler} 全局并发 {total}/{limit + extra} 已满，跳过提交")
            return False
        return True
    if total >= limit:
        sys_log("debug", f"[mlp] {scheduler} 全局并发 {total}/{limit} 已满，跳过提交")
        return False
    return True
