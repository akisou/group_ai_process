"""
5 张 Hive 表的查询模板。
表名从 config.hive_tables 注入，参数单引号转义防注入。
所有表分区：case_id, experiment, dt
"""
from __future__ import annotations

from typing import Optional

from config import Settings


def _q(value: object) -> str:
    """单引号 doubling 转义，用于 Hive SQL 字符串字面量。"""
    return str(value).replace("'", "''")


def _t(cfg: Settings, name: str) -> str:
    return getattr(cfg.hive_tables, name)


# ── 案件列表（不区分 experiment）────────────────────────────────────────

def cases_sql(cfg: Settings, dt: str) -> str:
    """case 清单。带 dt：当日 distinct；不带：全表按最新分区倒序取近 500 个 case
    （原 ORDER BY case_id 字典序 LIMIT 500 在 case 累计超 500 后永远截掉新 case——
    2026-09-13 实锤：前 500 全停在 260907，当天的 260912* 全部不可见）。"""
    if dt:
        return (
            f"SELECT DISTINCT case_id FROM {_t(cfg, 'validation_result')} "
            f"WHERE dt='{_q(dt)}' ORDER BY case_id LIMIT 500"
        )
    return (
        f"SELECT case_id FROM {_t(cfg, 'validation_result')} "
        f"GROUP BY case_id ORDER BY max(dt) DESC LIMIT 500"
    )


def latest_dt_sql(cfg: Settings, case_id: str, experiment: Optional[str] = None) -> str:
    """查某 case（可选 experiment）的最新 dt 分区（新老表取 max，用于 dt 留空时自动取最新）。"""
    cond = f"case_id='{_q(case_id)}'"
    if experiment:
        cond += f" AND experiment='{_q(experiment)}'"
    return (
        f"SELECT max(dt) AS dt FROM ("
        f"SELECT dt FROM {_t(cfg, 'validation_result')} WHERE {cond} "
        f"UNION ALL SELECT dt FROM {_t(cfg, 'rule_eval_result')} WHERE {cond}"
        f") t"
    )


def latest_experiment_sql(cfg: Settings, case_id: str) -> str:
    """查某 case 最新 dt 分区实际使用的 experiment（新老表合并，pyspark 可能用不同实验名）。"""
    return (
        f"SELECT experiment FROM ("
        f"SELECT experiment, dt FROM {_t(cfg, 'validation_result')} WHERE case_id='{_q(case_id)}' "
        f"UNION ALL SELECT experiment, dt FROM {_t(cfg, 'rule_eval_result')} WHERE case_id='{_q(case_id)}'"
        f") t ORDER BY dt DESC LIMIT 1"
    )


def case_overview_sql(cfg: Settings) -> str:
    """列出所有 case 的概述：最新 dt、规则总数、HIGH_RISK 数（跨所有 experiment）。"""
    return (
        f"SELECT case_id, max(dt) AS latest_dt, count(*) AS rule_count, "
        f"sum(CASE WHEN level='HIGH_RISK' THEN 1 ELSE 0 END) AS high_risk_count "
        f"FROM {_t(cfg, 'validation_result')} GROUP BY case_id ORDER BY latest_dt DESC"
    )


# ── 提纯：表1 规则验证结果 ────────────────────────────────────────────────

# 新表（acc_sec_rule_eval_result）列桥接 → 老表 39 列顺序 + 7 个新维度列（两表统一 46 列）。
# 布尔列从状态/阈值推导，前端零改动。占位：v_score=NULL、nontrust_pass=evidence_pass 同值、scene_growth=0。
_RULE_EVAL_BRIDGE = """
SELECT
  r.combo_id, r.rule_rank, r.predicates, r.combo_sql, r.combo_size,
  r.level, r.combo_growth,
  CAST(NULL AS VARCHAR)               AS recall_sql,
  r.surge_status = 'PASS'             AS surge_pass,
  CAST(NULL AS DOUBLE)                AS nontrust_growth,
  r.surge_status = 'PASS'             AS nontrust_pass,
  r.geo_max_ratio, r.geo_max_ratio >= 0.5 AS geo_pass,
  r.segment_max_ratio, r.segment_max_ratio >= 0.7 AS segment_pass,
  r.wifi_max_ratio, r.wifi_max_ratio >= 0.5 AS wifi_pass,
  r.cluster_count
    + CASE WHEN r.surge_status = 'PASS' THEN 1 ELSE 0 END AS l2_count,
  r.evidence_pass                     AS l1_pass,
  r.device_max_ratio, r.ja3_max_ratio, r.black_pool_rate,
  r.downstream_rate, r.market_hit_rate, r.lift,
  r.case_hit, r.case_coverage, r.baseline_hit, r.scaled_baseline_hit,
  (r.market_hit_rate < 0.001
   AND r.lift IS NOT NULL AND r.lift > 10) AS injury_pass,
  r.precision, r.recall,
  CAST(NULL AS DOUBLE)                AS v_score,
  CAST(0.0 AS DOUBLE)                 AS scene_growth,
  r.history_pct_pass, r.reasons, r.downstream_detail,
  r.generalization_ratio, r.consumer_rate, r.whitelist_rate,
  r.member_rate, r.high_value_rate, r.gray_market_rate, r.evidence_axes,
  CAST(NULL AS VARCHAR)               AS member_detail,
  CAST(NULL AS BIGINT)                AS consumer_total,
  CAST(NULL AS BIGINT)                AS consumer_hit,
  CAST(NULL AS BIGINT)                AS consumer_miss,
  CAST(-1 AS BIGINT)                  AS recalled_count,
  CAST(NULL AS VARCHAR)               AS black_pool_detail,
  CAST(NULL AS DOUBLE)                AS geo_mismatch_rate,
  CAST(NULL AS VARCHAR)               AS geo_mismatch_detail,
  CAST(NULL AS DOUBLE)                AS loc_off_rate,
  CAST(NULL AS DOUBLE)                AS loc_strong_off_rate,
  CAST(NULL AS VARCHAR)               AS loc_off_detail,
  r.case_id, r.experiment, r.dt
FROM {new_tbl} r
WHERE r.case_id='{case_id}' AND r.experiment='{experiment}' AND r.dt='{dt}'
"""

# 老表同样输出 46 列（新维度补 NULL），与新桥接列序完全一致。
# 注意：老表实际有 consumer_rate/consumer_total/consumer_hit/consumer_miss 列（直查验证），
# 只有 whitelist/member/high_value/gray_market/evidence_axes 等新维度列是老表没有的补 NULL。
_OLD_TBL_46COLS = """
SELECT
  combo_id, rule_rank, predicates, combo_sql, combo_size,
  level, combo_growth,
  recall_sql,
  surge_pass, nontrust_growth, nontrust_pass,
  geo_max_ratio, geo_pass, segment_max_ratio, segment_pass,
  wifi_max_ratio, wifi_pass, l2_count, l1_pass,
  device_max_ratio, ja3_max_ratio, black_pool_rate,
  downstream_rate, market_hit_rate, lift,
  case_hit, case_coverage, baseline_hit, scaled_baseline_hit,
  injury_pass, precision, recall, v_score, scene_growth,
  history_pct_pass, reasons, downstream_detail,
  CAST(NULL AS DOUBLE) AS generalization_ratio,
  consumer_rate,
  {dim6_cols},
  CAST(NULL AS DOUBLE) AS gray_market_rate,
  CAST(NULL AS STRING) AS evidence_axes,
  consumer_total, consumer_hit, consumer_miss,
  CASE WHEN recalled_count IS NULL THEN -1 ELSE recalled_count END AS recalled_count,
  CASE WHEN black_pool_detail IS NULL THEN '' ELSE black_pool_detail END AS black_pool_detail,
  CASE WHEN geo_mismatch_rate IS NULL THEN -1.0 ELSE geo_mismatch_rate END AS geo_mismatch_rate,
  COALESCE(geo_mismatch_detail, '') AS geo_mismatch_detail,
  CASE WHEN loc_off_rate IS NULL THEN -1.0 ELSE loc_off_rate END AS loc_off_rate,
  CASE WHEN loc_strong_off_rate IS NULL THEN -1.0 ELSE loc_strong_off_rate END AS loc_strong_off_rate,
  COALESCE(loc_off_detail, '') AS loc_off_detail,
  case_id, experiment, dt
FROM {old_tbl}
WHERE case_id='{case_id}' AND experiment='{experiment}' AND dt='{dt}'
"""


# 维度6 四列两种形态（2026-09-13）：hive 表由挖掘侧部署 _ensure_table_columns 自动加列——
# 部署前裸引用会 Sinux 报"字段不存在"打挂整个页面 SQL（case 26091300252 等实锤）。
# dim6=True 实列读取（部署后）；dim6=False NULL 占位（部署前，页面显示 —）。
_DIM6_REAL = """
  CASE WHEN whitelist_rate IS NULL THEN -1.0 ELSE whitelist_rate END AS whitelist_rate,
  CASE WHEN member_rate IS NULL THEN -1.0 ELSE member_rate END AS member_rate,
  CASE WHEN high_value_rate IS NULL THEN -1.0 ELSE high_value_rate END AS high_value_rate,
  COALESCE(member_detail, '') AS member_detail"""
_DIM6_NULL = """
  CAST(NULL AS DOUBLE) AS whitelist_rate,
  CAST(NULL AS DOUBLE) AS member_rate,
  CAST(NULL AS DOUBLE) AS high_value_rate,
  CAST(NULL AS STRING) AS member_detail"""


def validation_result_sql(cfg: Settings, case_id: str, experiment: str, dt: str,
                          dim6: bool = True) -> str:
    """规则验证结果：新老表 UNION（profiling 新版写 rule_eval_result，老链路写 validation_result）。
    新表布尔列在 SQL 层推导桥接，前端 Step3 的列依赖不变。同 case 两表都有时取老表（新表跳过）。
    dim6=False：老表维度6 四列用 NULL 占位（hive 表还没加列时用——Sinux 对不存在的列直接报错）。"""
    cond = f"case_id='{_q(case_id)}' AND experiment='{_q(experiment)}' AND dt='{_q(dt)}'"
    new_sql = _RULE_EVAL_BRIDGE.format(
        new_tbl=_t(cfg, 'rule_eval_result'),
        case_id=_q(case_id), experiment=_q(experiment), dt=_q(dt),
    )
    old_sql = _OLD_TBL_46COLS.format(
        old_tbl=_t(cfg, 'validation_result'),
        case_id=_q(case_id), experiment=_q(experiment), dt=_q(dt),
        dim6_cols=_DIM6_REAL if dim6 else _DIM6_NULL)
    # combo_id 去重（2026-10-10）：写入端半提交竞态可能把同 combo 写重
    # （表2 case 26100900250 实锤同族问题）；写入端已加行数断言根治（53f1c5d），
    # 读取端按主键 combo_id 取一行兜底历史脏分区。row_number 优于 DISTINCT——
    # 半提交两份可能列值不完全一致（时间戳类），DISTINCT 会双双保留。
    return (
        f"SELECT * FROM ("
        f"  SELECT t.*, row_number() OVER (PARTITION BY combo_id ORDER BY rule_rank) AS __rn "
        f"  FROM ("
        f"    SELECT * FROM ({new_sql}) n "
        f"    WHERE combo_id NOT IN (SELECT combo_id FROM {_t(cfg, 'validation_result')} WHERE {cond}) "
        f"    UNION ALL {old_sql}"
        f"  ) t"
        f") WHERE __rn = 1 ORDER BY rule_rank"
    )


def validation_combo_detail_sql(cfg: Settings, case_id: str, experiment: str, dt: str, combo_id: str) -> str:
    return (
        f"SELECT combo_id, combo_sql, recall_sql, predicates, reasons "
        f"FROM {_t(cfg, 'validation_result')} "
        f"WHERE case_id='{_q(case_id)}' AND experiment='{_q(experiment)}' AND dt='{_q(dt)}' "
        f"AND combo_id='{_q(combo_id)}'"
    )


def ts_daily_sql(cfg: Settings, case_id: str, combo_id: str, experiment: str, dt: str) -> str:
    """时序明细长表（2026-09-10 新表）：单 combo 的天粒度三线（hits/sample_hits/nt_hits）
    + t0 标记。combo_id 省略时返回该 case 全部 combo（前端可做对比图）。"""
    cond = f"case_id='{_q(case_id)}' AND experiment='{_q(experiment)}' AND dt='{_q(dt)}'"
    if combo_id:
        cond += f" AND combo_id='{_q(combo_id)}'"
    return (
        f"SELECT combo_id, d, stat_name, stat_value, is_t0 "
        f"FROM {_t(cfg, 'ts_daily')} "
        f"WHERE {cond} ORDER BY combo_id, d, stat_name"
    )


# ── 提纯：表2 候选 Predicate ───────────────────────────────────────────────

def candidate_predicates_sql(cfg: Settings, case_id: str, experiment: str, dt: str,
                             limit: int = 50) -> str:
    # DISTINCT 行（2026-10-10）：写入端半提交竞态曾把同 (field_name,op,value,...) 写重
    # （case 26100900250 分区 375=233+重复）。写入端已加行数终态断言根治（53f1c5d），
    # 读取端 DISTINCT 兜底历史脏分区 + 任何残余竞态——重复行所有列完全一致，DISTINCT 安全。
    return (
        f"SELECT DISTINCT field_name, op, value, clue_support, baseline_support, "
        f"lift, clue_hit, baseline_hit, passed "
        f"FROM {_t(cfg, 'candidate_predicates')} "
        f"WHERE case_id='{_q(case_id)}' AND experiment='{_q(experiment)}' AND dt='{_q(dt)}' "
        f"ORDER BY lift DESC LIMIT {int(limit)}"
    )


# ── 提纯：表3 挖掘过程 ────────────────────────────────────────────────────

def mining_process_sql(cfg: Settings, case_id: str, experiment: str, dt: str) -> str:
    return (
        f"SELECT combo_id, root_predicate, root_pool, depth, stop_reason, "
        f"predicates, precision, recall, v_score, clue_hit, baseline_hit "
        f"FROM {_t(cfg, 'mining_process')} "
        f"WHERE case_id='{_q(case_id)}' AND experiment='{_q(experiment)}' AND dt='{_q(dt)}' "
        f"ORDER BY v_score DESC"
    )


# ── 提纯：表0 时序图 SVG ───────────────────────────────────────────────────

def charts_list_sql(cfg: Settings, case_id: str, experiment: str, dt: str) -> str:
    return (
        f"SELECT combo_id, chart_type, chart_label "
        f"FROM {_t(cfg, 'validation_charts')} "
        f"WHERE case_id='{_q(case_id)}' AND experiment='{_q(experiment)}' AND dt='{_q(dt)}' "
        f"ORDER BY combo_id, chart_type"
    )


def chart_svg_sql(cfg: Settings, case_id: str, experiment: str, dt: str,
                  combo_id: str, chart_type: str) -> str:
    return (
        f"SELECT svg_content, chart_label "
        f"FROM {_t(cfg, 'validation_charts')} "
        f"WHERE case_id='{_q(case_id)}' AND experiment='{_q(experiment)}' AND dt='{_q(dt)}' "
        f"AND combo_id='{_q(combo_id)}' AND chart_type='{_q(chart_type)}' "
        f"LIMIT 1"
    )


def charts_svg_bulk_sql(cfg: Settings, case_id: str, experiment: str, dt: str) -> str:
    """全 case 的 SVG 一次取回：单条 Hive 往返（~20s）替代逐 combo N 次（case_prefetch 用）。
    列含 combo_id/chart_type 以便按读端 cache_key 拆分落缓存。"""
    return (
        f"SELECT combo_id, chart_type, svg_content, chart_label "
        f"FROM {_t(cfg, 'validation_charts')} "
        f"WHERE case_id='{_q(case_id)}' AND experiment='{_q(experiment)}' AND dt='{_q(dt)}'"
    )


# ── 回捞：表4 捞全账号 ────────────────────────────────────────────────────

def recall_summary_sql(cfg: Settings, case_id: str, experiment: str, dt: str) -> str:
    return (
        f"SELECT rule_rank, combo_id, combo_hit, count(*) AS total_accounts, "
        f"count(DISTINCT account_id) AS distinct_accounts "
        f"FROM {_t(cfg, 'recall_accounts')} "
        f"WHERE case_id='{_q(case_id)}' AND experiment='{_q(experiment)}' AND dt='{_q(dt)}' "
        f"GROUP BY rule_rank, combo_id, combo_hit ORDER BY rule_rank"
    )


# ── 回捞：Step4 最终规则集（acc_sec_gang_final_rules，独立表）────────────

def final_rules_sql(cfg: Settings, case_id: str, experiment: str, dt: str) -> str:
    """最终规则集：STAGE 6 diverse 选出的规则，含 precision/recall/v_score/coverage 等完整指标。
    LEFT JOIN validation_result 补 recall_sql（误伤评估 target_sql 原文）。"""
    return (
        f"SELECT fr.rule_rank, fr.combo_id, fr.combo_size, fr.combo_sql, fr.predicates, fr.level, "
        f"fr.precision, fr.recall, fr.v_score, fr.clue_hit, fr.baseline_hit, "
        f"fr.incremental_coverage, fr.total_coverage, vr.recall_sql "
        f"FROM {_t(cfg, 'final_rules')} fr "
        f"LEFT JOIN (SELECT combo_id, max(recall_sql) AS recall_sql FROM {_t(cfg, 'validation_result')} "
        f"WHERE case_id='{_q(case_id)}' AND experiment='{_q(experiment)}' AND dt='{_q(dt)}' "
        f"GROUP BY combo_id) vr ON vr.combo_id=fr.combo_id "
        f"WHERE fr.case_id='{_q(case_id)}' AND fr.experiment='{_q(experiment)}' AND fr.dt='{_q(dt)}' "
        f"ORDER BY fr.rule_rank"
    )


def recall_accounts_sql(cfg: Settings, case_id: str, experiment: str, dt: str,
                        rule_rank: Optional[int] = None, limit: int = 100) -> str:
    cond = (
        f"WHERE case_id='{_q(case_id)}' AND experiment='{_q(experiment)}' AND dt='{_q(dt)}'"
    )
    if rule_rank is not None:
        cond += f" AND rule_rank={int(rule_rank)}"
    return (
        f"SELECT account_id, rule_rank FROM {_t(cfg, 'recall_accounts')} "
        f"{cond} ORDER BY rule_rank, account_id LIMIT {int(limit)}"
    )


def recall_ids_by_combo_sql(cfg: Settings, case_id: str, experiment: str, dt: str,
                           combo_id: str) -> str:
    """按全局 combo_id 取表4 预落的回捞账号（step4b 直落，2026-10-12）。
    小分区点查（几千-几十万行），页面按钮秒回；区别于 recall_sql 现场实查。"""
    return (
        f"SELECT account_id FROM {_t(cfg, 'recall_accounts')} "
        f"WHERE case_id='{_q(case_id)}' AND experiment='{_q(experiment)}' AND dt='{_q(dt)}' "
        f"AND combo_id='{_q(combo_id)}' ORDER BY account_id"
    )


def recall_multi_hit_sql(cfg: Settings, case_id: str, experiment: str, dt: str) -> str:
    """被多条规则命中的账号（重点核查对象）"""
    return (
        f"SELECT account_id, count(*) AS rule_count, collect_set(rule_rank) AS rules "
        f"FROM {_t(cfg, 'recall_accounts')} "
        f"WHERE case_id='{_q(case_id)}' AND experiment='{_q(experiment)}' AND dt='{_q(dt)}' "
        f"GROUP BY account_id HAVING count(*) > 1 "
        f"ORDER BY rule_count DESC LIMIT 200"
    )


# ── 表6：case 基础信息（step1 末写，1 行/case）─────────────────────────────

def case_info_sql(cfg: Settings, case_id: str, dt: str) -> str:
    return (
        f"SELECT case_id, case_name, sample_count, feature_col_count, snapshot_dt, "
        f"window_days, core_seed_count, train_count, validation_count, excluded_count, "
        f"baseline_count, baseline_scale_factor, market_total, temporal_window_days, "
        f"seed_mode, experiments, run_experiments, hard_negative_count, whitelist_count, "
        f"create_time "
        f"FROM {_t(cfg, 'case_info')} "
        f"WHERE case_id='{_q(case_id)}' AND dt='{_q(dt)}' LIMIT 1"
    )


def case_list_sql(cfg: Settings, dt: str) -> str:
    """所有 case 列表（case_info 为主，LEFT JOIN validation_result/final_rules 补规则计数）。
    dt 给了按该 dt 过滤；留空取每 case 最新 dt 那行。"""
    vr = f"{_t(cfg, 'validation_result')}"
    fr = f"{_t(cfg, 'final_rules')}"
    if dt:
        return (
            f"SELECT ci.case_id, ci.case_name, ci.sample_count, ci.experiments, ci.dt AS latest_dt, "
            f"vr.rule_count, vr.high_risk_count, fr.final_count "
            f"FROM {_t(cfg, 'case_info')} ci "
            f"LEFT JOIN (SELECT case_id, count(*) AS rule_count, "
            f"sum(CASE WHEN level='HIGH_RISK' THEN 1 ELSE 0 END) AS high_risk_count "
            f"FROM {vr} WHERE dt='{_q(dt)}' GROUP BY case_id) vr ON vr.case_id=ci.case_id "
            f"LEFT JOIN (SELECT case_id, count(*) AS final_count "
            f"FROM {fr} WHERE dt='{_q(dt)}' GROUP BY case_id) fr ON fr.case_id=ci.case_id "
            f"WHERE ci.dt='{_q(dt)}' ORDER BY ci.case_id LIMIT 500"
        )
    return (
        f"SELECT ci.case_id, max(ci.case_name) AS case_name, max(ci.sample_count) AS sample_count, "
        f"max(ci.experiments) AS experiments, max(ci.dt) AS latest_dt, "
        f"max(vr.rule_count) AS rule_count, max(vr.high_risk_count) AS high_risk_count, "
        f"max(fr.final_count) AS final_count "
        f"FROM {_t(cfg, 'case_info')} ci "
        f"LEFT JOIN (SELECT case_id, count(*) AS rule_count, "
            f"sum(CASE WHEN level='HIGH_RISK' THEN 1 ELSE 0 END) AS high_risk_count "
            f"FROM {vr} GROUP BY case_id) vr ON vr.case_id=ci.case_id "
        f"LEFT JOIN (SELECT case_id, count(*) AS final_count "
            f"FROM {fr} GROUP BY case_id) fr ON fr.case_id=ci.case_id "
        # 最新分区倒序取近 500（ORDER BY case_id 字典序会在 case 累计 >500 后永远截掉新 case）
        f"GROUP BY ci.case_id ORDER BY max(ci.dt) DESC, ci.case_id DESC LIMIT 500"
    )


def case_dt_distribution_sql(cfg: Settings, limit: int = 30) -> str:
    """case 的 dt 分区分布（降序，供总览按天选项卡）。"""
    return (
        f"SELECT dt, count(DISTINCT case_id) AS n "
        f"FROM {_t(cfg, 'case_info')} GROUP BY dt ORDER BY dt DESC LIMIT {int(limit)}"
    )


def experiments_sql(cfg: Settings, case_id: str, dt: str) -> str:
    """查某 case 的实验列表（experiments 字段逗号分隔）。"""
    return (
        f"SELECT experiments FROM {_t(cfg, 'case_info')} "
        f"WHERE case_id='{_q(case_id)}' AND dt='{_q(dt)}' LIMIT 1"
    )


# ── 表7：快照源表信息（step1 末写，5 行/case）──────────────────────────────

def snapshot_info_sql(cfg: Settings, case_id: str, dt: str) -> str:
    return (
        f"SELECT source_name, source_table, prefix, table_type, id_field, "
        f"agg_field_count, cntd_field_count, has_json_map "
        f"FROM {_t(cfg, 'snapshot_info')} "
        f"WHERE case_id='{_q(case_id)}' AND dt='{_q(dt)}' ORDER BY source_name"
    )


def case_snapshot_sql(cfg: Settings, case_id: str, dt: str, limit: int = 200) -> str:
    """case 实际快照数据（ba_rc.app_acc_sec_case_snapshot，SELECT * 自适应列）。"""
    return (
        f"SELECT * FROM ba_rc.app_acc_sec_case_snapshot "
        f"WHERE case_id='{_q(case_id)}' AND dt='{_q(dt)}' LIMIT {int(limit)}"
    )


# ── 表8：种子切分（step2 末写，1 行/case）───────────────────────────────────

def seed_split_sql(cfg: Settings, case_id: str, dt: str) -> str:
    return (
        f"SELECT seed_mode, core_seed_count, excluded_count, weak_seed_count, "
        f"train_count, validation_count, train_ratio, baseline_count, "
        f"baseline_scale_factor, hard_negative_count, whitelist_count "
        f"FROM {_t(cfg, 'seed_split')} "
        f"WHERE case_id='{_q(case_id)}' AND dt='{_q(dt)}' LIMIT 1"
    )
