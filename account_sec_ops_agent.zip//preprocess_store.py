"""
CASE 预处理任务持久化层（Supabase）——与 laoquan 画布任务完全隔离。

独立表 preprocess_jobs（不与 canvas_jobs 混），独立发码表 case_seq。
status 流转：pending → submitted → done / failed（无 Talos 校验/结果缓存，比 laoquan 简单）。
"""
from __future__ import annotations

import json
import uuid
from datetime import datetime
from typing import Optional

from client.supabase_client import SupabaseClient
from logger import sys_log

_SCHEMA = """
CREATE TABLE IF NOT EXISTS preprocess_jobs (
  id TEXT PRIMARY KEY,
  case_id TEXT NOT NULL,
  group_id TEXT,
  dt TEXT,
  unique_key TEXT,
  status TEXT NOT NULL DEFAULT 'pending',
  canvas_phase TEXT DEFAULT 'canvas_polling',
  retry_count INTEGER DEFAULT 0,
  error_message TEXT,
  row_count INTEGER,
  extra JSONB DEFAULT '{}'::jsonb,
  created_at TEXT,
  updated_at TEXT
);
CREATE INDEX IF NOT EXISTS idx_pp_case ON preprocess_jobs(case_id);
CREATE INDEX IF NOT EXISTS idx_pp_group ON preprocess_jobs(group_id);
CREATE INDEX IF NOT EXISTS idx_pp_status ON preprocess_jobs(status);
CREATE TABLE IF NOT EXISTS case_seq (
  dt TEXT PRIMARY KEY,
  next_seq INTEGER DEFAULT 0
);
"""

_sb_client = None


def _sb():
    global _sb_client
    if _sb_client is None:
        _sb_client = SupabaseClient()
    return _sb_client


def _now() -> str:
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")


def _row_to_dict(row) -> dict:
    if not row:
        return {}
    d = dict(row)
    extra = d.get("extra")
    if isinstance(extra, str):
        try:
            d["extra"] = json.loads(extra)
        except Exception:
            d["extra"] = {}
    elif extra is None:
        d["extra"] = {}
    return d


def ensure_schema():
    try:
        _sb().execute(_SCHEMA)
        sys_log("info", "[Preprocess] schema ensured (preprocess_jobs + case_seq)")
    except Exception as e:
        sys_log("error", f"[Preprocess] ensure_schema failed: {str(e)[:200]}")


def allocate_case_id(dt: str) -> str:
    """按 dt 原子取号，返回 case_id = dt[2:] + 5位序号（如 26082700001）。"""
    rows = _sb().execute(
        "INSERT INTO case_seq (dt, next_seq) VALUES ($1, 1) "
        "ON CONFLICT (dt) DO UPDATE SET next_seq = case_seq.next_seq + 1 "
        "RETURNING next_seq",
        [dt],
    )
    seq = int(rows[0]["next_seq"]) if rows else 1
    return dt[2:] + f"{seq:05d}"


def create_task(case_id: str, group_id: str, dt: str, global_param: str,
                priority: bool = False) -> dict:
    """建 pending 任务（原子写入全部字段，避免调度器竞态）。
    priority=True 表示人工指定/紧急任务：提交时跳过 FIFO 等待，优先抢并发槽。"""
    job_id = str(uuid.uuid4())
    now = _now()
    placeholder = f"pending_{case_id}_{dt}"
    extra = json.dumps({
        "submit_dt": dt, "group_id": group_id, "global_param": global_param,
        **({"priority": True} if priority else {}),
    }, ensure_ascii=False)
    _sb().execute(
        "INSERT INTO preprocess_jobs (id, case_id, group_id, dt, unique_key, "
        "status, canvas_phase, extra, created_at, updated_at) "
        "VALUES ($1, $2, $3, $4, $5, 'pending', 'canvas_polling', $6::jsonb, $7, $8)",
        [job_id, case_id, group_id, dt, placeholder, extra, now, now],
    )
    sys_log("info", f"[Preprocess] created task={job_id} case={case_id} group={group_id}"
                    + (" [priority]" if priority else ""))
    return get_task(job_id)


def get_task(job_id: str) -> Optional[dict]:
    rows = _sb().execute("SELECT * FROM preprocess_jobs WHERE id=$1", [job_id])
    return _row_to_dict(rows[0]) if rows else None


def list_tasks(limit: int = 50) -> list:
    rows = _sb().execute(
        "SELECT * FROM preprocess_jobs ORDER BY created_at DESC LIMIT $1", [limit]
    )
    return [_row_to_dict(r) for r in rows]


def list_running() -> list:
    """调度器轮询用：所有 pending/submitted 任务。
    extra.priority=1 的任务优先出队（跳过 FIFO 等待，详见 preprocess_scheduler._round_robin_order）。"""
    rows = _sb().execute(
        "SELECT * FROM preprocess_jobs WHERE status IN ('pending','submitted') "
        "ORDER BY COALESCE(extra->>'priority','0')::int DESC, updated_at"
    )
    return [_row_to_dict(r) for r in rows]


def count_running() -> int:
    """已提交画布（submitted，不含 pending）——池限制计数。"""
    rows = _sb().execute("SELECT count(*) AS n FROM preprocess_jobs WHERE status='submitted'")
    return int(rows[0]["n"]) if rows else 0


def claim_for_submit(job_id: str) -> bool:
    """CAS：pending → submitted。"""
    now = _now()
    rows = _sb().execute(
        "UPDATE preprocess_jobs SET status='submitted', updated_at=$1 "
        "WHERE id=$2 AND status='pending' RETURNING id",
        [now, job_id],
    )
    return bool(rows)


def update_status(job_id: str, status: str, **fields) -> None:
    allowed = {"unique_key", "error_message", "row_count", "canvas_phase"}
    sets, vals = ["status=$1", "updated_at=$2"], [status, _now()]
    idx = 3
    for k, v in fields.items():
        if k in allowed:
            sets.append(f"{k}=${idx}")
            vals.append(v)
            idx += 1
    vals.append(job_id)
    _sb().execute(f"UPDATE preprocess_jobs SET {','.join(sets)} WHERE id=${idx}", vals)


def update_extra(job_id: str, extra_dict: dict) -> None:
    _sb().execute(
        "UPDATE preprocess_jobs SET extra = COALESCE(extra,'{}'::jsonb) || $1::jsonb, updated_at=$2 WHERE id=$3",
        [json.dumps(extra_dict, ensure_ascii=False), _now(), job_id],
    )


def get_by_group(group_id: str) -> Optional[dict]:
    rows = _sb().execute(
        "SELECT * FROM preprocess_jobs WHERE group_id=$1 ORDER BY created_at DESC LIMIT 1",
        [group_id],
    )
    return _row_to_dict(rows[0]) if rows else None


def reset_to_pending(job_id: str) -> bool:
    """手动重试：failed → pending（调度器重新提交）。"""
    now = _now()
    rows = _sb().execute(
        "UPDATE preprocess_jobs SET status='pending', canvas_phase='canvas_polling', "
        "unique_key=NULL, error_message=NULL, updated_at=$1 "
        "WHERE id=$2 AND status='failed' RETURNING id",
        [now, job_id],
    )
    return bool(rows)
