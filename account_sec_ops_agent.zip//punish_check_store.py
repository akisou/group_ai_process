"""
团伙处置任务持久化层（Supabase）——sceneKey=accountsec_agent_group_punish_check。
一个 combo 保留最新一条处置记录（重复点击覆盖：旧记录标 superseded）。
status: pending → submitted → done / failed
check_info: 0 不处罚 / 1 处罚（用户点击时选择）
"""
from __future__ import annotations

import json
import uuid
from datetime import datetime
from typing import Optional

from client.supabase_client import SupabaseClient
from logger import sys_log

_SCHEMA = """
CREATE TABLE IF NOT EXISTS punish_check_jobs (
  id TEXT PRIMARY KEY,
  case_id TEXT NOT NULL,
  combo_id TEXT NOT NULL,
  dt TEXT,
  check_info INTEGER,
  unique_key TEXT,
  status TEXT NOT NULL DEFAULT 'pending',
  error_message TEXT,
  extra JSONB DEFAULT '{}'::jsonb,
  created_at TEXT,
  updated_at TEXT
);
CREATE INDEX IF NOT EXISTS idx_pc_case ON punish_check_jobs(case_id);
CREATE INDEX IF NOT EXISTS idx_pc_status ON punish_check_jobs(status);
"""

_sb_client = None


def _sb():
    global _sb_client
    if _sb_client is None:
        _sb_client = SupabaseClient()
    return _sb_client


def _now() -> str:
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")


def _row_to_dict(row) -> dict:
    if not row:
        return {}
    d = dict(row)
    extra = d.get("extra")
    if isinstance(extra, str):
        try:
            d["extra"] = json.loads(extra)
        except Exception:
            d["extra"] = {}
    elif extra is None:
        d["extra"] = {}
    return d


def ensure_schema():
    try:
        _sb().execute(_SCHEMA)
        sys_log("info", "[PunishCheck] schema ensured (punish_check_jobs table)")
    except Exception as e:
        sys_log("error", f"[PunishCheck] ensure_schema failed: {str(e)[:200]}")


def create_job(case_id: str, combo_id: str, dt: str, check_info: int) -> dict:
    """建处置任务；同 combo 旧活跃/已完成记录标 superseded（最新一条生效）。"""
    now = _now()
    # 旧记录标 superseded（不删除，留历史）
    try:
        _sb().execute(
            "UPDATE punish_check_jobs SET status='superseded', updated_at=$1 "
            "WHERE case_id=$2 AND combo_id=$3 AND status IN ('pending','submitted','done','failed')",
            [now, case_id, combo_id])
    except Exception:
        pass
    job_id = str(uuid.uuid4())
    placeholder = f"pending_{case_id}_{combo_id}"
    _sb().execute(
        "INSERT INTO punish_check_jobs (id, case_id, combo_id, dt, check_info, unique_key, "
        "status, created_at, updated_at) VALUES ($1,$2,$3,$4,$5,$6,'pending',$7,$8)",
        [job_id, case_id, combo_id, dt, int(check_info), placeholder, now, now],
    )
    sys_log("info", f"[PunishCheck] created job={job_id} case={case_id} combo={combo_id} check_info={check_info}")
    return get_job(job_id)


def get_job(job_id: str) -> Optional[dict]:
    rows = _sb().execute("SELECT * FROM punish_check_jobs WHERE id=$1", [job_id])
    return _row_to_dict(rows[0]) if rows else None


def list_by_case(case_id: str) -> list:
    """该 case 每个 combo 的最新处置记录（superseded 排除，按创建时间倒序）。"""
    rows = _sb().execute(
        "SELECT * FROM punish_check_jobs WHERE case_id=$1 AND status != 'superseded' "
        "ORDER BY created_at DESC", [case_id])
    return [_row_to_dict(r) for r in rows]


def list_running() -> list:
    rows = _sb().execute(
        "SELECT * FROM punish_check_jobs WHERE status IN ('pending','submitted') ORDER BY updated_at")
    return [_row_to_dict(r) for r in rows]


def claim_for_submit(job_id: str) -> bool:
    rows = _sb().execute(
        "UPDATE punish_check_jobs SET status='submitted', updated_at=$1 "
        "WHERE id=$2 AND status='pending' RETURNING id", [_now(), job_id])
    return bool(rows)


def update_status(job_id: str, status: str, **fields) -> None:
    allowed = {"unique_key", "error_message"}
    sets, vals = ["status=$1", "updated_at=$2"], [status, _now()]
    idx = 3
    for k, v in fields.items():
        if k in allowed:
            sets.append(f"{k}=${idx}")
            vals.append(v)
            idx += 1
    vals.append(job_id)
    _sb().execute(f"UPDATE punish_check_jobs SET {','.join(sets)} WHERE id=${idx}", vals)


def update_extra(job_id: str, extra_dict: dict) -> None:
    _sb().execute(
        "UPDATE punish_check_jobs SET extra = COALESCE(extra,'{}'::jsonb) || $1::jsonb, updated_at=$2 WHERE id=$3",
        [json.dumps(extra_dict, ensure_ascii=False), _now(), job_id],
    )
