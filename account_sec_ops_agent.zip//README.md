# account_agent_dev

账号安全分析最小工程平台。基于 `migrate-from-clue-agent` 精简而来，只保留 4 项核心能力：

1. **读图片** — 反爬同款：带 SSO token 请求 mtsi 图片 URL → 307 到 S3 预签名 URL → 取字节流（`GET /api/image`）
2. **读写 Hive** — `TalosClient`（pytalos）提交 SQL + 轮询结果（`/api/hive/query`、`/api/hive/execute`）
3. **展示 case_id / rules** — 直接读 Hive 表，API + 极简单页（`/api/cases`、`/api/cases/{id}/rules`、`/`）
4. **触发 mlp pyspark** — `CICanvasClient` 调 mtsi 画布 `offlineStartCanvas`/`offlineQueryCanvasStatus`，画布里跑 pyspark 把 rule 落 Hive（`/api/cases/{id}/analyze`、`.../analyze/status`）

## 目录

```
main.py              # FastAPI 入口，lifespan 只 init SSO
config.py / yaml     # 精简配置
logger.py            # 本地日志（stdout + logs/app.log）
client/
  talos_client.py    # Hive 读写（pytalos）
  ci_canvas_client.py# mtsi 画布触发（mlp client）
  sso_auth.py        # SSO token 获取与缓存
api/routes.py        # 极简路由
static/index.html    # 单页 dashboard（原生 HTML+JS）
```

## 运行

```bash
pip install -r requirements.txt
# 编辑 config.yaml，填好下面两项后启动
./run.sh   # 或 python main.py，监听 :8010
```

### 上线前必填配置（config.yaml）

| 配置项 | 说明 |
|---|---|
| `mtsi_canvas.scene_key` | 产出 rule 的 pyspark 画布 sceneKey（必填，否则触发接口报错） |
| `hive_queries.cases_sql` / `rules_sql` | 列 case / 查规则的 SQL 模板，含 `{case_id}`/`{dt}` 占位，把 `<rules表>` 换成实际表 |

### 环境变量（可选，覆盖 config.yaml）

- `TALOS_USERNAME` / `TALOS_PASSWORD`
- `SSO_MIS`（同时覆盖 `sso.mis` 和 `mtsi_canvas.mis_id`）
- `ACCOUNT_AGENT_CONFIG`（指定其它 config 文件路径）

## 前置条件

- 配置的 SSO MIS（默认 `sunjiajun07`）首次需在大象 App 完成 CIBA 授权，之后 25h 自动缓存
- 内网可访问 `talostwo.vip.sankuai.com`（Hive）和 `mtsi-clue.sankuai.com`（画布/图片）

## 验证

```bash
curl 'http://localhost:8010/api/hive/query?sql=SELECT%201'
open http://localhost:8010/
```

## 后续可扩展（本期不做）

Supabase 持久化、APScheduler 定时轮询、完整 SSO 登录态、React 前端、鉴权、case_intelligence / case_autogang 等复杂能力。
