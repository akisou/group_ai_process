"""
CASE 预处理任务调度器 —— 与 laoquan 画布调度器（canvas_scheduler）完全隔离。

独立 BackgroundScheduler，只轮询 preprocess_jobs 表，调 PreprocessClient（硬编码 preprocess sceneKey）。
流程简单：pending → submitted（提交画布）→ 轮询 canvas 状态 → done/failed。
无 Talos 校验、无结果缓存（预处理结果在独立 Hive 表，不沾 laoquan 的 8 表/result_cache）。
"""
from __future__ import annotations

from apscheduler.schedulers.background import BackgroundScheduler

import preprocess_store as store
from client.preprocess_client import PreprocessClient, FAILED
from logger import sys_log


# ── 定性轮转（2026-09-30 用户定）───────────────────────────────────────
# mlp 资源每天只够消化 100-200 case，批量注册积压（400+）会把 FIFO 提交窗口
# 全部占满，其他定性（批量登录/账号租借/解冻等）饿死。改为按定性类别轮转：
# 每轮每类抽 ROUND_ROBIN_N 个提交；其他类别耗尽后批量注册自然获得全部
# 剩余资源（先轮转消化小类别，最后集中消费批量注册）。
ROUND_ROBIN_N = 5
_CATEGORY_KEYWORDS = ["批量注册", "批量登录", "账号租借", "账号转卖", "黑产自持", "批量解冻"]

def _category_of(reason: str) -> str:
    for kw in _CATEGORY_KEYWORDS:
        if kw in (reason or ""):
            return kw
    return "其他"


def _case_categories(case_ids: list) -> dict:
    """批量查 case → 定性类别（flow extra.external_reason，如"注册环节-批量注册，…"）。"""
    ids = [str(c) for c in case_ids if c][:500]
    if not ids:
        return {}
    try:
        sb = store._sb()
        in_list = ",".join(sb._escape(c) for c in ids)
        rows = sb.execute(
            f"SELECT case_id, extra->>'external_reason' AS er FROM flow_jobs WHERE case_id IN ({in_list})")
        return {r["case_id"]: _category_of(r.get("er") or "") for r in rows}
    except Exception as e:
        sys_log("warning", f"[PreprocessScheduler] 定性类别查询失败（本轮退化为 FIFO）: {str(e)[:120]}")
        return {}


def _round_robin_order(pending: list) -> list:
    """pending 按定性类别轮转重排：每类每轮 ROUND_ROBIN_N 个交替出队。"""
    if len(pending) <= ROUND_ROBIN_N:
        return pending
    cat_map = _case_categories([t.get("case_id") for t in pending])
    groups: dict = {}
    for t in pending:
        groups.setdefault(cat_map.get(t.get("case_id"), "其他"), []).append(t)
    ordered, i = [], 0
    while True:
        took = False
        for cat in sorted(groups):
            chunk = groups[cat][i * ROUND_ROBIN_N:(i + 1) * ROUND_ROBIN_N]
            if chunk:
                ordered.extend(chunk)
                took = True
        if not took:
            return ordered
        i += 1


class PreprocessScheduler:
    def __init__(self):
        from config import get_config
        cfg = get_config().canvas_scheduler
        self.interval = cfg.poll_interval_seconds
        self._sched: BackgroundScheduler | None = None

    def start(self):
        if self._sched is not None:
            return
        self._sched = BackgroundScheduler(timezone="Asia/Shanghai")
        self._sched.add_job(self._poll_all, "interval", seconds=self.interval, id="preprocess_poll",
                            max_instances=1, coalesce=True, misfire_grace_time=10)
        self._sched.start()
        sys_log("info", f"[PreprocessScheduler] started, interval={self.interval}s")

    def shutdown(self):
        if self._sched is not None:
            self._sched.shutdown(wait=False)
            self._sched = None
            sys_log("info", "[PreprocessScheduler] shutdown")

    def _poll_all(self):
        try:
            tasks = store.list_running()
            pending = [t for t in tasks if t["status"] == "pending"]
            submitted = [t for t in tasks if t["status"] == "submitted"]
            # 定性轮转：pending 按类别轮转排序优先提交（mlp 槽位跨定性公平分配），
            # submitted 画布轮询与顺序无关，随后处理
            for task in _round_robin_order(pending) + submitted:
                try:
                    self._advance(task)
                except Exception as e:
                    sys_log("warning", f"[PreprocessScheduler] task={task.get('id')} advance error: {str(e)[:200]}")
        except Exception as e:
            sys_log("error", f"[PreprocessScheduler] poll_all error: {str(e)[:200]}")

    def _advance(self, task: dict):
        status = task["status"]
        if status == "pending":
            self._submit(task)
            return
        if status == "submitted":
            self._poll_canvas(task)
            return

    def _submit(self, task: dict):
        jid = task["id"]
        # mlp 全局强限制：总开关 + 全局并发；priority=1 走加急通道（+10 独享槽）
        urgent = bool(((task.get("extra") or {}).get("priority"))
                      or str(task.get("priority") or "") not in ("", "0", "None"))
        from mlp_switch import mlp_can_submit
        if not mlp_can_submit("preprocess", urgent=urgent):
            return
        if not store.claim_for_submit(jid):
            return  # 已被抢占
        case_id = task["case_id"]
        extra = task.get("extra") or {}
        dt = extra.get("submit_dt") or task.get("dt") or ""
        group_id = task.get("group_id") or extra.get("group_id") or ""
        try:
            res = PreprocessClient().submit(case_id, dt, group_id)
            unique_key = res["unique_key"]
            sys_log("info", f"[PreprocessScheduler] submit returned task={jid} unique_key={unique_key}")
            try:
                store.update_extra(jid, {
                    "canvas_status": "SUBMITTED",
                    "start_canvas_request": res.get("request"),
                    "start_canvas_response": res.get("response"),
                })
            except Exception as ex_err:
                sys_log("warning", f"[PreprocessScheduler] store 报文失败 task={jid}: {str(ex_err)[:200]}")
            store.update_status(jid, "submitted", unique_key=unique_key, canvas_phase="canvas_polling")
        except Exception as e:
            err = str(e)
            store.update_status(jid, "failed", error_message=err[:500])
            store.update_extra(jid, {"submit_error": err[:500]})
            sys_log("warning", f"[PreprocessScheduler] submit failed task={jid}: {err[:200]}")

    def _poll_canvas(self, task: dict):
        jid = task["id"]
        unique_key = task.get("unique_key") or ""
        if not unique_key or unique_key.startswith("pending_"):
            # 旧快照竞态：提交线程可能刚写完真实 uk（本快照是轮询开始时读的占位符）。
            # 回查 DB 拿最新值，仍无才判失败。
            fresh = store.get_task(jid)
            unique_key = (fresh or {}).get("unique_key") or ""
            if not unique_key or unique_key.startswith("pending_"):
                store.update_status(jid, "failed", error_message="canvas_polling 阶段 unique_key 为空（回查仍为空，提交可能未完成）")
                return
        try:
            res = PreprocessClient().query_status(unique_key)
        except Exception as e:
            store.update_extra(jid, {"canvas_status": "UNKNOWN", "last_error": str(e)[:200]})
            return
        status = res["status"]
        store.update_extra(jid, {
            "canvas_status": status,
            "query_canvas_request": res.get("request"),
            "query_canvas_response": res.get("response"),
        })
        if status == "SUCCEEDED":
            store.update_status(jid, "done")
            sys_log("info", f"[PreprocessScheduler] task done task={jid}")
        elif status in FAILED:
            store.update_status(jid, "failed", error_message=f"画布执行 {status}")
            sys_log("warning", f"[PreprocessScheduler] canvas failed task={jid} status={status}")
        # NEW/READY/STARTING/RUNNING/ON_KILLED：等下轮
