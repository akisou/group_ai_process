"""
全流程串联持久化层（Supabase）——编排 CASE 预处理→snapshot 就绪→提纯捞全→完成。

flow_jobs 记录每个全流程的状态机：stage = preprocess → snapshot → laoquan → done。
子任务（preprocess_job / laoquan_job）由各自调度器跑，本表只做编排与推进。
"""
from __future__ import annotations

import json
import uuid
from datetime import datetime
from typing import Optional

from client.supabase_client import SupabaseClient
from logger import sys_log

_SCHEMA = """
CREATE TABLE IF NOT EXISTS flow_jobs (
  id TEXT PRIMARY KEY,
  group_id TEXT,
  dt TEXT,
  case_id TEXT NOT NULL,
  case_name TEXT,
  stage TEXT NOT NULL DEFAULT 'preprocess',   -- preprocess / snapshot / laoquan / done
  status TEXT NOT NULL DEFAULT 'running',     -- running / done / failed
  preprocess_task_id TEXT,
  laoquan_job_id TEXT,
  snapshot_last_check TEXT,                    -- 上次 snapshot 轮询时间（5min 节流）
  error_message TEXT,
  extra JSONB DEFAULT '{}'::jsonb,
  created_at TEXT,
  updated_at TEXT
);
CREATE INDEX IF NOT EXISTS idx_flow_status ON flow_jobs(status);
CREATE TABLE IF NOT EXISTS case_assignments (
  case_id TEXT PRIMARY KEY,
  mis TEXT NOT NULL,
  dt TEXT,
  assigned_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_flow_case ON flow_jobs(case_id);
"""

_sb_client = None


def _sb():
    global _sb_client
    if _sb_client is None:
        _sb_client = SupabaseClient()
    return _sb_client


def _now() -> str:
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")


def _row_to_dict(row) -> dict:
    if not row:
        return {}
    d = dict(row)
    extra = d.get("extra")
    if isinstance(extra, str):
        try:
            d["extra"] = json.loads(extra)
        except Exception:
            d["extra"] = {}
    elif extra is None:
        d["extra"] = {}
    return d


def ensure_schema():
    try:
        _sb().execute(_SCHEMA)
        sys_log("info", "[Flow] schema ensured (flow_jobs table)")
    except Exception as e:
        sys_log("error", f"[Flow] ensure_schema failed: {str(e)[:200]}")


def create_flow(group_id: str, dt: str, case_id: str, case_name: str, stage: str = "preprocess") -> dict:
    job_id = str(uuid.uuid4())
    now = _now()
    _sb().execute(
        "INSERT INTO flow_jobs (id, group_id, dt, case_id, case_name, stage, status, "
        "created_at, updated_at) VALUES ($1, $2, $3, $4, $5, $6, 'running', $7, $8)",
        [job_id, group_id, dt, case_id, case_name, stage, now, now],
    )
    sys_log("info", f"[Flow] created flow={job_id} case={case_id} group={group_id} dt={dt} stage={stage}")
    return get_flow(job_id)


def get_flow(flow_id: str) -> Optional[dict]:
    rows = _sb().execute("SELECT * FROM flow_jobs WHERE id=$1", [flow_id])
    return _row_to_dict(rows[0]) if rows else None


def get_by_case_id(case_id: str) -> Optional[dict]:
    """按 case_id 查最新 flow（对外接口用）。"""
    rows = _sb().execute(
        "SELECT * FROM flow_jobs WHERE case_id=$1 ORDER BY created_at DESC LIMIT 1", [case_id]
    )
    return _row_to_dict(rows[0]) if rows else None


def list_flows(limit: int = 50, offset: int = 0, dt: str = "",
               stage: str = "", q: str = "") -> list:
    """全流程列表（分页，按创建时间降序）。
    dt 按天 / stage 阶段（含虚拟阶段 laoquan_done=punish,done）/ q 搜索（case_id 或 group_id 前缀/包含）过滤。"""
    where, params = [], []
    if dt:
        params.append(dt)
        where.append(f"dt=${len(params)}")
    if stage:
        if stage == "laoquan_done":
            # 捞全完成（虚拟阶段）：flow 已过 laoquan（injury_eval/punish/done）
            where.append("stage IN ('injury_eval','punish','done')")
        else:
            params.append(stage)
            where.append(f"stage=${len(params)}")
    if q:
        params.append(f"%{q}%")
        where.append(f"(case_id LIKE ${len(params)} OR group_id LIKE ${len(params)})")
    w = ("WHERE " + " AND ".join(where)) if where else ""
    params += [limit, offset]
    rows = _sb().execute(
        f"SELECT * FROM flow_jobs {w} ORDER BY created_at DESC LIMIT ${len(params)-1} OFFSET ${len(params)}",
        params)
    return [_row_to_dict(r) for r in rows]


def count_flows(dt: str = "", stage: str = "", q: str = "") -> int:
    where, params = [], []
    if dt:
        params.append(dt)
        where.append(f"dt=${len(params)}")
    if stage:
        if stage == "laoquan_done":
            where.append("stage IN ('injury_eval','punish','done')")
        else:
            params.append(stage)
            where.append(f"stage=${len(params)}")
    if q:
        params.append(f"%{q}%")
        where.append(f"(case_id LIKE ${len(params)} OR group_id LIKE ${len(params)})")
    w = ("WHERE " + " AND ".join(where)) if where else ""
    rows = _sb().execute(f"SELECT count(*) AS n FROM flow_jobs {w}", params)
    return int(rows[0]["n"]) if rows else 0


def list_flow_dts(limit: int = 30) -> list:
    """全流程的 dt 分布（降序，供按天筛选下拉）。"""
    rows = _sb().execute(
        "SELECT dt, count(*) AS n FROM flow_jobs GROUP BY dt ORDER BY dt DESC LIMIT $1", [limit])
    return [{"dt": r["dt"], "count": int(r["n"])} for r in rows]


def list_running() -> list:
    rows = _sb().execute(
        "SELECT * FROM flow_jobs WHERE status='running' ORDER BY created_at"
    )
    return [_row_to_dict(r) for r in rows]


def terminate_flow(flow_id: str, reason: str = "手动终止") -> bool:
    """终止 flow：置 terminated（终态，调度器不再推进）+ 子任务标 failed 防各自调度器继续。"""
    flow = get_flow(flow_id)
    if not flow or flow.get("status") not in ("running", "pending"):
        return False
    _sb().execute(
        "UPDATE flow_jobs SET status='terminated', error_message=$1, updated_at=$2 WHERE id=$3",
        [f"{reason}", _now(), flow_id],
    )
    # 子任务终止（预处理任务 + 捞全 job 标 failed，各自调度器不再 pick up）
    tid = flow.get("preprocess_task_id")
    if tid:
        try:
            import preprocess_store as pp
            pp.update_status(tid, "failed", error_message=f"flow 终止: {reason}")
        except Exception:
            pass
    jid = flow.get("laoquan_job_id")
    if jid:
        try:
            import canvas_job_store as cs
            cs.update_status(jid, "failed", error_message=f"flow 终止: {reason}")
        except Exception:
            pass
    sys_log("info", f"[Flow] terminated flow={flow_id} case={flow.get('case_id')} reason={reason}")
    return True


# 可重跑阶段（从该阶段起重跑，其后阶段重新执行）
RETRY_STAGES = ("preprocess", "snapshot", "laoquan", "injury_eval")


def retry_from_stage(flow_id: str, stage: str) -> bool:
    """从指定阶段重跑：清该阶段（及之后）的子任务引用与时间戳，置 running。
    preprocess：清 preprocess_task_id（调度器重建预处理任务）
    snapshot：   仅回退阶段标记（重查 case_status）
    laoquan：    清 laoquan_job_id（调度器重建捞全 job）"""
    if stage not in RETRY_STAGES:
        return False
    flow = get_flow(flow_id)
    if not flow:
        return False
    now = _now()
    if stage == "preprocess":
        # 旧预处理任务标 failed（防误跟踪）
        tid = flow.get("preprocess_task_id")
        if tid:
            try:
                import preprocess_store as pp
                t = pp.get_task(tid)
                if t and t.get("status") in ("pending", "submitted"):
                    pp.update_status(tid, "failed", error_message="阶段重跑废弃")
            except Exception:
                pass
        # CAS 清引用：仅当 preprocess_task_id 仍是读到的旧值时才清（防两次重跑/与调度器竞争交错）
        old_tid = tid if tid else "__NULL__"
        cas_sql = ("UPDATE flow_jobs SET stage='preprocess', status='running', "
                   "preprocess_task_id=NULL, laoquan_job_id=NULL, snapshot_last_check=NULL, "
                   "error_message=NULL, updated_at=$1 WHERE id=$2 AND "
                   + ("preprocess_task_id=$3" if tid else "preprocess_task_id IS NULL"))
        cas_vals = [now, flow_id] + ([tid] if tid else [])
        rows = _sb().execute(cas_sql + " RETURNING id", cas_vals)
        if not rows:
            sys_log("warning", f"[Flow] retry_from_stage(preprocess) CAS miss flow={flow_id}（task_id 已被并发修改，跳过）")
            return False
        # stage_preprocess_at：重跑起点（前端耗时从重跑时刻计）
        _sb().execute(
            "UPDATE flow_jobs SET extra = extra || "
            f"'{{\"stage_preprocess_at\":\"{now}\",\"stage_snapshot_at\":null,"
            f"\"stage_laoquan_at\":null,\"stage_done_at\":null}}'::jsonb "
            "WHERE id=$1", [flow_id])
    elif stage == "snapshot":
        _sb().execute(
            "UPDATE flow_jobs SET stage='snapshot', status='running', "
            "snapshot_last_check=NULL, laoquan_job_id=NULL, error_message=NULL, updated_at=$1 "
            "WHERE id=$2", [now, flow_id])
        _sb().execute(
            "UPDATE flow_jobs SET extra = extra || "
            "'{\"stage_laoquan_at\":null,\"stage_done_at\":null}'::jsonb WHERE id=$1", [flow_id])
    elif stage == "injury_eval":
        # 误伤评估重跑：清旧评估任务（标 failed 防跟踪）→ 回 injury_eval 阶段重建
        try:
            import injury_eval_store as ie_store
            for j in ie_store.list_by_case(flow.get("case_id") or ""):
                if j["status"] in ("pending", "submitted"):
                    ie_store.update_status(j["id"], "failed", error_message="阶段重跑废弃")
        except Exception:
            pass
        _sb().execute(
            "UPDATE flow_jobs SET stage='injury_eval', status='running', "
            "error_message=NULL, updated_at=$1 WHERE id=$2", [now, flow_id])
        _sb().execute(
            "UPDATE flow_jobs SET extra = extra || "
            f"'{{\"stage_done_at\":null}}'::jsonb WHERE id=$1", [flow_id])
    else:  # laoquan
        jid = flow.get("laoquan_job_id")
        if jid:
            try:
                import canvas_job_store as cs
                j = cs.get_job(jid)
                if j and j.get("status") in ("pending", "submitted", "verifying", "syncing"):
                    cs.update_status(jid, "failed", error_message="阶段重跑废弃")
            except Exception:
                pass
        # CAS 清引用：仅当 laoquan_job_id 仍是读到的旧值时才清（防两次重跑/重跑与调度器竞争交错）
        rows = _sb().execute(
            "UPDATE flow_jobs SET stage='laoquan', status='running', "
            "laoquan_job_id=NULL, error_message=NULL, updated_at=$1 "
            "WHERE id=$2 AND laoquan_job_id=$3 RETURNING id", [now, flow_id, jid or None])
        if not rows:
            sys_log("warning", f"[Flow] retry_from_stage CAS miss flow={flow_id}（job_id 已被并发修改，跳过）")
            return False
        # 刷新阶段起点：重跑即重新计时（耗时从点击重跑开始）
        _sb().execute(
            "UPDATE flow_jobs SET extra = extra || "
            f"'{{\"stage_laoquan_at\":\"{now}\",\"stage_done_at\":null}}'::jsonb WHERE id=$1", [flow_id])
    sys_log("info", f"[Flow] retry_from_stage flow={flow_id} case={flow.get('case_id')} stage={stage}")
    return True


def update_flow(flow_id: str, **fields) -> None:
    allowed = {"stage", "status", "preprocess_task_id", "laoquan_job_id",
              "snapshot_last_check", "error_message"}
    sets, vals = ["updated_at=$1"], [_now()]
    idx = 2
    for k, v in fields.items():
        if k in allowed:
            sets.append(f"{k}=${idx}")
            vals.append(v)
            idx += 1
    vals.append(flow_id)
    _sb().execute(f"UPDATE flow_jobs SET {','.join(sets)} WHERE id=${idx}", vals)


def claim_laoquan_job(flow_id: str, job_id: str) -> bool:
    """CAS 绑定 laoquan job：仅当 laoquan_job_id 仍为空时写入。防两轮轮询各建一条 job。"""
    rows = _sb().execute(
        "UPDATE flow_jobs SET laoquan_job_id=$1, updated_at=$2 "
        "WHERE id=$3 AND laoquan_job_id IS NULL RETURNING id",
        [job_id, _now(), flow_id],
    )
    return bool(rows)


def claim_preprocess_task(flow_id: str, task_id: str) -> bool:
    """CAS 绑定 preprocess 任务：仅当 preprocess_task_id 仍为空时写入。"""
    rows = _sb().execute(
        "UPDATE flow_jobs SET preprocess_task_id=$1, updated_at=$2 "
        "WHERE id=$3 AND preprocess_task_id IS NULL RETURNING id",
        [task_id, _now(), flow_id],
    )
    return bool(rows)


def update_extra(flow_id: str, extra_dict: dict) -> None:
    _sb().execute(
        "UPDATE flow_jobs SET extra = COALESCE(extra,'{}'::jsonb) || $1::jsonb, updated_at=$2 WHERE id=$3",
        [json.dumps(extra_dict, ensure_ascii=False), _now(), flow_id],
    )


# ── 任务分配（case_assignments 表）───────────────────────────────────────

def ensure_assignment_schema() -> None:
    try:
        _sb().execute("""CREATE TABLE IF NOT EXISTS case_assignments (
          case_id TEXT PRIMARY KEY,
          mis TEXT NOT NULL,
          dt TEXT,
          assigned_at TEXT NOT NULL,
          done BOOLEAN DEFAULT FALSE
        )""")
        try:
            _sb().execute("ALTER TABLE case_assignments ADD COLUMN IF NOT EXISTS done BOOLEAN DEFAULT FALSE")
        except Exception:
            pass
    except Exception as e:
        sys_log("warning", f"[Assign] schema ensure fail: {str(e)[:120]}")


def list_assignments(dt: str = "") -> list:
    ensure_assignment_schema()
    where = "WHERE dt=$1" if dt else ""
    params = [dt] if dt else []
    rows = _sb().execute(f"SELECT * FROM case_assignments {where} ORDER BY assigned_at DESC", params)
    return [dict(r) for r in rows]


def get_assignment(case_id: str) -> Optional[dict]:
    ensure_assignment_schema()
    rows = _sb().execute("SELECT * FROM case_assignments WHERE case_id=$1", [case_id])
    return dict(rows[0]) if rows else None


def upsert_assignments(items: list) -> int:
    """批量写入分配（ON CONFLICT 覆盖）。items: [{case_id, mis, dt}]"""
    if not items:
        return 0
    ensure_assignment_schema()
    n = 0
    for it in items:
        try:
            _sb().execute(
                "INSERT INTO case_assignments (case_id, mis, dt, assigned_at) VALUES ($1,$2,$3,$4) "
                "ON CONFLICT (case_id) DO UPDATE SET mis=EXCLUDED.mis, dt=EXCLUDED.dt, assigned_at=EXCLUDED.assigned_at",
                [str(it.get("case_id")), str(it.get("mis")), str(it.get("dt") or ""),
                 datetime.now().strftime("%Y-%m-%d %H:%M:%S")])
            n += 1
        except Exception:
            continue
    return n


def delete_assignment(case_id: str) -> None:
    ensure_assignment_schema()
    try:
        _sb().execute("DELETE FROM case_assignments WHERE case_id=$1", [case_id])
    except Exception:
        pass


def toggle_done(case_id: str, done: bool) -> bool:
    """勾选/取消完成。"""
    ensure_assignment_schema()
    try:
        _sb().execute("UPDATE case_assignments SET done=$1 WHERE case_id=$2", [done, case_id])
        return True
    except Exception:
        return False


# ── 分配人配置与自动分配 ─────────────────────────────────────────────────

def get_assign_config() -> dict:
    """分配人配置（system_config 表 assign_people，JSON 数组 [{mis, weight}]）。
    缺省：lichao168 25 / sunjiajun07 25 / wuxiaonan05 35 / wucheng17 15（2026-09-20 用户定）。"""
    ensure_assignment_schema()
    try:
        rows = _sb().execute(
            "SELECT value FROM system_config WHERE category='access' AND key='assign_people'")
        if rows:
            v = rows[0].get("value")
            if isinstance(v, list) and v:
                return {"people": v}
    except Exception:
        pass
    return {"people": [
        {"mis": "lichao168", "weight": 25},
        {"mis": "sunjiajun07", "weight": 25},
        {"mis": "wuxiaonan05", "weight": 35},
        {"mis": "wucheng17", "weight": 15},
    ]}


def save_assign_config(people: list) -> None:
    ensure_assignment_schema()
    from datetime import datetime as _dt
    _sb().execute(
        "INSERT INTO system_config (category, key, value, updated_at) VALUES ('access','assign_people',$1::jsonb,$2) "
        "ON CONFLICT (category, key) DO UPDATE SET value=EXCLUDED.value, updated_at=EXCLUDED.updated_at",
        [json.dumps(people, ensure_ascii=False), _dt.now().strftime("%Y-%m-%d %H:%M:%S")])


def assign_single(case_id: str, dt: str, mis: str) -> None:
    """单个 case 自动分配（捞全完成即调）。"""
    ensure_assignment_schema()
    try:
        _sb().execute(
            "INSERT INTO case_assignments (case_id, mis, dt, assigned_at) VALUES ($1,$2,$3,$4) "
            "ON CONFLICT (case_id) DO NOTHING",   # 已分配的不覆盖（人工分配优先）
            [case_id, mis, dt or "", datetime.now().strftime("%Y-%m-%d %H:%M:%S")])
    except Exception as e:
        sys_log("warning", f"[Assign] auto assign fail case={case_id}: {str(e)[:100]}")


def auto_assign(case_id: str, dt: str) -> Optional[str]:
    """按权重自动分配一个 case 给配置中的人（加权轮转：各人累计份额逼近权重比）。
    返回分配到的 mis。未配置人 → None。"""
    cfg = get_assign_config()
    people = cfg.get("people") or []
    if not people:
        return None
    ensure_assignment_schema()
    # 统计各人当日已有分配数（含当日权重基线）——按 dt 分组轮转保证每日比例独立
    counts = {}
    try:
        rows = _sb().execute(
            "SELECT mis, count(*) AS n FROM case_assignments WHERE dt=$1 GROUP BY mis", [dt or ""])
        for r in rows:
            counts[r["mis"]] = int(r["n"])
    except Exception:
        pass
    # 加权轮转（2026-09-20 修复）：选「累计实际数 + 1 ≤ 目标累计」的最大缺口者——
    # 逐个分配时任意前缀逼近权重比（与批量分配的交错算法同源）。低权重者必轮到
    # （15% 的人在每 20 个里约 3 个，而非全局占比比较下可能饿死）。
    total_w = sum(float(p.get("weight") or 0) for p in people) or 1.0
    cur_total = sum(counts.values())
    best, best_gap = None, None
    for p in people:
        mis = str(p.get("mis") or "").strip()
        if not mis:
            continue
        w = float(p.get("weight") or 0)
        if w <= 0:
            continue
        # 若分给此人：其占比 vs 目标占比 的缺口（越大越该分给TA）
        cur = counts.get(mis, 0)
        gap = (w / total_w) - ((cur + 1) / (cur_total + 1))
        if best is None or gap > best_gap:
            best, best_gap = mis, gap
    if best:
        assign_single(case_id, dt, best)
    return best


# ── 复盘（case_reviews 表）────────────────────────────────────────────

def ensure_review_schema() -> None:
    try:
        _sb().execute("""CREATE TABLE IF NOT EXISTS case_reviews (
          id TEXT PRIMARY KEY,
          case_id TEXT NOT NULL,
          group_id TEXT,
          category_l1 TEXT NOT NULL,
          category_l2 TEXT NOT NULL,
          env TEXT,
          gang_verdict TEXT,
          problem_desc TEXT NOT NULL,
          follow_up TEXT,
          reviewer TEXT NOT NULL,
          reason_snapshot TEXT,
          dt TEXT,
          review_date TEXT NOT NULL,
          created_at TEXT NOT NULL
        )""")
    except Exception as e:
        sys_log("warning", f"[Review] schema ensure fail: {str(e)[:120]}")


L1_OPTIONS = ["团伙判断", "团伙定性", "提纯捞全", "误伤评估", "运营通过"]
L2_OPTIONS = ["非团伙", "团伙无有效聚集", "定性不正确", "规则推荐不正确",
              "规则判断不正确", "误伤评估不正确", "运营通过（无异常/优化点）",
              "运营通过（无风险）"]
ENV_OPTIONS = ["登录", "注册", "解冻", "token"]


def create_review(data: dict) -> dict:
    ensure_review_schema()
    rid = str(uuid.uuid4())
    now = _now()
    _sb().execute(
        "INSERT INTO case_reviews (id, case_id, group_id, category_l1, category_l2, env, "
        "gang_verdict, problem_desc, follow_up, reviewer, reason_snapshot, dt, review_date, created_at) "
        "VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14)",
        [rid, data.get("case_id", ""), data.get("group_id", ""),
         data.get("category_l1", ""), data.get("category_l2", ""),
         data.get("env", ""), data.get("gang_verdict", ""),
         data.get("problem_desc", ""), data.get("follow_up", ""),
         data.get("reviewer", ""), str(data.get("reason_snapshot") or "")[:6000],
         data.get("dt", ""), now[:10], now])
    return get_review(rid)


def get_review(rid: str):
    rows = _sb().execute("SELECT * FROM case_reviews WHERE id=$1", [rid])
    return dict(rows[0]) if rows else None


def get_review_by_case(case_id: str):
    rows = _sb().execute(
        "SELECT * FROM case_reviews WHERE case_id=$1 ORDER BY created_at DESC LIMIT 1", [case_id])
    return dict(rows[0]) if rows else None


def list_reviews(date_from: str = "", date_to: str = "",
                 l1: str = "", env: str = "") -> list:
    ensure_review_schema()
    where, params = [], []
    if date_from:
        params.append(date_from); where.append(f"review_date >= ${len(params)}")
    if date_to:
        params.append(date_to); where.append(f"review_date <= ${len(params)}")
    if l1:
        params.append(l1); where.append(f"category_l1 = ${len(params)}")
    if env:
        params.append(env); where.append(f"env = ${len(params)}")
    w = ("WHERE " + " AND ".join(where)) if where else ""
    rows = _sb().execute(
        f"SELECT * FROM case_reviews {w} ORDER BY created_at DESC LIMIT 500", params)
    return [dict(r) for r in rows]


def update_review(rid: str, data: dict) -> bool:
    sets, vals, idx = [], [], 1
    for k in ("category_l1", "category_l2", "env", "gang_verdict",
              "problem_desc", "follow_up", "reviewer"):
        if k in data:
            sets.append(f"{k}=${idx}"); vals.append(data[k]); idx += 1
    if not sets:
        return False
    vals.append(rid)
    _sb().execute(f"UPDATE case_reviews SET {','.join(sets)} WHERE id=${idx}", vals)
    return True


def delete_review(rid: str) -> None:
    ensure_review_schema()
    _sb().execute("DELETE FROM case_reviews WHERE id=$1", [rid])
