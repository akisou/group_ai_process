"""
画布 job 持久化层（Supabase）。
对标反爬 ci_supabase 的画布相关方法，用 Supabase PostgreSQL 替代 SQLite。
重启无损 + 多实例共享。

status 流转：pending → submitted → verifying → done / failed / needs_reconcile
canvas_phase：canvas_polling（等画布 SUCCEEDED）/ verifying（Talos 校验结果表）

表 canvas_jobs 需在 Supabase 预建（见 ensure_schema）。
"""
from __future__ import annotations

import json
import uuid
from datetime import datetime
from typing import Optional

from logger import sys_log

_SCHEMA = """
CREATE TABLE IF NOT EXISTS canvas_jobs (
  id TEXT PRIMARY KEY,
  case_id TEXT NOT NULL,
  experiment TEXT,
  submit_dt TEXT,
  unique_key TEXT,
  hive_qid TEXT,
  status TEXT NOT NULL DEFAULT 'pending',
  canvas_phase TEXT DEFAULT 'canvas_polling',
  retry_count INTEGER DEFAULT 0,
  max_retries INTEGER DEFAULT 2,
  error_message TEXT,
  row_count INTEGER,
  extra JSONB DEFAULT '{}'::jsonb,
  created_at TEXT,
  updated_at TEXT
);
CREATE INDEX IF NOT EXISTS idx_canvas_jobs_case_id ON canvas_jobs(case_id);
CREATE INDEX IF NOT EXISTS idx_canvas_jobs_status ON canvas_jobs(status);
CREATE TABLE IF NOT EXISTS deleted_cases (
  case_id TEXT PRIMARY KEY,
  deleted_at TEXT NOT NULL
);
"""

_sb_client = None


def _sb():
    """全局复用 SupabaseClient（线程安全，复用 TCP 连接）。"""
    global _sb_client
    if _sb_client is None:
        from client.supabase_client import SupabaseClient
        _sb_client = SupabaseClient()
    return _sb_client


def ensure_schema():
    """建表（幂等）。首次启动调用，或在 Supabase 控制台手动执行 _SCHEMA。"""
    try:
        _sb().execute(_SCHEMA)
        sys_log("info", "[CanvasJob] schema ensured (canvas_jobs table)")
    except Exception as e:
        sys_log("error", f"[CanvasJob] ensure_schema failed: {str(e)[:200]}")
    # 分析结果缓存表（画布完成后落 PG，界面读 PG）
    try:
        import result_cache
        result_cache.ensure_schema()
    except Exception as e:
        sys_log("error", f"[CanvasJob] result_cache ensure_schema failed: {str(e)[:200]}")


def _row_to_dict(row) -> dict:
    if not row:
        return {}
    d = dict(row)
    extra = d.get("extra")
    if isinstance(extra, str):
        try:
            d["extra"] = json.loads(extra)
        except Exception:
            d["extra"] = {}
    elif extra is None:
        d["extra"] = {}
    return d


def _now() -> str:
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")


def create_job(case_id: str, experiment: str, submit_dt: str, unique_key: str) -> dict:
    """建 pending job（端点调，不提交画布，等调度器 pick up）。"""
    job_id = str(uuid.uuid4())
    now = _now()
    extra = json.dumps({"submit_dt": submit_dt}, ensure_ascii=False)
    _sb().execute(
        "INSERT INTO canvas_jobs (id, case_id, experiment, submit_dt, unique_key, "
        "status, canvas_phase, extra, created_at, updated_at) "
        "VALUES ($1, $2, $3, $4, $5, 'pending', 'canvas_polling', $6::jsonb, $7, $8)",
        [job_id, case_id, experiment, submit_dt, unique_key, extra, now, now],
    )
    sys_log("info", f"[CanvasJob] created job={job_id} case={case_id} unique_key={unique_key}")
    return get_job(job_id)


def claim_for_submit(job_id: str) -> bool:
    """CAS：pending → submitted。成功返回 True（调用方负责调 offlineStartCanvas）。"""
    now = _now()
    rows = _sb().execute(
        "UPDATE canvas_jobs SET status='submitted', updated_at=$1 "
        "WHERE id=$2 AND status='pending' RETURNING id",
        [now, job_id],
    )
    return bool(rows)


def count_running() -> int:
    """统计 submitted/verifying 数量（并发限制）。"""
    rows = _sb().execute(
        "SELECT count(*) AS n FROM canvas_jobs WHERE status IN ('submitted','verifying')"
    )
    return int(rows[0]["n"]) if rows else 0


def update_status(job_id: str, status: str, **fields) -> None:
    """更新状态 + 可选字段。"""
    allowed = {"unique_key", "hive_qid", "error_message", "row_count", "canvas_phase"}
    sets, vals = ["status=$1", "updated_at=$2"], [status, _now()]
    idx = 3
    for k, v in fields.items():
        if k in allowed:
            sets.append(f"{k}=${idx}")
            vals.append(v)
            idx += 1
    vals.append(job_id)
    _sb().execute(f"UPDATE canvas_jobs SET {','.join(sets)} WHERE id=${idx}", vals)


def update_extra(job_id: str, extra_dict: dict) -> None:
    """merge extra JSON。"""
    _sb().execute(
        "UPDATE canvas_jobs SET extra = COALESCE(extra,'{}'::jsonb) || $1::jsonb, updated_at=$2 WHERE id=$3",
        [json.dumps(extra_dict, ensure_ascii=False), _now(), job_id],
    )


def increment_retry(job_id: str) -> int:
    """retry_count += 1，返回新值。"""
    rows = _sb().execute(
        "UPDATE canvas_jobs SET retry_count=retry_count+1, updated_at=$1 "
        "WHERE id=$2 RETURNING retry_count",
        [_now(), job_id],
    )
    return int(rows[0]["retry_count"]) if rows else 0


def mark_needs_reconcile(job_id: str, error: str, hive_qid: Optional[str] = None) -> None:
    """fail closed：禁止自动重试，需人工核对。"""
    fields = {"error_message": error[:500]}
    if hive_qid:
        fields["hive_qid"] = hive_qid
    update_status(job_id, "needs_reconcile", **fields)
    sys_log("error", f"[CanvasJob] needs_reconcile job={job_id} error={error[:200]}")


def get_running_jobs() -> list:
    """调度器轮询用：所有 pending/submitted/verifying/syncing 的 job。
    priority=1（加急）优先出队，同优先级按 updated_at。"""
    rows = _sb().execute(
        "SELECT * FROM canvas_jobs WHERE status IN ('pending','submitted','verifying','syncing') "
        "ORDER BY (COALESCE(extra->>'priority','0') != '0') DESC, updated_at"
    )
    return [_row_to_dict(r) for r in rows]


def get_job(job_id: str) -> Optional[dict]:
    rows = _sb().execute("SELECT * FROM canvas_jobs WHERE id=$1", [job_id])
    return _row_to_dict(rows[0]) if rows else None


def list_jobs(case_id: str, limit: int = 20) -> list:
    rows = _sb().execute(
        "SELECT * FROM canvas_jobs WHERE case_id=$1 ORDER BY created_at DESC LIMIT $2",
        [case_id, limit],
    )
    return [_row_to_dict(r) for r in rows]


def list_recent(limit: int = 50) -> list:
    rows = _sb().execute(
        "SELECT * FROM canvas_jobs ORDER BY created_at DESC LIMIT $1", [limit]
    )
    return [_row_to_dict(r) for r in rows]


def reset_to_pending(job_id: str) -> bool:
    """手动重试：needs_reconcile/failed → pending。"""
    now = _now()
    rows = _sb().execute(
        "UPDATE canvas_jobs SET status='pending', canvas_phase='canvas_polling', "
        "hive_qid=NULL, error_message=NULL, updated_at=$1 "
        "WHERE id=$2 AND status IN ('needs_reconcile','failed') RETURNING id",
        [now, job_id],
    )
    return bool(rows)


# ── case 删除（黑名单 + 级联清理 Supabase 侧数据）────────────────────────

def delete_case_data(case_id: str) -> dict:
    """删除 case 的全部 Supabase 侧数据 + 拉黑（展示查询过滤）。Hive 源数据不动。
    返回各表删除行数。"""
    now = _now()
    _sb().execute(
        "INSERT INTO deleted_cases (case_id, deleted_at) VALUES ($1, $2) "
        "ON CONFLICT (case_id) DO UPDATE SET deleted_at=EXCLUDED.deleted_at",
        [case_id, now],
    )
    n = {}
    n["result_cache"] = _sb().execute(
        "DELETE FROM result_cache WHERE case_id=$1 RETURNING cache_key", [case_id])
    n["canvas_jobs"] = _sb().execute(
        "DELETE FROM canvas_jobs WHERE case_id=$1 RETURNING id", [case_id])
    n["flow_jobs"] = _sb().execute(
        "DELETE FROM flow_jobs WHERE case_id=$1 RETURNING id", [case_id])
    n["preprocess_jobs"] = _sb().execute(
        "DELETE FROM preprocess_jobs WHERE case_id=$1 RETURNING id", [case_id])
    counts = {k: len(v) for k, v in n.items()}
    sys_log("info", f"[delete] case={case_id} 黑名单+清理 {counts}")
    return counts


def list_deleted_cases() -> set:
    """已删除（拉黑）的 case_id 集合，展示查询过滤用。"""
    try:
        rows = _sb().execute("SELECT case_id FROM deleted_cases")
        return {r["case_id"] for r in rows}
    except Exception:
        return set()
