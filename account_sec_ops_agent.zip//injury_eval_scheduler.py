"""
误伤评估调度器——独立调度（sceneKey=accountsec_agent_group_evaluation）。
pending → submitted（提交画布）→ 轮询 canvas 状态 → done/failed。
"""
from __future__ import annotations

from apscheduler.schedulers.background import BackgroundScheduler

import injury_eval_store as store
from client.injury_eval_client import InjuryEvalClient, FAILED
from logger import sys_log


class InjuryEvalScheduler:
    def __init__(self):
        from config import get_config
        cfg = get_config().canvas_scheduler
        self.interval = cfg.poll_interval_seconds
        self._sched: BackgroundScheduler | None = None

    def start(self):
        if self._sched is not None:
            return
        self._sched = BackgroundScheduler(timezone="Asia/Shanghai")
        self._sched.add_job(self._poll_all, "interval", seconds=self.interval, id="injury_eval_poll",
                            max_instances=1, coalesce=True, misfire_grace_time=10)
        self._sched.start()
        sys_log("info", f"[InjuryEvalScheduler] started, interval={self.interval}s")

    def shutdown(self):
        if self._sched is not None:
            self._sched.shutdown(wait=False)
            self._sched = None
            sys_log("info", "[InjuryEvalScheduler] shutdown")

    def _poll_all(self):
        try:
            for job in store.list_running():
                try:
                    self._advance(job)
                except Exception as e:
                    sys_log("warning", f"[InjuryEvalScheduler] job={job.get('id')} advance error: {str(e)[:200]}")
        except Exception as e:
            sys_log("error", f"[InjuryEvalScheduler] poll_all error: {str(e)[:200]}")

    def _advance(self, job: dict):
        if job["status"] == "pending":
            self._submit(job)
        elif job["status"] == "submitted":
            self._poll_canvas(job)

    def _submit(self, job: dict):
        jid = job["id"]
        # 提交暂停开关：mlp 总开关 + 误伤评估自身开关；priority=1 走加急通道（+10 独享槽）
        from config import get_config
        from mlp_switch import mlp_can_submit
        if not get_config().injury_eval.auto_submit:
            sys_log("debug", f"[InjuryEvalScheduler] auto_submit 关闭，job={jid} 保持 pending")
            return
        urgent = bool(((job.get("extra") or {}).get("priority"))
                      or str(job.get("priority") or "") not in ("", "0", "None"))
        if not mlp_can_submit("injury_eval", urgent=urgent):
            return
        if not store.claim_for_submit(jid):
            return
        try:
            res = InjuryEvalClient().submit(
                case_id=job["case_id"], dt=job.get("dt") or "",
                combo_id=job["combo_id"],
                target_sql_b64=job.get("target_sql_b64") or "",
                action_type=job.get("action_type") or "",
            )
            unique_key = res["unique_key"]
            try:
                store.update_extra(jid, {
                    "canvas_status": "SUBMITTED",
                    "start_canvas_request": res.get("request"),
                    "start_canvas_response": res.get("response"),
                })
            except Exception:
                pass
            store.update_status(jid, "submitted", unique_key=unique_key)
            sys_log("info", f"[InjuryEvalScheduler] submitted job={jid} unique_key={unique_key}")
        except Exception as e:
            # 失败也存报文（request/response 在 res 里，submit 抛异常前已构造）
            try:
                store.update_extra(jid, {"submit_error": str(e)[:500]})
            except Exception:
                pass
            store.update_status(jid, "failed", error_message=str(e)[:500])
            sys_log("warning", f"[InjuryEvalScheduler] submit failed job={jid}: {str(e)[:200]}")

    def _poll_canvas(self, job: dict):
        jid = job["id"]
        unique_key = job.get("unique_key") or ""
        if not unique_key or unique_key.startswith("pending_"):
            # 旧快照竞态：回查 DB 再判（与 preprocess/canvas 同款防御）
            fresh = store.get_job(jid)
            unique_key = (fresh or {}).get("unique_key") or ""
            if not unique_key or unique_key.startswith("pending_"):
                store.update_status(jid, "failed", error_message="unique_key 为空（回查仍为空）")
                return
        try:
            res = InjuryEvalClient().query_status(unique_key)
        except Exception as e:
            store.update_extra(jid, {"canvas_status": "UNKNOWN", "last_error": str(e)[:200]})
            return
        status = res["status"]
        store.update_extra(jid, {
            "canvas_status": status,
            "query_canvas_request": res.get("request"),
            "query_canvas_response": res.get("response"),
        })
        if status == "SUCCEEDED":
            store.update_status(jid, "done")
            sys_log("info", f"[InjuryEvalScheduler] job done job={jid}")
        elif status in FAILED:
            store.update_status(jid, "failed", error_message=f"画布执行 {status}")
        # NEW/READY/STARTING/RUNNING：等下轮
