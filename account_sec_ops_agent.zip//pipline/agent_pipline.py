#!/usr/bin/env python3
"""
风险事件排查流水线脚本 v9（基于 v8）
=====================================

架构：直接在 Jupyter cell 中运行，使用 Jupyter 预创建的 `spark` 变量。
不创建新的 SparkSession，避免 HDFS token 过期问题。

v9 变更：
1. 【核心 bug 修复】提纯捞全 step_tichun_create 中 reason 参数原传 penalty_reason（处罚原因摘要），
   改为传 summary_text（所有有风险结果的汇总，格式：{yy环节-xx风险，详情：{xxx}}）
2. 【核心 bug 修复】四个风险判定环节（注册/登录/解冻/Token）改为并发执行（ThreadPoolExecutor），
   而非串行执行，提升效率
3. 【功能完善】落表 write_results_to_hive 字段对齐用户要求：
   group_id, dt, is_risk_group, is_risk_group_reason,
   register_result, register_reason, login_result, login_reason,
   unfreeze_result, unfreeze_reason, token_result, token_reason
4. 【功能完善】process_single_group 返回字典新增 is_risk_group_reason、register_result、
   register_reason、login_result、login_reason、unfreeze_result、unfreeze_reason、
   token_result、token_reason 字段，用于落表
5. 【细节优化】step_summarize_risks 返回的 summary 去掉前缀 group_id 风险汇总：
   只返回格式化的风险汇总字符串，避免与 penalty_reason 混淆
6. 【细节优化】determine_penalty 中冻结规则登录环节的 reason 显示具体检测到的关键词

v8 变更：
1. 团伙判定新增 is_missed 判断（近90天历史零值天数）+ Hive 落表到 ba_rc.app_account_risk_group_is_group_result_dt
2. Token 判定使用新的 parse_token_risk_results 解析逻辑（正则提取 {result:"xxx",reason:"yyy"} 对）
3. 团伙判定增加重试机制（2次重试，间隔5秒）
4. 所有 v7 功能保留
"""

import json
import logging
import os
import random
import re
import sys
import time
import traceback
from datetime import datetime, timedelta
from typing import Any, Dict, List, Optional
from concurrent.futures import ThreadPoolExecutor, as_completed

import requests

# ============================================================
# 配置
# ============================================================
ARCEUS_BASE_URL = "https://arceusllm-api.sankuai.com/v1/workflows/run"

# 团伙判定已改读感知表（不调 dify），API_KEY_IS_GROUP 移除
API_KEY_RISK_REGISTER = "app-JjkDJgCgwzTatAfdVcoZol3N"
API_KEY_RISK_LOGIN = "app-UkQm0gWHvqlguysfhHxDAUzJ"
API_KEY_RISK_UNFREEZE = "app-lodpO6ChqH27nLudUAPIxhdK"
API_KEY_RISK_TOKEN = "app-Y0T7D7sobWSkOsQzODhwPvCt"

TICHUN_CREATE_URL = "http://acc-sec-agent-huilao.adp.st.sankuai.com/agent/tichunlaoquan/task_create"
TICHUN_STATUS_URL = "http://acc-sec-agent-huilao.adp.st.sankuai.com/agent/tichunhuilao/task_status"

HIVE_TABLE = "ba_rc.app_account_risk_group_perception_result_dt"
JUDGE_TABLE = "ba_rc.app_account_agent_risk_group_judge_d"   # 团伙判定表（is_risk_group/reason/is_missed 来源）
IS_GROUP_TABLE = "ba_rc.app_account_risk_group_is_group_result_dt"  # v8 新增：团伙判定落表
TICHUN_BIZ = "acc_sec_agent_pipline"
TICHUN_CREATE_REASON = '{"k":"v"}'

# 团伙判定缓存：主入口读 judge 表时一次填充（group_id → is_risk_group/reason/is_missed）。
# step_is_group 读缓存，不调 dify 工作流——judge 表 is_risk_group=1 即团伙，0 非团伙。
_PERCEPTION_CACHE: Dict[str, Dict[str, str]] = {}

WORKFLOW_USERS = {
    "风险判定-注册": "haoyiran02",
    "风险判定-登录": "wuxiaonan05",
    "风险判定-解冻": "haoyiran02",
    "风险判定-Token": "zhanglei288",
}
WORKFLOW_TIMEOUT = 600

MAX_STATUS_CHECKS = 96
STATUS_CHECK_INTERVAL = 1800
OUTPUT_FILE = os.environ.get("RISK_PIPELINE_OUTPUT_FILE", "/home/sankuai/abnormal_param/risk_result.json")
RISK_RESULT_TABLE = os.environ.get("RISK_RESULT_TABLE", "ba_rc.app_account_ai_group_risk_pipeline_result")
os.environ["RISK_PIPELINE_CONCURRENCY"] = "4"


logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    handlers=[
        logging.StreamHandler(sys.stdout),
        logging.FileHandler("/tmp/risk_pipeline_v8.log", encoding="utf-8"),
    ],
)
logger = logging.getLogger("risk_pipeline_v9")


# ============================================================
# 通用：调用 Arceus 工作流（流式模式）
# ============================================================
def call_arceus_workflow(
    api_key: str,
    inputs: Dict[str, Any],
    workflow_name: str,
    user: str = None,
    timeout: int = 600,
) -> Dict[str, Any]:
    """通用 Arceus 工作流流式调用"""
    if user is None:
        user = WORKFLOW_USERS.get(workflow_name, "haoyiran02")
    headers = {"Content-Type": "application/json", "Authorization": f"Bearer {api_key}"}
    payload = {"inputs": inputs, "response_mode": "streaming", "user": user}
    logger.info(f"  调用 [{workflow_name}] user={user}")
    try:
        resp = requests.post(ARCEUS_BASE_URL, headers=headers, json=payload, stream=True, timeout=timeout)
        resp.raise_for_status()
        outputs = {}
        for line in resp.iter_lines(decode_unicode=True):
            if not line:
                continue
            line = line.strip()
            if line == "[DONE]":
                break
            if line.startswith("data:"):
                data_str = line[5:].strip()
                if not data_str:
                    continue
                try:
                    event_data = json.loads(data_str)
                except json.JSONDecodeError:
                    continue
                event_type = event_data.get("event")
                data = event_data.get("data", {})
                if event_type == "node_started":
                    logger.info(f"  [{workflow_name}] 节点开始: {data.get('title', '')}")
                elif event_type == "node_finished":
                    logger.info(f"  [{workflow_name}] 节点完成: {data.get('title', '')}")
                elif event_type == "workflow_finished":
                    outputs = data.get("outputs", {})
                    logger.info(f"  [{workflow_name}] 完成")
                    break
        return {"status": "succeeded", "outputs": outputs}
    except Exception as e:
        logger.error(f"  [{workflow_name}] 调用失败: {e}")
        return {"status": "failed", "outputs": {}, "error": str(e)}


# ============================================================
# 登录环节专用：流式调用（来自 2783438891）
# ============================================================
def run_workflow_streaming(
    inputs: Dict[str, str],
    api_key: str = API_KEY_RISK_LOGIN,
    user: str = "wuxiaonan05",
    api_base: str = "https://arceusllm-api.sankuai.com",
) -> str:
    """以流式模式运行登录环节工作流"""
    payload = {
        "inputs": inputs,
        "response_mode": "streaming",
        "user": user,
    }
    headers = {
        "Authorization": f"Bearer {api_key}",
        "Content-Type": "application/json",
    }
    result_text = ""
    try:
        with requests.post(
            f"{api_base}/v1/workflows/run",
            headers=headers,
            json=payload,
            timeout=600,
            stream=True,
        ) as resp:
            resp.raise_for_status()
            for line in resp.iter_lines(decode_unicode=True):
                if not line:
                    continue
                if line.startswith("data:"):
                    raw = line[5:].strip()
                    if raw == "[DONE]":
                        break
                    try:
                        event = json.loads(raw)
                    except json.JSONDecodeError:
                        continue
                    evt_type = event.get("event", "")
                    data = event.get("data", {})
                    if evt_type == "node_started":
                        title = data.get("title", "")
                        node_type = data.get("node_type", "")
                        logger.info(f"  → 节点开始: [{node_type}] {title}")
                    if evt_type == "node_finished":
                        title = data.get("title", "")
                        node_type = data.get("node_type", "")
                        status = data.get("status", "")
                        elapsed = data.get("elapsed_time", 0)
                        logger.info(
                            f"  ← 节点完成: [{node_type}] {title} ({status}, {elapsed:.2f}s)"
                        )
                    if evt_type == "node_finished":
                        outputs = data.get("outputs", {})
                        if outputs and isinstance(outputs, dict):
                            for key in ["text", "result", "answer", "output"]:
                                if key in outputs and outputs[key]:
                                    result_text += str(outputs[key])
                                    break
                    if evt_type == "workflow_finished":
                        summary = data.get("outputs", {})
                        if summary:
                            result_text = json.dumps(
                                summary, ensure_ascii=False, indent=2
                            )
                    message = event.get("message", {})
                    if message:
                        answer = message.get("answer", "")
                        if answer:
                            result_text += answer
    except requests.exceptions.HTTPError as e:
        raise RuntimeError(
            f"API 请求失败: {e} (状态码: {e.response.status_code})\n"
            f"响应: {e.response.text[:300]}"
        ) from e
    except requests.exceptions.Timeout:
        raise RuntimeError("请求超时（>600s），工作流执行时间过长")
    except requests.exceptions.RequestException as e:
        raise RuntimeError(f"网络错误: {e}") from e
    return result_text


# ============================================================
# 通用：解析 JSON
# ============================================================
def _parse_json_string(value: Any) -> Dict[str, Any]:
    if isinstance(value, dict):
        return value
    if isinstance(value, str):
        try:
            parsed = json.loads(value)
            if isinstance(parsed, dict):
                return parsed
            return {"raw": parsed}
        except json.JSONDecodeError:
            return {"raw": value}
    return {"raw": value}


# ============================================================
# Step 1: 团伙判定（改读感知表，不调 dify 工作流）
# ============================================================
def _write_is_group_to_hive(spark, record: Dict[str, Any]):
    """将团伙判定结果写入 Hive 表 — 参考 2783188791"""
    try:
        columns = [
            "group_id", "platform_app_partner", "label", "status",
            "elapsed_time", "total_steps", "total_tokens", "error",
            "output_result", "is_risk_group", "reason", "is_missed", "dt"
        ]
        values = [record.get(c) for c in columns]
        from pyspark.sql.types import StructType, StructField, StringType, DoubleType, IntegerType
        schema = StructType([
            StructField("group_id", StringType(), True),
            StructField("platform_app_partner", StringType(), True),
            StructField("label", StringType(), True),
            StructField("status", StringType(), True),
            StructField("elapsed_time", DoubleType(), True),
            StructField("total_steps", IntegerType(), True),
            StructField("total_tokens", IntegerType(), True),
            StructField("error", StringType(), True),
            StructField("output_result", StringType(), True),
            StructField("is_risk_group", StringType(), True),
            StructField("reason", StringType(), True),
            StructField("is_missed", StringType(), True),
            StructField("dt", StringType(), True),
        ])
        df = spark.createDataFrame([values], schema)
        df.createOrReplaceTempView("tmp_is_group_result_single")
        spark.sql("SET hive.exec.dynamic.partition=true")
        spark.sql("SET hive.exec.dynamic.partition.mode=nonstrict")
        spark.sql(f"""
            INSERT INTO TABLE {IS_GROUP_TABLE} PARTITION (dt)
            SELECT group_id, platform_app_partner, label, status,
                   elapsed_time, total_steps, total_tokens, error,
                   output_result, is_risk_group, reason, is_missed, dt
            FROM tmp_is_group_result_single
        """)
        logger.info(f"  已写入 {IS_GROUP_TABLE}, group_id={record['group_id']}")
    except Exception as e:
        logger.warning(f"  写入 is_group Hive 表失败: {e}")


def step_is_group(group_id: str, platform_app_partner: str, label: str, dt: str) -> Dict[str, Any]:
    """团伙判定：读 judge 表缓存（主入口一次 SELECT 填充），不调 dify 工作流。
    is_risk_group=1 团伙 / 0 非团伙；reason=判定依据（judge 表列）。"""
    try:
        cached = _PERCEPTION_CACHE.get(group_id)
        if cached is None:
            # 兜底：主入口未填充（单独调用本函数）→ 单查团伙判定表
            try:
                df = spark.sql(f"SELECT is_risk_group, reason, is_missed FROM {JUDGE_TABLE} "
                               f"WHERE dt='{dt}' AND group_id='{group_id}' LIMIT 1")
                rows = df.collect()
                if rows:
                    r = rows[0]
                    cached = {"is_risk_group": "1" if str(r["is_risk_group"]) == "1" else "0",
                              "reason": str(r["reason"] or ""),
                              "is_missed": "1" if str(r["is_missed"]) == "1" else "0"}
                    _PERCEPTION_CACHE[group_id] = cached
            except Exception as e:
                logger.warning(f"  团伙判定表单查失败 group={group_id}: {e}")
        if cached is None:
            return {"is_risk_group": "-1", "reason": f"团伙判定表无该 group 当日记录: {group_id}",
                    "is_missed": "", "status": "failed"}

        is_risk_group_val = cached["is_risk_group"]
        reason_val = cached["reason"]
        is_missed_val = cached["is_missed"]

        # Hive 落表（对齐 v8 的 13 列，来源改感知表）
        try:
            record = {
                "group_id": group_id,
                "platform_app_partner": platform_app_partner,
                "label": label,
                "status": "succeeded",
                "elapsed_time": 0.0,
                "total_steps": 0,
                "total_tokens": 0,
                "error": "",
                "output_result": json.dumps({"source": "judge_table", **cached}, ensure_ascii=False),
                "is_risk_group": is_risk_group_val,
                "reason": reason_val,
                "is_missed": is_missed_val,
                "dt": dt,
            }
            _write_is_group_to_hive(spark, record)
        except Exception as e:
            logger.warning(f"  is_group 落表异常: {e}")

        logger.info(f"  团伙判定(感知表): is_risk_group={is_risk_group_val}, is_missed={is_missed_val}, reason={reason_val[:200]}")
        return {
            "is_risk_group": is_risk_group_val,
            "reason": reason_val,
            "is_missed": is_missed_val,
            "status": "succeeded",
        }
    except Exception as e:
        logger.error(f"  团伙判定异常: {e}")
        return {"is_risk_group": "-1", "reason": f"调用异常: {e}", "is_missed": "", "status": "failed"}


# ============================================================
# Step 2: 风险判定详细拉取 — 注册/解冻/token
# ============================================================
def _parse_risk_output(outputs: Dict[str, Any], workflow_type: str) -> List[Dict[str, Any]]:
    """按工作流类型的字段映射解析风险判定输出。"""
    key_dict = {
        "注册": {"result": "风险类型", "reason": "判定依据"},
        "Token": {"result": "result", "reason": "reason"},
        "解冻": {"result": "风险类型", "reason": "判定依据"},
    }
    key_mapping = key_dict.get(workflow_type, {"reason": "reason", "result": "result"})
    reason_key = key_mapping["reason"]
    result_key = key_mapping["result"]
    risks = []

    candidates = [value.strip() for value in outputs.values() if isinstance(value, str) and value.strip()]
    text = max(candidates, key=len, default="")
    if not text or text == "无风险":
        return risks

    try:
        inner = json.loads(text)
    except (TypeError, json.JSONDecodeError):
        inner = None

    # JSON 对象或对象列表按 key_dict 中当前工作流的字段名取值。
    if isinstance(inner, dict):
        result = inner.get(result_key, "")
        reason = inner.get(reason_key, "")
        if result or reason:
            risks.append({"result": str(result), "reason": str(reason)})
    elif isinstance(inner, list):
        for item in inner:
            if not isinstance(item, dict):
                continue
            result = item.get(result_key, "")
            reason = item.get(reason_key, "")
            if result or reason:
                risks.append({"result": str(result), "reason": str(reason)})

    # JSON 解析失败或未命中映射字段时，兼容 JSON-like 和自然文本的“字段: 值”格式。
    if not risks:
        result_values = re.findall(
            rf"[\"'`]?{re.escape(result_key)}[\"'`]?\s*[:：=]\s*[\"'`]?(.*?)(?=\s*[\"'`]?\s*(?:[,，;；}}\]\n]|$))",
            text,
            flags=re.DOTALL,
        )
        reason_values = re.findall(
            rf"[\"'`]?{re.escape(reason_key)}[\"'`]?\s*[:：=]\s*[\"'`]?(.*?)(?=\s*[\"'`]?\s*(?:[,，;；}}\]\n]|$))",
            text,
            flags=re.DOTALL,
        )
        for index in range(max(len(result_values), len(reason_values))):
            result = result_values[index].strip() if index < len(result_values) else ""
            reason = reason_values[index].strip() if index < len(reason_values) else ""
            if result or reason:
                risks.append({"result": result, "reason": reason})

    # 仍无法识别字段时，前 20 个字符作为 result，剩余文本作为 reason。
    if not risks:
        risks.append({"result": text[:20], "reason": text[20:]})

    return risks


def step_risk_register(group_id: str, platform_app_partner: str, label: str, dt: str) -> List[Dict[str, Any]]:
    """风险判定-注册"""
    try:
        inputs = {"group_id": group_id, "user_id": "-", "label": label, "platform_app_partner": platform_app_partner, "dt": dt}
        result = call_arceus_workflow(API_KEY_RISK_REGISTER, inputs, "风险判定-注册", user="haoyiran02")
        if result["status"] != "succeeded":
            logger.warning(f"  注册判定工作流失败: {result.get('error', '')}")
            return []
        risks = _parse_risk_output(result["outputs"], "注册")
        for r in risks:
            logger.info(f"  注册风险: {r['result']} - {r['reason'][:200]}")
        if not risks:
            logger.info("  注册环节无风险")
        return risks
    except Exception as e:
        logger.error(f"  注册风险判定异常: {e}")
        return []


# ============================================================
# Step 3: 风险判定 — 登录（使用 2783438891 的独立流式调用）
# ============================================================
def step_risk_login(group_id: str, platform_app_partner: str, label: str, dt: str) -> List[Dict[str, Any]]:
    """风险判定-登录（使用 2783438891 的 run_workflow_streaming 独立流式调用）"""
    try:
        inputs = {"group_id": group_id, "user_id": "-", "label": label, "platform_app_partner": platform_app_partner, "dt": dt}
        result_text = run_workflow_streaming(inputs=inputs, api_key=API_KEY_RISK_LOGIN, user="wuxiaonan05")
        logger.info(f"  登录环节原始输出: {result_text[:300]}")
        risks = []
        if result_text and result_text.strip():
            try:
                parsed = json.loads(result_text)
                if isinstance(parsed, dict):
                    risk_type = parsed.get("risk_type", "")
                    risk_conclusion = parsed.get("risk_conclusion", "")
                    evidence = parsed.get("evidence", "")
                    result = parsed.get("result", "")
                    if risk_type or risk_conclusion:
                        risks.append({
                            "result": "无风险" if "无风险" in risk_type else risk_type,
                            "reason": risk_conclusion[:512] if risk_conclusion else "",
                            "type": "登录",
                        })
                        if evidence:
                            risks[-1]["详情"] = evidence[:1000]
                        if result:
                            risks[-1]["分析结果"] = result[:500]
                    elif result:
                        risks.append({"result": "登录分析", "reason": result[:500], "type": "登录"})
                    else:
                        risks.append({"result": "登录风险", "reason": json.dumps(parsed, ensure_ascii=False)[:500], "type": "登录"})
                elif isinstance(parsed, list):
                    for item in parsed:
                        if isinstance(item, dict):
                            risks.append({"result": str(item.get("risk_type", "登录无风险")), "reason": str(item.get("risk_conclusion", "")), "type": "登录"})
                else:
                    risks.append({"result": "登录无风险", "reason": str(parsed)[:500], "type": "登录"})
            except json.JSONDecodeError:
                risks.append({"result": "登录分析", "reason": result_text[:500], "type": "登录"})
        for r in risks:
            logger.info(f"  登录风险: {r['result']} - {r.get('reason', '')[:500]}")
        if not risks:
            logger.info("  登录环节无风险")
        return risks
    except Exception as e:
        logger.error(f"  登录风险判定异常: {e}")
        logger.error(traceback.format_exc())
        return []


# ============================================================
# Step 4: 风险判定 — 解冻
# ============================================================
def step_risk_unfreeze(group_id: str, platform_app_partner: str, label: str, dt: str) -> List[Dict[str, Any]]:
    """风险判定-解冻"""
    try:
        inputs = {"group_id": group_id, "user_id": "-", "label": label, "platform_app_partner": platform_app_partner, "dt": dt}
        result = call_arceus_workflow(API_KEY_RISK_UNFREEZE, inputs, "风险判定-解冻", user="haoyiran02")
        if result["status"] != "succeeded":
            logger.warning(f"  解冻判定工作流失败: {result.get('error', '')}")
            return []
        risks = _parse_risk_output(result["outputs"], "解冻")
        for r in risks:
            logger.info(f"  解冻风险: {r['result']} - {r['reason'][:200]}")
        if not risks:
            logger.info("  解冻环节无风险")
        return risks
    except Exception as e:
        logger.error(f"  解冻风险判定异常: {e}")
        return []


# ============================================================
# Step 5: 风险判定 — Token（v8 更新：使用 parse_token_risk_results 解析）
# ============================================================
def parse_token_risk_results(outputs: Dict[str, Any]) -> List[Dict[str, Any]]:
    """
    v8 新增：解析 Token 风险工作流输出（参考 2783188791 的 token_risk.py）

    解析 outputs.text 中的 group_id 和 {result:"xxx", reason:"yyy"} 对

    返回: list of dict [{"result": "xxx", "reason": "yyy"}, ...]
    """
    risks = []
    candidates = [value.strip() for value in outputs.values() if isinstance(value, str) and value.strip()]
    text = max(candidates, key=len, default="")
    if not text or not isinstance(text, str) or not text.strip():
        return risks

    # 尝试解析为 JSON list
    try:
        parsed = json.loads(text)
        if isinstance(parsed, list):
            for item in parsed:
                if isinstance(item, dict):
                    risks.append({"result": str(item.get("result", "")), "reason": str(item.get("reason", ""))})
            return risks
    except json.JSONDecodeError:
        pass

    # 尝试解析为 JSON dict
    try:
        parsed = json.loads(text)
        if isinstance(parsed, dict) and 'result' in parsed:
            risks.append({"result": str(parsed.get("result", "")), "reason": str(parsed.get("reason", ""))})
        return risks
    except json.JSONDecodeError:
        pass

    # 正则兜底：提取所有 {result:"xxx", reason:"yyy"} 对
    items = re.findall(r'\{result[:"\s]+([^"}]+)[^}]*reason[:"\s]+([^"}]+)\}', text)
    if items:
        for res_val, res_reason in items:
            risks.append({"result": res_val.strip(), "reason": res_reason.strip()})
    else:
        # 如果正则没匹配到，整体作为一条风险
        risks.append({"result": "Token风险", "reason": text[:500]})

    return risks


def step_risk_token(group_id: str, platform_app_partner: str, label: str, dt: str) -> List[Dict[str, Any]]:
    """风险判定-Token（v8：使用 parse_token_risk_results 解析，is_risk_group 固定传 "1"）"""
    try:
        inputs = {"dt": dt, "group_id": group_id, "label": label, "platform_app_partner": platform_app_partner, "is_risk_group": "1"}
        result = call_arceus_workflow(API_KEY_RISK_TOKEN, inputs, "风险判定-Token", user="zhanglei288")
        if result["status"] != "succeeded":
            logger.warning(f"  Token判定工作流失败: {result.get('error', '')}")
            return []
        risks = parse_token_risk_results(result["outputs"])
        for r in risks:
            logger.info(f"  Token风险: {r['result']} - {r['reason'][:200]}")
        if not risks:
            logger.info("  Token环节无风险")
        return risks
    except Exception as e:
        logger.error(f"  Token风险判定异常: {e}")
        return []


# ============================================================
# === v7 新增：处罚结论判定 ===
# ============================================================
def determine_penalty(
    register_risks: List[Dict[str, Any]],
    login_risks: List[Dict[str, Any]],
    unfreeze_risks: List[Dict[str, Any]],
    token_risks: List[Dict[str, Any]],
) -> Dict[str, str]:
    """
    根据四个环节的风险判定结果，判定处罚结论。
    """
    def _contains_risk(risk_list: List[Dict[str, Any]], keywords: List[str]) -> List[str]:
        matched = []
        for r in risk_list:
            text = str(r.get("result", "")) # + str(r.get("reason", ""))
            for kw in keywords:
                if kw in text:
                    matched.append(kw)
                    break  # 一条结果只记一个关键词
        return matched

    # --- 规则 (1): 冻结 ---
    freeze_keywords_register = ["批量注册"]
    freeze_keywords_login = ["黑产自持", "账号转卖"]
    freeze_from_register = _contains_risk(register_risks, freeze_keywords_register)
    freeze_from_login = _contains_risk(login_risks, freeze_keywords_login)

    if freeze_from_register or freeze_from_login:
        risk_types = []
        reason_parts = []
        if freeze_from_register:
            risk_types.append("批量注册")
            reason_parts.append("注册环节检测到批量注册风险")
        if freeze_from_login:
            risk_types.extend(freeze_from_login)
            reason_parts.append(f"登录环节检测到{'、'.join(freeze_from_login)}风险")
        return {
            "penalty": "冻结",
            "risk_types": "、".join(set(risk_types)),
            "reason": "，".join(reason_parts),
        }

    # --- 规则 (2): 冻结加禁止解冻 ---
    unfreeze_keywords = ["批量解冻"]
    unfreeze_matched = _contains_risk(unfreeze_risks, unfreeze_keywords)
    if unfreeze_matched:
        return {
            "penalty": "冻结加禁止解冻",
            "risk_types": "批量解冻",
            "reason": "解冻环节检测到批量解冻风险",
        }

    # --- 规则 (3): 踢登 ---
    # 注意：Token 工作流输出的 result 形如 "token跨操作系统风险"（"风险"结尾），
    # 关键词需为其子串，否则永远匹配不上
    kick_keywords = [
        "微信号的租借",
        "账号租借",
        "批量登录",
        "黑产自持手机号/wx资源",
        "众包",
        "token跨设备型号",
        "token跨操作系统",
        "token跨App",
        "token跨渠道",
        "同token对应多操作系统",
        "tokenOS降级",
        "失效token作弊",
        "token伪造",
    ]
    kick_from_login = _contains_risk(login_risks, kick_keywords)
    kick_from_token = _contains_risk(token_risks, kick_keywords)

    if kick_from_login or kick_from_token:
        risk_types = []
        reason_parts = []
        if kick_from_login:
            risk_types.extend(kick_from_login)
            reason_parts.append("登录环节检测到" + "、".join(kick_from_login) + "风险")
        if kick_from_token:
            risk_types.extend(kick_from_token)
            reason_parts.append("Token环节检测到" + "、".join(kick_from_token) + "风险")
        return {
            "penalty": "踢登",
            "risk_types": "、".join(set(risk_types)),
            "reason": "，".join(reason_parts),
        }

    # --- 规则 (4): 无风险 ---
    return {
        "penalty": "不处置",
        "risk_types": "无风险",
        "reason": "四个风险判定环节均无风险",
    }


# ============================================================
# Step 6: 风险汇总
# ============================================================
def step_summarize_risks(group_id: str, all_risks: List[Dict[str, Any]]) -> str:
    """汇总所有有风险的结果，格式：{注册环节-xxx风险，详情：{xxx}，登录环节-xxx风险，详情：{xxx}}"""
    if not all_risks:
        summary = f"{group_id} 风险汇总：无风险"
        logger.info(summary)
        return summary

    risk_by_type = {}
    for r in all_risks:
        rtype = r.get("type", "未知")
        risk_by_type.setdefault(rtype, []).append(r)

    parts = []
    for t in ["注册", "登录", "解冻", "Token"]:
        if t in risk_by_type:
            for item in risk_by_type[t]:
                result_val = item.get("result", "")
                reason = item.get("reason", "")
                result_txt = "无风险" if "无风险" in result_val else f"{result_val}风险"
                if reason:
                    parts.append(f"{t}环节-{result_txt}，详情：{{{reason}}} ")
                else:
                    parts.append(f"{t}环节-{result_txt}，详情：{{}} ")

    summary = "，\n".join(parts)
    logger.info(f"{group_id} 风险汇总：{summary}")
    return summary


# ============================================================
# Step 7: 创建提纯捞全任务（v7 修改：新增 action_type、result、reason 参数）
# ============================================================
def step_tichun_create(
    group_id: str,
    summary_text: str,
    action_type: str = "auto",
    result: str = "",
    reason: str = TICHUN_CREATE_REASON,
) -> Optional[str]:
    """
    创建提纯捞全任务。status=1 → 创建成功，返回 case_id；status=0 → 创建失败，返回 None
    """
    if "无风险" in action_type:
        # 无风险不创建提纯捞全任务
        logger.info("  无风险不创建提纯捞全任务")
        return None
    
    try:
        payload = {
            "group_id": group_id,
            "result": result[:200] if result else "",
            "action_type": action_type,
            "reason": reason[:2000] if reason else reason,
            "biz": TICHUN_BIZ,
        }
        resp = requests.post(TICHUN_CREATE_URL, json=payload, timeout=60)
        resp.raise_for_status()
        data = resp.json()
        logger.info(f"  提纯捞全创建响应: {json.dumps(data, ensure_ascii=False)}")

        if data.get("status") == 1:
            case_id = data.get("data", {}).get("case_id", "")
            message = data.get("message", "")
            logger.info(f"  提纯捞全创建成功: case_id={case_id}, message={message}")
            return case_id
        else:
            message = data.get("message", "未知错误")
            logger.warning(f"  提纯捞全创建失败: {message}")
            return None
    except Exception as e:
        logger.error(f"  提纯捞全创建异常: {e}")
        return None


# ============================================================
# Step 8: 查询提纯捞全任务状态
# ============================================================
def step_tichun_status_check(case_id: str) -> Dict[str, Any]:
    """循环查询提纯捞全任务状态，每30分钟一次，最多96次（48小时）"""
    logger.info(f"  开始查询提纯捞全任务状态，case_id={case_id}")
    for i in range(MAX_STATUS_CHECKS):
        try:
            payload = {"case_id": case_id, "biz": TICHUN_BIZ}
            resp = requests.post(TICHUN_STATUS_URL, json=payload, timeout=60)
            resp.raise_for_status()
            data = resp.json()

            case_task_status_msg = data.get("data", {}).get("case_task_status_msg", "")
            case_task_status_stage = data.get("data", {}).get("case_task_status_stage", "")

            logger.info(f"  提纯捞全状态: msg={case_task_status_msg}, stage={case_task_status_stage} ({i+1}/{MAX_STATUS_CHECKS})")

            if case_task_status_msg in ("SUCCESS", "FAILURE"):
                return {
                    "case_id": case_id,
                    "case_task_status_msg": case_task_status_msg,
                    "case_task_status_stage": case_task_status_stage,
                    "is_done": True,
                }
            elif case_task_status_msg == "RUNNING":
                logger.info(f"  任务进行中，{STATUS_CHECK_INTERVAL//60}分钟后再次查询...")
                time.sleep(STATUS_CHECK_INTERVAL)
            else:
                logger.warning(f"  未知状态: {case_task_status_msg}")
                time.sleep(STATUS_CHECK_INTERVAL)
        except Exception as e:
            logger.error(f"  查询状态异常: {e}")
            time.sleep(STATUS_CHECK_INTERVAL)

    return {
        "case_id": case_id,
        "case_task_status_msg": "TIMEOUT",
        "case_task_status_stage": "",
        "is_done": False,
    }


# ============================================================
# Step 9: 落表 — Hive 写入（v9 改动：字段对齐用户要求）
# ============================================================
def write_results_to_hive(results: List[Dict[str, Any]], dt: str, table_name: str):
    """
    将最终结果写入 Hive 表 ba_rc.app_account_ai_group_risk_pipeline_result

    落表字段（用户要求）：
    group_id, dt, 是否是团伙的判定结果和理由, 风险判定-注册环节输出结果和理由,
    风险判定-登录环节输出结果和理由, 风险判定-解冻环节输出结果和理由,
    风险判定-token环节输出结果和理由
    """
    if not results:
        logger.info("无结果需要落表")
        return
    try:
        from pyspark.sql.types import StructType, StructField, StringType
        fields = [
            "group_id", "dt",
            "is_risk_group", "is_risk_group_reason",
            "register_result", "register_reason",
            "login_result", "login_reason",
            "unfreeze_result", "unfreeze_reason",
            "token_result", "token_reason",
        ]
        schema = StructType([StructField(f, StringType(), True) for f in fields])
        rows = []
        for r in results:
            rows.append((
                r.get("group_id", ""),
                dt,
                r.get("is_risk_group", ""),
                r.get("is_risk_group_reason", r.get("penalty_reason", "")),  # is_risk_group 的判定理由用 penalty_reason（非团伙时）
                r.get("register_result", ""),
                r.get("register_reason", ""),
                r.get("login_result", ""),
                r.get("login_reason", ""),
                r.get("unfreeze_result", ""),
                r.get("unfreeze_reason", ""),
                r.get("token_result", ""),
                r.get("token_reason", ""),
            ))
        df = spark.createDataFrame(rows, schema)
        df.createOrReplaceTempView("tmp_risk_pipeline_result")
        spark.sql("SET hive.exec.dynamic.partition=true")
        spark.sql("SET hive.exec.dynamic.partition.mode=nonstrict")
        spark.sql(f"""
            INSERT INTO TABLE {table_name} PARTITION (dt)
            SELECT group_id, dt,
                   is_risk_group, is_risk_group_reason,
                   register_result, register_reason,
                   login_result, login_reason,
                   unfreeze_result, unfreeze_reason,
                   token_result, token_reason
            FROM tmp_risk_pipeline_result
        """)
        logger.info(f"  已落表 {table_name}，共 {len(results)} 条")
    except Exception as e:
        logger.error(f"  落表异常: {e}")


# ============================================================
# 单组处理流程
# ============================================================
def process_single_group(group_id: str, platform_app_partner: str, label: str, dt: str) -> Dict[str, Any]:
    """处理单个 group_id 的完整流水线"""
    logger.info(f"\n{'='*60}")
    logger.info(f"处理 group_id: {group_id}")

    # Step 1: 团伙判定
    try:
        is_group_result = step_is_group(group_id, platform_app_partner, label, dt)
        is_risk_group = is_group_result.get("is_risk_group", "-1")
        is_missed = is_group_result.get("is_missed", "")

        if is_risk_group == "-1":
            return {
                "group_id": group_id,
                "platform_app_partner": platform_app_partner,
                "label": label,
                "is_risk_group": "-1",
                "is_missed": is_missed,
                "penalty": "",
                "risk_types": "",
                "penalty_reason": is_group_result.get("reason", ""),
                "risk_summary": "",
                "tichun_case_id": "",
                "tichun_status_msg": "",
                "tichun_status_stage": "",
                # v9 新增：各环节结果和理由，用于落表
                "is_risk_group_reason": is_group_result.get("reason", ""),
                "register_result": "",
                "register_reason": "",
                "login_result": "",
                "login_reason": "",
                "unfreeze_result": "",
                "unfreeze_reason": "",
                "token_result": "",
                "token_reason": "",
                "dt": dt,
            }

        # 非团伙 → 直接返回（v9 新增：补充落表字段）
        if is_risk_group == "0":
            logger.info(f"  group_id={group_id} 不是团伙，跳过后续步骤")
            return {
                "group_id": group_id,
                "platform_app_partner": platform_app_partner,
                "label": label,
                "is_risk_group": "0",
                "is_missed": is_missed,
                "penalty": "无风险（非团伙）",
                "risk_types": "",
                "penalty_reason": is_group_result.get("reason", ""),
                "risk_summary": "非团伙，无需风险判定",
                "tichun_case_id": "",
                "tichun_status_msg": "",
                "tichun_status_stage": "",
                # v9 新增：各环节结果和理由，用于落表（非团伙时均为空）
                "is_risk_group_reason": is_group_result.get("reason", ""),
                "register_result": "",
                "register_reason": "",
                "login_result": "",
                "login_reason": "",
                "unfreeze_result": "",
                "unfreeze_reason": "",
                "token_result": "",
                "token_reason": "",
                "dt": dt,
            }
    except Exception as e:
        logger.error(f"  团伙判定异常: {e}")
        return {
            "group_id": group_id,
            "platform_app_partner": platform_app_partner,
            "label": label,
            "is_risk_group": "-1",
            "is_missed": "",
            "penalty": "",
            "risk_types": "",
            "penalty_reason": f"团伙判定异常: {e}",
            "risk_summary": "",
            "tichun_case_id": "",
            "tichun_status_msg": "",
            "tichun_status_stage": "",
            # v9 新增：各环节结果和理由，用于落表
            "is_risk_group_reason": f"团伙判定异常: {e}",
            "register_result": "",
            "register_reason": "",
            "login_result": "",
            "login_reason": "",
            "unfreeze_result": "",
            "unfreeze_reason": "",
            "token_result": "",
            "token_reason": "",
            "dt": dt,
        }

    # Step 2-5: 风险判定（注册/登录/解冻/Token）
    register_risks = []
    login_risks = []
    unfreeze_risks = []
    token_risks = []
    all_risk_items = []

    # --- 并发执行四个风险判定环节 ---
    from concurrent.futures import ThreadPoolExecutor
    risk_futures = {}

    def _run_register():
        return step_risk_register(group_id, platform_app_partner, label, dt)

    def _run_login():
        return step_risk_login(group_id, platform_app_partner, label, dt)

    def _run_unfreeze():
        return step_risk_unfreeze(group_id, platform_app_partner, label, dt)

    def _run_token():
        return step_risk_token(group_id, platform_app_partner, label, dt)

    with ThreadPoolExecutor(max_workers=4) as executor:
        risk_futures[executor.submit(_run_register)] = ("注册", "register")
        risk_futures[executor.submit(_run_login)] = ("登录", "login")
        risk_futures[executor.submit(_run_unfreeze)] = ("解冻", "unfreeze")
        risk_futures[executor.submit(_run_token)] = ("Token", "token")

        for future, (name, var_name) in risk_futures.items():
            try:
                risks = future.result()
                if var_name == "register":
                    register_risks = risks
                elif var_name == "login":
                    login_risks = risks
                elif var_name == "unfreeze":
                    unfreeze_risks = risks
                elif var_name == "token":
                    token_risks = risks
                for r in risks:
                    r["type"] = name
                    all_risk_items.append(r)
            except Exception as e:
                logger.error(f"  {name}判定异常: {e}")

    # Step 6: 处罚结论判定（在提纯捞全之前）
    penalty_info = determine_penalty(register_risks, login_risks, unfreeze_risks, token_risks)
    penalty = "不处置" if "不处置" in penalty_info["penalty"] or "无风险" in penalty_info["penalty"] else penalty_info["penalty"]
    risk_types = penalty_info["risk_types"]
    penalty_reason = penalty_info["reason"]

    # Step 7: 风险汇总
    summary_text = step_summarize_risks(group_id, all_risk_items)

    # Step 8: 创建提纯捞全任务
    case_id = None
    try:
        logger.info(f"  创建提纯捞全任务参数: action_type={penalty}, result={risk_types}, reason={summary_text[:200]}")
        case_id = step_tichun_create(
            group_id=group_id,
            summary_text=summary_text,
            action_type=penalty,
            result=risk_types,
            reason=summary_text,  # <--- 修正：reason 传的是所有有风险结果的汇总，不是处罚原因摘要
        )
    except Exception as e:
        logger.error(f"  创建提纯捞全任务异常: {e}")

    # Step 9: 查询提纯捞全任务状态
    tichun_status_msg = ""
    tichun_status_stage = ""
    if case_id:
        try:
            status_info = step_tichun_status_check(case_id)
            tichun_status_msg = status_info.get("case_task_status_msg", "")
            tichun_status_stage = status_info.get("case_task_status_stage", "")
        except Exception as e:
            logger.error(f"  查询提纯捞全状态异常: {e}")

    def _format_risks(risk_list: List[Dict[str, Any]]) -> tuple:
        """将风险列表格式化为 (result, reason) 对（无风险时也返回"无风险"标记）"""
        if not risk_list:
            return ("无风险", "无风险")
        results = []
        reasons = []
        for r in risk_list:
            results.append(r.get("result", ""))
            reasons.append(r.get("reason", ""))
        return ("、".join(set(results)), "；".join(r for r in reasons if r))

    register_result, register_reason = _format_risks(register_risks)
    login_result, login_reason = _format_risks(login_risks)
    unfreeze_result, unfreeze_reason = _format_risks(unfreeze_risks)
    token_result, token_reason = _format_risks(token_risks)

    result = {
        "group_id": group_id,
        "platform_app_partner": platform_app_partner,
        "label": label,
        "is_risk_group": is_risk_group,
        "is_missed": is_missed,
        "penalty": penalty,
        "risk_types": risk_types,
        "penalty_reason": penalty_reason,
        "risk_summary": summary_text,
        "tichun_case_id": case_id or "",
        "tichun_status_msg": tichun_status_msg,
        "tichun_status_stage": tichun_status_stage,
        # v9 新增：各环节结果和理由，用于落表
        "is_risk_group_reason": is_group_result.get("reason", "") if is_risk_group == "1" else penalty_reason,
        "register_result": register_result,
        "register_reason": register_reason,
        "login_result": login_result,
        "login_reason": login_reason,
        "unfreeze_result": unfreeze_result,
        "unfreeze_reason": unfreeze_reason,
        "token_result": token_result,
        "token_reason": token_reason,
        "dt": dt,
    }

    logger.info(f"  group_id={group_id} 处理完成: is_risk_group={is_risk_group}, penalty={penalty}, case_id={case_id}")
    return result

# if __name__ == "__main__":
#     process_single_group(group_id='ce54117699505ee5cdb63c28da36b78c',label='week_end_signup_fpm', platform_app_partner='13_214_0', dt='20260906')

# ============================================================
# 主入口
# ============================================================
if __name__ == "__main__":
    # 读取参数（Jupyter 环境下 sys.argv 可能被 kernel 连接文件路径污染，过滤掉路径参数）
    _clean_args = [a for a in sys.argv[1:] if '/' not in a and '.json' not in a and '.py' not in a]
    dt='20260902'
    # dt = _clean_args[0] if len(_clean_args) > 0 else datetime.now().strftime("%Y%m%d")
    sample_pct = int(_clean_args[1]) if len(_clean_args) > 1 else 100
    max_groups = int(_clean_args[2]) if len(_clean_args) > 2 else None
    concurrency = int(os.environ.get("RISK_PIPELINE_CONCURRENCY", "1"))

    logger.info(f"\n{'='*60}")
    logger.info(f"风险事件排查流水线 v8 启动")
    logger.info(f"日期: {dt}, 采样: {sample_pct}%, 最大: {max_groups or '无限制'}, 并发: {concurrency}")

    # 读取 Hive 表：感知表出 group 清单；judge 表一次查询出团伙判定（建进程内缓存——
    # step_is_group 直接读缓存，不调 dify 工作流、零额外 Hive IO）
    try:
        spark.sql("SET hive.exec.dynamic.partition=true")
        spark.sql("SET hive.exec.dynamic.partition.mode=nonstrict")
        df = spark.sql(f"""
            SELECT group_id, max(platform_app_partner) AS platform_app_partner, max(label) AS label
            FROM {HIVE_TABLE}
            WHERE dt = '{dt}'
              AND group_id IS NOT NULL AND group_id != ''
              AND risk_level != '9'
            GROUP BY group_id
        """)
        records = [{"group_id": r["group_id"], "platform_app_partner": r["platform_app_partner"], "label": r["label"]} for r in df.collect()]
        jdf = spark.sql(f"""
            SELECT group_id, is_risk_group, reason, is_missed
            FROM {JUDGE_TABLE}
            WHERE dt = '{dt}'
        """)
        for r in jdf.collect():
            _PERCEPTION_CACHE[r["group_id"]] = {
                "is_risk_group": "1" if str(r["is_risk_group"]) == "1" else "0",
                "reason": str(r["reason"] or ""),
                "is_missed": "1" if str(r["is_missed"]) == "1" else "0",
            }
        logger.info(f"团伙判定表缓存: {len(_PERCEPTION_CACHE)} 个 group")
    except Exception as e:
        logger.error(f"读取 Hive 表失败: {e}")
        records = []

    logger.info(f"共读取 {len(records)} 条记录")

    if not records:
        logger.warning(f"日期 {dt} 无数据，流水线结束")

    # 去重
    seen = set()
    unique = []
    for r in records:
        gid = r["group_id"]
        if gid not in seen:
            seen.add(gid)
            unique.append(r)
    total = len(unique)
    logger.info(f"去重后共 {total} 个 group_id")

    # 随机采样
    if sample_pct < 100:
        random.shuffle(unique)
        sample_count = max(1, int(total * sample_pct / 100))
        unique = unique[:sample_count]
        logger.info(f"随机采样 {sample_pct}%，实际处理 {len(unique)} 个（共 {total} 个）")

    # 最大条数
    if max_groups and len(unique) > max_groups:
        random.shuffle(unique)
        unique = unique[:max_groups]
        logger.info(f"截取前 {max_groups} 个 group_id（共 {total} 个）")

    # ===== 并发处理模式 =====
    final_results = []
    processed_count = 0
    failed_count = 0

    if concurrency > 1:
        logger.info(f"\n{'='*60}")
        logger.info(f"并发模式启动，最大并发数: {concurrency}")

        with ThreadPoolExecutor(max_workers=concurrency) as executor:
            futures = {}
            for record in unique:
                if len(futures) >= concurrency:
                    break
                gid = record["group_id"]
                future = executor.submit(
                    process_single_group,
                    gid,
                    record["platform_app_partner"],
                    record["label"],
                    dt,
                )
                futures[future] = gid
                logger.info(f"已提交 group_id={gid}（当前并发: {len(futures)}/{concurrency}）")

            submitted_idx = min(concurrency, len(unique))

            for future in as_completed(futures):
                gid = futures[future]
                try:
                    result = future.result()
                    final_results.append(result)
                    processed_count += 1
                    logger.info(f"\n{'='*40}")
                    logger.info(f"✅ group_id={gid} 处理完成 ({processed_count}/{len(unique)})")
                    logger.info(json.dumps(result, ensure_ascii=False, indent=2))
                except Exception as e:
                    failed_count += 1
                    logger.error(f"group_id={gid} 处理异常: {e}")
                    logger.error(traceback.format_exc())
                    final_results.append({"group_id": gid, "错误": str(e)})

                if submitted_idx < len(unique):
                    next_record = unique[submitted_idx]
                    next_gid = next_record["group_id"]
                    next_future = executor.submit(
                        process_single_group,
                        next_gid,
                        next_record["platform_app_partner"],
                        next_record["label"],
                        dt,
                    )
                    futures[next_future] = next_gid
                    submitted_idx += 1
                    logger.info(f"已补充提交 group_id={next_gid}（总提交: {submitted_idx}/{len(unique)}）")
    else:
        logger.info(f"\n{'='*60}")
        logger.info("串行模式运行")
        for record in unique:
            gid = record["group_id"]
            logger.info(f"\n{'='*60}")
            logger.info(f"处理 group_id: {gid}")
            try:
                result = process_single_group(gid, record["platform_app_partner"], record["label"], dt)
                final_results.append(result)
                processed_count += 1
                logger.info(f"group_id={gid} 处理完成: {json.dumps(result, ensure_ascii=False, indent=2)}")
            except Exception as e:
                failed_count += 1
                logger.error(f"  group_id={gid} 处理异常: {e}")
                logger.error(traceback.format_exc())
                final_results.append({"group_id": gid, "错误": str(e)})

    # 输出结果到文件
    try:
        with open(OUTPUT_FILE, "w", encoding="utf-8") as f:
            json.dump(final_results, f, ensure_ascii=False, indent=2)
        logger.info(f"结果已写入: {OUTPUT_FILE}")
    except Exception as e:
        logger.error(f"写入结果文件失败: {e}")

    # ===== 落表（v8：包括 is_missed 字段） =====
    if final_results:
        try:
            write_results_to_hive(final_results, dt, RISK_RESULT_TABLE)
        except Exception as e:
            logger.error(f"落表异常: {e}")

    logger.info(f"\n{'='*60}")
    logger.info(f"===== 流水线完成，共处理 {len(unique)} 个 group_id (成功: {processed_count}, 失败: {failed_count}) =====")
