"""
团伙处置调度器——sceneKey=accountsec_agent_group_punish_check。
pending → submitted（提交画布）→ 轮询 canvas 状态 → done/failed。
"""
from __future__ import annotations

from apscheduler.schedulers.background import BackgroundScheduler

import punish_check_store as store
from client.punish_check_client import PunishCheckClient, FAILED
from logger import sys_log


class PunishCheckScheduler:
    def __init__(self):
        from config import get_config
        cfg = get_config().canvas_scheduler
        self.interval = cfg.poll_interval_seconds
        self._sched: BackgroundScheduler | None = None

    def start(self):
        if self._sched is not None:
            return
        self._sched = BackgroundScheduler(timezone="Asia/Shanghai")
        self._sched.add_job(self._poll_all, "interval", seconds=self.interval, id="punish_check_poll",
                            max_instances=1, coalesce=True, misfire_grace_time=10)
        self._sched.start()
        sys_log("info", f"[PunishCheckScheduler] started, interval={self.interval}s")

    def shutdown(self):
        if self._sched is not None:
            self._sched.shutdown(wait=False)
            self._sched = None
            sys_log("info", "[PunishCheckScheduler] shutdown")

    def _poll_all(self):
        try:
            for job in store.list_running():
                try:
                    self._advance(job)
                except Exception as e:
                    sys_log("warning", f"[PunishCheckScheduler] job={job.get('id')} advance error: {str(e)[:200]}")
        except Exception as e:
            sys_log("error", f"[PunishCheckScheduler] poll_all error: {str(e)[:200]}")

    def _advance(self, job: dict):
        if job["status"] == "pending":
            self._submit(job)
        elif job["status"] == "submitted":
            self._poll_canvas(job)

    def _submit(self, job: dict):
        jid = job["id"]
        # mlp 全局强限制：总开关 + 全局并发；priority=1 走加急通道（+10 独享槽）
        urgent = bool(((job.get("extra") or {}).get("priority"))
                      or str(job.get("priority") or "") not in ("", "0", "None"))
        from mlp_switch import mlp_can_submit
        if not mlp_can_submit("punish_check", urgent=urgent):
            return
        if not store.claim_for_submit(jid):
            return
        try:
            res = PunishCheckClient().submit(
                case_id=job["case_id"], combo_id=job["combo_id"],
                dt=job.get("dt") or "", check_info=int(job.get("check_info") or 0),
            )
            unique_key = res["unique_key"]
            try:
                store.update_extra(jid, {
                    "canvas_status": "SUBMITTED",
                    "start_canvas_request": res.get("request"),
                    "start_canvas_response": res.get("response"),
                })
            except Exception:
                pass
            store.update_status(jid, "submitted", unique_key=unique_key)
            sys_log("info", f"[PunishCheckScheduler] submitted job={jid} unique_key={unique_key}")
        except Exception as e:
            store.update_status(jid, "failed", error_message=str(e)[:500])
            sys_log("warning", f"[PunishCheckScheduler] submit failed job={jid}: {str(e)[:200]}")

    def _poll_canvas(self, job: dict):
        jid = job["id"]
        unique_key = job.get("unique_key") or ""
        if not unique_key or unique_key.startswith("pending_"):
            fresh = store.get_job(jid)
            unique_key = (fresh or {}).get("unique_key") or ""
            if not unique_key or unique_key.startswith("pending_"):
                store.update_status(jid, "failed", error_message="unique_key 为空（回查仍为空）")
                return
        try:
            res = PunishCheckClient().query_status(unique_key)
        except Exception as e:
            store.update_extra(jid, {"canvas_status": "UNKNOWN", "last_error": str(e)[:200]})
            return
        status = res["status"]
        store.update_extra(jid, {
            "canvas_status": status,
            "query_canvas_request": res.get("request"),
            "query_canvas_response": res.get("response"),
        })
        if status == "SUCCEEDED":
            store.update_status(jid, "done")
            sys_log("info", f"[PunishCheckScheduler] job done job={jid}")
        elif status in FAILED:
            store.update_status(jid, "failed", error_message=f"画布执行 {status}")
