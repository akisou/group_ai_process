#!/bin/sh
# ── 健康检查脚本 ───────────────────────────────────────────────────
# 容器内执行，访问本地 127.0.0.1:8010（外部主机名在容器内可能解析不了）
# 带重试：服务启动慢时多次尝试（Hulk 平台 checkRetry=10 × checkInterval=5s 兜底，
# 但脚本内部也重试 3 次避免单次 curl 超时误判）

PORT="${PORT:-8010}"
HOST="127.0.0.1:$PORT"

echo "check account_agent_dev service: $HOST"

for i in 1 2 3; do
    if curl -s -o /dev/null --max-time 5 "http://$HOST/" 2>/dev/null; then
        echo "check succeeded (attempt $i)"
        exit 0
    fi
    echo "attempt $i failed, retry..."
    sleep 2
done

echo "check failed"
exit 1
