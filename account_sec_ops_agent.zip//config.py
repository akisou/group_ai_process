"""
精简配置加载：读 config.yaml + 环境变量覆盖。
仅保留 account_agent_dev 平台必要段。
"""
from __future__ import annotations

import os
from functools import lru_cache

import yaml
from pydantic import BaseModel


class AppConfig(BaseModel):
    host: str = "0.0.0.0"
    port: int = 8010


class TalosConfig(BaseModel):
    endpoint: str = "https://talostwo.vip.sankuai.com"
    scene: str = "system"             # system=服务账号(账密)，mis=个人场景(MIS+session_id)
    username: str = "talos_account_sec"  # mis 场景=个人 MIS；system 场景=服务账号名
    password: str = ""                # mis 场景=文谍 session id；system 场景=服务账号密码


class MtsiCanvasConfig(BaseModel):
    start_url: str = "https://mtsi-clue.sankuai.com/api/case/autoCutLoss/offlineStartCanvasForAccount"
    status_url: str = "https://mtsi-clue.sankuai.com/api/case/autoCutLoss/offlineQueryCanvasStatusForAccount"
    scene_key: str = ""              # 产出 rule 的 pyspark 画布 sceneKey，必填
    mis_id: str = "wucheng17"        # CIBA 用户 MIS
    global_param_template: str = 'dt={dt} --case_id={case_id} --case_name={case_name}'
    cookie: str = ""                 # 已弃用（走 CIBA access-token）


class SsoConfig(BaseModel):
    rhino_ai_base: str = "https://reactmind.sankuai.com"
    mis: str = "wucheng17"           # CIBA 取票 MIS（图片代理等场景）
    session_secret_key: str = "change-me"


class SupabaseConfig(BaseModel):
    base_url: str = ""
    service_key: str = ""            # 敏感：环境变量 SUPABASE_SERVICE_KEY 或 config.local.yaml


class HiveTablesConfig(BaseModel):
    """8 张 Hive 表完整名（schema 变动时只改 config.yaml）"""
    validation_result: str = "ba_rc.acc_sec_gang_validation_result"
    rule_eval_result: str = "ba_rc.acc_sec_rule_eval_result"   # profiling 新版规则评估表（布尔列推导桥接）
    validation_charts: str = "ba_rc.acc_sec_gang_validation_charts"
    ts_daily: str = "ba_rc.acc_sec_gang_validation_ts_daily"   # 时序明细长表（天粒度三线+t0）
    candidate_predicates: str = "ba_rc.acc_sec_candidate_predicates"
    mining_process: str = "ba_rc.acc_sec_mining_process"
    recall_accounts: str = "ba_rc.acc_sec_gang_recall_accounts"
    case_info: str = "ba_rc.acc_sec_case_info"
    snapshot_info: str = "ba_rc.acc_sec_snapshot_info"
    seed_split: str = "ba_rc.acc_sec_seed_split"
    final_rules: str = "ba_rc.acc_sec_gang_final_rules"


class CanvasSchedulerConfig(BaseModel):
    enabled: bool = True
    poll_interval_seconds: int = 30
    canvas_pool_limit: int = 20
    preprocess_pool_limit: int = 20      # 预处理画布并发池（与 laoquan 分开计数）
    verify_sql_template: str = (
        "SELECT count(*) FROM ba_rc.acc_sec_gang_validation_result "
        "WHERE case_id='{case_id}' AND dt='{dt}'"
    )


class DataMonitorConfig(BaseModel):
    """数据监控页：关注的表，逐表查 dt/count 聚合。schema 变动加这里。"""
    tables: list = [
        {"key": "baseline_snapshot", "name": "Baseline快照", "table": "ba_rc.app_acc_sec_baseline_snapshot_set"},
        {"key": "baseline_users", "name": "Baseline用户", "table": "ba_rc.app_acc_sec_market_baseline_sample_ids"},
    ]


class LionConfig(BaseModel):
    """Lion 配置中心（部署时 lion-agent 注入，本地读不到走 config.local.yaml 兜底）"""
    enabled: bool = True
    appkey: str = "com.sankuai.accountsecurity.caseops.huilao"
    # Lion 配置 key 映射（和 Lion 后台配的 key 名一致）
    supabase_service_key_key: str = "SUPABASE_SERVICE_KEY"
    supabase_base_url_key: str = "SUPABASE_BASE_URL"
    talos_username_key: str = "TALOS_USERNAME"
    talos_password_key: str = "TALOS_PASSWORD"
    catx_api_key_key: str = "CATX_API_KEY"


class InjuryEvalConfig(BaseModel):
    """误伤评估调度（Step6）。auto_submit=False 时暂停自动提交画布（pending 任务保持等待）。"""
    auto_submit: bool = False


class CatXConfig(BaseModel):
    """CatX（CatPaw Managed Agents）规则判定 Agent。key 走 config.local.yaml 不进 git。"""
    api_key: str = ""
    agent_id: str = ""
    environment_id: str = ""


class S3UploadConfig(BaseModel):
    """S3plus 对象存储图片上传（时序折线图等）。
    auth=kms 同反爬（appkey 走 KMS agent 透明密钥，需部署环境支持）；
    auth=ak 用 access_key/secret_key（本地通用）。凭证走 config.local.yaml 不进 git。"""
    enabled: bool = False
    auth: str = "kms"
    endpoint: str = "msstest.vip.sankuai.com"
    appkey: str = ""
    access_key: str = ""
    secret_key: str = ""
    bucket: str = ""
    image_prefix: str = "rule_agent"


class MlpSubmitConfig(BaseModel):
    """mlp 画布提交总开关。False 时所有画布调度器（laoquan/预处理/误伤评估/团伙处置）
    暂停提交新任务——已在跑的继续轮询到终态，pending 的保持等待，开关打开后自动继续。"""
    enabled: bool = True


class PipelineConfig(BaseModel):
    """风险事件排查流水线（移植自 pipline/agent_pipline v9；团伙判定已改读感知表不调 dify）"""
    enabled: bool = True
    # Arceus 工作流 API key（dify 应用级；团伙判定不再调用，key 移除）
    api_key_risk_register: str = "app-JjkDJgCgwzTatAfdVcoZol3N"
    api_key_risk_login: str = "app-UkQm0gWHvqlguysfhHxDAUzJ"
    api_key_risk_unfreeze: str = "app-lodpO6ChqH27nLudUAPIxhdK"
    api_key_risk_token: str = "app-Y0T7D7sobWSkOsQzODhwPvCt"
    # 工作流 user 标识（计费/审计归属）
    user_risk_register: str = "haoyiran02"
    user_risk_login: str = "wuxiaonan05"
    user_risk_unfreeze: str = "haoyiran02"
    user_risk_token: str = "zhanglei288"
    # 调度
    poll_interval_seconds: int = 15        # 调度器轮询间隔
    max_concurrent_jobs: int = 4           # 同时处理的 group 数（原脚本 RISK_PIPELINE_CONCURRENCY=4）
    tichun_poll_interval_seconds: int = 1800  # 提纯捞全状态轮询间隔（原 30min）
    tichun_max_checks: int = 96            # 提纯捞全最多轮询次数（96×30min=48h）
    # 每日定时启动（2026-09-20 用户定）：每天 07:00 自动启动 dt=昨天-1（即 dt-2）的流水线
    daily_start_enabled: bool = True
    daily_start_hour: int = 7             # 启动时刻（时）
    daily_start_minute: int = 0           # 启动时刻（分）
    daily_start_dt_offset_days: int = 2   # dt = 今天 - offset（处理两天前的团伙）
    # Hive 表
    perception_table: str = "ba_rc.app_account_risk_group_perception_result_dt"   # 输入：感知表（group 清单）
    judge_table: str = "ba_rc.app_account_agent_risk_group_judge_d"              # 团伙判定表（is_risk_group/reason/is_missed 来源）
    is_group_table: str = "ba_rc.app_account_risk_group_is_group_result_dt"       # 落表：团伙判定
    result_table: str = "ba_rc.app_account_ai_group_risk_pipeline_result"         # 落表：最终结果
    tichun_biz: str = "acc_sec_agent_pipline"


class Settings(BaseModel):
    app: AppConfig = AppConfig()
    talos: TalosConfig = TalosConfig()
    mtsi_canvas: MtsiCanvasConfig = MtsiCanvasConfig()
    sso: SsoConfig = SsoConfig()
    supabase: SupabaseConfig = SupabaseConfig()
    hive_tables: HiveTablesConfig = HiveTablesConfig()
    canvas_scheduler: CanvasSchedulerConfig = CanvasSchedulerConfig()
    lion: LionConfig = LionConfig()
    data_monitors: DataMonitorConfig = DataMonitorConfig()
    pipeline: PipelineConfig = PipelineConfig()
    injury_eval: InjuryEvalConfig = InjuryEvalConfig()
    catx: CatXConfig = CatXConfig()
    s3_upload: S3UploadConfig = S3UploadConfig()
    mlp_submit: MlpSubmitConfig = MlpSubmitConfig()
    default_experiment: str = "with_mark"


_CONFIG_PATH = os.environ.get("ACCOUNT_AGENT_CONFIG", "config.yaml")
_LOCAL_PATH = os.environ.get("ACCOUNT_AGENT_LOCAL", "config.local.yaml")


def _deep_merge(base: dict, override: dict) -> dict:
    """override 深覆盖 base（仅嵌套 dict 递归，列表/标量直接替换）。"""
    for k, v in override.items():
        if k in base and isinstance(base[k], dict) and isinstance(v, dict):
            _deep_merge(base[k], v)
        else:
            base[k] = v
    return base


_lion_inited = False
_LION_AGENT_SOCK = "/opt/meituan/appdatas/lion-agent/lion-agent.sock"


def _lion_agent_available() -> bool:
    """检测 lion-agent 是否在跑（socket 存在）。本地无 agent 返回 False，避免 init 报噪音。"""
    return os.path.exists(_LION_AGENT_SOCK)


def init_lion():
    """初始化 pylion（main.py lifespan 调用一次）。本地无 lion-agent 静默跳过，走兜底。"""
    global _lion_inited
    if _lion_inited:
        return
    cfg = get_config()
    if not cfg.lion.enabled:
        return
    if not _lion_agent_available():
        # 本地/未装 lion-agent → 不 init，走 config.local.yaml/环境变量兜底
        return
    try:
        import pylion
        pylion.init(cfg.lion.appkey, init_log=False)
        _lion_inited = True
    except Exception as e:
        import logging
        logging.getLogger("account_agent").info(f"[Lion] init failed (fallback to env/local): {str(e)[:120]}")


def _lion_get(appkey: str, key: str) -> str | None:
    """从 Lion 读单个配置，失败返回 None。"""
    if not _lion_inited:
        return None
    try:
        import pylion
        return pylion.get_default_group_string(appkey, key)
    except Exception:
        return None


def _apply_lion(data: dict) -> None:
    """用 Lion 配置覆盖敏感字段（优先级最高）。本地无 lion-agent 则不覆盖。"""
    global _lion_inited
    lion_cfg = data.get("lion") or {}
    if not lion_cfg.get("enabled", True):
        return
    if not _lion_agent_available():
        return  # 本地无 lion-agent，走兜底
    appkey = lion_cfg.get("appkey", "com.sankuai.accountsecurity.caseops.huilao")
    sb_key_name = lion_cfg.get("supabase_service_key_key", "SUPABASE_SERVICE_KEY")
    sb_url_name = lion_cfg.get("supabase_base_url_key", "SUPABASE_BASE_URL")
    talos_user_name = lion_cfg.get("talos_username_key", "TALOS_USERNAME")
    talos_key_name = lion_cfg.get("talos_password_key", "TALOS_PASSWORD")
    if not _lion_inited:
        try:
            import pylion
            pylion.init(appkey, init_log=False)
            _lion_inited = True
        except Exception:
            return
    sb_key = _lion_get(appkey, sb_key_name)
    if sb_key:
        data.setdefault("supabase", {})["service_key"] = sb_key
    sb_url = _lion_get(appkey, sb_url_name)
    if sb_url:
        data.setdefault("supabase", {})["base_url"] = sb_url
    talos_user = _lion_get(appkey, talos_user_name)
    if talos_user:
        data.setdefault("talos", {})["username"] = talos_user
    talos_pass = _lion_get(appkey, talos_key_name)
    if talos_pass:
        data.setdefault("talos", {})["password"] = talos_pass
    catx_key_name = lion_cfg.get("catx_api_key_key", "CATX_API_KEY")
    catx_key = _lion_get(appkey, catx_key_name)
    if catx_key:
        data.setdefault("catx", {})["api_key"] = catx_key


@lru_cache(maxsize=1)
def get_config() -> Settings:
    data: dict = {}
    if os.path.exists(_CONFIG_PATH):
        with open(_CONFIG_PATH, "r", encoding="utf-8") as f:
            data = yaml.safe_load(f) or {}

    # config.local.yaml 覆盖（存敏感值，已在 .gitignore，不进版本库）
    if os.path.exists(_LOCAL_PATH):
        with open(_LOCAL_PATH, "r", encoding="utf-8") as f:
            local = yaml.safe_load(f) or {}
        if local:
            _deep_merge(data, local)

    # Lion 配置中心覆盖（优先级最高，部署时 lion-agent 注入；本地读不到走兜底）
    _apply_lion(data)

    # 环境变量覆盖（次高，.env 文件 / export）
    if talos_user := os.getenv("TALOS_USERNAME"):
        data.setdefault("talos", {})["username"] = talos_user
    if talos_pass := os.getenv("TALOS_PASSWORD"):
        data.setdefault("talos", {})["password"] = talos_pass
    if sb_key := os.getenv("SUPABASE_SERVICE_KEY"):
        data.setdefault("supabase", {})["service_key"] = sb_key
    if sso_mis := os.getenv("SSO_MIS"):
        data.setdefault("sso", {})["mis"] = sso_mis
        data.setdefault("mtsi_canvas", {})["mis_id"] = sso_mis

    return Settings(**data)
