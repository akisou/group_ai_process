"""
风险事件排查流水线持久化层（Supabase）——pipeline_jobs 表。
移植自 pipline/agent_pipline（Jupyter 脚本 v9），服务化改造：每个 group_id 一行，
状态机断点续跑。

stage 流转：
  pending → is_group（团伙判定）→ risks（四环节风险判定并发）→ penalty（处罚结论）
  → tichun_create（建提纯捞全）→ tichun_poll（轮询提纯状态）→ done / failed
  非团伙（is_risk_group=0）→ 直接 done（记录判定，不进提纯）

各环节原始输出存 extra（JSONB），供排查 dify 判定依据。
"""
from __future__ import annotations

import json
import uuid
from datetime import datetime
from typing import Optional

from client.supabase_client import SupabaseClient
from logger import sys_log

_SCHEMA = """
CREATE TABLE IF NOT EXISTS pipeline_jobs (
  id TEXT PRIMARY KEY,
  dt TEXT NOT NULL,
  group_id TEXT NOT NULL,
  platform_app_partner TEXT,
  label TEXT,
  stage TEXT NOT NULL DEFAULT 'pending',   -- pending/is_group/risks/penalty/tichun_create/tichun_poll/done/failed
  status TEXT NOT NULL DEFAULT 'running',  -- running / done / failed
  batch_id TEXT,                            -- 同一次 pipeline/start 的批次
  concurrency INTEGER,                      -- 批次级并发数（空 = 全局默认）
  error_message TEXT,
  extra JSONB DEFAULT '{}'::jsonb,          -- 各环节输出（is_group/risks/penalty/tichun 等）
  created_at TEXT,
  updated_at TEXT
);
CREATE INDEX IF NOT EXISTS idx_pipe_batch ON pipeline_jobs(batch_id);
CREATE INDEX IF NOT EXISTS idx_pipe_group ON pipeline_jobs(group_id, dt);
CREATE INDEX IF NOT EXISTS idx_pipe_stage ON pipeline_jobs(stage, status);

CREATE TABLE IF NOT EXISTS pipeline_batches (
  batch_id TEXT PRIMARY KEY,
  dt TEXT NOT NULL,
  phase TEXT NOT NULL DEFAULT 'is_group',   -- is_group / risks / tichun / done（批次当前阶段）
  status TEXT NOT NULL DEFAULT 'running',   -- running / done
  concurrency INTEGER,
  created_at TEXT,
  updated_at TEXT
);
"""

_sb_client = None


def _is_no_penalty_action(action) -> bool:
    """无风险短路动作判断：兼容新口径「不处置」与旧口径「无风险」（旧数据 extra 残留）。"""
    a = str(action or "")
    return a == "无风险" or a == "不处置" or "无风险" in a


def _sb():
    global _sb_client
    if _sb_client is None:
        _sb_client = SupabaseClient()
    return _sb_client


def _now() -> str:
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")


def _row_to_dict(row) -> dict:
    if not row:
        return {}
    d = dict(row)
    extra = d.get("extra")
    if isinstance(extra, str):
        try:
            d["extra"] = json.loads(extra)
        except Exception:
            d["extra"] = {}
    elif extra is None:
        d["extra"] = {}
    return d


def ensure_schema():
    try:
        _sb().execute(_SCHEMA)
        sys_log("info", "[Pipeline] schema ensured (pipeline_jobs table)")
    except Exception as e:
        sys_log("error", f"[Pipeline] ensure_schema failed: {str(e)[:200]}")


def create_batch(dt: str, records: list, sample_pct: int, max_groups: Optional[int],
                 concurrency: Optional[int] = None) -> str:
    """一次流水线启动 = 一个 batch：批次行（阶段门控）+ 每条 group 一行 pipeline_job。返回 batch_id。"""
    batch_id = str(uuid.uuid4())
    now = _now()
    # 采样（与原脚本一致：shuffle 后截取）
    import random
    unique, seen = [], set()
    for r in records:
        if r.get("group_id") and r["group_id"] not in seen:
            seen.add(r["group_id"])
            unique.append(r)
    if sample_pct < 100:
        random.shuffle(unique)
        unique = unique[:max(1, int(len(unique) * sample_pct / 100))]
    if max_groups:
        random.shuffle(unique)
        unique = unique[:max_groups]
    _sb().execute(
        "INSERT INTO pipeline_batches (batch_id, dt, phase, status, concurrency, created_at, updated_at) "
        "VALUES ($1,$2,'is_group','running',$3,$4,$5)",
        [batch_id, dt, concurrency, now, now],
    )
    for r in unique:
        # 感知表团伙判定字段随 job 存 extra.perception（判定阶段直接读，不调 dify 不查 Hive）
        perception = None
        if r.get("is_risk_group") is not None:
            perception = {"is_risk_group": r["is_risk_group"],
                          "reason": r.get("reason") or "",
                          "is_missed": r.get("is_missed") or "0",
                          # 感知上下文（2026-09-22 用户定）：随 job 预存，建 case 时透传
                          # 到 flow extra —— 详情页零 Hive 直读
                          "items_str": str(r.get("items_str") or "")[:5000],
                          "risk_level": str(r.get("risk_level") or ""),
                          "perception_dt": str(dt)}
        _sb().execute(
            "INSERT INTO pipeline_jobs (id, dt, group_id, platform_app_partner, label, "
            "stage, status, batch_id, concurrency, extra, created_at, updated_at) "
            "VALUES ($1,$2,$3,$4,$5,'pending','running',$6,$7,$8,$9,$10)",
            [str(uuid.uuid4()), dt, r["group_id"], r.get("platform_app_partner") or "",
             r.get("label") or "", batch_id, concurrency,
             json.dumps({"perception": perception}, ensure_ascii=False) if perception else "{}",
             now, now],
        )
    sys_log("info", f"[Pipeline] batch={batch_id[:8]} dt={dt} 建任务 {len(unique)} 个"
                    f"（采样 {sample_pct}%，流水线模式·全局并发独立控制）")
    return batch_id


def create_manual_batch(records: list, concurrency: Optional[int] = None) -> str:
    """手工指定分析批次（感知表 risk_level='9' 的团伙）。
    记录可跨多个 dt 分区（每 group_id 取最新 dt），batch_id 行 dt 用批次创建日。
    已在 pipeline_jobs 中有未终态记录的 group_id 跳过（避免重复建批）。"""
    existing = {r["group_id"] for r in _sb().execute(
        "SELECT group_id FROM pipeline_jobs GROUP BY group_id")}
    now = _now()
    batch_id = str(uuid.uuid4())
    inserted = 0
    for r in records:
        gid = str(r.get("group_id") or "")
        if not gid or gid in existing:
            continue
        extra = json.dumps({
            "perception": {
                "is_risk_group": "1",  # 手工指定视为团伙，强制走完整流水线
                "reason": "手工指定分析",
                "is_missed": "0",
                "items_str": str(r.get("items_str") or "")[:5000],
                "risk_level": str(r.get("risk_level") or "9"),
                "perception_dt": str(r.get("dt") or "")
            }
        }, ensure_ascii=False)
        _sb().execute(
            "INSERT INTO pipeline_jobs (id, dt, group_id, platform_app_partner, label, "
            "stage, status, batch_id, concurrency, extra, created_at, updated_at) "
            "VALUES ($1::uuid, $2, $3, $4, $5, "
            "'is_group', 'running', $6::uuid, $7, $8::jsonb, $9, $9)",
            [str(uuid.uuid4()), str(r.get("dt") or now[:10].replace("-", "")), gid,
             str(r.get("platform_app_partner") or ""), str(r.get("label") or ""),
             batch_id, concurrency, extra, now])
        inserted += 1
    if inserted == 0:
        sys_log("warning", f"[Pipeline] 手工批次 {batch_id[:8]} 无新增团伙（全部已存在）")
        return ""
    _sb().execute(
        "INSERT INTO pipeline_batches (batch_id, dt, phase, status, concurrency, created_at, updated_at) "
        "VALUES ($1::uuid, $2, 'is_group', 'running', $3, $4, $4)",
        [batch_id, now[:10].replace("-", ""), concurrency, now])
    sys_log("info", f"[Pipeline] 手工批次 {batch_id[:8]} 建任务 {inserted} 个")
    return batch_id


# ── 批次阶段操作 ──────────────────────────────────────────────────────────

def list_running_batches() -> list:
    rows = _sb().execute(
        "SELECT * FROM pipeline_batches WHERE status='running' ORDER BY created_at")
    return [dict(r) for r in rows]


def update_batch(batch_id: str, **fields) -> None:
    allowed = {"phase", "status"}
    sets, vals = ["updated_at=$1"], [_now()]
    idx = 2
    for k, v in fields.items():
        if k in allowed:
            sets.append(f"{k}=${idx}")
            vals.append(v)
            idx += 1
    vals.append(batch_id)
    _sb().execute(f"UPDATE pipeline_batches SET {','.join(sets)} WHERE batch_id=${idx}", vals)


def stop_batch(batch_id: str) -> dict:
    """停止批次：批次置 stopped，未终态 job 置 cancelled（error_message 标注）。
    调度器取件全部按 status='running' 过滤，cancelled 自动退出所有取件路径；
    在跑线程（≤并发数）自然跑完当前阶段后不再推进。先置批次再取消 job，
    避免 _check_batches_done 在中间态把批次判成 done。

    联动终止 flow：批次内 group 对应的全流程任务（flow_jobs，group_id 1:1 关联）
    同步 terminate——释放画布并发池占位，否则停止批次后残留 flow 继续占线程/排队。"""
    now = _now()
    _sb().execute(
        "UPDATE pipeline_batches SET phase='stopped', status='stopped', updated_at=$1 "
        "WHERE batch_id=$2 AND status='running'", [now, batch_id])
    rows = _sb().execute(
        "UPDATE pipeline_jobs SET status='cancelled', "
        "error_message='批次已停止（未跑完不再推进）', updated_at=$1 "
        "WHERE batch_id=$2 AND status='running' RETURNING id",
        [now, batch_id])
    # 联动：终止该批次所有 group 的 running flow（含预处理/捞全/误伤/处置子任务）
    flows_terminated = 0
    try:
        import flow_store
        group_rows = _sb().execute(
            "SELECT group_id FROM pipeline_jobs WHERE batch_id=$1", [batch_id])
        for gr in group_rows:
            gid = gr.get("group_id") or ""
            if not gid:
                continue
            frows = _sb().execute(
                "SELECT id FROM flow_jobs WHERE group_id=$1 AND status IN ('running','pending')",
                [gid])
            for fr in frows:
                try:
                    if flow_store.terminate_flow(fr["id"], reason="批次停止联动终止"):
                        flows_terminated += 1
                except Exception:
                    pass
    except Exception as e:
        sys_log("warning", f"[Pipeline] stop_batch flow 联动终止失败 batch={batch_id[:8]}: {str(e)[:150]}")
    return {"cancelled": len(rows), "flows_terminated": flows_terminated}


def list_by_batch_stages(batch_id: str, stages: tuple, limit: int = 50) -> list:
    """取批次内指定阶段的 job（updated_at 升序，公平推进）。"""
    in_list = ",".join(f"'{s}'" for s in stages)
    rows = _sb().execute(
        f"SELECT * FROM pipeline_jobs WHERE batch_id=$1 AND stage IN ({in_list}) "
        f"ORDER BY updated_at LIMIT $2", [batch_id, limit])
    return [_row_to_dict(r) for r in rows]


def count_by_batch_stages(batch_id: str, stages: tuple) -> int:
    in_list = ",".join(f"'{s}'" for s in stages)
    rows = _sb().execute(
        f"SELECT count(*) AS n FROM pipeline_jobs WHERE batch_id=$1 AND stage IN ({in_list})",
        [batch_id])
    return int(rows[0]["n"]) if rows else 0


def batch_stats(batch_id: str) -> dict:
    """批次统计——状态流程树（严格互斥口径：每个 job 归且只归一个主节点，主节点之和=总数）。

    主链节点（互斥完备，按优先级归位）：
      待团伙分析  status=running 且 stage IN (pending, is_group)
      无法判定    status=failed 且无判定结果
      非团伙      ig=0（短路，覆盖一切残留）
      定性失败    status=failed 且 ig=1 且无 action
      待团伙定性  status=running 且 stage IN (risks, penalty)
      无风险      ig=1 且 action=无风险（短路）
      有风险 → 提纯链路【当前位置】（互斥）：
        待提纯捞全    stage=tichun_create（case 未建或未过预处理）
        预处理中      flow 在 preprocess/snapshot running
        预处理失败    flow 在 preprocess/snapshot failed/terminated
        提纯捞全中    flow=laoquan running（或 tichun_poll 未 SUCCESS）
        提纯捞全失败  flow=laoquan failed/terminated
        提纯捞全完成  SUCCESS 标记或 flow 已过捞全（injury_eval/punish/done）
          其中 误伤评估完成 = flow=done（细分展示，含于捞全完成）
    里程碑累计（非互斥，单调递减）：预处理完成 ≥ 捞全完成 ≥ 误伤完成。
    关联键 group_id（不用 dt：团伙发现日与处理日不同）。一 group 多 case 取最新。
    """
    import json as _json
    # pipeline 维度
    rows = _sb().execute(
        "SELECT stage, count(*) AS n FROM pipeline_jobs WHERE batch_id=$1 GROUP BY stage", [batch_id])
    by_stage = {r["stage"]: int(r["n"]) for r in rows}

    # 全量 job 快照（维度：ig / action / case / SUCCESS / flow）
    jobs = _sb().execute(
        "SELECT id, group_id, stage, status, extra FROM pipeline_jobs WHERE batch_id=$1", [batch_id])
    flows = {}
    for f in _sb().execute(
            "SELECT group_id, stage, status FROM flow_jobs "
            "WHERE extra->>'biz'='acc_sec_agent_pipline' ORDER BY created_at"):
        flows[f["group_id"]] = (f["stage"], f["status"])

    N = {k: 0 for k in ("awaiting_is_group", "judge_failed", "not_gangs", "qual_failed",
                         "awaiting_risks", "no_risk", "queue_tichun", "pre_running",
                         "pre_failed", "laoquan_running", "laoquan_failed",
                         "tichun_done", "injury_done", "unknown_action", "cancelled",
                         "intercepted")}
    risk = {}      # 团伙定性细分（risk_types 多值拆计）
    pen = {}       # 处置动作细分
    pre_done_total = 0  # 里程碑累计

    def _norm_ig(ex):
        ig = ex.get("is_group") or {}
        if isinstance(ig, str):
            try: ig = _json.loads(ig)
            except Exception: ig = {}
        return ig.get("is_risk_group")

    def _norm_pn(ex):
        pn = ex.get("penalty")
        if isinstance(pn, str):
            # 老格式字符串（如"无风险（非团伙）"）按字面处置动作处理
            return {"penalty": pn} if pn and "非团伙" not in pn else {}
        return pn if isinstance(pn, dict) else {}

    for j in jobs:
        ex = j["extra"] if isinstance(j["extra"], dict) else _json.loads(j["extra"] or "{}")
        igv = _norm_ig(ex)
        pn = _norm_pn(ex)
        action = pn.get("penalty")
        status, stage = j["status"], j["stage"]

        if status == "cancelled":
            N["cancelled"] += 1; continue
        if status == "running" and stage in ("pending", "is_group"):
            N["awaiting_is_group"] += 1; continue
        if status == "failed" and igv is None:
            N["judge_failed"] += 1; continue
        if igv == "0":
            N["not_gangs"] += 1; continue
        if igv != "1":
            # 无判定结果且非上述状态（数据异常）→ 归无法判定
            N["judge_failed"] += 1; continue
        # —— 以下 ig=1（团伙）——
        if action:
            if pn.get("risk_types"):
                for part in str(pn["risk_types"]).replace("，", "、").split("、"):
                    part = part.strip()
                    if part:
                        risk[part] = risk.get(part, 0) + 1
            # 处置动作口径统一：旧数据 penalty=无风险 展示为 不处置（与新口径对齐）
            pen_key = "不处置" if action == "无风险" else action
            pen[pen_key] = pen.get(pen_key, 0) + 1
        if status == "failed" and not action:
            N["qual_failed"] += 1; continue
        if status == "running" and stage in ("risks", "penalty"):
            N["awaiting_risks"] += 1; continue
        if action and ("未知" in action or "丢失" in action):
            N["unknown_action"] += 1  # 计数但继续归位提纯链路（case 已建是事实）
        if _is_no_penalty_action(action):
            N["no_risk"] += 1; continue
        # 拦截开关短路：有风险但命中拦截清单，不建 case 直接完成——终态（不进提纯链路，
        # 否则被归"待提纯捞全"虚高且永不收敛）
        if ex.get("skipped") and "拦截开关" in str(ex.get("skipped")):
            N["intercepted"] += 1; continue
        # —— 有风险：提纯链路当前位置（action 非无风险，或定性结论丢失但已按团伙推进）——
        fstage, fstatus = flows.get(j["group_id"], (None, None))
        if stage == "tichun_create" or (fstage is None and stage != "tichun_poll"):
            N["queue_tichun"] += 1; continue
        if fstage in ("preprocess", "snapshot") and fstatus == "failed":
            N["pre_failed"] += 1; continue
        if fstage in ("preprocess", "snapshot"):
            N["pre_running"] += 1; continue
        if fstage == "laoquan" and fstatus in ("failed", "terminated"):
            N["laoquan_failed"] += 1; continue
        # 捞全完成判定：SUCCESS 标记 或 flow 已过捞全
        done_mark = ex.get("tichun_status_msg") == "SUCCESS" or fstage in ("injury_eval", "punish", "done")
        if not done_mark:
            N["laoquan_running"] += 1; continue
        N["tichun_done"] += 1
        if fstage == "done" and fstatus == "done":
            N["injury_done"] += 1

    # 里程碑累计（展示用，非互斥）：预处理完成 = 有风险中过了预处理/snapshot 的
    pre_done_total = N["laoquan_running"] + N["laoquan_failed"] + N["tichun_done"]
    batch = _sb().execute("SELECT * FROM pipeline_batches WHERE batch_id=$1", [batch_id])
    total = len(jobs)
    return {
        "phase": batch[0]["phase"] if batch else "unknown",
        "total": total,
        # 主链（互斥，和=total）
        "awaiting_is_group": N["awaiting_is_group"],
        "judge_failed": N["judge_failed"],
        "not_gangs": N["not_gangs"],
        "gangs": sum(1 for j in jobs
                     if _norm_ig(j["extra"] if isinstance(j["extra"], dict) else {}) == "1"),
        "awaiting_risks": N["awaiting_risks"],
        "qual_failed": N["qual_failed"],
        "no_risk": N["no_risk"],
        "unknown_action": N["unknown_action"],   # 无法定性（结论丢失，按 case 推断有风险）
        "cancelled": N["cancelled"],             # 批次停止时未跑完的 job
        "intercepted": N["intercepted"],         # 拦截开关短路（有风险但不进提纯，终态）
        "risky_total": (N["queue_tichun"] + N["pre_running"] + N["pre_failed"]
                        + N["laoquan_running"] + N["laoquan_failed"] + N["tichun_done"]),
        "queue_tichun": N["queue_tichun"],
        "pre_running": N["pre_running"],
        "pre_failed": N["pre_failed"],
        "laoquan_running": N["laoquan_running"],
        "laoquan_failed": N["laoquan_failed"],
        "tichun_done": N["tichun_done"],
        # 细分与里程碑
        "qual_done": sum(pen.values()),
        "risk_breakdown": risk,
        "qual_breakdown": pen,
        "pre_done": pre_done_total,               # 里程碑：含捞全中/完成
        "injury_done": N["injury_done"],          # 含于 tichun_done
        "final_done": by_stage.get("done", 0),
        "failed": N["judge_failed"] + N["qual_failed"],
    }


def ensure_batch_rows() -> None:
    """迁移：pipeline_jobs 有批次而 pipeline_batches 无行（旧数据）→ 按job状态推断阶段补行。幂等。"""
    try:
        rows = _sb().execute(
            "SELECT DISTINCT batch_id FROM pipeline_jobs WHERE batch_id IS NOT NULL")
        for r in rows:
            bid = r["batch_id"]
            exists = _sb().execute(
                "SELECT 1 FROM pipeline_batches WHERE batch_id=$1", [bid])
            if exists:
                continue
            stats = _sb().execute(
                "SELECT stage, count(*) AS n FROM pipeline_jobs WHERE batch_id=$1 GROUP BY stage", [bid])
            stages = {s["stage"]: int(s["n"]) for s in stats}
            dt_row = _sb().execute(
                "SELECT dt FROM pipeline_jobs WHERE batch_id=$1 LIMIT 1", [bid])
            c_row = _sb().execute(
                "SELECT created_at FROM pipeline_jobs WHERE batch_id=$1 ORDER BY created_at LIMIT 1", [bid])
            dt = dt_row[0]["dt"] if dt_row else ""
            created = c_row[0]["created_at"] if c_row else _now()
            if stages.get("pending", 0) or stages.get("is_group", 0):
                phase, status = "is_group", "running"
            elif stages.get("risks", 0) or stages.get("penalty", 0):
                phase, status = "risks", "running"
            elif stages.get("tichun_create", 0) or stages.get("tichun_poll", 0):
                phase, status = "tichun", "running"
            else:
                phase, status = "done", "done"
            _sb().execute(
                "INSERT INTO pipeline_batches (batch_id, dt, phase, status, created_at, updated_at) "
                "VALUES ($1,$2,$3,$4,$5,$6)", [bid, dt, phase, status, created, _now()])
            sys_log("info", f"[Pipeline] 迁移批次 {bid[:8]} → phase={phase}")
    except Exception as e:
        sys_log("warning", f"[Pipeline] ensure_batch_rows error: {str(e)[:150]}")


def _job_filters(stage: Optional[str], dt: Optional[str],
                 is_group: Optional[str], penalty: Optional[str],
                 tichun: Optional[str] = None,
                 risk: Optional[str] = None,
                 q: Optional[str] = None) -> tuple:
    # 注：tree（批次状态流程树节点）筛选不在本函数——SQL 表达不了的桶（flow 联动）由
    # _tree_match 在 Python 侧过滤，见 list_by_batch 的 tree 参数。
    """公共筛选条件构造（键与批次状态流程树对齐）：
    stage 树节点键 / dt / is_group / penalty（处置动作）/ tichun（提纯状态）/ risk（团伙定性）/
    q（group_id 或 case_id 包含搜索）→ (where, vals)。"""
    where, vals = [], []
    # 注意：$1 保留给 batch_id（调用方 list_by_batch/count_jobs 会 insert 到参数首位），
    # 这里的编号从 $2 开始
    if q:
        vals.append(f"%{q}%")
        where.append(f"(group_id LIKE ${len(vals) + 1} OR extra->>'tichun_case_id' LIKE ${len(vals) + 1})")
    if stage:
        # 树节点 → SQL 条件（与 batch_stats 口径一致）
        stage_cond = {
            "is_group":     "stage IN ('pending','is_group')",
            "gangs":        "extra->'is_group'->>'is_risk_group'='1'",
            "not_gangs":    "extra->'is_group'->>'is_risk_group'='0'",
            "risks":        "stage IN ('risks','penalty')",
            "judge_failed": "status='failed' AND extra->'is_group'->>'is_risk_group' IS NULL",
            "qual_failed":  "status='failed' AND extra->'is_group'->>'is_risk_group' IS NOT NULL",
            "tichun":       "stage IN ('tichun_create','tichun_poll')",
            "done":         "stage IN ('done')",
            "failed":       "status='failed'",
        }
        if stage in stage_cond:
            where.append(stage_cond[stage])
        else:
            stages = (stage,)
            in_list = ",".join(f"'{s}'" for s in stages)
            where.append(f"stage IN ({in_list})")
    if dt:
        vals.append(dt)
        where.append(f"dt=${len(vals) + 1}")
    if is_group:
        vals.append(is_group)
        where.append(f"extra#>>'{{is_group,is_risk_group}}'=${len(vals) + 1}")
    if penalty:
        vals.append(penalty)
        where.append(f"extra#>>'{{penalty,penalty}}'=${len(vals) + 1}")
    if risk:
        # 团伙定性（risk_types 包含匹配：多值如"黑产自持、批量注册"任一命中即算）
        vals.append(f"%{risk}%")
        where.append(f"extra#>>'{{penalty,risk_types}}' LIKE ${len(vals) + 1}")
    if tichun:
        # 提纯链路细分（树节点口径）：需 join flow 判定的走 EXISTS 子查询
        tichun_cond = {
            # 待提纯捞全：case 已建排队（pipeline stage）
            "queue":    "stage='tichun_create'",
            # 预处理完成/预处理失败/捞全完成/捞全失败/误伤完成：flow 维度（group_id 关联最新 case）
            "pre_done": ("EXISTS (SELECT 1 FROM flow_jobs f WHERE f.group_id=pipeline_jobs.group_id "
                         "AND f.extra->>'biz'='acc_sec_agent_pipline' "
                         "AND f.stage IN ('laoquan','injury_eval','punish') AND f.status='running')"),
            "pre_fail": ("EXISTS (SELECT 1 FROM flow_jobs f WHERE f.group_id=pipeline_jobs.group_id "
                         "AND f.extra->>'biz'='acc_sec_agent_pipline' "
                         "AND f.stage IN ('preprocess','snapshot') AND f.status='failed')"),
            "lq_done":  "extra#>>'{tichun_status_msg}'='SUCCESS'",
            "lq_fail":  ("EXISTS (SELECT 1 FROM flow_jobs f WHERE f.group_id=pipeline_jobs.group_id "
                         "AND f.extra->>'biz'='acc_sec_agent_pipline' "
                         "AND f.stage='laoquan' AND f.status='failed')"),
            "inj_done": ("EXISTS (SELECT 1 FROM flow_jobs f WHERE f.group_id=pipeline_jobs.group_id "
                         "AND f.extra->>'biz'='acc_sec_agent_pipline' "
                         "AND f.stage='done' AND f.status='done')"),
        }
        if tichun in tichun_cond:
            where.append(tichun_cond[tichun])
        else:
            # 兼容旧键
            if tichun == "done":
                where.append("extra#>>'{tichun_status_msg}'='SUCCESS'")
            elif tichun == "running":
                where.append("extra#>>'{tichun_status_msg}' IS NULL AND extra->>'tichun_case_id' IS NOT NULL")
            elif tichun == "none":
                where.append("extra->>'tichun_case_id' IS NULL")
    return where, vals


TREE_FLOW_KEYS = ("pre_running", "pre_failed", "laoquan_running", "laoquan_failed",
                  "tichun_done", "injury_done")


def _tree_match(j: dict, tree: str, flows: dict) -> bool:
    """批次状态流程树节点匹配——条件链与 batch_stats 完全同源（同顺序同判断），
    保证筛出的行数 = 流程树上该节点数。返回 job 是否属于该树节点。"""
    ex = j["extra"] if isinstance(j.get("extra"), dict) else {}
    ig = ex.get("is_group") or {}
    if isinstance(ig, str):
        try:
            ig = json.loads(ig)
        except Exception:
            ig = {}
    pn = ex.get("penalty") or {}
    if isinstance(pn, str):
        pn = {"penalty": pn} if "非团伙" not in pn else {}
    status, stage = j.get("status"), j.get("stage")
    igv = ig.get("is_risk_group")
    action = pn.get("penalty")

    def bucket() -> str:
        # ↓ 与 batch_stats 逐行同构（键改为树节点键：awaiting_* 是 stats 内部名）
        if status == "cancelled":
            return "cancelled"
        if status == "running" and stage in ("pending", "is_group"):
            return "is_group"
        if status == "failed" and igv is None:
            return "judge_failed"
        if igv == "0":
            return "not_gangs"
        if igv != "1":
            return "judge_failed"
        # —— ig=1 ——
        if status == "failed" and not action:
            return "qual_failed"
        if status == "running" and stage in ("risks", "penalty"):
            return "risks"
        if _is_no_penalty_action(action):
            return "no_risk"
        if ex.get("skipped") and "拦截开关" in str(ex.get("skipped")):
            return "intercepted"
        fstage, fstatus = flows.get(j.get("group_id"), (None, None))
        if stage == "tichun_create" or (fstage is None and stage != "tichun_poll"):
            return "queue_tichun"
        if fstage in ("preprocess", "snapshot") and fstatus in ("failed", "terminated"):
            return "pre_failed"
        if fstage in ("preprocess", "snapshot"):
            return "pre_running"
        if fstage == "laoquan" and fstatus in ("failed", "terminated"):
            return "laoquan_failed"
        done_mark = ex.get("tichun_status_msg") == "SUCCESS" or fstage in ("injury_eval", "punish", "done")
        if not done_mark:
            return "laoquan_running"
        if fstage == "done" and fstatus == "done":
            return "injury_done"
        return "tichun_done"

    b = bucket()
    if tree == "gangs":
        return igv == "1"      # gangs 是里程碑展示（非互斥桶），单独支持
    return b == tree or (tree == "done" and stage == "done" and status == "done" and b in ("injury_done", "tichun_done"))


def list_by_batch(batch_id: str, limit: int = 100, offset: int = 0,
                  stage: Optional[str] = None, dt: Optional[str] = None,
                  is_group: Optional[str] = None, penalty: Optional[str] = None,
                  tichun: Optional[str] = None, risk: Optional[str] = None,
                  q: Optional[str] = None, tree: Optional[str] = None) -> list:
    """批次内 job 分页列表（created_at 升序，稳定翻页）。
    stage/dt/is_group（0 非团伙 / 1 团伙）/penalty/tichun（done 提纯完成 / running 提纯中 / none 未生成 case）可选过滤。
    tree=批次状态流程树节点键（与状态列/流程树同口径；flow 联动桶在 Python 侧过滤后再分页）。"""
    where, fvals = _job_filters(stage, dt, is_group, penalty, tichun, risk, q)
    where.insert(0, "batch_id=$1")
    vals = [batch_id] + fvals
    if not tree:
        vals += [limit, offset]
        li, oi = len(vals) - 1, len(vals)
        rows = _sb().execute(
            f"SELECT * FROM pipeline_jobs WHERE {' AND '.join(where)} "
            f"ORDER BY created_at LIMIT ${li} OFFSET ${oi}", vals)
        return [_row_to_dict(r) for r in rows]
    # tree 筛选：全量取（tree 键无 SQL 表达）→ Python 过滤 → 内存分页
    rows = _sb().execute(
        f"SELECT * FROM pipeline_jobs WHERE {' AND '.join(where)} ORDER BY created_at", vals)
    flows = _flow_map()
    matched = [r for r in (_row_to_dict(x) for x in rows) if _tree_match(r, tree, flows)]
    return matched[offset:offset + limit]


def _flow_map() -> dict:
    """group_id → (flow.stage, flow.status)（biz=流水线的最新 flow）。"""
    flows = {}
    for f in _sb().execute(
            "SELECT group_id, stage, status FROM flow_jobs "
            "WHERE extra->>'biz'='acc_sec_agent_pipline' ORDER BY created_at"):
        flows[f["group_id"]] = (f["stage"], f["status"])
    return flows


def count_jobs(batch_id: str, stage: Optional[str] = None, dt: Optional[str] = None,
               is_group: Optional[str] = None, penalty: Optional[str] = None,
               tichun: Optional[str] = None, risk: Optional[str] = None,
               q: Optional[str] = None, tree: Optional[str] = None) -> int:
    """与 list_by_batch 同条件的总数（分页用）。"""
    where, fvals = _job_filters(stage, dt, is_group, penalty, tichun, risk, q)
    where.insert(0, "batch_id=$1")
    vals = [batch_id] + fvals
    rows = _sb().execute(
        f"SELECT * FROM pipeline_jobs WHERE {' AND '.join(where)}", vals)
    if not tree:
        return len(rows)
    flows = _flow_map()
    return sum(1 for r in (_row_to_dict(x) for x in rows) if _tree_match(r, tree, flows))


def list_batch_dts(batch_id: str) -> list:
    """批次内出现的 dt 值（去重，供日期筛选下拉）。"""
    rows = _sb().execute(
        "SELECT DISTINCT dt FROM pipeline_jobs WHERE batch_id=$1 ORDER BY dt DESC", [batch_id])
    return [r["dt"] for r in rows]


def get_job(job_id: str) -> Optional[dict]:
    rows = _sb().execute("SELECT * FROM pipeline_jobs WHERE id=$1", [job_id])
    return _row_to_dict(rows[0]) if rows else None


def list_running(limit: int = 50) -> list:
    """调度器轮询用：running 中的任务。进行中的阶段（is_group/risks/penalty/tichun_*）优先
    于 pending（避免大量 pending 淹没窗口导致进行中任务饿死），同优先级按 updated_at。"""
    rows = _sb().execute(
        "SELECT * FROM pipeline_jobs WHERE status='running' "
        "ORDER BY CASE WHEN stage IN ('pending') THEN 1 ELSE 0 END, updated_at LIMIT $1", [limit])
    return [_row_to_dict(r) for r in rows]


def list_pending_all() -> list:
    """查全部 pending job（批量团伙判定用——list_running 的 LIMIT 可能被非 pending 占满）。
    不分页一次拉全部（pending 是轻量内存判定，数千条秒级消化）。"""
    rows = _sb().execute(
        "SELECT * FROM pipeline_jobs WHERE status='running' AND stage='pending' "
        "ORDER BY updated_at")
    return [_row_to_dict(r) for r in rows]


def update_stage(job_id: str, stage: str, **fields) -> None:
    allowed = {"status", "error_message"}
    sets, vals = ["stage=$1", "updated_at=$2"], [stage, _now()]
    idx = 3
    for k, v in fields.items():
        if k in allowed:
            sets.append(f"{k}=${idx}")
            vals.append(v)
            idx += 1
    vals.append(job_id)
    _sb().execute(f"UPDATE pipeline_jobs SET {','.join(sets)} WHERE id=${idx}", vals)


def update_extra(job_id: str, extra_dict: dict) -> None:
    _sb().execute(
        "UPDATE pipeline_jobs SET extra = COALESCE(extra,'{}'::jsonb) || $1::jsonb, "
        "updated_at=$2 WHERE id=$3",
        [json.dumps(extra_dict, ensure_ascii=False), _now(), job_id],
    )


def list_batches(limit: int = 20) -> list:
    ensure_batch_rows()
    rows = _sb().execute(
        "SELECT b.batch_id, b.dt, b.phase, b.status, b.concurrency, b.created_at AS started_at, "
        "count(j.id) AS total, "
        "sum(CASE WHEN j.status='done' THEN 1 ELSE 0 END) AS done_n, "
        "sum(CASE WHEN j.status='failed' THEN 1 ELSE 0 END) AS failed_n "
        "FROM pipeline_batches b LEFT JOIN pipeline_jobs j ON j.batch_id=b.batch_id "
        "GROUP BY b.batch_id, b.dt, b.phase, b.status, b.concurrency, b.created_at "
        "ORDER BY b.created_at DESC LIMIT $1", [limit])
    return [dict(r) for r in rows]


def count_inflight() -> int:
    """全局在推进的 job 数（跨实例口径）：running 且处于【活跃执行阶段】。
    pending 是等待队列（尚未开始），不占并发配额——否则大批量批次的排队 job
    会把配额瞬间吃满导致死锁（12k pending × 配额 40 = 永远拉不进新任务）。
    查询失败返回 -1（调度器 fail-closed 不拉新）。"""
    try:
        rows = _sb().execute(
            "SELECT count(*) AS n FROM pipeline_jobs WHERE status='running' "
            "AND stage IN ('is_group','risks','penalty','tichun_create')")
        return int(rows[0]["n"]) if rows else 0
    except Exception:
        return -1


JUDGE_STAGES = ("is_group",)
RISK_STAGES = ("risks", "penalty", "tichun_create")


def count_inflight_by(stages: tuple) -> int:
    """按阶段集合数 inflight（拆分配额用）：
    判定池（is_group，读表毫秒级）与定性池（risks/penalty/tichun_create，dify 10-15min）
    分开计数，慢阶段不挤占判定配额。查询失败返回 -1（fail-closed）。"""
    try:
        in_list = ",".join(f"'{s}'" for s in stages)
        rows = _sb().execute(
            f"SELECT count(*) AS n FROM pipeline_jobs WHERE status='running' "
            f"AND stage IN ({in_list})")
        return int(rows[0]["n"]) if rows else 0
    except Exception:
        return -1


def claim_batch(jobs: list, quota: int) -> list:
    """CAS 抢占配额内的 job（防双实例同轮重复处理同一 job）。
    抢占方式：updated_at 原子前移（SET updated_at=now WHERE id=$1 AND updated_at=$快照值），
    更新成功=本实例抢占。抢占后 stage 不变（由 _advance 正常流转），仅时间戳变更。
    返回实际抢占到的 job 列表。"""
    now = _now()
    claimed = []
    for job in jobs[:quota]:
        try:
            rows = _sb().execute(
                "UPDATE pipeline_jobs SET updated_at=$1 WHERE id=$2 AND updated_at=$3 "
                "RETURNING id",
                [now, job["id"], job.get("updated_at") or ""])
            if rows:
                claimed.append(job)
        except Exception:
            # 抢占查询失败跳过该 job（fail-safe：宁可少处理不重复）
            continue
    return claimed


def count_by_stage(stage: str) -> int:
    """指定 stage 的 running job 数（跨实例口径）。"""
    try:
        rows = _sb().execute(
            "SELECT count(*) AS n FROM pipeline_jobs WHERE status='running' AND stage=$1",
            [stage])
        return int(rows[0]["n"]) if rows else 0
    except Exception:
        return 0


def list_stale_active(minutes: int = 3, limit: int = 20, stages: tuple = None) -> list:
    """活跃 stage 但超 N 分钟未更新的僵尸 job（进程重启/线程死亡后 CAS 抢占无人推进）。
    stages 指定阶段集合（分层阈值用）；默认全活跃阶段。CAS 复活：updated_at 前移抢回。"""
    from datetime import datetime, timedelta
    stage_set = stages or ("is_group", "risks", "penalty", "tichun_create")
    in_list = ",".join(f"'{s}'" for s in stage_set)
    cutoff = (datetime.now() - timedelta(minutes=minutes)).strftime("%Y-%m-%d %H:%M:%S")
    try:
        rows = _sb().execute(
            f"SELECT * FROM pipeline_jobs WHERE status='running' "
            f"AND stage IN ({in_list}) "
            f"AND updated_at < $1 ORDER BY updated_at LIMIT $2", [cutoff, limit])
    except Exception:
        return []
    # CAS 复活（updated_at 前移，防止双实例同时回收同一僵尸）
    now = _now()
    revived = []
    for r in rows:
        job = _row_to_dict(r)
        try:
            ok = _sb().execute(
                "UPDATE pipeline_jobs SET updated_at=$1 WHERE id=$2 AND updated_at=$3 RETURNING id",
                [now, job["id"], job.get("updated_at") or ""])
            if ok:
                revived.append(job)
        except Exception:
            continue
    return revived


def claim_stage(job_id: str, from_stage: str, to_stage: str) -> bool:
    """CAS 阶段抢占：仅当 stage 仍为 from_stage 时置 to_stage（原子）。
    成功=本线程独占该 job 的本阶段处理；失败=另一线程已在处理（防僵尸回收并发重入）。"""
    try:
        rows = _sb().execute(
            "UPDATE pipeline_jobs SET stage=$1, updated_at=$2 "
            "WHERE id=$3 AND stage=$4 RETURNING id",
            [to_stage, _now(), job_id, from_stage])
        return bool(rows)
    except Exception:
        return False
