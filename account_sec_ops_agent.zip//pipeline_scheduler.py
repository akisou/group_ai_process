"""
风险事件排查流水线调度器 —— 移植自 pipline/agent_pipline v9（Jupyter 脚本服务化）。

每个 group_id 一个 pipeline_job，状态机断点续跑：
  pending → is_group → risks（四环节并发）→ penalty → tichun_create
  → tichun_poll（节流轮询提纯捞全状态）→ done
  非团伙（is_risk_group=0）→ 直接 done；判定失败（-1）→ failed（可人工重跑）

与原脚本的差异：
- 48h 阻塞轮询 → tichun_poll 阶段节流轮询（每轮调度查一次，间隔 tichun_poll_interval_seconds）
- Spark 写 Hive → _run_hive_sync（Talos INSERT）
- 结果同时落 pipeline_jobs.extra（Supabase），前端可查
"""
from __future__ import annotations

import json
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timedelta

from apscheduler.schedulers.background import BackgroundScheduler

import pipeline_store as store
from logger import sys_log


# ── 四环节风险判定输出解析（2026-09-13 定稿：纯字段映射，无兼容分支）─────────
# 输出契约（实测四工作流，结论字段各不相同）：
#   注册/解冻: outputs["xx风险判定结果"] = JSON串 {"风险类型": <结论>, "判定依据": [...]}
#   Token:     outputs["result"]         = JSON串 {"result": <结论>, "reason": <观察>}
#   登录:      平铺键 risk_type = <结论>，evidence = 证据文字
#
# 规则（用户定，2026-09-13）：
#   1. 只解析结论字段，reason/判定依据一律不解析不参与判定（历史 651 例误判的根因）
#   2. 注册「无法确定」→ 按无风险处理（模型分歧不足以定罪）
#   3. 登录「登录无风险团伙」→ 按无风险处理
# 4. 解析失败（格式漂移/调用失败）→ 结论为空 = 无风险（fail-safe：不误触发处罚）


def _parse_risk_std(outputs: dict, env: str) -> list:
    """四环节标准契约解析（2026-09-15，对齐 stream_optimize 分支工作流升级后输出）：
    workflow_finished outputs 平铺 risk_type（结论）+ reason（依据）——四环节已统一。
    归一化（用户定）：空/含「无风险」/「无法确定」→ result='无风险'（不参与关键词匹配）；
    其余原样作为风险结论，reason 仅存档。"""
    if not isinstance(outputs, dict):
        return [{"result": "无风险", "reason": "", "type": env}]
    rt = str(outputs.get("risk_type") or "").strip()
    reason = str(outputs.get("reason") or "")[:1000]
    if rt and "无风险" not in rt and rt != "无法确定":
        return [{"result": rt, "reason": reason, "type": env}]
    return [{"result": "无风险", "reason": "", "type": env}]


def _parse_login_output(outputs: dict) -> list:
    """登录环节（兼容层）：转发标准契约解析。"""
    return _parse_risk_std(outputs, "登录")


def _summarize_risks(all_risks: list) -> str:
    """风险汇总：注册环节-xxx，登录环节-xxx，……（结论字段拼接，无详情——reason 不再解析）。"""
    if not all_risks:
        return "无风险"
    parts = [f"{r.get('type', '未知')}环节-{r.get('result', '')}" for r in all_risks]
    return "，".join(parts)


def _determine_penalty(register_risks: list, login_risks: list,
                       unfreeze_risks: list, token_risks: list) -> dict:
    """处罚结论判定（规则引擎）：只匹配结论字段（result）。无风险/无法确定已在上游
    归一化为 result='无风险'，此处无风险条目直接跳过。"""
    def _contains_risk(risk_list, keywords):
        matched = []
        for r in risk_list:
            if "无风险" in str(r.get("result", "")):
                continue
            text = str(r.get("result", ""))
            for kw in keywords:
                if kw in text:
                    matched.append(kw)
                    break
        return matched

    # 规则1：冻结（批量注册 / 黑产自持 / 账号转卖）
    freeze_from_register = _contains_risk(register_risks, ["批量注册"])
    freeze_from_login = _contains_risk(login_risks, ["黑产自持", "账号转卖"])
    if freeze_from_register or freeze_from_login:
        risk_types, reason_parts = [], []
        if freeze_from_register:
            risk_types.append("批量注册")
            reason_parts.append("注册环节检测到批量注册风险")
        if freeze_from_login:
            risk_types.extend(freeze_from_login)
            reason_parts.append(f"登录环节检测到{'、'.join(freeze_from_login)}风险")
        return {"penalty": "冻结", "risk_types": "、".join(set(risk_types)), "reason": "，".join(reason_parts)}

    # 规则2：冻结加禁止解冻（批量解冻）
    if _contains_risk(unfreeze_risks, ["批量解冻"]):
        return {"penalty": "冻结加禁止解冻", "risk_types": "批量解冻", "reason": "解冻环节检测到批量解冻风险"}

    # 规则3：踢登
    kick_keywords = ["微信号的租借", "账号租借", "批量登录", "黑产自持手机号/wx资源", "众包",
                     "token跨设备型号", "token跨操作系统", "token跨App", "token跨渠道", "失效token作弊", "token伪造"]
    kick_from_login = _contains_risk(login_risks, kick_keywords)
    kick_from_token = _contains_risk(token_risks, kick_keywords)
    if kick_from_login or kick_from_token:
        risk_types, reason_parts = [], []
        if kick_from_login:
            risk_types.extend(kick_from_login)
            reason_parts.append("登录环节检测到" + "、".join(kick_from_login) + "风险")
        if kick_from_token:
            risk_types.extend(kick_from_token)
            reason_parts.append("Token环节检测到" + "、".join(kick_from_token) + "风险")
        return {"penalty": "踢登", "risk_types": "、".join(set(risk_types)), "reason": "，".join(reason_parts)}

    # 规则4：无风险（处罚口径与 agent_pipline.determine_penalty 对齐："不处置"）
    return {"penalty": "不处置", "risk_types": "无风险", "reason": "四个风险判定环节均无风险"}


def _is_no_penalty(penalty: dict) -> bool:
    """无风险短路判断：兼容新口径「不处置」与旧口径「无风险」（旧数据 extra 里仍有）。"""
    p = (penalty.get("penalty") or "") if isinstance(penalty, dict) else str(penalty or "")
    return "无风险" in p or "不处置" in p


# ── Hive 落表（Talos INSERT，替代原 Spark 写入）──────────────────────────
# 落表是旁路（数据已在 Supabase extra 留全量），失败/超时不应拖慢判定主流程：
# 短超时（10s）快速失败 + 后台线程执行，主流程不等待。

def _hive_insert(sql: str, wait: bool = False) -> bool:
    from api.routes import _run_hive_sync

    def _run() -> bool:
        res = _run_hive_sync(sql, max_wait_s=10)
        ok = res.get("status") == "done"
        if not ok:
            sys_log("warning", f"[Pipeline] Hive 写入失败: {(res.get('error') or '')[:150]}")
        return ok

    if wait:
        return _run()
    from threading import Thread
    Thread(target=_run, daemon=True).start()
    return True


def _esc(v) -> str:
    s = str(v if v is not None else "")
    return s.replace("\\", "\\\\").replace("'", "\\'")


def _write_is_group(job: dict, is_group_result: dict) -> None:
    """团伙判定落表（对齐原 _write_is_group_to_hive 的 13 列）。"""
    from config import get_config
    tbl = get_config().pipeline.is_group_table
    cols = ("group_id, platform_app_partner, label, status, elapsed_time, total_steps, "
            "total_tokens, error, output_result, is_risk_group, reason, is_missed, dt")
    vals = _esc(job["group_id"]), _esc(job.get("platform_app_partner")), _esc(job.get("label")), \
        "succeeded", "0.0", "0", "0", "''", \
        _esc(json.dumps({"is_risk_group": is_group_result.get("is_risk_group"),
                         "reason": is_group_result.get("reason", "")}, ensure_ascii=False)), \
        _esc(is_group_result.get("is_risk_group")), _esc(is_group_result.get("reason", "")), \
        _esc(is_group_result.get("is_missed", "")), job["dt"]
    sql = (f"INSERT INTO TABLE {tbl} PARTITION (dt) SELECT "
           f"'{vals[0]}','{vals[1]}','{vals[2]}','{vals[3]}',{vals[4]},{vals[5]},{vals[6]},"
           f"'{vals[7]}','{vals[8]}','{vals[9]}','{vals[10]}','{vals[11]}','{vals[12]}'")
    try:
        _hive_insert(sql)
    except Exception as e:
        sys_log("warning", f"[Pipeline] is_group 落表失败 group={job['group_id']}: {str(e)[:150]}")


def _write_final_result(job: dict, ex: dict) -> None:
    """最终结果落表（对齐原 write_results_to_hive 的 12 列）。"""
    from config import get_config
    tbl = get_config().pipeline.result_table
    def g(k):
        return _esc(ex.get(k, ""))
    sql = (f"INSERT INTO TABLE {tbl} PARTITION (dt) SELECT "
           f"'{g('group_id')}','{job['dt']}',"
           f"'{g('is_risk_group')}','{g('is_risk_group_reason')}',"
           f"'{g('register_result')}','{g('register_reason')}',"
           f"'{g('login_result')}','{g('login_reason')}',"
           f"'{g('unfreeze_result')}','{g('unfreeze_reason')}',"
           f"'{g('token_result')}','{g('token_reason')}'")
    try:
        _hive_insert(sql)
    except Exception as e:
        sys_log("warning", f"[Pipeline] 最终结果落表失败 group={job['group_id']}: {str(e)[:150]}")


# ── 调度器 ────────────────────────────────────────────────────────────────
# 流水线模式（无阶段门控）：每个 group 独立推进全链路
#   pending → is_group → risks/penalty → tichun_create → tichun_poll → done
# 不同 group 可处于不同阶段互不阻塞（对比旧分阶段模式：全员判完才能定性）。
#
# 并发安全三层：
#   1. 流水线全局并发（pipeline_concurrency，DB 可配默认 40，页面开关+可调）——
#      控制同时在推进的 group 数（dify 调用总量闸门）
#   2. mlp 总开关 + 全局画布并发（mlp_switch，默认 20）——画布提交硬闸门，与本层独立
#   3. 调度器轮询间隔内提交的 job 数 ≤ 第 1 层配额，不会瞬时超发

def pipeline_enabled() -> bool:
    """流水线运行开关：system_config 表 pipeline_enabled 优先（页面实时控制）。"""
    try:
        import canvas_job_store as _cjs
        rows = _cjs._sb().execute(
            "SELECT value FROM system_config WHERE category='access' AND key='pipeline_enabled'")
        if rows:
            v = rows[0].get("value")
            if isinstance(v, list) and v:
                return bool(v[0])
            return str(v).lower() in ("true", "1")
    except Exception:
        pass
    return True


def tichun_blocked_risk_types() -> list:
    """提纯捞全环节的风险类型拦截清单（页面实时控制）：
    命中清单的处罚结论（risk_types 含对应类型）不再建提纯任务，直接短路完成。
    存 system_config tichun_blocked_risk_types（JSON 数组）；空数组 = 不拦截。"""
    try:
        import canvas_job_store as _cjs
        rows = _cjs._sb().execute(
            "SELECT value FROM system_config WHERE category='access' AND key='tichun_blocked_risk_types'")
        if rows:
            v = rows[0].get("value")
            if isinstance(v, list):
                return [str(x) for x in v if str(x).strip()]
    except Exception:
        pass
    return []


def _hits_blocked_risk_type(penalty: dict) -> str:
    """处罚结论的 risk_types 是否命中拦截清单。命中返回类型名，未命中返回空串。"""
    blocked = tichun_blocked_risk_types()
    if not blocked:
        return ""
    rt = str((penalty or {}).get("risk_types") or "")
    for b in blocked:
        if b and b in rt:
            return b
    return ""


# ── 代码级硬上限（焊死）：任何配置（DB/页面/config.yaml）都不可突破 ──────────
PIPELINE_HARD_CAP = 100   # 流水线全局并发绝对上限——防配置错误/改库绕过把 dify 打挂


def pipeline_concurrency() -> int:
    """流水线全局并发上限：system_config 表 pipeline_concurrency 优先（页面可调 1-100），
    默认 40。返回值强制 clamp 到 [1, PIPELINE_HARD_CAP]——即使 DB 被手工改成 999，
    实际生效也不超过 100（代码焊死，双保险）。"""
    n = None
    try:
        import canvas_job_store as _cjs
        rows = _cjs._sb().execute(
            "SELECT value FROM system_config WHERE category='access' AND key='pipeline_concurrency'")
        if rows:
            v = rows[0].get("value")
            if isinstance(v, list) and v:
                v = v[0]
            n = int(v)
    except Exception:
        pass
    if n is None or n < 1:
        from config import get_config
        n = get_config().pipeline.max_concurrent_jobs * 10  # config 兜底（默认 4×10=40）
    # ★ 代码级 clamp：最终生效值永不超 HARD_CAP
    return max(1, min(n, PIPELINE_HARD_CAP))


class PipelineScheduler:
    def __init__(self):
        from config import get_config
        cfg = get_config().pipeline
        self.interval = cfg.poll_interval_seconds
        self.tichun_interval = cfg.tichun_poll_interval_seconds
        self.tichun_max_checks = cfg.tichun_max_checks
        self._sched = None
        self._perception_cache: dict = {}   # (dt, group_id) → 感知表判定（兜底查询缓存）

    def start(self):
        if self._sched is not None:
            return
        self._sched = BackgroundScheduler(timezone="Asia/Shanghai")
        self._sched.add_job(self._poll_all, "interval", seconds=self.interval, id="pipeline_poll",
                            max_instances=1, coalesce=True, misfire_grace_time=30)
        # 每日定时启动（2026-09-20 用户定）：每天 07:00 自动启动 dt=今天-2 的流水线批次。
        # 幂等防重：同 dt 已有 running 批次则跳过（重复触发/服务重启不重建）。
        from config import get_config
        _pcfg = get_config().pipeline
        if _pcfg.daily_start_enabled:
            self._sched.add_job(self._daily_start, "cron",
                                hour=_pcfg.daily_start_hour, minute=_pcfg.daily_start_minute,
                                id="pipeline_daily_start", max_instances=1, coalesce=True,
                                misfire_grace_time=3600)
            sys_log("info", f"[PipelineScheduler] 每日定时启动已配置：每天 "
                            f"{_pcfg.daily_start_hour:02d}:{_pcfg.daily_start_minute:02d} "
                            f"启动 dt-{_pcfg.daily_start_dt_offset_days} 流水线")
        self._sched.start()
        sys_log("info", f"[PipelineScheduler] started, interval={self.interval}s, "
                        f"concurrency={pipeline_concurrency()}(DB可配,硬上限{PIPELINE_HARD_CAP})")

    def _daily_start(self):
        """每日 07:00：启动 dt = 今天-2 的流水线（感知表数据延迟两天才完整）。
        幂等：该 dt 已有 running 批次则跳过。失败只记日志，次日重试。"""
        try:
            from datetime import datetime, timedelta
            from config import get_config
            _pcfg = get_config().pipeline
            target_dt = (datetime.now() - timedelta(days=_pcfg.daily_start_dt_offset_days)).strftime("%Y%m%d")
            # 幂等：同 dt 已有 running 批次 → 跳过
            try:
                existing = store._sb().execute(
                    "SELECT count(*) AS n FROM pipeline_batches WHERE dt=$1 AND status='running'", [target_dt])
                if existing and int(existing[0]["n"]) > 0:
                    sys_log("info", f"[PipelineScheduler] 每日启动跳过：dt={target_dt} 已有 running 批次")
                    return
            except Exception:
                pass
            # 进程内调 pipeline_start 逻辑（不走 HTTP）
            from api.routes import pipeline_start, PipelineStartRequest
            r = pipeline_start(PipelineStartRequest(dt=target_dt))
            if r.get("status") == 1:
                sys_log("info", f"[PipelineScheduler] 每日定时启动成功：dt={target_dt} "
                                f"批次={str(r.get('batch_id'))[:8]} 共{r.get('total')}个group")
            else:
                sys_log("warning", f"[PipelineScheduler] 每日定时启动失败：dt={target_dt} {str(r.get('message'))[:120]}")
        except Exception as e:
            sys_log("warning", f"[PipelineScheduler] 每日定时启动异常: {str(e)[:200]}")

    def shutdown(self):
        if self._sched is not None:
            self._sched.shutdown(wait=False)
            self._sched = None
            sys_log("info", "[PipelineScheduler] shutdown")

    def _poll_all(self):
        """流水线模式：全局拉取 running 的 job（不分批次、不分阶段），并发配额内推进。
        并发计数【纯 DB 跨实例】：job 的 stage 落在 Supabase（pending→is_group→risks→...），
        所有实例读同一份状态，每个 job 同一时刻只被一个实例的 CAS 抢占（claim_for_advance），
        双实例各拉 quota 也不会重复计算同一个 job。
        开关关闭时暂停拉取（在跑的线程自然结束）。"""
        try:
            if not pipeline_enabled():
                return  # 暂停：不拉新任务，已提交线程跑完为止
            store.ensure_batch_rows()
            conc = pipeline_concurrency()
            # tichun_poll 轻量（节流查询，不占 dify/mlp 配额）单独处理；
            # tichun_create 也是轻量快操作（拦截开关秒级短路 / 本地 HTTP 建任务秒级），
            # 一并正常轮询——否则判完的 job 停在 tichun_create 显示"待提纯捞全"
            # 长达 20 分钟（等僵尸回收），拦截开关被误认为失效（2026-09-13 用户实锤）
            polling = store.list_running(limit=600)
            poll_jobs = [j for j in polling if j["stage"] in ("tichun_poll", "tichun_create")]
            # 配额拆两段：新 job 拉起只受「判定池」配额限制（is_group 读表毫秒级快进快出）；
            # 定性池（risks/penalty/tichun_create，dify 10-15min）占满不再堵住 pending 拉新——
            # job 过判定后落 stage=risks，由 _advance 的僵尸回收/正常轮询推进定性。
            inflight_judge = store.count_inflight_by(store.JUDGE_STAGES)
            if inflight_judge < 0:
                return  # 查询失败 fail-closed
            judge_quota = max(0, conc - inflight_judge)
            # 批量团伙判定（2026-09-11 用户定）：perception 已从 Hive 读入缓存，
            # 判定逻辑纯内存（读 extra.perception.is_risk_group → 0=非团伙 done / 1=团伙 risks）
            # + 1 次 Hive INSERT 落表——无 Hive 查询、无 dify 调用，逐个排队纯属浪费。
            # 一次性推进所有 pending（不限 quota），秒级消化数千积压。
            # 单独查 pending（list_running 的 LIMIT 600 可能被非 pending 占满拉不到）
            all_pendings = store.list_pending_all()
            if all_pendings:
                self._batch_is_group(all_pendings)
            # risks 正常拉取（2026-09-13 吞吐修复）：原只靠僵尸回收（20/轮 × 20min stale）
            # = ~1 个/分钟，2000 积压要 30+ 小时。按配额拉取待判定的 risks job。
            # 注意 inflight 口径：count_inflight_by 把「排队中」的 risks 也计入（stage=risks
            # 且 status=running 就是 2155 个）——不能用它当配额（永远 0）。真在跑的判定
            # 无法从 DB 区分（CAS 后 stage 即变 penalty）——用 CAS 幂等兜底：拉多了
            # _stage_risks 的 claim_stage 会跳过已处理的，最多浪费一次拉取。
            # 实际并发控制由 dify 调用方（登录工作流 15-30s/个）自然限流。
            risk_jobs = [j for j in polling
                         if j["stage"] == "risks" and j.get("status") == "running"]
            # 每轮拉取量：配额的一半（给判定池留余量；CAS 防重复）
            pull_n = max(1, conc // 2)
            if risk_jobs:
                self._run_jobs(risk_jobs[:pull_n])
            # 僵尸回收（分层阈值）：判定池（is_group，秒级）3 分钟即可回收；
            # 定性池（risks/penalty 等，四环节正常 10-15min）20 分钟——须大于正常耗时防误抢
            zombies = (store.list_stale_active(minutes=3, stages=store.JUDGE_STAGES, limit=20)
                       + store.list_stale_active(minutes=20, stages=store.RISK_STAGES, limit=20))
            if zombies:
                sys_log("info", f"[PipelineScheduler] 回收僵尸 job {len(zombies)} 个")
                self._run_jobs(zombies)
            for job in poll_jobs:
                self._safe_advance(job)
            self._check_batches_done()
        except Exception as e:
            sys_log("error", f"[PipelineScheduler] poll_all error: {str(e)[:200]}")

    def _check_batches_done(self):
        """批次完成检测：批次内所有 job 终态（done/failed）→ 批次置 done。"""
        try:
            for batch in store.list_running_batches():
                bid = batch["batch_id"]
                remaining = store.count_by_batch_stages(
                    bid, ("pending", "is_group", "risks", "penalty", "tichun_create", "tichun_poll"))
                if remaining == 0:
                    store.update_batch(bid, phase="done", status="done")
                    stats = store.batch_stats(bid)
                    sys_log("info", f"[Pipeline] batch={bid[:8]} 全部完成 → done"
                                    f"（{stats['done']} done / {stats['failed']} failed）")
        except Exception as e:
            sys_log("warning", f"[PipelineScheduler] check_batches error: {str(e)[:150]}")

    def _run_jobs(self, jobs: list):
        """并发执行已 CAS 抢占的 job（fire-and-forget，不阻塞轮询）。
        分池按耗时划分：
        - 快池（20 worker）：is_group（读表毫秒级）/ penalty（DB 更新）/
          tichun_create（本地 HTTP 建提纯任务，秒级）
        - 慢池（200 worker）：risks（dify 四环节并发调用，分钟级长调用）
        2026-09-12 修复：tichun_create 原与 risks 共用慢池——risks 长调用占满
        worker 后，秒级的建任务操作在 FIFO 队列里饿死（千级积压卡在
        待提纯捞全）。分池后 tichun_create 快速出队。"""
        if not jobs:
            return
        import threading
        if not hasattr(self, "_pool_judge") or self._pool_judge is None:
            self._pool_judge = ThreadPoolExecutor(max_workers=20)
            self._pool_risks = ThreadPoolExecutor(max_workers=200)
            self._pool_lock = threading.Lock()
        with self._pool_lock:
            for job in jobs:
                if job.get("stage") in ("pending", "is_group", "penalty", "tichun_create"):
                    self._pool_judge.submit(self._safe_advance, job)
                else:
                    self._pool_risks.submit(self._safe_advance, job)

    def _safe_advance(self, job: dict):
        try:
            self._advance(job)
        except Exception as e:
            # 连接层异常 str(e) 常为空串（如 SSLEOFError），补异常类型保证可排查
            err = str(e).strip() or type(e).__name__
            # 写库瞬时失败（SSL 超时/连接重置/EOF/网关 5xx）：不标 failed——判定结果可能已写入，
            # 下轮调度按已有结果幂等推进，避免误杀已完成的判定
            transient = ("handshake" in err or "Connection reset" in err or "timed out" in err.lower()
                         or "EOF" in err or "SSLError" in err or "502" in err or "503" in err
                         or "RemoteDisconnected" in err or type(e).__name__ in
                         ("SSLError", "RemoteDisconnected", "ConnectionResetError", "ReadTimeout"))
            if transient:
                sys_log("warning", f"[PipelineScheduler] job={job.get('group_id')} 瞬时错误（下轮重试）: {err[:120]}")
                return
            sys_log("warning", f"[PipelineScheduler] job={job.get('group_id')} advance error: {err[:200]}")
            try:
                store.update_stage(job["id"], "failed", status="failed", error_message=err[:500])
            except Exception:
                pass

    def _advance(self, job: dict):
        stage = job.get("stage", "pending")
        if stage == "pending":
            self._stage_is_group(job)
        elif stage == "is_group":
            # 进行中的团伙判定（重启中断后 stage 残留）：幂等重入，已有结果直接走分支
            self._stage_is_group(job)
        elif stage == "risks":
            # 团伙判定已过、四环节判定未做（_stage_risks 自身先把 stage 置 penalty）
            self._stage_risks(job)
        elif stage == "penalty":
            self._stage_penalty_and_create(job)
        elif stage == "tichun_create":
            self._stage_tichun_create(job)
        elif stage == "tichun_poll":
            self._stage_tichun_poll(job)

    # ── 阶段1：团伙判定（读感知表，不调 dify）──
    def _stage_is_group(self, job: dict):
        # 幂等重入：已有团伙判定结果（服务重启等中断后 stage 残留 is_group）→ 直接走分支
        existing = (job.get("extra") or {}).get("is_group") or {}
        if existing.get("is_risk_group") in ("0", "1"):
            parsed = existing
        else:
            store.update_stage(job["id"], "is_group")
            # 首选：建批时随 job 带出的感知表判定（extra.perception，零 Hive IO）
            perception = (job.get("extra") or {}).get("perception") or {}
            if perception.get("is_risk_group") in ("0", "1"):
                parsed = {"is_risk_group": perception["is_risk_group"],
                          "reason": perception.get("reason") or "",
                          "is_missed": perception.get("is_missed") or "0"}
                parsed["source"] = "perception"
            else:
                # 兼容回退：旧批次 job 无 perception 字段 → 单查感知表（结果进缓存供重入复用）
                parsed = self._query_perception(job["group_id"], job["dt"])
                if parsed is None:
                    store.update_stage(job["id"], "failed", status="failed",
                                       error_message="感知表团伙判定查询失败（无该 group 当日记录）")
                    return
            store.update_extra(job["id"], {"is_group": parsed})
            _write_is_group(job, parsed)
            sys_log("info", f"[Pipeline] group={job['group_id']} 团伙判定"
                            f"（{parsed.get('source', 'perception')}）: {parsed['is_risk_group']} "
                            f"is_missed={parsed['is_missed']} reason={parsed['reason'][:100]}")
        if parsed["is_risk_group"] == "0":
            # 非团伙：短路完成（不下发提纯捞全），落最终表
            ex = {"is_risk_group": "0", "is_risk_group_reason": parsed.get("reason", ""),
                  "penalty": "无风险（非团伙）", "risk_summary": "非团伙，无需风险判定"}
            store.update_extra(job["id"], ex)
            _write_final_result(job, {**ex, "group_id": job["group_id"]})
            store.update_stage(job["id"], "done", status="done")
            return
        store.update_stage(job["id"], "risks")

    def _batch_is_group(self, jobs: list):
        """批量团伙判定（2026-09-11 用户定）：perception 已缓存，一次性推进所有 pending。
        纯内存读 extra.perception.is_risk_group → 0=非团伙(done) / 1=团伙(risks)。
        非团伙批量落 Supabase + Hive；团伙批量推进到 risks 阶段排队定性。
        不受 judge_quota 限制——判定是毫秒级内存操作，无 Hive 查询无 dify 调用。"""
        import json as _json
        non_gangs, gangs, missing = [], [], []
        for job in jobs:
            ex = job.get("extra")
            if isinstance(ex, str):
                try: ex = _json.loads(ex or "{}")
                except Exception: ex = {}
            if not isinstance(ex, dict): ex = {}
            perc = ex.get("perception") or {}
            igv = perc.get("is_risk_group")
            if igv in ("0", "1"):
                parsed = {"is_risk_group": str(igv),
                          "reason": perc.get("reason") or "",
                          "is_missed": perc.get("is_missed") or "0",
                          "source": "perception_batch"}
                if igv == "0":
                    non_gangs.append((job, parsed))
                else:
                    gangs.append((job, parsed))
            else:
                missing.append(job)
        for job, parsed in non_gangs:
            try:
                store.update_extra(job["id"], {"is_group": parsed})
                ex = {"is_risk_group": "0", "is_risk_group_reason": parsed.get("reason", ""),
                      "penalty": "无风险（非团伙）", "risk_summary": "非团伙，无需风险判定"}
                store.update_extra(job["id"], ex)
                _write_is_group(job, parsed)
                _write_final_result(job, {**ex, "group_id": job["group_id"]})
                store.update_stage(job["id"], "done", status="done")
            except Exception as e:
                sys_log("warning", f"[Pipeline] batch non-gang fail group={job['group_id']}: {str(e)[:100]}")
        for job, parsed in gangs:
            try:
                store.update_extra(job["id"], {"is_group": parsed})
                _write_is_group(job, parsed)
                store.update_stage(job["id"], "risks")
            except Exception as e:
                sys_log("warning", f"[Pipeline] batch gang fail group={job['group_id']}: {str(e)[:100]}")
        if missing:
            sys_log("info", f"[Pipeline] 批量判定: {len(non_gangs)} 非团伙 + {len(gangs)} 团伙 + {len(missing)} 无缓存回退查询")
            for job in missing:
                self._pool_judge.submit(self._safe_advance, job)
        else:
            sys_log("info", f"[Pipeline] 批量判定: {len(non_gangs)} 非团伙→done, {len(gangs)} 团伙→risks")

    def _query_perception(self, group_id: str, dt: str):
        """兜底：旧批次 job 无 perception 字段时单查团伙判定表（is_risk_group/reason/is_missed）。
        进程内缓存（dt+group_id），重试/重入不重复查。查询失败或无记录返回 None。"""
        key = (dt, group_id)
        if key in self._perception_cache:
            return self._perception_cache[key]
        from config import get_config
        tbl = get_config().pipeline.judge_table
        from api.routes import _run_hive_sync
        sql = (f"SELECT is_risk_group, reason, is_missed FROM {tbl} "
               f"WHERE dt='{_esc(dt)}' AND group_id='{_esc(group_id)}' LIMIT 1")
        parsed = None
        try:
            res = _run_hive_sync(sql, max_wait_s=30)
            if res.get("status") == "done" and res.get("rows"):
                r = res["rows"][0]
                cols = res["columns"]
                iR, iRs, iM = cols.index("is_risk_group"), cols.index("reason"), cols.index("is_missed")
                parsed = {"is_risk_group": "1" if str(r[iR]) == "1" else "0",
                          "reason": str(r[iRs] or ""),
                          "is_missed": "1" if str(r[iM]) == "1" else "0",
                          "source": "perception_query"}
        except Exception as e:
            sys_log("warning", f"[Pipeline] 感知表查询失败 group={group_id}: {str(e)[:150]}")
        self._perception_cache[key] = parsed
        return parsed

    # ── 阶段2：四环节风险判定（并发）──
    def _stage_risks(self, job: dict):
        """风险定性（2026-09-15）：四环节并发调用，统一标准契约解析
        （risk_type 结论 + reason 依据，只信结论字段——历史 651 例误判根因是
        解析兜底把 reason 文字当结论，工作流输出标准化后已消除）。
        「无法确定」/含「无风险」归一为无风险；调用失败按无风险（fail-safe）。"""
        # 防御：团伙判定结果缺失（不应发生）→ 退回 is_group 阶段，禁止无判定依据跑定性
        ig = (job.get("extra") or {}).get("is_group") or {}
        if ig.get("is_risk_group") not in ("0", "1"):
            sys_log("warning", f"[Pipeline] group={job['group_id']} 缺团伙判定结果，退回 is_group 阶段")
            store.update_stage(job["id"], "is_group")
            return
        # CAS 防并发重入：仅当 stage 仍是 risks 时推进（僵尸回收与原线程竞态防护）
        if not store.claim_stage(job["id"], "risks", "penalty"):
            return  # 已有另一线程在处理
        gid, pap, label, dt = job["group_id"], job.get("platform_app_partner") or "", job.get("label") or "", job["dt"]

        from client import arceus_client
        # 四环节并发调用（2026-09-15 恢复——工作流输出已升级为统一标准契约
        # risk_type/reason，解析层只信结论字段，历史误判源已消除）
        with ThreadPoolExecutor(max_workers=4) as _exe:
            _futs = {
                "register": _exe.submit(arceus_client.call_risk_register, gid, pap, label, dt),
                "login": _exe.submit(arceus_client.call_risk_login, gid, pap, label, dt),
                "unfreeze": _exe.submit(arceus_client.call_risk_unfreeze, gid, pap, label, dt),
                "token": _exe.submit(arceus_client.call_risk_token, gid, pap, label, dt),
            }
        _env_map = {"register": "注册", "login": "登录", "unfreeze": "解冻", "token": "Token"}
        _parsed = {}
        for _key, _fut in _futs.items():
            _out = _fut.result()
            if _out.get("status") == "succeeded":
                _parsed[_key] = _parse_risk_std(_out.get("outputs") or {}, _env_map[_key])
            else:
                # 调用失败 → 该环节按无风险处理（fail-safe：不误触发处罚）
                _parsed[_key] = [{"result": "无风险", "reason": "", "type": _env_map[_key]}]
        register_risks = _parsed["register"]
        login_risks = _parsed["login"]
        unfreeze_risks = _parsed["unfreeze"]
        token_risks = _parsed["token"]

        penalty = _determine_penalty(register_risks, login_risks, unfreeze_risks, token_risks)
        summary = _summarize_risks(register_risks + login_risks + unfreeze_risks + token_risks)
        store.update_extra(job["id"], {
            "risks": {"register": register_risks, "login": login_risks,
                      "unfreeze": unfreeze_risks, "token": token_risks},
            "penalty": penalty, "risk_summary": summary,
            "register_result": "、".join({r.get("result", "") for r in register_risks}) or "无风险",
            "register_reason": "；".join(r.get("reason", "") for r in register_risks if r.get("reason"))[:500],
            "login_result": "、".join({r.get("result", "") for r in login_risks}) or "无风险",
            "login_reason": "；".join(r.get("reason", "") for r in login_risks if r.get("reason"))[:500],
            "unfreeze_result": "、".join({r.get("result", "") for r in unfreeze_risks}) or "无风险",
            "unfreeze_reason": "；".join(r.get("reason", "") for r in unfreeze_risks if r.get("reason"))[:500],
            "token_result": "、".join({r.get("result", "") for r in token_risks}) or "无风险",
            "token_reason": "；".join(r.get("reason", "") for r in token_risks if r.get("reason"))[:500],
        })
        sys_log("info", f"[Pipeline] group={job['group_id']} 定性完成（四环节）: penalty={penalty['penalty']} "
                        f"summary={summary[:100]}")
        # 无风险：立即短路 done（不生成 case、不调 task_create）
        if _is_no_penalty(penalty):
            ex = job.get("extra") or {}
            store.update_extra(job["id"], {"skipped": "定性无风险，短路（未生成 case）"})
            _write_final_result(job, {**ex, "group_id": job["group_id"],
                                      "is_risk_group": "1",
                                      "is_risk_group_reason": (ex.get("is_group") or {}).get("reason", "")})
            store.update_stage(job["id"], "done", status="done")
            sys_log("info", f"[Pipeline] group={job['group_id']} 定性无风险 → 短路完成（未生成 case）")
            return
        # 有风险：停在 tichun_create（拦截开关/建提纯在 _do_tichun_create，正常轮询秒级处理）
        store.update_stage(job["id"], "tichun_create")

    def _stage_penalty_and_create(self, job: dict):
        # 兼容旧数据（stage=penalty 卡住的 job）：定性结果已在 extra，直接推进到提纯等待
        store.update_stage(job["id"], "tichun_create")

    # ── 阶段3：建提纯捞全任务（调本系统 task_create，无风险会被拦截跳过）──
    def _do_tichun_create(self, job: dict, penalty: dict, summary: str):
        # 防御（2026-09-14）：定性结果缺失（penalty 空 dict——SSL 瞬时错误时 CAS 已推进
        # 但 update_extra 失败，job 带空定性残留）→ 回退 risks 阶段重新定性，禁止建 case。
        # 否则空 penalty 被当"有风险"建出 action=auto 的无意义 case（9b6f581b 批次 4 例实锤）
        if not (penalty or {}).get("penalty"):
            sys_log("warning", f"[Pipeline] group={job['group_id']} 定性结果缺失，回退 risks 重新判定")
            store.update_stage(job["id"], "risks")
            return
        store.update_stage(job["id"], "tichun_create")
        # 双保险：无风险在这里也短路（覆盖 tichun_create 阶段残留的 job）
        if _is_no_penalty(penalty):
            ex = job.get("extra") or {}
            store.update_extra(job["id"], {"skipped": "定性无风险，短路（未生成 case）"})
            _write_final_result(job, {**ex, "group_id": job["group_id"],
                                      "is_risk_group": "1",
                                      "is_risk_group_reason": (ex.get("is_group") or {}).get("reason", "")})
            store.update_stage(job["id"], "done", status="done")
            return
        # 风险类型拦截开关（页面实时控制）：risk_types 命中拦截清单 → 不建提纯任务，短路完成
        blocked = _hits_blocked_risk_type(penalty)
        if blocked:
            ex = job.get("extra") or {}
            store.update_extra(job["id"], {"skipped": f"风险类型「{blocked}」已配置为不进提纯（拦截开关）"})
            _write_final_result(job, {**ex, "group_id": job["group_id"],
                                      "is_risk_group": "1",
                                      "is_risk_group_reason": (ex.get("is_group") or {}).get("reason", "")})
            store.update_stage(job["id"], "done", status="done")
            sys_log("info", f"[Pipeline] group={job['group_id']} 风险类型「{blocked}」命中拦截开关 → 短路（不建提纯）")
            return
        # 直接进程内调 external_task_create 逻辑（复用 biz 白名单）
        import httpx
        from config import get_config
        cfg = get_config()
        base = f"http://127.0.0.1:{cfg.app.port}"
        payload = {
            "group_id": job["group_id"],
            "result": (penalty.get("risk_types") or "")[:200],
            "action_type": penalty.get("penalty") or "auto",
            "reason": (summary or "")[:2000],
            "biz": cfg.pipeline.tichun_biz,
            # 批次号透传到 flow extra（CASE总览/任务调度唯一标识，同 group 多批次区分）
            "batch_id": job.get("batch_id") or "",
            # 感知上下文透传（2026-09-22 用户定）：详情页直接读 extra 零 Hive
            "perception_context": {
                "items_str": str(((job.get("extra") or {}).get("perception") or {}).get("items_str") or "")[:5000],
                "risk_level": str(((job.get("extra") or {}).get("perception") or {}).get("risk_level") or ""),
                "perception_dt": str(((job.get("extra") or {}).get("perception") or {}).get("perception_dt") or ""),
                "label": str(job.get("label") or ""),
                "platform_app_partner": str(job.get("platform_app_partner") or ""),
            },
        }
        try:
            resp = httpx.post(f"{base}/agent/tichunlaoquan/task_create", json=payload, timeout=60)
            data = resp.json()
        except Exception as e:
            store.update_stage(job["id"], "failed", status="failed",
                               error_message=f"task_create 调用异常: {str(e)[:200]}")
            return
        if data.get("status") == 1:
            case_id = data.get("data", {}).get("case_id", "")
            # 无风险被拦截（case 直接 skipped）→ 短路完成，不启动提纯
            import flow_store
            flow = flow_store.get_by_case_id(case_id)
            if flow and flow.get("stage") == "skipped":
                store.update_extra(job["id"], {"tichun_case_id": case_id,
                                               "skipped": "无风险拦截，未启动提纯"})
                sys_log("info", f"[Pipeline] group={job['group_id']} 无风险短路（不启动提纯）case={case_id}")
                ex = job.get("extra") or {}
                _write_final_result(job, {**ex, "group_id": job["group_id"],
                                          "is_risk_group": "1",
                                          "is_risk_group_reason": (ex.get("is_group") or {}).get("reason", "")})
                store.update_stage(job["id"], "done", status="done")
                return
            # case_id 记账加固（2026-09-13）：PG 抖动会让 update_extra 落库失败——case 已建
            # 但 job 无 tichun_case_id → 推进 tichun_poll 立即失败'case_id 为空'，产生孤儿 case
            # （凌晨事故 272 例）。先重试 1 次；仍失败则不推进阶段（job 留在 tichun_create，
            # 外部 task_create 幂等复用已有 case，下轮重入无害）。
            try:
                store.update_extra(job["id"], {"tichun_case_id": case_id,
                                               "tichun_check_count": 0,
                                               "tichun_last_check": datetime.now().strftime("%Y-%m-%d %H:%M:%S")})
            except Exception as e:
                sys_log("warning", f"[Pipeline] case_id 记账失败重试 group={job['group_id']}: {str(e)[:120]}")
                import time as _t
                _t.sleep(2)
                store.update_extra(job["id"], {"tichun_case_id": case_id,
                                               "tichun_check_count": 0,
                                               "tichun_last_check": datetime.now().strftime("%Y-%m-%d %H:%M:%S")})
            store.update_stage(job["id"], "tichun_poll")
        else:
            store.update_stage(job["id"], "failed", status="failed",
                               error_message=f"task_create 失败: {data.get('message', '')[:200]}")

    def _stage_tichun_create(self, job: dict):
        ex = job.get("extra") or {}
        self._do_tichun_create(job, ex.get("penalty") or {}, ex.get("risk_summary") or "")

    # ── 阶段4：轮询提纯捞全状态（节流）──
    def _stage_tichun_poll(self, job: dict):
        ex = job.get("extra") or {}
        case_id = ex.get("tichun_case_id") or ""
        if not case_id:
            # 记账丢失兜底（2026-09-13）：按 group_id 反查 flow 找回 case_id 重记账；
            # 查不到才 failed（外部 task_create 幂等，重入 tichun_create 也安全）
            import flow_store as _fs
            try:
                existing = _fs._sb().execute(
                    "SELECT case_id, stage FROM flow_jobs WHERE group_id=$1 "
                    "ORDER BY created_at DESC LIMIT 1", [job["group_id"]])
                if existing and existing[0]["case_id"] and existing[0]["stage"] != "skipped":
                    found = existing[0]["case_id"]
                    store.update_extra(job["id"], {"tichun_case_id": found})
                    sys_log("info", f"[Pipeline] tichun_poll 记账兜底找回 group={job['group_id']} case={found}")
                    case_id = found
            except Exception:
                pass
            if not case_id:
                store.update_stage(job["id"], "failed", status="failed", error_message="tichun_case_id 为空")
                return
        # 节流
        last = ex.get("tichun_last_check") or ""
        if last:
            try:
                t = datetime.strptime(last, "%Y-%m-%d %H:%M:%S")
                if datetime.now() - t < timedelta(seconds=self.tichun_interval):
                    return
            except Exception:
                pass
        count = int(ex.get("tichun_check_count") or 0)
        if count >= self.tichun_max_checks:
            store.update_stage(job["id"], "failed", status="failed",
                               error_message=f"提纯捞全轮询超时（{count} 次）")
            return
        store.update_extra(job["id"], {
            "tichun_check_count": count + 1,
            "tichun_last_check": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        })
        import httpx
        from config import get_config
        cfg = get_config()
        base = f"http://127.0.0.1:{cfg.app.port}"
        try:
            resp = httpx.post(f"{base}/agent/tichunhuilao/task_status",
                              json={"case_id": case_id, "biz": cfg.pipeline.tichun_biz}, timeout=60)
            data = resp.json().get("data", {})
        except Exception as e:
            sys_log("warning", f"[Pipeline] task_status 异常 case={case_id}: {str(e)[:150]}")
            return
        msg = data.get("case_task_status_msg", "")
        sys_log("info", f"[Pipeline] group={job['group_id']} 提纯状态: {msg} stage={data.get('case_task_status_stage')} "
                        f"({count + 1}/{self.tichun_max_checks})")
        if msg == "SUCCESS":
            store.update_extra(job["id"], {
                "tichun_status_msg": msg,
                "tichun_status_stage": data.get("case_task_status_stage", ""),
                "tichun_rules": data.get("rules") or {},
            })
            final_ex = job.get("extra") or {}
            final_ex.setdefault("is_risk_group", "1")
            final_ex["is_risk_group_reason"] = (final_ex.get("is_group") or {}).get("reason", "")
            _write_final_result(job, {**final_ex, "group_id": job["group_id"]})
            store.update_stage(job["id"], "done", status="done")
            # 提纯捞全成功 → 数据预热：主切片 + SVG/ts_daily 批量落 Supabase 缓存
            # + Agent 判定预触发（后台 worker 池，不阻塞流水线，失败只记日志）
            try:
                import case_prefetch
                case_prefetch.warm_case(case_id, "default", job["dt"])
                sys_log("info", f"[Pipeline] 数据预热已提交 case={case_id} group={job['group_id']} dt={job['dt']}")
            except Exception as e:
                sys_log("warning", f"[Pipeline] 数据预热提交失败 case={case_id}: {str(e)[:150]}")
        elif msg == "FAILURE":
            store.update_stage(job["id"], "failed", status="failed",
                               error_message=f"提纯捞全失败: {data.get('case_task_status_stage', '')[:200]}")
        # RUNNING → 等下轮（节流间隔）
