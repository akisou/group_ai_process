#!/usr/bin/env bash
set -e

# ── 启动脚本：daemontools 托管，exec 启动服务 ──────────────────────
# 显式 cd 到部署目录（daemontools run 文件的工作目录可能不是 targetDir）
cd /opt/meituan/account_agent_dev

# 加载 .env 文件（敏感配置：SUPABASE_SERVICE_KEY / TALOS_PASSWORD 等）
# .env 不进 git，部署时手动放或挂载到 targetDir
if [ -f .env ]; then
    set -o allexport
    source .env
    set +o allexport
fi

# 调试：启动失败时把错误打到标准输出（daemontools 会收集到部署日志）
exec venv/bin/python -u main.py 2>&1
