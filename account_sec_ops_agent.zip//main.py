"""
account_agent_dev 服务入口。
lifespan 只初始化 SSO token 管理器，无 supabase / scheduler。
"""
from __future__ import annotations

import os
from contextlib import asynccontextmanager

from fastapi import FastAPI, Request
from fastapi.responses import FileResponse, RedirectResponse
from fastapi.staticfiles import StaticFiles
from starlette.middleware.sessions import SessionMiddleware
from urllib.parse import quote

from api.routes import router
from client.sso_auth import SSOTokenManager, init_sso_manager
from config import get_config
from logger import sys_log


@asynccontextmanager
async def lifespan(app: FastAPI):
    cfg = get_config()
    try:
        sso = SSOTokenManager(
            rhino_ai_base=cfg.sso.rhino_ai_base,
            fallback_mis=cfg.sso.mis,
        )
        init_sso_manager(sso)

        # Lion 配置中心初始化（部署时 lion-agent 注入；本地无 agent 静默降级）
        try:
            from config import init_lion
            init_lion()
        except Exception as e:
            print(f"[WARN] init_lion failed (non-fatal): {e}", flush=True)

        # 画布 job 调度器（对标反爬 poll_ci_jobs，laoquan 提纯捞全任务）
        scheduler = None
        if cfg.canvas_scheduler.enabled:
            from canvas_scheduler import CanvasScheduler
            scheduler = CanvasScheduler()
            scheduler.start()
            app.state.canvas_scheduler = scheduler

        # CASE 预处理任务调度器（独立，与 laoquan 隔离，sceneKey=accountsec_agent_preprocess）
        pp_scheduler = None
        if cfg.canvas_scheduler.enabled:
            from preprocess_scheduler import PreprocessScheduler
            pp_scheduler = PreprocessScheduler()
            pp_scheduler.start()
            app.state.preprocess_scheduler = pp_scheduler

        # 全流程串联调度器（编排 预处理→snapshot→提纯捞全→完成）
        flow_scheduler = None
        if cfg.canvas_scheduler.enabled:
            from flow_scheduler import FlowScheduler
            flow_scheduler = FlowScheduler()
            flow_scheduler.start()
            app.state.flow_scheduler = flow_scheduler

        # 误伤评估调度器（Step6，sceneKey=accountsec_agent_group_evaluation）
        ie_scheduler = None
        if cfg.canvas_scheduler.enabled:
            from injury_eval_scheduler import InjuryEvalScheduler
            ie_scheduler = InjuryEvalScheduler()
            ie_scheduler.start()
            app.state.injury_eval_scheduler = ie_scheduler

        # 团伙处置调度器（Step7，sceneKey=accountsec_agent_group_punish_check）
        pc_scheduler = None
        if cfg.canvas_scheduler.enabled:
            from punish_check_scheduler import PunishCheckScheduler
            pc_scheduler = PunishCheckScheduler()
            pc_scheduler.start()
            app.state.punish_check_scheduler = pc_scheduler

        # 风险事件排查流水线调度器（dify 工作流编排：团伙判定→四环节风险→处罚→提纯捞全）
        pipe_scheduler = None
        if cfg.pipeline.enabled:
            from pipeline_scheduler import PipelineScheduler
            pipe_scheduler = PipelineScheduler()
            pipe_scheduler.start()
            app.state.pipeline_scheduler = pipe_scheduler

        sys_log("info", f"[startup] account_agent_dev 启动，监听 {cfg.app.host}:{cfg.app.port}")

        # result_cache 定时增量同步（3 分钟/轮）：捞全完成但缺缓存的 case 补同步
        try:
            import result_cache as _rc
            _rc.start_incremental_sync()
        except Exception as _e:
            print(f"[WARN] incremental sync start failed (non-fatal): {_e}", flush=True)

        # Supabase 建表（幂等）：canvas_jobs（laoquan）+ result_cache + preprocess_jobs
        try:
            import canvas_job_store
            canvas_job_store.ensure_schema()
        except Exception as schema_err:
            print(f"[WARN] canvas_job_store ensure_schema failed (non-fatal): {schema_err}", flush=True)
        try:
            import preprocess_store
            preprocess_store.ensure_schema()
        except Exception as schema_err:
            print(f"[WARN] preprocess_store ensure_schema failed (non-fatal): {schema_err}", flush=True)
        try:
            import flow_store
            flow_store.ensure_schema()
        except Exception as schema_err:
            print(f"[WARN] flow_store ensure_schema failed (non-fatal): {schema_err}", flush=True)
        try:
            import injury_eval_store
            injury_eval_store.ensure_schema()
        except Exception as schema_err:
            print(f"[WARN] injury_eval_store ensure_schema failed (non-fatal): {schema_err}", flush=True)
        try:
            import punish_check_store
            punish_check_store.ensure_schema()
        except Exception as schema_err:
            print(f"[WARN] punish_check_store ensure_schema failed (non-fatal): {schema_err}", flush=True)
        try:
            import pipeline_store
            pipeline_store.ensure_schema()
        except Exception as schema_err:
            print(f"[WARN] punish_check_store ensure_schema failed (non-fatal): {schema_err}", flush=True)
    except Exception as e:
        # lifespan 异常必须打到标准输出，否则 uvicorn 静默退出无法排查
        import traceback
        print(f"[FATAL] lifespan startup error: {e}", flush=True)
        traceback.print_exc()
        raise

    yield
    try:
        if app.state.canvas_scheduler is not None:
            app.state.canvas_scheduler.shutdown()
    except Exception:
        pass
    try:
        if getattr(app.state, "preprocess_scheduler", None) is not None:
            app.state.preprocess_scheduler.shutdown()
    except Exception:
        pass
    try:
        if getattr(app.state, "flow_scheduler", None) is not None:
            app.state.flow_scheduler.shutdown()
    except Exception:
        pass
    try:
        if getattr(app.state, "injury_eval_scheduler", None) is not None:
            app.state.injury_eval_scheduler.shutdown()
    except Exception:
        pass
    try:
        if getattr(app.state, "punish_check_scheduler", None) is not None:
            app.state.punish_check_scheduler.shutdown()
    except Exception:
        pass
    try:
        if getattr(app.state, "pipeline_scheduler", None) is not None:
            app.state.pipeline_scheduler.shutdown()
    except Exception:
        pass
    sys_log("info", "[shutdown] account_agent_dev 退出")


app = FastAPI(title="account_agent_dev", lifespan=lifespan)


# API 守卫：未登录的 /api/* 返回 401（/api/auth/* 放行；静态资源和 /login 不在此列）
# 纯 ASGI 中间件。add_middleware 后注册的在更外层——本守卫必须先注册（内层），
# 这样请求流经它时 SessionMiddleware（外层）已解析出 scope["session"]
class APIAuthGuard:
    def __init__(self, app):
        self.app = app

    async def __call__(self, scope, receive, send):
        if scope["type"] == "http":
            path = scope.get("path", "")
            if path.startswith("/api") and not path.startswith("/api/auth"):
                session = scope.get("session") or {}
                if not session.get("mis"):
                    from starlette.responses import JSONResponse
                    resp = JSONResponse({"detail": "未登录"}, status_code=401)
                    await resp(scope, receive, send)
                    return
        await self.app(scope, receive, send)


app.add_middleware(APIAuthGuard)

# Session 中间件（签名 Cookie）。token 缓存 25h、session 30 天，一次授权长期有效
app.add_middleware(
    SessionMiddleware,
    secret_key=get_config().sso.session_secret_key,
    max_age=86400 * 30,
    https_only=False,   # 线上部署改为 True
    same_site="lax",
)

app.include_router(router)
class _NoCacheStaticFiles(StaticFiles):
    """静态文件 + Cache-Control: no-cache（2026-10-12）：index.html 迭代频繁，
    ETag 协商缓存下浏览器普通刷新仍可能展示旧 JS——强制每次回源校验，
    改版必然生效（资源小，代价可忽略）。"""
    def file_response(self, *args, **kwargs):
        resp = super().file_response(*args, **kwargs)
        resp.headers["Cache-Control"] = "no-cache"
        return resp


app.mount("/static", _NoCacheStaticFiles(directory="static"), name="static")


def _login_redirect(request: Request) -> RedirectResponse:
    """未登录时跳转 /login，带原始路径 next 参数，登录后原路返回。"""
    next_path = request.url.path
    if request.url.query:
        next_path += "?" + request.url.query
    return RedirectResponse(f"/login?next={quote(next_path, safe='')}")


@app.get("/login")
def login_page():
    return FileResponse("static/login.html")


@app.get("/monitor/alive")
def alive():
    return "ok"


if __name__ == "__main__":
    import uvicorn
    cfg = get_config()
    print(f"[main] starting uvicorn on {cfg.app.host}:{cfg.app.port}", flush=True)
    uvicorn.run(app, host=cfg.app.host, port=cfg.app.port, log_level="info")
