"""
分析结果缓存层（Supabase）。
把 Hive 查询结果按 cache_key 整体存 JSONB，界面改读 PG（毫秒级），miss 回退 Hive。

写入由 canvas_scheduler 画布完成后触发（sync_case_results）；读由 api/routes 的 _cached 回退填。
"""
from __future__ import annotations

import time
from datetime import datetime
from typing import Callable, Optional

import sql_templates as Q
from logger import sys_log

_SCHEMA = """
CREATE TABLE IF NOT EXISTS result_cache (
  cache_key  TEXT PRIMARY KEY,
  table_key  TEXT NOT NULL,
  case_id    TEXT NOT NULL,
  experiment TEXT,
  dt         TEXT,
  columns    JSONB NOT NULL,
  rows       JSONB NOT NULL,
  row_count  INTEGER,
  synced_at  TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_rc_case ON result_cache(case_id, experiment, dt);
"""


def _sb():
    from canvas_job_store import _sb as sb
    return sb()


def _escape(v) -> str:
    from client.supabase_client import SupabaseClient
    return SupabaseClient._escape(v)


def _now() -> str:
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")


def ensure_schema():
    try:
        _sb().execute(_SCHEMA)
        sys_log("info", "[ResultCache] schema ensured (result_cache table)")
    except Exception as e:
        sys_log("error", f"[ResultCache] ensure_schema failed: {str(e)[:200]}")


def make_key(table_key: str, case_id: str, experiment: Optional[str], dt: str,
             params: str = "") -> str:
    exp = experiment or "_NONE_"
    base = f"{table_key}:{case_id}:{exp}:{dt}"
    return f"{base}:{params}" if params else base


def get(cache_key: str) -> Optional[dict]:
    """命中返回 {columns, rows}，否则 None。"""
    rows = _sb().execute(
        "SELECT columns, rows FROM result_cache WHERE cache_key=$1", [cache_key]
    )
    if not rows:
        return None
    r = rows[0]
    return {"columns": r.get("columns"), "rows": r.get("rows")}


def upsert(cache_key: str, table_key: str, case_id: str, experiment: Optional[str],
           dt: str, columns: list, rows: list) -> None:
    """整结果集 upsert（ON CONFLICT 覆盖，重跑画布自动刷新）。"""
    sql = (
        "INSERT INTO result_cache (cache_key, table_key, case_id, experiment, dt, "
        "columns, rows, row_count, synced_at) "
        f"VALUES ({_escape(cache_key)}, {_escape(table_key)}, {_escape(case_id)}, "
        f"{_escape(experiment)}, {_escape(dt)}, {_escape(columns)}::jsonb, "
        f"{_escape(rows)}::jsonb, {len(rows)}, {_escape(_now())}) "
        "ON CONFLICT (cache_key) DO UPDATE SET "
        "columns=EXCLUDED.columns, rows=EXCLUDED.rows, row_count=EXCLUDED.row_count, "
        "synced_at=EXCLUDED.synced_at"
    )
    _sb().execute(sql)


def invalidate(cache_keys: list) -> int:
    """删除指定 cache_key 的缓存（画布同步后让列表/元数据下次重查，保证新数据可见）。"""
    n = 0
    for k in cache_keys:
        try:
            _sb().execute("DELETE FROM result_cache WHERE cache_key=$1", [k])
            n += 1
        except Exception:
            pass
    return n


# ── Hive 同步执行（不 import routes 防循环，等价于 routes._run_hive_sync）─────────
def _run_hive(tc, sql: str, max_wait_s: int = 120, interval_s: float = 2.0) -> dict:
    try:
        qid = tc.submit_query(sql)
    except Exception as e:
        return {"qid": "", "status": "failed", "error": str(e)[:300], "columns": [], "rows": []}
    deadline = time.time() + max_wait_s
    while time.time() < deadline:
        try:
            r = tc.get_query_status(qid)
        except Exception as e:
            return {"qid": qid, "status": "failed", "error": str(e)[:300], "columns": [], "rows": []}
        if r["status"] != "pending":
            return {"qid": qid, **r}
        time.sleep(interval_s)
    return {"qid": qid, "status": "pending", "columns": [], "rows": [], "error": None}


# ── 预缓存端点：(table_key, sql_fn(cfg, exp, dt), 用experiment, params)──────────
# params 必须与 api/routes 读时构造的 cache_key params 一致，否则预缓存命中不了。
# 带参明细端点（validation/combo、charts/svg、recall/accounts by rank）靠读时 miss 回填。
_PRECACHE: list[tuple[str, Callable, bool, str]] = [
    ("validation_result",    lambda c, cid, e, d: Q.validation_result_sql(c, cid, e, d),        True, ""),
    ("candidate_predicates", lambda c, cid, e, d: Q.candidate_predicates_sql(c, cid, e, d, 500), True, "limit=500"),
    ("mining_process",       lambda c, cid, e, d: Q.mining_process_sql(c, cid, e, d),           True, ""),
    ("validation_charts",    lambda c, cid, e, d: Q.charts_list_sql(c, cid, e, d),              True, ""),
    ("recall_summary",       lambda c, cid, e, d: Q.recall_summary_sql(c, cid, e, d),           True, ""),
    ("recall_multi",         lambda c, cid, e, d: Q.recall_multi_hit_sql(c, cid, e, d),         True, ""),
    ("recall_accounts",      lambda c, cid, e, d: Q.recall_accounts_sql(c, cid, e, d, None, 500), True, "rank=None|limit=500"),
    ("case_info",            lambda c, cid, e, d: Q.case_info_sql(c, cid, d),                   False, ""),
    ("seed_split",           lambda c, cid, e, d: Q.seed_split_sql(c, cid, d),                  False, ""),
    ("snapshot_info",        lambda c, cid, e, d: Q.snapshot_info_sql(c, cid, d),              False, ""),
]


def sync_case_results(case_id: str, experiment: str, dt: str, _retry_depth: int = 0) -> dict:
    """画布完成后同步该 case+dt 的主切片到 result_cache。幂等可重试。

    先查真实 experiment（job.experiment 可能不准），再同步所有预缓存端点。
    返回 {synced, empty, failed} 统计。
    _retry_depth 为内部参数（空表延迟重试的递归深度，防无限自旋）。
    """
    from config import get_config
    from client.talos_client import TalosClient
    cfg = get_config()
    tc = TalosClient()

    # 对齐真实 experiment：优先 latest_experiment 查到的值，job.experiment 兜底
    real_exp = experiment
    exp_res = _run_hive(tc, Q.latest_experiment_sql(cfg, case_id), max_wait_s=30)
    if exp_res["status"] == "done" and exp_res.get("rows"):
        row0 = exp_res["rows"][0]
        v = str((row0[0] if row0 else "") or "").strip()
        if v:
            real_exp = v

    synced, empty, failed = [], [], []
    for table_key, sql_fn, use_exp, params in _PRECACHE:
        sql = sql_fn(cfg, case_id, real_exp, dt)
        res = _run_hive(tc, sql)
        if res["status"] != "done":
            failed.append(table_key)
            err = str(res.get("error") or "")[:120]
            sys_log("warning", f"[ResultCache] sync fail table={table_key} case={case_id} err={err}")
            continue
        if not res["rows"]:
            empty.append(table_key)  # 表未落库（如 case_info），读时走 mock，跳过缓存
            continue
        exp_key = real_exp if use_exp else None
        cache_key = make_key(table_key, case_id, exp_key, dt, params)
        try:
            upsert(cache_key, table_key, case_id, exp_key, dt, res["columns"], res["rows"])
            synced.append(table_key)
        except Exception as e:
            failed.append(table_key)
            sys_log("warning", f"[ResultCache] upsert fail table={table_key} case={case_id} err={str(e)[:120]}")

    sys_log("info", f"[ResultCache] sync done case={case_id} exp={real_exp} dt={dt} "
                    f"synced={len(synced)} empty={len(empty)} failed={len(failed)}")

    # 空表延迟重试：画布状态 done ≠ Hive 分区立即可查（写入有秒-分钟级时延），
    # 首 sync 时 empty 的表数据可能马上就到——5 分钟后后台补一次（幂等，仅同步
    # 仍空的表对应键 + 全量覆盖 upsert 均安全）。有数据则补上缓存，用户首开不再 miss。
    # 全空保护：所有表都 empty = 该 dt 分区无本 case 数据（如流水线传入的团伙发现日，
    # 数据实际在处理日分区）——重试 1 次仍全空即终止，防止 5min Timer 无限自旋
    # （2026-09-12 实锤：dt=20260907 空分区每 5 分钟重试一次，循环写坏 latest_dt）。
    _RETRY_MAX = 2
    if empty:
        import threading
        retry_n = [0]

        def _retry():
            try:
                r2 = sync_case_results(case_id, experiment, dt,
                                       _retry_depth=retry_n[0] + 1)
                sys_log("info", f"[ResultCache] sync 重试完成 case={case_id} "
                                f"synced={len(r2['synced'])} empty={len(r2['empty'])} failed={len(r2['failed'])}")
            except Exception as e:
                sys_log("warning", f"[ResultCache] sync 重试失败 case={case_id}: {str(e)[:150]}")

        if _retry_depth < _RETRY_MAX:
            retry_n[0] = _retry_depth
            threading.Timer(300.0, _retry).start()
        elif _retry_depth == _RETRY_MAX:
            sys_log("info", f"[ResultCache] sync 终止重试 case={case_id} dt={dt}（连续全空，"
                            f"该分区无数据——流水线传入的可能不是数据分区日）")

    # 刷新该 case 的元数据缓存，保证画布新数据对界面可见：
    # latest_dt 取 max(本次同步 dt, 现缓存值)——流水线路径传入的 dt 是团伙发现日
    # （处理日与发现日不同），直接覆盖会把更新的分区时间倒拨回过去（2026-09-12 实锤：
    # 20260912 的分区被 20260907 的 job dt 覆盖，详情页 case_info 查空表回退 mock）。
    # 列表/experiment 缓存失效，下次访问重查。
    try:
        key = make_key("latest_dt", case_id, None, "_")
        prev = get(key)
        prev_dt = str((prev or {}).get("rows", [[None]])[0][0] or "")
        max_dt = max(dt, prev_dt) if prev_dt else dt
        upsert(key, "latest_dt", case_id, None, "_", ["dt"], [[max_dt]])
    except Exception:
        pass
    invalidate([
        make_key("latest_experiment", case_id, None, "_"),
        make_key("case_overview", "_ALL_", None, "_ALL_"),
        make_key("cases", "_ALL_", None, "_ALL_"),
        make_key("case_overview", "_ALL_", None, max_dt),
        # 日期分布缓存也失效：新 case 落表后总览的 dt 选项卡需含新日期（2026-09-15 实锤：
        # 昨天建的 20 个 case 的日期没出现在选项卡——分布缓存陈旧）
        make_key("case_dt_distrib", "_ALL_", None, "_"),
    ])
    # 预热当天总览：重查 case_list_sql(dt) 并落缓存——用户打开 CASE 总览（默认当天）
    # 大概率命中，不用现场等 Hive。仅当本次 sync 实际写入了数据才做（幂等，多 case 并发
    # 时重复 upsert 安全且廉价）。
    if synced:
        try:
            res = _run_hive(tc, Q.case_list_sql(cfg, max_dt), max_wait_s=60)
            if res.get("status") == "done" and res.get("rows") is not None:
                upsert(make_key("case_overview", "_ALL_", None, max_dt), "case_overview",
                       "_ALL_", None, max_dt, res["columns"], res["rows"])
        except Exception:
            pass
    return {"synced": synced, "empty": empty, "failed": failed, "experiment": real_exp}


# ── 定时增量同步（2026-09-20 用户定，3 分钟一轮）─────────────────────────
# 捞全完成但 result_cache 缺主键（validation_result）的 case → 补同步。
# 幂等：已有键的 case 跳过；预热失败 / PG 500 期间丢写的自动补上。
# 单轮上限防积压压爆（超的下轮继续）。复用 case_prefetch 的 worker 池限并发。

_sync_sched = None


def start_incremental_sync():
    """启动 3 分钟定时增量同步（服务启动时调）。"""
    global _sync_sched
    if _sync_sched is not None:
        return
    from apscheduler.schedulers.background import BackgroundScheduler
    _sync_sched = BackgroundScheduler(timezone="Asia/Shanghai")
    _sync_sched.add_job(_incremental_sync_round, "interval", seconds=180,
                        id="result_cache_incremental", max_instances=1, coalesce=True,
                        misfire_grace_time=60)
    _sync_sched.start()
    sys_log("info", "[ResultCache] 定时增量同步已启动（3 分钟/轮，单轮上限 10 case）")


def stop_incremental_sync():
    global _sync_sched
    if _sync_sched is not None:
        _sync_sched.shutdown(wait=False)
        _sync_sched = None
        sys_log("info", "[ResultCache] 定时增量同步停止")


def _incremental_sync_round():
    """一轮增量：找缺缓存的 case → 提交到预热池补同步。"""
    try:
        # 捞全完成（injury_eval 及之后）且无 validation_result 缓存键的 case
        rows = _sb().execute(
            "SELECT case_id, dt FROM flow_jobs WHERE stage IN ('injury_eval','punish') "
            "AND status='running' AND dt >= '20260915' "
            "ORDER BY updated_at DESC LIMIT 30")
        missing = []
        for r in rows:
            cid, dt = r["case_id"], r.get("dt") or ""
            key = make_key("validation_result", cid, "default", dt)
            key2 = make_key("validation_result", cid, "no_mark", dt)
            try:
                if not get(key) and not get(key2):
                    missing.append((cid, dt))
            except Exception:
                continue
            if len(missing) >= 10:   # 单轮上限
                break
        if not missing:
            return
        import case_prefetch
        for cid, dt in missing:
            case_prefetch.warm_case(cid, "default", dt)
        sys_log("info", f"[ResultCache] 增量同步本轮提交 {len(missing)} 个 case："
                        f"{[c for c, _ in missing][:5]}{'...' if len(missing) > 5 else ''}")
    except Exception as e:
        sys_log("warning", f"[ResultCache] 增量同步异常: {str(e)[:150]}")
